# AI Safety Course - Phase 2 Design Package

*Created 2026-06-27. Status: Phase 2 draft built from `57_AI_Safety_Course_Claim_Register.md`, after the Breaker pass in `60_AI_Safety_Course_G1_Breaker_Findings.md`. This supersedes `55_AI_Readiness_Lab_Complete_Course_Pack.md` for the safety-course track only. It is not canonical or sellable until human legal/safeguarding review clears the flagged rows and fast-moving re-checks.*

## Operating Boundary

This package is for the Bearings AI-safety offer, not the capability/learning product. It teaches parents how to set household boundaries, keep private information out of AI tools, check before trusting or acting, recognise safety-relevant patterns, and route live concerns to qualified services. It does not teach children to use AI better, build projects, produce better prompts, or gain academic advantage. Those belong to a separate capability product. [HAW-005, GAP-009]

Parent is the sole learner and user. There are no child accounts, no child-facing flows, no child PII, no uploads of child content, no live-incident triage, and no AI judgement of real messages or images. [PRI-003, PRI-004, VBT-004, GRM-002, GAP-013]

## A. Positioning And Offer

### Working Name

**Bearings AI Safety Course for Families**

If the name **AI Readiness Lab** is retained, the launch copy should make the safety membrane explicit: this is readiness for protection, boundaries, checking, and routing, not AI proficiency. [HAW-005, GAP-009]

### One-Sentence Promise

A calm parent-led course that helps families set practical AI rules, keep private things private, check confident outputs before trust or action, and know when to route concerns to school, police, or child-safety services. [PRI-002, VBT-001, RTE-007]

### What A Parent Can Do Afterwards

After the course, a parent should be able to:

- Explain the four safety facts in plain English: plausible does not mean true; AI is a tool, not a person; convincing images or voices still need source checks; private inputs can create data exposure. [HAW-001, HAW-002, HAW-003, HAW-004]
- Set age-adjusted household rules for AI use without turning the topic into a panic lecture. [SMI-005, AIC-004, PRI-005, GRM-003]
- Use a "private stays private" rule for prompts, uploads, images, voices, messages, schoolwork, location, family detail, and live incidents. [PRI-001, PRI-002]
- Use a verify-before-trust routine before believing, sharing, buying, submitting, or acting on AI output. [VBT-001, VBT-002, VBT-003]
- Name warning patterns that should move to a trusted adult or service, without diagnosing the child or giving live-incident advice. [AIC-003, AIC-005, ORW-004, HCM-003]
- Use signpost-only routing for online sexual abuse, under-18 nude-image concerns, fraud, immediate danger, school-linked concerns, and child/adult support. [RTE-001, RTE-002, RTE-003, RTE-004, RTE-005, RTE-006, RTE-007]

### What They Leave With

- Family AI Safety Agreement.
- Private Stays Private card.
- Tool, Not Person boundary script.
- Verify Before Trust check sheet.
- Schoolwork Ask-First rule sheet.
- Synthetic-media and image-risk rules card.
- Contact, pressure, and scams pause card.
- Incident-routing card.
- Age-by-age rule sheet.

### Why Buy This Over Free Official Guidance Or Asking A Chatbot?

Free official guidance is valuable but scattered across education, data protection, online safety, police, and child-safety routes. This course turns the Claim Register into a parent-ready sequence, scripts, printables, and household decisions, while preserving the limits: it frames, it does not adjudicate; it routes live concerns, it does not advise through them; and it avoids child data collection. [RTE-007, RTE-008, PRI-003, PRI-004]

A chatbot can sound fluent while being wrong, incomplete, or overconfident, and it may invite families to describe real situations or private information. This course uses authored content, deterministic assets, and signpost-only routing rather than live AI judgement. [HCM-001, VBT-004, PRI-001, GAP-013]

### Buyer State By Module

| Module | Buyer state it addresses |
|---|---|
| 1. The AI Safety Map | "I do not know what I need to understand before setting rules." |
| 2. Private Stays Private | "I am worried my child will put the wrong things into AI tools." |
| 3. Tool, Not Person | "I am uneasy about companion apps, emotional dependence, or secretive AI use." |
| 4. Verify Before Trust | "I worry my child will believe, share, buy, or submit something false." |
| 5. Schoolwork Boundaries | "I do not know what to allow around homework and assessed work." |
| 6. Synthetic Media, Consent, And Image Risk | "I am frightened by deepfakes and image abuse, but I do not want a scare session." |
| 7. Contact, Pressure, Scams, And Routing | "I want to know what to watch for and where to go if something has already happened." |

## B. Course Architecture

### Recommended Build Shape

Seven recorded core modules, each 20-35 minutes, plus a printable asset pack. The modules can also be grouped into four live sessions:

| Live session | Recorded modules |
|---|---|
| Session 1: Rules Before Tools | 1. The AI Safety Map; 2. Private Stays Private |
| Session 2: Trust And People | 3. Tool, Not Person; 4. Verify Before Trust |
| Session 3: Schoolwork And Synthetic Media | 5. Schoolwork Boundaries; 6. Synthetic Media, Consent, And Image Risk |
| Session 4: Pressure, Routing, And The Household Agreement | 7. Contact, Pressure, Scams, And Routing; final agreement walk-through |

### Sequence Rationale

The foundation module comes first because parents need a simple explanation of why AI outputs need human checks, why tools should not be treated as people, why generated media needs source/context checks, and why private information should stay out of prompts. [HAW-001, HAW-002, HAW-003, HAW-004]

The next modules turn those facts into the four household habits: think before use; tool, not person; private stays private; human check before trust or action. [ORW-001, ORW-002, PRI-002, VBT-001]

Threat modules come after the habits so parents meet synthetic media, companion tools, scams, contact pressure, and harmful content through prevention and routing, not panic. [SMI-004, AIC-001, SCF-001, GRM-001, HCM-003]

Routing comes last and appears throughout: if it is already happening, the course stops and points to the correct service. [RTE-001, RTE-002, RTE-003, RTE-004, RTE-005, RTE-006, RTE-007]

### Module Outcomes, Age Adaptations, And Core/Add-On Status

| Module | Learning outcomes | Age-band adaptation | Core or add-on |
|---|---|---|---|
| 1. The AI Safety Map | Parent can explain plausible-not-true, tool-not-person, generated-media checks, and private-input risk. [HAW-001, HAW-002, HAW-003, HAW-004] | 9-11: concrete examples and co-use. 12-14: group-chat and homework examples. 15-17: independence with explicit review points. [SMI-005, PRI-005] | Core |
| 2. Private Stays Private | Parent can name what counts as private information and set a default no-private-data rule. [PRI-001, PRI-002] | 9-11: parent chooses and sits in. 12-14: co-set ask-first categories. 15-17: consent, accountability, and tool-setting checks. [PRI-005] | Core |
| 3. Tool, Not Person | Parent can distinguish utility AI from companion-style use and use watchpoints as conversation prompts, not diagnosis. [AIC-001, AIC-003, ORW-004] | 9-11: avoid open-ended companion chat. 12-14: boundaries around secrecy and late-night use. 15-17: privacy, wellbeing, and trusted-person routes. [AIC-004] | Core |
| 4. Verify Before Trust | Parent can teach source, date, evidence, and consequence checks without presenting checklists as verdicts. [VBT-001, HCM-004, GAP-007] | 9-11: ask an adult before sharing. 12-14: check links, claims, and messages. 15-17: inspect primary sources before submitting or acting. [VBT-002] | Core |
| 5. Schoolwork Boundaries | Parent can set "school policy first", "try first", and "ask before assessed work" rules. [ORW-001, ORW-003, VBT-002] | 9-11: practice only with parent-set examples. 12-14: homework support versus hidden authorship. 15-17: coursework, assessments, acknowledgements, and school policy. [ORW-003, GAP-010] | Core |
| 6. Synthetic Media, Consent, And Image Risk | Parent can explain consent, harm, source checks, legal seriousness, and the no-save/no-forward rule without teaching mechanisms. [SMI-001, SMI-002, SMI-003, SMI-004, GAP-015] | 9-11: simple fake-media and tell-a-grown-up rules. 12-14: peer pressure, jokes, group chats. 15-17: coercion, consent, legal seriousness, and future-sharing consequences. [SMI-005] | Core |
| 7. Contact, Pressure, Scams, And Routing | Parent can identify route-now patterns, avoid AI verdicts, and use the incident-routing card. [GRM-001, GRM-002, GRM-004, SCF-001, RTE-007] | 9-11: unknown person plus secrecy means show an adult. 12-14: peer pressure, gifts, platform switching. 15-17: coercion, blackmail, money, and image threats. [GRM-003, SCF-003] | Core |
| Stay Current briefing | Parent gets checked updates on legal, platform, policy, or route changes. [RTE-008, GAP-014, GAP-016] | All age bands: updates tagged by age relevance. | Paid recurring add-on only |

## C. Module Content Map

### Module 1: The AI Safety Map

**Safety point:** AI can generate plausible content that is not necessarily true; it is a tool, not a person; generated media needs source/context checks; private inputs can create data exposure. [HAW-001, HAW-002, HAW-003, HAW-004]

**Plain-English explanation:** The parent does not need a technical explainer. They need four load-bearing facts that justify the household rules: fluent output still needs checking; relationship-like language is not care; convincing images and voices are easy to fake; and private inputs should be treated carefully.

**Scenario examples:** A child shows a confident AI answer for homework. A family member receives a convincing voice note asking for help.

**Parent action:** Create the four-rule baseline: think before use; tool, not person; private stays private; human check before trust or action. [ORW-001, ORW-002, PRI-002, VBT-001]

**Take-home asset:** Four Habits card.

### Module 2: Private Stays Private

**Safety point:** Personal or private information can be exposed through prompts, uploads, images, audio, and account settings. [PRI-001, PRI-002]

**Plain-English explanation:** Private information is broader than a name. It includes school, location, routines, account details, health, family conflict, private images, voice, private messages, schoolwork, and live-incident details. [PRI-002]

**Scenario examples:** A child wants to paste a friendship problem into a chatbot. A teen wants to upload a school essay that includes personal details.

**Parent action:** Set "never enter" and "ask first" categories. No course tool asks for child content, child accounts, uploads, screenshots, or live incidents. [PRI-003, PRI-004, GAP-013]

**Take-home asset:** Private Stays Private card.

### Module 3: Tool, Not Person

**Safety point:** Companion and character-chatbot use needs different boundaries from utility AI because relationship-like design can encourage attachment, secrecy, or excessive trust. [AIC-001, AIC-002]

**Plain-English explanation:** The family rule is not "no AI ever"; it is "AI is not a private friend, therapist, judge, or secret-keeper." Watchpoints are prompts for a parent conversation, not a diagnosis or score. [AIC-003, ORW-004]

**Scenario examples:** A child says an AI character "understands me better than people." A teen uses a chatbot late at night and becomes secretive about it.

**Parent action:** Set time, place, topic, and secrecy boundaries. Route emotional or safeguarding concerns to trusted people or qualified services. [AIC-005, RTE-004, RTE-006]

**Take-home asset:** Tool, Not Person boundary script.

### Module 4: Verify Before Trust

**Safety point:** Confident AI output can be wrong, fabricated, out of date, biased, or misleading, so verification is an anti-deception habit. [HCM-001, VBT-001, VBT-002, VBT-003]

**Plain-English explanation:** Verification is not a way to make AI "better"; it is a pause before believing, sharing, buying, submitting, or acting. Checklists support a decision about what to check or route, never a verdict that something is safe. [VBT-001, HCM-004, GAP-007]

**Scenario examples:** AI gives a source that looks real. A giveaway message asks a child to act quickly. A video or image claims something shocking happened.

**Parent action:** Use the four checks: who says this, what evidence, how current, what happens if wrong? For money or urgent requests, verify through a separate route. [SCF-001, SCF-002]

**Take-home asset:** Verify Before Trust check sheet.

### Module 5: Schoolwork Boundaries

**Safety point:** School policy and assessment rules come first; AI-assisted final work can become a problem if presented as the student's own work. [ORW-003, GAP-010]

**Plain-English explanation:** This is not an AI productivity module. The household rule is: try first, ask before assessed work, check sources, and do not submit hidden AI-authored work as your own. [ORW-001, VBT-002]

**Scenario examples:** A child asks AI to write a paragraph. A teen asks AI to rewrite coursework in adult language. A child asks AI to quiz them after they have tried a topic.

**Parent action:** Use a schoolwork ladder: no AI where the school says no; ask first for assessed or unclear work; practice uses are only for learning and still need human checking. [ORW-003, VBT-002]

**Take-home asset:** Schoolwork Ask-First rule sheet.

### Module 6: Synthetic Media, Consent, And Image Risk

**Safety point:** Synthetic or altered media can be convincing, and nude or sexual images involving under-18s are legally and safeguarding serious; parents must not save, screenshot, copy, download, forward, or ask a child to resend suspected nude or sexual images of under-18s. [SMI-001, SMI-002, SMI-003, SMI-006, GAP-015]

**Plain-English explanation:** The course teaches recognition, consent, harm, source checks, legal seriousness, prevention, and routing. It never teaches mechanisms, tools, prompt patterns, or how-to detail. [SMI-004]

**Scenario examples:** A fake image is mentioned in a group chat. A voice note sounds like someone familiar. A classmate says an altered image was "just a joke."

**Parent action:** Use the no-save/no-forward rule, reassure rather than blame, and route to the correct service if it has already happened. [SMI-006, RTE-002, RTE-003, RTE-007]

**Take-home asset:** Synthetic Media Rules card plus What Not To Say card.

### Module 7: Contact, Pressure, Scams, And Routing

**Safety point:** AI can make impersonation, scripts, or fake profiles more convincing, but the course must not judge whether a real message is grooming, a scam, or safe. [GRM-001, GRM-002, SCF-001, GAP-007]

**Plain-English explanation:** Parents learn route-now patterns: secrecy, pressure, gifts, platform switching, sexualised contact, blackmail, urgent money requests, account codes, and threats. The course uses authored scenarios only and never asks for real messages, images, or incident detail. [GRM-001, GRM-004, SCF-003, VBT-004, GAP-013]

**Scenario examples:** Someone asks a child to move to a different app. A friend-looking account asks for a code. A child is pressured not to tell an adult.

**Parent action:** Use the routing card: 999/101 for police urgency, CEOP for online sexual abuse/grooming, Report Remove for eligible under-18 nude-image removal, Childline/NSPCC for support, Report Fraud for fraud in England/Wales/Northern Ireland, Police Scotland 101 in Scotland, and school DSL for school-linked concerns. [RTE-001, RTE-002, RTE-003, RTE-004, RTE-005, RTE-006, RTE-007]

**Take-home asset:** Incident-routing card and household escalation rule.

## D. Asset Pack

| Asset | Purpose | One-line content spec | Claim IDs |
|---|---|---|---|
| Family AI Safety Agreement | Turns the course into household rules. | Allowed uses, ask-first uses, never-enter data, human-check moments, stop-and-route moments. | PRI-002, VBT-001, AIC-005, RTE-007 |
| Four Habits card | Gives parents the repeated course spine. | Think before use; tool, not person; private stays private; human check before trust or action. | HAW-001, HAW-002, PRI-002, VBT-001 |
| Private Stays Private card | Makes privacy concrete. | Names, school, location, routines, account details, private images, voice, messages, health, family conflict, schoolwork, live incidents. | PRI-001, PRI-002 |
| Tool, Not Person script | Sets companion/chatbot boundaries. | AI is not a friend, therapist, judge, or secret-keeper; emotional worries go to trusted people. | AIC-001, AIC-002, AIC-003, HAW-002 |
| Verify Before Trust check sheet | Creates an anti-deception habit. | Who says this, what evidence, how current, what happens if wrong; never a safety verdict. | VBT-001, VBT-002, HCM-004 |
| Schoolwork Ask-First sheet | Keeps school policy and assessment rules first. | Try first, ask before assessed work, check sources, do not submit hidden AI-authored work as your own. | ORW-001, ORW-003, VBT-002 |
| Synthetic-media rules card | Covers recognition, consent, and routing without mechanism. | Pause before forwarding; no tool how-to; no save/screenshot/copy/download/forward for suspected under-18 sexual images. | SMI-001, SMI-002, SMI-004, SMI-006 |
| What Not To Say card | Supports calm disclosure response. | Avoid blame, panic, punishment-first responses, requests to resend material, or amateur investigation. | SMI-006, GRM-004, RTE-007, GAP-015 |
| Contact and scams pause card | Helps families stop urgent pressure loops. | Unknown person plus secrecy/pressure means show an adult; verify urgent money/code requests separately. | GRM-001, SCF-001, SCF-002, SCF-003 |
| Incident-routing card | Keeps live incidents out of the course. | Signpost-only routes by harm type, with pre-launch re-check required. | RTE-001, RTE-002, RTE-003, RTE-004, RTE-005, RTE-006, RTE-008 |
| Age-by-age rule sheet | Adapts without claiming measured thresholds. | 9-11 co-use, 12-14 co-set, 15-17 consult, with practical examples only. | SMI-005, AIC-004, PRI-005, GRM-003 |

## E. Delivery Recommendation

### Primary Recommendation

Build a **recorded core course with printable asset pack**, sold as either:

- a paid add-on to The System, or
- a standalone parent safety course that includes the asset pack and routing card.

Why: the audience needs calm, repeatable explanations and printable household assets, not a high-touch advisory service. Recorded delivery lets the course be reviewed, corrected, and updated more reliably than improvised live delivery. It also reduces the risk that a live Q&A drifts into incident advice. [RTE-007, RTE-008, GAP-014]

Recommended package:

- Seven modules, 20-35 minutes each.
- Total core watch time: about 2.5 to 3.5 hours.
- Asset pack delivered as printable PDFs and web pages.
- Final "set this tonight" task after every module.
- Footer on every asset: frames, does not guarantee outcomes; school, law, and platform rules take precedence; live concerns route to official services. [GAP-001, ORW-003, RTE-007]

### Runner-Up

Run a **school/PTA parent evening** as the acquisition and trust format.

Tradeoff: higher trust and easier distribution through schools, but more recurring labour and greater risk of parents asking for live incident advice in the room. The evening should therefore be a taster plus take-home assets, with a firm signpost-only boundary. [RTE-006, RTE-007]

### Pricing Logic

Pricing is a founder/commercial assumption, not validated by the evidence layer. [GAP-012]

Defensible launch ranges:

| Format | Range | Logic |
|---|---:|---|
| Recorded add-on to The System | GBP 49-99 | Low-friction add-on; value is asset pack plus reviewed structure. |
| Standalone recorded course | GBP 79-149 | Parent buys a complete household safety pack, not a generic AI literacy course. |
| Live parent cohort | GBP 149-249 per household | Adds accountability and Q&A, but must keep incident-routing boundary. |
| School/PTA evening | GBP 450-950 per event | Trust and distribution channel; includes school boundary slide and take-home handout. |
| Concierge enhancement | scoped manually | Only for family-specific setup, not live incident advice. |

### First Launch Sequence

1. Complete human legal/safeguarding review of flagged claims and routes.
2. Record Modules 1, 2, 4, 6, and 7 first; these carry the highest buyer anxiety and asset value.
3. Produce printable assets before recording final scripts, so each module ends with a concrete action.
4. Create a 45-minute PTA taster from Modules 1, 2, 6, and 7.
5. Offer recorded course to existing Bearings list and Concierge leads.
6. Use feedback only for clarity, pacing, and usability. Do not claim efficacy from early sales or testimonials. [GAP-001, GAP-012]

### Load-Bearing Assumption

The commercial bet is that parents will pay for curated, calm, UK-oriented, source-traceable household assets and routing boundaries because official guidance is fragmented and chatbot answers are not a trusted safety structure. This is a founder assumption until sales or research validate it. [GAP-012]

## F. Tone And Engagement Spec

### Tone Rules

- Calm, specific, practical, non-alarmist.
- Authority through source traceability and review flags, not fear.
- Scenario-led and decision-led.
- No guarantees, no efficacy claims, no safety-outcome promises, no academic/exam/career promises. [GAP-001, GAP-009]
- No mechanism, tool how-to, tool names as instructions, or explicit sexual content in synthetic-media sections. [SMI-004]
- No real-case free text, uploads, screenshots, or AI verdicts. [PRI-003, VBT-004, GAP-013]
- No diagnosis, score, "at-risk" profile, or child assessment. [AIC-003, ORW-004]

### Engagement Pattern

Every module follows the same rhythm:

1. Name the parent worry in plain language.
2. Teach one safety fact or boundary.
3. Use one non-explicit authored scenario.
4. Make one household decision.
5. Print or complete one asset.
6. Remind parents what routes out of the course if it is already happening.

### Scenario Rules

Scenarios must be:

- pre-written and non-explicit;
- prevention-framed;
- age-band adapted;
- free of real child data;
- free of tool how-to;
- routed immediately if they enter live-incident territory. [SMI-004, PRI-003, VBT-004, RTE-007]

### Language To Prefer

- "The tool generated..."
- "This needs a human check before..."
- "Do not paste or upload private information..."
- "If it has already happened, use the route on the card..."
- "This is a watchpoint for a conversation, not a diagnosis..."

### Language To Avoid

- Any wording that promises a safety outcome.
- Any wording that claims the course stops harm from happening.
- Any wording that claims to identify grooming, scams, or deepfakes.
- Any wording that says a checklist can decide whether something is safe.
- "Screenshot it for evidence" in under-18 image contexts.
- "AI friend", "AI therapist", "the AI understands", "the AI cares."
- Any proficiency promise about improving model output.

## G. Pre-Launch Review List

### Legal Review Required

| Claim IDs | What to review | Source / reason |
|---|---|---|
| SMI-002, SMI-003, SMI-006 | Under-18 sexual/nude image wording, adult-scoped purported-intimate-image law, no-save/no-forward carve-out, and legal-seriousness phrasing. | S16, S19, S20, GAP-003, GAP-015 |
| PRI-001, PRI-002, PRI-003, PRI-004, PRI-005, HAW-004 | Data-protection and child-data wording; make sure design intent is not represented as compliance determination. | S04, S05, 60 Breaker findings |
| HCM-002 | Online Safety Act / Ofcom duties framed as platform responsibility, not course or platform guarantee. | S07, S15 |
| RTE-003, RTE-008 | Report Remove/IWF/CEOP eligibility, now-18+ route, pre-launch route re-check process. | S08, S09, S10, GAP-011, GAP-016 |
| ORW-003, VBT-002 | Schoolwork and assessment wording, especially "own work", acknowledgement, and school policy first. | S03, S01, GAP-010 |

### Safeguarding Review Required

| Claim IDs | What to review | Source / reason |
|---|---|---|
| RTE-001 to RTE-008 | All routing card wording, route scope, and "live incidents terminate the course" boundary. | S08-S14, S18, GAP-011, GAP-016 |
| SMI-002 to SMI-006 | Synthetic-media and image-risk scenarios, no mechanism, no explicit content, no save/screenshot/copy/download/forward rule. | S08, S09, S10, S19, S20, GAP-015 |
| AIC-001 to AIC-005, ORW-004 | Companion/chatbot and emotional-support watchpoints; no diagnosis, score, or child profile. | S02, S11, S17, GAP-004, GAP-005 |
| GRM-001 to GRM-004 | Contact pressure, grooming, coercion, secrecy, and blackmail scenarios; no verdicts on real messages. | S07, S08, S13, GAP-007, GAP-013 |
| HCM-003, HCM-005 | Self-harm, eating-disorder, extremist, sexual, threat, coercion, and emergency thresholds. | S07, S11, S12, S18 |
| SCF-001 to SCF-004, RTE-005 | Scam and fraud examples, Report Fraud / Police Scotland routing, urgent-money verification. | S13, S14, S12 |

### Fast-Moving Pre-Launch Re-Checks

| Claim IDs | Re-check item |
|---|---|
| S02-dependent rows | Exact DfE product-safety title, URL, and status as non-binding product guidance. |
| SMI-002, SMI-003, RTE-003 | Data (Use and Access) Act 2025 adult scope, under-18 image law, Report Remove/IWF/CEOP eligibility. |
| HCM-002, RTE-008 | Ofcom Online Safety Act child-protection duties and codes. |
| RTE-001, RTE-004, RTE-005 | Police, NSPCC, Childline, Report Fraud, and Police Scotland routing details. |
| RTE-006 | Current KCSIE edition and school DSL wording. |
| ORW-003, VBT-002 | Current JCQ AI-in-assessments guidance. |
| GAP-006, GAP-008, GAP-014, GAP-016 | Any platform-specific, product-specific, or route-specific update that would otherwise go stale. |

### Build Lock Before Sale

Before sale, every final module script, worksheet, landing-page claim, email, and tool clause should be checked against:

- Claim IDs in `57_AI_Safety_Course_Claim_Register.md`.
- Gaps in `58_AI_Safety_Course_Gap_Register.md`.
- Breaker findings in `60_AI_Safety_Course_G1_Breaker_Findings.md`.
- Human legal/safeguarding review decisions.

Anything without a Claim ID is either removed, reframed as an assumption, or routed to the Gap Register before launch.
