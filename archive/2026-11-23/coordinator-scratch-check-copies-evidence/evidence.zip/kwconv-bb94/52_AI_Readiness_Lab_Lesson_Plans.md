# AI Readiness Lab for Families - Facilitator Lesson Plans

*Draft 1.0. Created 24 June 2026. These plans are for a parent-facing course. They are not written as direct child lessons.*

## Facilitator Notes

### Tone

Calm, practical, warm, and specific. Avoid breathless AI hype and avoid frightening parents into action. The repeated message is: parents do not need to master every tool; they need a few durable rules and review habits.

### Demo Rules

- Use invented examples only.
- Do not enter a child's name, school, account, private message, image, voice, health detail, worry, or live incident into any AI tool.
- Use parent-owned accounts only.
- Recheck tool terms, age restrictions, data settings, and training controls before recording or live delivery.
- If demonstrating a model output, say that AI output always needs human checking.

### Course Spine

Every session should land one simple family object:

1. Family AI Agreement v0.1.
2. Prompt card.
3. Schoolwork and synthetic-media rules.
4. Small project canvas and review checklist.

## Session 1 - The AI Map And The Household Rules

**Length:** 75 minutes.

**Parent promise:** By the end, you will know the main types of AI tools your child is likely to meet, and you will have a first draft of your family's AI rules.

### Learning Outcomes

Parents can:

- Explain the difference between search, chatbot, generative AI, assistant, and agent in plain English.
- Name three limits of AI output: it can be wrong, biased, or out of date.
- Explain why personal information should not be entered into AI tools.
- Start a family AI agreement without making it a lecture.

### Materials

- Slide deck or notes.
- Workbook worksheet 1: Family AI Agreement.
- Prompt demo using an invented child, school, and homework topic.
- Optional: current school AI policy, if the parent already has it.

### Minute Plan

| Time | Segment | Facilitator Move |
|---|---|---|
| 0-5 | Welcome and boundary | "This is a judgement course, not a tool-chasing course." Mention no private family data in examples. |
| 5-15 | The AI map | Explain search, chatbot, generative AI, assistant, agent, automation. Use ordinary examples. |
| 15-25 | What AI is good and bad at | Show one useful answer and one flawed answer. Ask: what would a child trust too quickly? |
| 25-35 | Why agents need boundaries | Explain autonomy as "more steps without asking". Introduce review points and stop conditions. |
| 35-45 | Private stays private | Walk through allowed, ask-first, and never-enter examples. |
| 45-55 | AI is not a person | Explain companion-style risk calmly: relationship language, secrecy cues, emotional dependence. |
| 55-65 | Family agreement setup | Parents complete the first four agreement clauses. |
| 65-72 | Family conversation script | Practise a short non-alarmist opener. |
| 72-75 | Close | Assign family lab and preview session 2. |

### Key Teaching Points

- The more an AI tool can do on your behalf, the more clearly the human boundary needs to be set.
- "Sounds confident" is not the same as "is correct".
- Personal information includes more than names: school, photos, account details, voice, private messages, routine, location, family circumstances, and live worries.
- The first family rule should be positive: AI can be useful for learning, practising, and making, but people stay responsible for what they use.

### Parent Script

"AI can be useful in this house, but we are going to use it like a tool, not like a person. We do not put private things into it. We do not let it do schoolwork for us. We check important answers. And if a tool ever gets weird, pushy, too personal, or asks you to keep something secret, you come and show me."

### Family Lab

Parent and child spend 20 minutes completing the first version of the Family AI Agreement:

- What AI can help with.
- What stays private.
- When to ask first.
- What must be checked by a person.

### Watch Points

- Do not imply parents need to monitor every prompt.
- Do not recommend reading a child's private chats as a default habit.
- Do not tell parents to override school rules with household rules.

## Session 2 - Prompting As Clear Thinking

**Length:** 75 minutes.

**Parent promise:** By the end, you will have a repeatable prompt pattern that helps your child think more clearly instead of outsourcing the work.

### Learning Outcomes

Parents can:

- Use the Bearings prompt pattern.
- Convert a weak prompt into a learning prompt.
- Ask AI for hints, practice, feedback, and explanation.
- Spot when a prompt is asking the system to do too much.

### Materials

- Workbook worksheet 2: Prompt Card.
- Workbook worksheet 3: Learning Prompt Builder.
- Invented school topic, for example "volcanoes", "Macbeth themes", or "fractions".
- Optional: a printed school assignment with all identifying details removed.

### Minute Plan

| Time | Segment | Facilitator Move |
|---|---|---|
| 0-8 | Recap | Ask parents which family agreement clause felt easiest and hardest. |
| 8-18 | Bad prompt, better prompt | Compare "write my homework" with a prompt that asks for hints and checks understanding. |
| 18-30 | The six-part prompt | Teach goal, context, boundaries, attempt, help wanted, output. |
| 30-42 | Try-first routine | Show how to require the child to attempt one step before asking AI. |
| 42-52 | Prompt types | Demonstrate explain, quiz, feedback, source-check, counterexample, and "what am I missing?" prompts. |
| 52-62 | Parent practice | Parents rewrite three weak prompts from the workbook. |
| 62-70 | Schoolwork boundary | Introduce help vs substitution. Tie to school policy and JCQ-style assessment expectations. |
| 70-75 | Close | Assign family lab and preview synthetic media. |

### Key Teaching Points

- Prompting is not magic phrasing. It is clear task definition.
- A good learning prompt asks for support around the child's attempt.
- A bad learning prompt hides the child's thinking.
- For schoolwork, the child's own understanding must stay visible.

### Prompt Pattern

```text
Goal: I am trying to learn...
Context: The topic is...
Boundary: Do not write the final answer for me.
My attempt: Here is what I think so far...
Help wanted: Give me hints / ask me questions / explain the mistake / quiz me.
Output: Keep it short and age-appropriate.
```

### Parent Script

"Before you ask AI, show me what you have tried. Then we can use it for hints, practice questions, or feedback. If it gives you a whole answer, that does not become your answer. Your job is to understand and write your own version."

### Family Lab

Choose one safe school topic. Parent and child create:

- One explanation prompt.
- One quiz prompt.
- One feedback prompt.
- One "what should I check?" prompt.

The child then explains back what they learned without looking at the AI output.

### Watch Points

- Avoid teaching prompt tricks that bypass safeguards.
- Avoid presenting AI as an always-available tutor for emotional support.
- Do not use real homework submissions unless the parent has removed identifying details and school rules allow AI use.

## Session 3 - Schoolwork, Creativity, And Synthetic Media

**Length:** 75 minutes.

**Parent promise:** By the end, you will have a practical household position on homework, AI images, voice, deepfakes, and creative work.

### Learning Outcomes

Parents can:

- Use a simple schoolwork ladder.
- Explain why AI-generated content cannot simply be submitted as a child's own work.
- Talk about image and voice generation without panic.
- Set rules around consent, private images, and misrepresentation.

### Materials

- Workbook worksheet 4: Schoolwork Ladder.
- Workbook worksheet 5: Synthetic Media Rules.
- Workbook worksheet 6: Source Check Sheet.
- Invented AI image scenario and invented AI citation example.

### Minute Plan

| Time | Segment | Facilitator Move |
|---|---|---|
| 0-8 | Recap | Ask what parents noticed in the family prompt lab. |
| 8-20 | Schoolwork ladder | Teach four categories: no AI, ask first, allowed with acknowledgement, useful for practice. |
| 20-32 | Academic integrity | Explain "your own work" in parent-friendly terms. Mention school policy comes first. |
| 32-42 | Source-checking | Show an invented AI answer with one fake or weak claim. Use the source check sheet. |
| 42-55 | Synthetic media | Explain image generation, deepfakes, nudify tools, voice cloning, and consent. |
| 55-65 | Creative work | Separate brainstorming and feedback from passing off generated work as personal work. |
| 65-72 | Rule writing | Parents add schoolwork and synthetic media clauses to the Family AI Agreement. |
| 72-75 | Close | Assign family lab and preview build week. |

### Key Teaching Points

- AI can be useful for practice, but school assessment work must reflect the child's own independent work.
- If AI is used as a source or helper, the child may need to acknowledge it according to school rules.
- AI can produce false sources or plausible wrong claims.
- Synthetic images and voice can affect real people. Consent and context matter.
- Private images and voices of other children are off-limits for family AI projects.

### Schoolwork Ladder

| Level | Household Rule | Examples |
|---|---|---|
| Red | No AI | Tests, controlled assessments, tasks where school says no AI. |
| Amber | Ask first | Homework where the rule is unclear, coursework planning, anything to be submitted. |
| Blue | Allowed with acknowledgement | Brainstorming, summarising sources, getting feedback, if school permits and use is declared. |
| Green | Useful for practice | Quizzes, explanations, revision questions, flashcards, checking understanding. |

### Parent Script

"I do not want AI to become a secret shortcut. I want it to become a useful study tool. The difference is whether your own thinking is still there and whether the school would be comfortable with how you used it."

### Family Lab

Create a one-page "AI and schoolwork" rule for the family agreement:

- What the school says.
- What is always okay for practice.
- What needs parent or teacher permission.
- How AI use should be acknowledged.
- What the child should do if they are unsure.

Then run one source-check exercise using an invented topic.

### Watch Points

- Do not provide legal advice on copyright or school discipline.
- Do not tell parents that AI detectors are reliable.
- Do not invite children to generate deepfake examples of real people.

## Session 4 - Small Projects, Agents, And Human Review

**Length:** 75 minutes.

**Parent promise:** By the end, you will be able to guide a small AI project with clear boundaries, review points, and stop conditions.

### Learning Outcomes

Parents can:

- Distinguish automation from autonomy.
- Fill in a project canvas before using a tool.
- Choose a green first project.
- Review an AI project before it is reused.

### Materials

- Workbook worksheet 7: Project Canvas.
- Workbook worksheet 8: Project Review Checklist.
- Workbook worksheet 9: Project Menu.
- Optional demo: paper prototype of a study quiz generator.

### Minute Plan

| Time | Segment | Facilitator Move |
|---|---|---|
| 0-8 | Recap | Ask which schoolwork rule parents expect will need the most discussion. |
| 8-18 | Automation vs autonomy | Explain more steps, more permissions, more need for review. |
| 18-30 | Project menu | Walk through green, amber, and red projects. Explain why red projects are out. |
| 30-45 | Project canvas | Demonstrate a project plan before touching a tool. |
| 45-55 | Human review points | Add checks before trust, sharing, submitting, sending, or reuse. |
| 55-65 | Parent practice | Parents draft one project canvas for their child's age band. |
| 65-72 | Showcase reset | Teach the child presentation questions: what it does, what it gets wrong, what data it uses, where a human checks. |
| 72-75 | Close | Assign final family lab and explain next-month reset. |

### Key Teaching Points

- A small useful project is better than a dramatic project that needs risky data or too much autonomy.
- Agentic workflows need boundaries: allowed inputs, allowed actions, checks, and stop conditions.
- First projects should not send, post, buy, message, scrape, or store private feelings.
- The child should be able to explain what they built and what could go wrong.

### Parent Script

"Before we build, we decide the job, the data, the steps, the checks, and the stop point. If the tool wants more access than the project needs, we change the project."

### Family Lab

Choose one green project and complete either:

- A paper prototype, if the parent does not want to use an AI tool yet.
- A supervised tool demo using invented or non-sensitive information.

The child then answers:

- What problem does this help with?
- What information did we give it?
- Where could it be wrong?
- What should a person check?
- Would we use it again, change it, or stop here?

### Watch Points

- Avoid public showcases.
- Avoid portfolio language that overstates independent work.
- Avoid any workflow that controls accounts, sends messages, or makes purchases.

## Optional Bonus Session - Parent Q&A And Household Reset

**Length:** 45-60 minutes.

**Use case:** Live cohort, Concierge add-on, or school follow-up.

### Agenda

- Revisit the Family AI Agreement.
- Share anonymised project types, not child details.
- Discuss school policy questions.
- Review new tools parents have encountered.
- Re-run the private-data rule.
- Pick one next-month review habit.

## Recording Plan

If producing this as a recorded course:

- Record the four sessions as 25-35 minute videos, not 75-minute webinars.
- Move parent practice into the workbook.
- Add one short demo video per session.
- Keep all demos tool-agnostic enough that they can be refreshed without re-recording the whole course.
- Add a last-reviewed date and a note that tools and terms change.

