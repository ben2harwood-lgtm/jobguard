# 103 — M0: OSA Scope Memo & M0 Decisions/Standards Record

**Product:** Keepwise, fully automated (blueprint `99`; build plan `100` v1.1; specs `101`).
**Milestone:** M0 (decision sweep, taxonomy lock, launch scoping).
**Status of this file:** the single citable record for the M0 Definition-of-Done items in `100` §2 ("M0 done when…") that call for an OSA scope memo, a naming decision, taxonomy sign-off, the two flag decisions, and the adopted standards.

---

## PART 1 — THE OSA SCOPE MEMO

*Internal analysis. Not legal advice. Read against `100` §5 (Gate B0) and `100` §2 ("M0 done when… OSA scope memo written").*

### What the product is

Keepwise is a **parent-facing** digital-safety product. A parent answers a self-contained questionnaire about their own household; the system assembles a static plan from pre-published, human-reviewed content blocks and delivers it to that one parent. There is no second party anywhere in the product.

### What the product is *not* — verified against the repo

Read directly from the codebase on this branch (`feat/milestone-2`):

- **No user-to-user (U2U) functionality.** The app route list (`app/` — `checkout`, `emergency`, `how-it-works`, `library`, `pricing`, `privacy`, `quiz`, `sample`, `start`, `terms`, `for-schools`, `concierge`, `skins`, `api`) contains no posting, messaging, chat, comment, forum, community, or profile surface. This is **structurally enforced**, not merely absent: `tests/guardrails-structure.test.ts` → *"no user-to-user features anywhere (§2)"* asserts that no app route directory is named `forum`, `chat`, `messages`, `comments`, `community`, or `profile` (lines ~76–115), and a second assertion forbids any `child` or `kids` route directory.
- **No public posting / no feed / no algorithmic ranking.** No content is created by one user for other users to encounter. There is no feed of any kind; the sole "internal workflow, not public feed" item (the update-stream draft, `lib/ai-safety-update-stream.ts`) is asserted to be `draft_internal_workflow_not_public` and is unrouted (`guardrails-structure.test.ts` line ~224–226).
- **No child accounts or child-facing surfaces.** Purchaser and recipient are the same adult. The test above forbids `child`/`kids` routes; `child_firstname` was deleted from the questionnaire on 2026-07-04 (`tests/questionnaire-pii.test.ts` line ~30–39 asserts `questionnaireKeys` does **not** contain `child_firstname`; `lib/questionnaire-data.ts` line ~88 carries the removal note). The internal North Star is zero child-identifiable data (`100` §1.9).
- **No search over user-generated content.** The library is a fixed set of editor-published guides; there is no user-content index and no search route over user content (grep of `app/library/` for a search surface returns nothing).
- **No messaging/chat/comments/community, and no AI chat.** No LLM sits in any delivery path; plans are block-assembled from a locked library, and the crisis signpost is a **hash-pinned constant** (`lib/signpost.ts`, `SIGNPOST` + `SIGNPOST_SHA256`, `verifySignpost()`), never model output.

> **Note on the two contact forms.** `app/api/concierge/route.ts` and `app/api/schools/route.ts` capture an adult's enquiry to the operator (name/email/organisation/optional `message`), PII-guarded by `checkNoChildPii` and never published, never shown to another user, with no reply/recipient surface. A one-way contact form to the business is not "content… encountered by other users" and does not create a U2U service.

### Scope conclusion (on the face of Ofcom's published scope)

Part 3 of the Online Safety Act regulates two service types:

- **User-to-user service** — an internet service that lets users *create, upload and/or share content on the service that can be encountered by other users of the service*.
- **Search service** — a service that lets users search *across multiple websites/databases* (a search of a single site/database is not covered).

Keepwise has **no U2U functionality, no public posting, no messaging/chat/comments/community, no child accounts or child-facing surfaces, no search over user-generated content, and no algorithmic feed**. On the face of that published scope, **Keepwise is OUTSIDE the OSA Part 3 duties** (no U2U service and no search service ⇒ not a "Part 3 service", so no children's access assessment, illegal-content, or protection-of-children duties arise).

**[LEGAL TO CONFIRM at Gate B0 — this memo is analysis, not advice.]** Confirmation route: Ofcom's own **"Check if the Online Safety Act applies to you"** Regulation Checker, plus solicitor sign-off folded into the B0 pack (`102`). See scope basis: Ofcom, *Regulated services / illegal-content duties under the Online Safety Act* (ofcom.org.uk/online-safety).

### STANDING RULE — re-assess OSA scope BEFORE building

```
┌──────────────────────────────────────────────────────────────────────────┐
│  OSA SCOPE STANDING RULE                                                    │
│                                                                            │
│  The out-of-scope conclusion above holds ONLY while the product has no     │
│  user-to-user or search features. RE-ASSESS OSA SCOPE — with legal — BEFORE│
│  building — if ANY of these is ever proposed:                              │
│                                                                            │
│    • a community / forum / comments feature                                │
│    • parent-to-parent anything (messaging, sharing, groups, reviews         │
│      other parents can read)                                               │
│    • any child-facing surface or child account                             │
│    • search over user-generated content                                    │
│    • an algorithmic / personalised feed                                    │
│    • AI chat (an interactive model-backed conversation surface)            │
│                                                                            │
│  Any one of these can pull the product INTO Part 3. Scope is re-opened at   │
│  design time, not after launch.                                           │
└──────────────────────────────────────────────────────────────────────────┘
```

The guardrail tests in `tests/guardrails-structure.test.ts` (forbidden U2U/child route segments; unrouted internal-workflow drafts) **structurally enforce the out-of-scope posture today** — any PR that introduces one of the above surfaces breaks these tests loudly, which is the intended trip-wire for invoking this rule.

---

## PART 2 — M0 DECISIONS & STANDARDS RECORD

**Dated 2026-07-05.** Everything below is recorded as **DECIDED / ADOPTED** with pointers, so each M0 DoD item (`100` §2 "M0 done when…") has one citable record. Numbers are held consistent with blueprint `99`, build plan `100` v1.1, and specs `101`.

### 1. Naming — DECIDED: **Keepwise** everywhere customer-facing

- Keepwise is the customer-facing name (per files 95–99; blueprint `99` §6). Bearings is retired as a customer name; brand mockups exist under Bearings but the decision set is Keepwise (`100` §7 flag 3).
- **Bearings residue patched this milestone in `79` and `85`:** both now read zero "Bearings" mentions and use "Keepwise" (verified — `grep -c Bearings` returns 0 in `79_..._Email_Templates.md` and `85_..._First_Sale_Legal_Admin_Pack.md`).
- **Remaining "Bearings" mentions live only in historical/superseded docs** and in the reconciliation lines of `99`/`100`/`101` (which exist precisely to say "reconcile to Keepwise" — e.g. `100` §1.8, §7 flag 3; `99` §6; `101` naming note). No customer-facing surface carries Bearings. *Standing constraint (`100` §1.8): no offer page ships until this naming decision is applied to the offer-page draft.*

### 2. Taxonomy + trigger table — LOCKED as the authoring checklist

- The block taxonomy (11 classes, ID grammar, frontmatter schema) and the **trigger/selection table** (`100` §3, esp. §3.4) are **LOCKED as the authoring checklist**, pending (a) **founder sign-off** and (b) the **Gate A0 safeguarding pre-read** (`100` §5; runs after the taxonomy draft and *before* bulk authoring, ~wk 3).
- **What sign-off means here:** the founder confirms the taxonomy/trigger table is the frozen spec authors write against — no block is authored, and no assembly rule is coded, against a different structure. It is an editorial/architectural lock, **not** a safeguarding approval: safeguarding approval is Gate A0 (architecture pre-read) and then Gate A (full block-library review, which blocks first sale). Sign-off unblocks bulk authoring; it does not release the product.

### 3. Flag decision 1 — Uncovered platforms → **THIN HONEST BLOCKS in M1**

- The **seven listed-but-uncovered platforms — X, Telegram, Signal, smart TV, VR, smartwatch, mobile games with chat** — each get a **thin honest block in M1**, authored on the `100` §2-M1 template: *what it is / common misunderstanding / what to check this week / what we cannot verify / library link / last-checked date / age-band notes / fallback*.
- **Decided per `100` v1.1** (`100` §7 flag 1, resolved by design; §2 M1 coverage list; §3.5 authoring order). The generic-platform fallback remains for anything genuinely unmatched. M1 DoD makes silent empty renders impossible.

### 4. Flag decision 2 — Q1 becomes **MULTI-BAND** (design decision recorded now)

- A multi-child household **selects every applicable age band**; plans render **per-band sections**. **Never** per-child personalisation claims, and **no per-child identifiers** (consistent with the deleted `child_firstname` and the enumerated data promise, `100` §1.9).
- **Implementation lands in M2** (multi-band splice connectors, Spec 1 — `101`; Spec 1 AC5 requires per-band sections) and in the diagnostic form when built. **Recorded now as the design decision** (`100` §7 flag 2). Marketing constraint: no per-child personalisation beyond band sections until this ships — the "9-year-old and a 13-year-old" plan-title framing from `99` §3 stays off the offer page.

### 5. Standards adopted

**(a) Accessibility — WCAG 2.2 AA target on core flows.** Acceptance at **M3** (`100` §2 M3 DoD: "accessibility pass (WCAG 2.2 AA target) on core flows"; §1 v1.1 standards list).

**(b) Content-health thresholds — ADOPTED per `100` §3.6 (the four, quoted):**
1. **Emergency signpost stale → hard fail: no plan rendering** until refreshed.
2. **Any high-risk block stale → auto-withdraw + designated fallback + editor alert.**
3. **>10% of top-platform blocks stale → the "kept current" claim comes off the offer page** until fixed.
4. **>20% stale → pause sales / generic-plan mode.**
(Green status is a pilot-line condition; the dashboard surfaces all four in the publish admin at M3.)

**(c) Admin security baseline — ADOPTED per `100` §4.1 (summary):** the publish admin is treated as a safety surface — admin-only routes; 2FA; role separation (author ≠ checker where possible, with a **mandatory second reviewer** for emergency/sextortion/grooming/self-harm blocks); an explicit publish-confirmation step for high-risk blocks; append-only audit log; withdrawal flow; an **emergency pause-plan-generation switch**; backups; and staleness / unreviewed-change alerts.

**(d) Launch-critical platform coverage — ADOPTED:** full blocks for the **top-10 questionnaire platforms**, plus **thin blocks for the seven** (§3 above), plus an **explicitly-named generic fallback** for anything else. From `lib/questionnaire-data.ts` (`social_platforms` options, excluding "Other"/"None that I know of"), the top-10 questionnaire platforms are:

> **Snapchat, TikTok, Instagram, YouTube, Discord, BeReal, X, Reddit, Twitch, Pinterest.**

(Note: **X** appears both here and in the seven — it is a listed option that is currently uncovered, so it takes a thin honest block until a full block is authored; the coverage rule is "≥1 published block or an explicitly-named published fallback for every option," `100` §2 M1 DoD.) Gaming options (`Roblox, Fortnite, Minecraft, Console online (PS/Xbox), PC/Steam, Mobile games with chat`) and messaging options (`WhatsApp, Snapchat, iMessage/SMS, Instagram DMs, Discord, Telegram, Signal, In-game chat`) are covered under the same coverage rule; **mobile games with chat, Telegram and Signal** are in the seven thin-block set.

### 6. Cross-references (forward pointers)

- **VAT position + unit-economics checkpoint → file `104`.** Held facts: £49 one-off, **VAT-inclusive** pilot price; **£29/yr** Stay Current renewal; UK VAT registration threshold **£90,000** (to be re-verified as current at B0), standard rate **20%**; ~**1,837 sales** crosses the threshold; **~£40.83 net** per sale if the £49 price is held post-registration; Stripe UK standard **1.5% + 20p**; refunds/chargebacks budget **6%**; editorial currency cost **£20–30k/yr** equivalent. Decision point logged, not decided here (`100` §1.4, §2 M0).
- **B0 launch scope (privacy/terms/checkout/data-model, incl. the sibling-count minimisation justification and OSA legal confirmation) → file `102`.**
- **A0 safeguarding pre-read pack → file `105`.**

*(Files `102`, `104`, `105` are forward references created alongside this record; `103` is the OSA + decisions anchor.)*

---

### Held-fact check (for consistency)

Pricing £49 one-off VAT-inclusive + £29/yr renewal; no founding pricing; no Concierge as a paid tier; no per-customer human labour; block-assembly plans (per-block human publish, no runtime LLM, locked `lib/signpost.ts`); `child_firstname` deleted; questionnaire collects **age band(s), devices, platforms, concern answers, optional parent free-text worry box (`priority_note`, `optional`+`pii`)**, and **sibling count KEPT** as an interpolation input needing a minimisation justification (`lib/questionnaire-data.ts` Q "How many children in the household use connected devices?", options 1/2/3+; `100` §1.9, §3.4). Gates: **A0** (safeguarding pre-read, ~wk3) · **A** (block-library safeguarding review, blocks first sale) · **B0** (launch privacy/terms/checkout/data-model, blocks first sale) · **B1** (digest/first-phone) · **B2** (DNS). Guardrails: no monitoring, no child-identifiable data (enumerated promise, `100` §1.9), no U2U, signpost-only emergencies, no safety guarantees, claims lint (14 patterns), British English throughout.

**Repo facts asserted above are cited to file/line on branch `feat/milestone-2`.** Ofcom scope basis: ofcom.org.uk/online-safety (regulated services / illegal-content duties under the Online Safety Act).
