# Seasonal Template Packs (System library / Stay Current)

**Generated 20 Jun 2026 from `20`/`19`/`16`, guardrail-verified. Calm, finishable ~20-minute resets timed to the year. Fill `[DATE]`.**

---

# Bearings · Seasonal Reset — Back-to-school device & settings reset

*Timing: September. One calm pass, about 20 minutes, any age band. Last reviewed [DATE].*

---

## Why now

New school year, new phones, new apps, new contacts — settings drift over a summer of holiday use, and term brings fresh group chats and a quieter window before the year gets busy. This is a once-a-term tidy, not an emergency. Most boxes below will already be fine; tick them and move on.

---

## The 20-minute reset (work top to bottom — the order is the point)

Set a timer, grab a coffee, do it in one sitting. The device layer governs every app at once, so it comes first.

**Device layer first (about 8 min) — the broad backstop that still applies when an app's own controls are loosened or bypassed**
- [ ] Open **Apple Screen Time** (Settings → Screen Time) or **Google Family Link** — whichever matches the device.
- [ ] Confirm Screen Time is **locked with a passcode your child doesn't know** (Apple) / supervision is still active (Family Link). If it's off, everything else can be switched off.
- [ ] Check **Downtime / bedtime** hours still suit the new term timetable (homework, earlier mornings).
- [ ] Confirm **Ask to Buy / purchase approval** is on — holiday spending habits reset here.
- [ ] Confirm **SafeSearch and the broadband adult-content filter** are still on.

**Age check — the linchpin (about 2 min)**
- [ ] On each app your child uses, confirm the **real date of birth** is set. Almost every protection keys off it, and Meta/Roblox now re-check age with AI/face scans.

**The two or three apps they actually use (about 8 min — pick from the band note below, skip the rest)**
- [ ] **Snapchat:** Contact Me = **Friends**; **Ghost Mode** on; Family Centre still linked.
- [ ] **Instagram:** Teen Account defaults on (private, strictest messaging); supervision still linked.
- [ ] **TikTok:** Family Pairing still linked; DMs off for under-16s; account private.
- [ ] **Roblox:** maturity ceiling, chat setting, and **monthly Robux spend cap** as you want them.
- [ ] **Discord / WhatsApp / Fortnite / YouTube:** re-check the one or two your child genuinely uses (friend/DM controls, autoplay off, spend PIN).

**New-term housekeeping (about 2 min)**
- [ ] Skim new **group chats and contacts** added over summer — anything from someone they don't actually know?
- [ ] Confirm where the **phone sleeps at night** for the new routine (charging outside the bedroom is the habit worth keeping).

> Heads-up: settings menus move and apps rename things often. If a path doesn't match your screen, search the setting name in the app or open the official help page (links below). Paths last checked [DATE].

---

## One conversation to have

September brings new classmates, older year groups, and money talk. The one to have now is the **money / "easy cash" conversation** — recruiting teens to move money for strangers (often dressed up as a quick favour or a side hustle) picks up at the start of the school year. Keep it short and non-alarming: *"if anyone — online or at school — offers easy money for using your bank account or moving cash, that's a scam. It's the young person who moves the money who ends up in trouble; the person who set it up walks away. Tell me and you won't be in any bother."* Older bands can pair this with the cornerstone line: *the door is always open, no judgement.*

---

## What to re-check (the settings that quietly drift)

- **Age accuracy** — a fake birthday set during summer quietly switches off teen protections.
- **Purchase approval / spend caps** — easily toggled off during holiday gaming; in-game spend is a top regret.
- **Downtime / bedtime windows** — summer hours rarely fit the term timetable.
- **Family-centre links** — a phone reset, reinstall or new device can silently unlink supervision.
- **DM and friend-request settings** — defaults can loosen after app updates; under-16 DM/private settings are the ones to confirm.
- **Autoplay and Shorts/feed limits** — re-check after the constant updates over summer.

---

## Posture by band (so this fits any age)

- **5–10 / 11–12 (co-use):** do this *with* them, front-loaded; lead on device-layer limits, Ask-to-Buy, YouTube Kids/autoplay-off, Roblox.
- **13–14 (co-set):** agree the changes together; prioritise real birthday on every app, Snapchat/Instagram/TikTok defaults.
- **15–16 (coach):** review *with* them, hand them the screen-time tool with a parental backstop.
- **17–18 (consult):** they lead; focus on account security (2FA, unique passwords) and their public footprint.

---

## Where to go next

- **Your age-band pack** — the full "do it this weekend" bundle for your child's stage (settings, conversations, family-agreement clauses).
- **Platform guides** — step-by-step paths and official links: Apple Screen Time `support.apple.com/en-us/108806` · Google Family Link `support.google.com/families/answer/7101025` · Snapchat `parents.snapchat.com` · Instagram `familycenter.meta.com` · TikTok `tiktok.com/safety/en/guardians-guide` · Roblox `about.roblox.com/parental-controls`.
- **Stay Current (monthly briefing)** — we re-check these settings for you each month, so a 10-minute term-time pass is all you ever need.

---

*General guidance from UK authorities (e.g. Ofcom, NSPCC, CEOP/NCA), not a safeguarding assessment or a guarantee. If something has already gone wrong, this isn't the place to handle it — use the emergency signpost to reach the right helpline or authority. Emergency signpost: [LINK].*

---

# Bearings — Seasonal Reset: Exam-season screen-time & sleep

*Spring exams. A calm ~20-minute reset for one teen, any age band. General guidance from UK authorities — not a safeguarding assessment, prediction or guarantee. All paths checked [DATE]; menus move (see caveats below).*

---

## Why now

Exam season stacks two pressures at once: more time on screens "to revise," and less sleep when it matters most. This isn't about locking anything down — it's a light, shared reset that guards rest and lowers the background noise, then steps back out of the way.

---

## The 20-minute reset (checklist)

Work top to bottom. Most boxes take two minutes. You won't finish exam season calmer by doing more — just the few things below, once.

**Set the tone (2 min)**
- [ ] Frame it out loud: *"Quick reset so screens help revision instead of eating your sleep — not a crackdown."* Agree it together, not at them.

**Protect the night (8 min)** *(sleep is the single biggest lever this season)*
- [ ] Agree where the phone sleeps overnight — ideally charging outside the bedroom (younger bands), or a co-agreed wind-down time (older bands).
- [ ] **Apple:** Settings → Screen Time → **Downtime** for overnight hours. (Apple's **Sleep Focus**, set via the Health app's Sleep schedule, also mutes notifications overnight — labels and location may have moved, so search "Sleep" in Settings if the path differs.)
- [ ] **Android:** Family Link → **Screen time** → **Bedtime / Downtime**.
- [ ] **Instagram (teens):** Sleep Mode mutes notifications 10pm–7am by default — confirm it's on.
- [ ] **YouTube:** turn off **Autoplay**; set **bedtime reminders**; a Shorts daily limit can be set (down to zero, from March 2026).

**Cut the daytime pull during revision (5 min)**
- [ ] **Apple:** Screen Time → **App Limits** on the apps that derail focus (e.g. Social), set for revision blocks.
- [ ] **Android:** Family Link → **Controls** → per-app limits; mark genuine study apps unlimited.
- [ ] **TikTok:** Family Pairing → screen-time limit. **Snapchat:** check daily time-spent in Family Centre.
- [ ] Quietly mute group-chat notifications during agreed revision windows (their choice, framed as their advantage).

**One honest check (3 min)**
- [ ] Ask, don't audit: *"Is anything online stressing you out more than the exams?"* Listen. Most seasons the answer is "I'm fine" — and that's a real answer.

**Step back (2 min)**
- [ ] Restate that this lifts after exams, and that the "come to me, no trouble" door stays open the whole time.

---

## One conversation to have

Pick the moment, not the lecture. Something like:

> *"Exams are stressful enough — I don't want your phone making the nights worse. Let's set a couple of things together so it's working for you, then I'll leave it alone. And if anything online is getting to you while you're under pressure, tell me — you're never in trouble for that."*

This is the cornerstone "come to me" line, dressed for exam season. For younger bands, keep it to the sleep half. For 15–18, lead with handing them control and offering backup, not imposing limits.

---

## What to re-check (settings drift)

This is far from the first setup you'll have done — these are the ones most likely to have quietly changed or switched off since:

- [ ] **Screen Time / Family Link is still locked** with a passcode the teen doesn't know (Apple) — if it's off, everything else can be undone.
- [ ] **Downtime / Bedtime** hours still cover the actual night (they drift after clock changes and timetable shifts).
- [ ] **YouTube Autoplay** hasn't crept back on.
- [ ] **Instagram Sleep Mode** notifications quiet-hours still set.
- [ ] App limits survived the latest app update.

*Heads-up: settings menus and labels move often — if a path above doesn't match your screen, search the setting name in the app or use the official help page. TikTok labels, Snapchat iOS-vs-Android labels, and YouTube controls are the ones most likely to have shifted.*

---

## Relevant guides

- Device layer (set first): `/library/platforms/apple-screen-time` · `/library/platforms/google-family-link` — official: support.apple.com/en-us/108806 · support.google.com/families/answer/7101025
- `/library/platforms/youtube` — autoplay, bedtime, Shorts limits — official: support.google.com/youtube/answer/13877231
- `/library/platforms/instagram` — Sleep Mode, Teen Account defaults — official: familycenter.meta.com
- `/library/platforms/tiktok` — Family Pairing, screen-time — official: tiktok.com/safety/en/guardians-guide
- `/library/platforms/snapchat` — Family Centre time-spent — official: parents.snapchat.com/en-GB/parental-controls
- Your age-band pack — the screen-time/sleep conversation tuned to your teen (co-use → co-set → coach → consult).

---

*If something is wrong right now and someone is at risk, this is not the place — go to your emergency signpost, which routes you to the right helpline or authority. Bearings gives general guidance and does not handle incidents. Worried about your teen's wellbeing under exam pressure? Samaritans (116 123) and, for eating concerns, Beat, are the right places to turn.*

---

# Holidays & a new device — a calm 20-minute reset

*A Bearings seasonal pack · timing: December and birthdays · last checked [DATE]*

A new tablet, phone or console is exciting — and the box rarely comes with the settings already where you'd want them. This is a single, finishable reset you can run in about twenty minutes, before the device becomes "theirs" and harder to revisit. It works for any age band. Calm beats thorough: doing the few things below is far better than meaning to do everything later.

---

## Why now

New devices usually arrive set wide open — full access, no limits, real money one tap away — and the first week sets the habits. Twenty minutes now, while the device is still new, is the easiest it will ever be to set the tone.

---

## The ~20-minute reset (work top to bottom; stop when your timer's up)

- [ ] **Set the device layer first — it governs everything else.** On iPhone/iPad turn on **Apple Screen Time** (Settings → Screen Time); on Android/Chromebook set up **Google Family Link**. This single layer covers limits, app installs and websites at once. *(Pick the one that matches the gift; skip the other.)*
- [ ] **Lock the controls with a passcode your child doesn't know.** On Apple, *do this first* — otherwise the rest can simply be switched back off (Settings → Screen Time → Lock Screen Time Settings).
- [ ] **Make spending need you.** Turn on **Ask to Buy** (Apple) or **purchase approval** (Family Link), and set any in-game spend cap. New consoles and game accounts are where surprise holiday charges happen.
- [ ] **Set the real birthday on every account.** Almost every protection keys off the date of birth — a real one switches on the age-appropriate defaults automatically. *(A new device is the moment fake ages get entered "to make it work." Keep them honest.)*
- [ ] **Turn on content filters and SafeSearch** at the device level, and the broadband adult-content filter on your home network.
- [ ] **Set a "where it sleeps" spot.** Decide tonight where the device charges overnight — ideally outside the bedroom. Easiest to make normal on day one.
- [ ] **Do one app, not ten.** Pick the *one* app they'll actually use most and set its key controls (see the band note below). The device layer is your backstop for the rest; you can come back another weekend.
- [ ] **Save your reporting routes.** Note the right helpline/report link for your household somewhere you'll find it again — see *What to do if something goes wrong* in your guides. You won't need it today; you'll be glad it's there.

*That's the reset. If you only get through the first three boxes, you've done the high-leverage part.*

---

## One conversation to have

Open the door before you open the apps. In your own words: **"If anything ever feels weird, scary or just off on this — a message, a pop-up, a person — come and tell me, and you won't be in trouble for telling."** This cornerstone line matters more than any setting, and a new device is the natural moment to say it warmly rather than as a rule. For younger children, add: *"things that ask for money are a grown-up's job — come and get me."*

---

## What to re-check (the settings that quietly drift)

Pick the one app that fits your child's age and confirm its defaults — these are starting points and **a menu may have moved**, so if a path doesn't match your screen, search the setting name in the app or use the official link.

- **5–10 / 11–12 (co-use):** **YouTube Kids** with autoplay off and approved-content-only mode; **Roblox** set to the youngest age-appropriate settings, with chat off or restricted and a spend cap. Official: support.google.com/youtubekids · about.roblox.com/parental-controls
- **13–14 (co-set):** **Snapchat** — Contact Me set to Friends (not "Friends and Contacts"), Snap Map → Ghost Mode (parents.snapchat.com). **Instagram** — confirm Teen-Account defaults (private, restricted messaging) via Family Centre (familycenter.meta.com). Real birthday checked on both.
- **15–16 (coach) / 17–18 (consult):** review privacy and contact settings *with* them rather than imposing; turn on **2FA** and check account security (NCSC has plain-English guidance). For older teens, the agreement becomes a standing offer of help, not a lock.

A 10-minute re-check each school term keeps these from drifting — that's the habit our *Stay Current* briefings are built to prompt.

---

*General guidance drawn from UK sources (Ofcom, NSPCC, CEOP/NCA, Internet Matters). Not a safeguarding assessment or a guarantee. Settings reflect platforms as of [DATE] and change often. In an emergency, use the signpost in your guides to reach the right authority or helpline.*

---
