# AI Readiness Lab for Families - Parent Workbook

*Draft 1.0. Created 24 June 2026. Parent-facing workbook. Family activities are optional and should be supervised by the parent.*

## How To Use This Workbook

Use this alongside the four AI Readiness Lab sessions. You do not need to complete every box. The aim is to leave with a few clear household rules, one useful prompt pattern, and a small project that has been checked by a person.

Do not write a child's full name, school, address, account details, private messages, health details, private worries, photos, voice recordings, or live-incident details in this workbook or in AI tools.

If something urgent is happening now, use the Bearings emergency signpost instead of this course.

## Worksheet 1 - Family AI Agreement v0.1

### Our Starting Position

In our house, AI can be used for:

- [ ] Explaining ideas.
- [ ] Practice questions.
- [ ] Revision quizzes.
- [ ] Brainstorming.
- [ ] Feedback on a draft.
- [ ] Creative ideas.
- [ ] Small supervised projects.
- [ ] Other: ______________________________

AI should not be used for:

- [ ] Submitting work that is not your own.
- [ ] Pretending to be someone else.
- [ ] Making or editing images of real people without permission.
- [ ] Entering private information.
- [ ] Emotional support instead of talking to a person.
- [ ] Sending messages automatically.
- [ ] Buying, posting, downloading, or changing accounts automatically.
- [ ] Other: ______________________________

### Private Stays Private

We do not put these into AI tools:

- Names, school, address, or location.
- Account details or passwords.
- Private messages.
- Photos or voice recordings of real people.
- Health details.
- Family problems or private worries.
- Details of anything happening right now that needs adult help.

Our own extra private-data rule:

```text

```

### Ask First

In our house, ask a parent before using AI for:

- [ ] Homework that will be submitted.
- [ ] Anything involving another person.
- [ ] Images, video, or voice.
- [ ] Anything that asks for an account, upload, or permission.
- [ ] Anything that feels private, upsetting, secret, or too personal.

### Check With A Person

Before we trust, submit, send, post, or reuse AI output, we check:

- [ ] Is it true?
- [ ] Is it allowed by school rules?
- [ ] Is any private information included?
- [ ] Does it represent my own thinking honestly?
- [ ] Does a parent, teacher, or another person need to see it first?

### Family Opener

Parent says:

"AI can be useful here, but we use it like a tool, not like a person. Private things stay private. Schoolwork still needs to be your own thinking. If an AI tool ever gets weird, pushy, too personal, or asks you to keep something secret, show me."

Our version in our own words:

```text

```

## Worksheet 2 - The Bearings Prompt Card

Use this when the goal is learning, not outsourcing.

```text
Goal: I am trying to learn...
Context: The topic is...
Boundary: Do not write the final answer for me.
My attempt: Here is what I think so far...
Help wanted: Give me hints / ask me questions / explain the mistake / quiz me.
Output: Keep it short and age-appropriate.
```

### Prompt Types

| Prompt Type | Use It For | Starter |
|---|---|---|
| Explain | Understanding a topic | "Explain this in simple steps..." |
| Hint | Getting unstuck | "Give me one hint, not the answer..." |
| Quiz | Revision | "Ask me five questions, one at a time..." |
| Feedback | Improving a draft | "Tell me what is unclear, but do not rewrite it..." |
| Check | Finding weaknesses | "What might be wrong or missing here?" |
| Source | Verifying | "What claims should I check with a reliable source?" |

### Weak Prompt To Better Prompt

Weak prompt:

```text
Write my homework about __________________.
```

Better learning prompt:

```text
I am learning about __________________.
Here is what I think so far: __________________.
Do not write my final answer.
Ask me three questions that will help me improve my own answer.
```

## Worksheet 3 - Learning Prompt Builder

Topic:

```text

```

What I already know:

```text

```

What I am stuck on:

```text

```

The kind of help I want:

- [ ] Explain it simply.
- [ ] Give me a hint.
- [ ] Ask me questions.
- [ ] Quiz me.
- [ ] Check my draft.
- [ ] Show one example after I try.

My prompt:

```text

```

After using AI, explain back without looking:

```text

```

What still needs checking:

```text

```

## Worksheet 4 - Schoolwork Ladder

School policy checked?

- [ ] Yes.
- [ ] Not yet.
- [ ] I need to ask.

### Our Ladder

| Level | Rule | Our Examples |
|---|---|---|
| No AI | School says no, or it is a test/controlled task. | |
| Ask first | The rule is unclear or it will be submitted. | |
| Allowed with acknowledgement | School allows it and the use is declared. | |
| Good for practice | Revision, explanations, quizzes, flashcards. | |

### If Unsure

The child should:

1. Pause.
2. Ask a parent or teacher.
3. Keep a record of what AI was used for.
4. Make sure the final work reflects their own thinking.

Our schoolwork rule:

```text

```

## Worksheet 5 - Synthetic Media Rules

Synthetic media means AI-generated or AI-edited images, video, audio, or voice.

### Our Rules

- [ ] We do not make fake images, video, or voice of real people without permission.
- [ ] We do not use AI to embarrass, sexualise, impersonate, bully, or trick anyone.
- [ ] We do not upload private photos or voice recordings into AI tools.
- [ ] We label AI-generated creative work honestly where needed.
- [ ] We ask a parent before using image, video, or voice tools.

### Scenario Check

Scenario:

```text
A classmate asks your child to use an AI image tool to make a funny fake picture of another pupil.
```

What is the problem?

```text

```

What should your child say or do?

```text

```

Who should they tell if it has already happened?

```text

```

## Worksheet 6 - Source Check Sheet

Use this when AI gives information that might matter.

### Claim To Check

```text

```

### Check Questions

- [ ] Is there a named source?
- [ ] Is the source real?
- [ ] Is it current enough?
- [ ] Is it relevant to the UK, if this is a UK question?
- [ ] Does another reliable source agree?
- [ ] Could the AI have invented or distorted this?

### Result

- [ ] Looks reliable enough for learning.
- [ ] Needs a better source.
- [ ] Do not use.
- [ ] Ask a teacher or parent.

Notes:

```text

```

## Worksheet 7 - Small Project Canvas

Choose a green project first.

Project name:

```text

```

Problem it helps with:

```text

```

Who will use it?

```text

```

Allowed information:

```text

```

Information we will not use:

```text

```

Steps:

1. ________________________________________
2. ________________________________________
3. ________________________________________
4. ________________________________________

Human check points:

- [ ] Before entering information.
- [ ] Before trusting an answer.
- [ ] Before saving anything.
- [ ] Before sharing anything.
- [ ] Before using it again.

Stop conditions:

- [ ] Tool asks for private information.
- [ ] Tool asks for access it does not need.
- [ ] Output looks wrong, strange, or too personal.
- [ ] Project starts involving another real person.
- [ ] Child feels uncomfortable or secretive.

## Worksheet 8 - Project Menu

### Green First Projects

- [ ] Study quiz generator for one topic.
- [ ] Reading companion that asks questions.
- [ ] "Explain this three ways" learning helper.
- [ ] Family activity planner using non-sensitive preferences.
- [ ] Creative story-world builder.
- [ ] Source-checking helper.
- [ ] Revision timetable draft.

### Amber Later Projects

- [ ] Research assistant for an older teen.
- [ ] Simple app prototype.
- [ ] Portfolio explainer.
- [ ] Email draft that is not sent automatically.
- [ ] Coding helper that explains changes.

### Red Projects For Now

- [ ] Automatic messaging.
- [ ] Private emotional journaling with AI.
- [ ] Classmate image, voice, or data projects.
- [ ] Public posting.
- [ ] Autonomous buying, downloading, or account changes.
- [ ] Companion-style persona for emotional support.

Chosen project:

```text

```

## Worksheet 9 - Project Review Checklist

Before reuse, ask:

- [ ] Can the child explain what the project does?
- [ ] Can the child explain what information it used?
- [ ] Can the child name where it might be wrong?
- [ ] Is any private information included?
- [ ] Is any other person involved?
- [ ] Does school need to know if this is for schoolwork?
- [ ] Is there a human check before any real-world action?
- [ ] Would we be comfortable explaining this project to a teacher?

Decision:

- [ ] Use again as-is.
- [ ] Change it first.
- [ ] Keep it as a learning experiment only.
- [ ] Stop using it.

What we will change:

```text

```

## Worksheet 10 - Next-Month Reset

Date for next check:

```text

```

Three questions:

1. What AI tools has the child used this month?
2. Did any school rules change?
3. Do any family AI agreement clauses need updating?

Notes:

```text

```

