# AI Readiness Lab for Families - Complete Course Pack

*Draft 1.0. Created 26 June 2026. Consolidates the course proposal, curriculum spec, lesson plans, parent workbook, parent offer copy, and school/PTA taster into one file.*

## 1. Short Verdict

Yes, a course based on the public "agentic AI for kids" market signal is worth developing, but Bearings should not copy or extract that course. The stronger move is to create an original parent-mediated course that teaches AI judgement, schoolwork boundaries, privacy habits, source-checking, synthetic-media awareness, and small supervised projects.

This pack designs that course as **AI Readiness Lab for Families**.

## 2. Competitive Inspiration And Boundary

The public course we reviewed appears to sell a four-week, grades 7-9 "build with agentic AI" camp: AI concepts, hands-on tools, workflows/apps, final projects, and a showcase.

What is useful:

- It sells building, not passive AI tips.
- It has a simple four-week arc.
- It ends with a project.
- It frames agentic AI as a new literacy.

What Bearings should change:

- Make it parent-mediated rather than child-facing.
- Teach transferable judgement rather than a specific tool stack.
- Add privacy, schoolwork, source-checking, synthetic media, and emotional-dependence boundaries.
- Avoid career hype and shaky future-work claims.
- Keep all activities inside existing Bearings guardrails.

Boundary:

- Do not copy their copy, slides, lesson materials, tool setup, brand names, images, proprietary worksheets, LMS flows, or non-public material.
- Use the public structure as competitive research only.

## 3. Product Decision

**Working name:** AI Readiness Lab for Families

**One-line description:** A calm practical course that helps parents understand how children are using AI, set sensible household boundaries, and guide one small family-reviewed AI project.

**Best first format:** Four weekly parent sessions, 60-75 minutes each, with one optional 20-45 minute family lab after each session.

**Primary buyer:** Parents of 11-16s.

**Adjacent buyers:**

- Parents of 9-11s preparing for AI-enabled homework years.
- Parents of 15-17s dealing with revision, research, writing, coding, and portfolio pressure.
- Schools/PTAs that want a calm parent evening and take-home activities.

**Commercial use cases:**

- Paid add-on to The System.
- Recorded mini-course.
- Live parent cohort.
- School/PTA taster.
- Concierge module for families with AI-specific worries.
- Stay Current monthly AI update slot.

## 4. Product Boundary

This course is designed to remain inside the current Bearings V1 guardrails:

- Parent is the purchaser and learner.
- Bearings collects no child-identifiable data.
- Family activities happen at home, supervised by the parent.
- No child accounts are created by Bearings.
- No public student profiles, peer community, comments, messaging, or showcase gallery.
- No automated assessment of a child.
- No live-incident handling. Any urgent concern routes to the existing emergency signpost.
- School policy comes first for homework, coursework, and assessment.

A direct kids' workshop, live child cohort, student portfolio, school LMS, or child account flow would be a separate product line and needs a fresh legal/safeguarding/data review before sale.

## 5. Course Principles

### Think First, AI Second

Define the task, decide what information is allowed, try the first step yourself, then use AI for support.

### AI Is A Tool, Not A Person

Avoid personifying AI. Use language like "the tool generated" or "the system suggested", not "it understood", "it cares", or "it knows you".

### Private Stays Private

Do not enter names, schools, addresses, personal worries, health details, private photos, private messages, account details, voice recordings, or live-incident details into AI tools.

### Help, Practice, Feedback, Not Substitution

AI can explain, quiz, give feedback, or offer a worked example after an attempt. It should not become the hidden author of a child's school submission.

### Human Review Points

Every workflow has at least one human check before anything is trusted, shared, submitted, sent, posted, bought, or used to make a real decision.

### Calm Proportion

Name real issues: hallucination, bias, academic integrity, privacy, deepfakes, companion apps, scams, and overreliance. Avoid panic and avoid career-hype.

## 6. Guidance Anchors

Use these sources to guide lesson content, disclaimers, and launch copy:

- DfE, "Generative artificial intelligence (AI) in education", updated 12 August 2025. Key implications: evidence on pupil use is still emerging; pupil-facing use needs care, supervision, safeguarding, data protection, and critical judgement; generative AI output can be inaccurate, inappropriate, biased, out of date, unreliable, or affected by intellectual-property issues. https://www.gov.uk/government/publications/generative-artificial-intelligence-in-education/generative-artificial-intelligence-ai-in-education
- DfE, "Generative AI: product safety standards", updated 19 January 2026. Key implications: do not exaggerate capabilities; child-facing AI products need clear purpose, privacy, filtering, monitoring, governance, cognitive-offloading safeguards, and should avoid anthropomorphising or relationship-forming patterns. https://www.gov.uk/government/publications/generative-ai-product-safety-standards/generative-ai-product-safety-standards
- JCQ, "AI Use in Assessments", 30 April 2025. Key implications: students must submit their own work for qualification assessments; AI use should be acknowledged where relevant; schools should communicate risks and expectations to parents/carers. https://www.jcq.org.uk/knowledge-hub/ai-use-in-assessments-your-role-in-protecting-the-integrity-of-qualifications/
- ICO AI and data protection guidance. Key implications: personal data, transparency, fairness, accountability, and risk assessment matter when AI systems process information about people. https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/artificial-intelligence/
- Existing Bearings content: `01`, `02`, `06`, `17`, `18`, `19`, `20`, `29`, and `50`.

## 7. Course Outcomes

By the end, a parent should have:

- A plain-English map of what generative AI, chatbots, assistants, agents, and automation are.
- A household AI agreement drafted for their child's age band.
- A prompt pattern that supports thinking rather than replacing it.
- A way to talk about schoolwork, plagiarism, and acknowledgement.
- A private-data rule for AI tools.
- A source-checking habit for AI answers.
- A basic understanding of synthetic media, AI companions, and emotional overreliance.
- A small AI project reviewed through a parent checklist.
- A "what we will re-check next month" routine.

The course should not promise a certain risk outcome, academic improvement, exam advantage, career advantage, or future earning uplift.

## 8. Modular Course Map

These modules can run independently or as a four-part course. Each standalone module should include the same short baseline: no child data, no child accounts, school policy first, private stays private, and human check before trust/share/submit/send.

| Module | Parent Question | Family Object |
|---|---|---|
| 1. AI Map And Household Rules | What are my child and their friends actually using, and what rules should we have at home? | Family AI Agreement v0.1 |
| 2. Prompting As Clear Thinking | How do I help my child use AI without letting it do the thinking? | Prompt Card |
| 3. Schoolwork, Creativity, And Synthetic Media | What is okay around homework, images, voice, and creative work? | Schoolwork + Synthetic Media Rules |
| 4. Small Projects, Agents, And Human Review | How can my child build something useful without handing too much agency to the tool? | Project Canvas + Review Checklist |

## 9. Facilitator Notes

### Tone

Calm, practical, warm, and specific. Avoid breathless AI hype and avoid frightening parents into action. The repeated message is: parents do not need to master every tool; they need a few durable rules and review habits.

### Demo Rules

- Use invented examples only.
- Do not enter a child's name, school, account, private message, image, voice, health detail, worry, or live incident into any AI tool.
- Use parent-owned accounts only.
- Recheck tool terms, age restrictions, data settings, and training controls before recording or live delivery.
- If demonstrating a model output, say that AI output always needs human checking.

## 10. Module 1 - The AI Map And The Household Rules

**Length:** 75 minutes.

**Parent promise:** By the end, you will know the main types of AI tools your child is likely to meet, and you will have a first draft of your family's AI rules.

### Learning Outcomes

Parents can:

- Explain the difference between search, chatbot, generative AI, assistant, and agent in plain English.
- Name three limits of AI output: it can be wrong, biased, or out of date.
- Explain why personal information should not be entered into AI tools.
- Start a family AI agreement without making it a lecture.

### Materials

- Slide deck or notes.
- Worksheet 1: Family AI Agreement.
- Prompt demo using an invented child, school, and homework topic.
- Optional: current school AI policy, if the parent already has it.

### Minute Plan

| Time | Segment | Facilitator Move |
|---|---|---|
| 0-5 | Welcome and boundary | "This is a judgement course, not a tool-chasing course." Mention no private family data in examples. |
| 5-15 | The AI map | Explain search, chatbot, generative AI, assistant, agent, automation. |
| 15-25 | What AI is good and bad at | Show one useful answer and one flawed answer. Ask: what would a child trust too quickly? |
| 25-35 | Why agents need boundaries | Explain autonomy as "more steps without asking". Introduce review points and stop conditions. |
| 35-45 | Private stays private | Walk through allowed, ask-first, and never-enter examples. |
| 45-55 | AI is not a person | Explain companion-style risk calmly: relationship language, secrecy cues, emotional dependence. |
| 55-65 | Family agreement setup | Parents complete the first four agreement clauses. |
| 65-72 | Family conversation script | Practise a short non-alarmist opener. |
| 72-75 | Close | Assign family lab and preview Module 2. |

### Key Teaching Points

- The more an AI tool can do on your behalf, the more clearly the human boundary needs to be set.
- "Sounds confident" is not the same as "is correct".
- Personal information includes more than names: school, photos, account details, voice, private messages, routine, location, family circumstances, and live worries.
- The first family rule should be positive: AI can be useful for learning, practising, and making, but people stay responsible for what they use.

### Parent Script

"AI can be useful in this house, but we are going to use it like a tool, not like a person. We do not put private things into it. We do not let it do schoolwork for us. We check important answers. And if a tool ever gets weird, pushy, too personal, or asks you to keep something secret, you come and show me."

### Family Lab

Parent and child spend 20 minutes completing the first version of the Family AI Agreement:

- What AI can help with.
- What stays private.
- When to ask first.
- What must be checked by a person.

### Watch Points

- Do not imply parents need to monitor every prompt.
- Do not recommend reading a child's private chats as a default habit.
- Do not tell parents to override school rules with household rules.

## 11. Module 2 - Prompting As Clear Thinking

**Length:** 75 minutes.

**Parent promise:** By the end, you will have a repeatable prompt pattern that helps your child think more clearly instead of outsourcing the work.

### Learning Outcomes

Parents can:

- Use the Bearings prompt pattern.
- Convert a weak prompt into a learning prompt.
- Ask AI for hints, practice, feedback, and explanation.
- Spot when a prompt is asking the system to do too much.

### Materials

- Worksheet 2: Prompt Card.
- Worksheet 3: Learning Prompt Builder.
- Invented school topic, for example "volcanoes", "Macbeth themes", or "fractions".
- Optional: a printed school assignment with all identifying details removed.

### Minute Plan

| Time | Segment | Facilitator Move |
|---|---|---|
| 0-8 | Recap | Ask parents which family agreement clause felt easiest and hardest. |
| 8-18 | Bad prompt, better prompt | Compare "write my homework" with a prompt that asks for hints and checks understanding. |
| 18-30 | The six-part prompt | Teach goal, context, boundaries, attempt, help wanted, output. |
| 30-42 | Try-first routine | Show how to require the child to attempt one step before asking AI. |
| 42-52 | Prompt types | Demonstrate explain, quiz, feedback, source-check, counterexample, and "what am I missing?" prompts. |
| 52-62 | Parent practice | Parents rewrite three weak prompts from the workbook. |
| 62-70 | Schoolwork boundary | Introduce help vs substitution. Tie to school policy and assessment expectations. |
| 70-75 | Close | Assign family lab and preview synthetic media. |

### Prompt Pattern

```text
Goal: I am trying to learn...
Context: The topic is...
Boundary: Do not write the final answer for me.
My attempt: Here is what I think so far...
Help wanted: Give me hints / ask me questions / explain the mistake / quiz me.
Output: Keep it short and age-appropriate.
```

### Key Teaching Points

- Prompting is not magic phrasing. It is clear task definition.
- A good learning prompt asks for support around the child's attempt.
- A bad learning prompt hides the child's thinking.
- For schoolwork, the child's own understanding must stay visible.

### Parent Script

"Before you ask AI, show me what you have tried. Then we can use it for hints, practice questions, or feedback. If it gives you a whole answer, that does not become your answer. Your job is to understand and write your own version."

### Family Lab

Choose one safe school topic. Parent and child create:

- One explanation prompt.
- One quiz prompt.
- One feedback prompt.
- One "what should I check?" prompt.

The child then explains back what they learned without looking at the AI output.

### Watch Points

- Avoid teaching prompt tricks that bypass safeguards.
- Avoid presenting AI as an always-available tutor for emotional support.
- Do not use real homework submissions unless the parent has removed identifying details and school rules allow AI use.

## 12. Module 3 - Schoolwork, Creativity, And Synthetic Media

**Length:** 75 minutes.

**Parent promise:** By the end, you will have a practical household position on homework, AI images, voice, deepfakes, and creative work.

### Learning Outcomes

Parents can:

- Use a simple schoolwork ladder.
- Explain why AI-generated content cannot simply be submitted as a child's own work.
- Talk about image and voice generation without panic.
- Set rules around consent, private images, and misrepresentation.

### Materials

- Worksheet 4: Schoolwork Ladder.
- Worksheet 5: Synthetic Media Rules.
- Worksheet 6: Source Check Sheet.
- Invented AI image scenario and invented AI citation example.

### Minute Plan

| Time | Segment | Facilitator Move |
|---|---|---|
| 0-8 | Recap | Ask what parents noticed in the family prompt lab. |
| 8-20 | Schoolwork ladder | Teach four categories: no AI, ask first, AI allowed with acknowledgement, AI encouraged for practice. |
| 20-32 | Academic integrity | Explain "your own work" in parent-friendly terms. Mention school policy comes first. |
| 32-42 | Source-checking | Show an invented AI answer with one fake or weak claim. Use the source check sheet. |
| 42-55 | Synthetic media | Explain image generation, deepfakes, nudify tools, voice cloning, and consent. |
| 55-65 | Creative work | Separate brainstorming and feedback from passing off generated work as personal work. |
| 65-72 | Rule writing | Parents add schoolwork and synthetic media clauses to the Family AI Agreement. |
| 72-75 | Close | Assign family lab and preview build week. |

### Schoolwork Ladder

| Level | Household Rule | Examples |
|---|---|---|
| Red | No AI | Tests, controlled assessments, tasks where school says no AI. |
| Amber | Ask first | Homework where the rule is unclear, coursework planning, anything to be submitted. |
| Blue | Allowed with acknowledgement | Brainstorming, summarising sources, getting feedback, if school permits and use is declared. |
| Green | Useful for practice | Quizzes, explanations, revision questions, flashcards, checking understanding. |

### Key Teaching Points

- AI can be useful for practice, but school assessment work must reflect the child's own independent work.
- If AI is used as a source or helper, the child may need to acknowledge it according to school rules.
- AI can produce false sources or plausible wrong claims.
- Synthetic images and voice can affect real people. Consent and context matter.
- Private images and voices of other children are off-limits for family AI projects.

### Parent Script

"I do not want AI to become a secret shortcut. I want it to become a useful study tool. The difference is whether your own thinking is still there and whether the school would be comfortable with how you used it."

### Family Lab

Create a one-page "AI and schoolwork" rule for the family agreement:

- What the school says.
- What is always okay for practice.
- What needs parent or teacher permission.
- How AI use should be acknowledged.
- What the child should do if they are unsure.

Then run one source-check exercise using an invented topic.

### Watch Points

- Do not provide legal advice on copyright or school discipline.
- Do not tell parents that AI detectors are reliable.
- Do not invite children to generate deepfake examples of real people.

## 13. Module 4 - Small Projects, Agents, And Human Review

**Length:** 75 minutes.

**Parent promise:** By the end, you will be able to guide a small AI project with clear boundaries, review points, and stop conditions.

### Learning Outcomes

Parents can:

- Distinguish automation from autonomy.
- Fill in a project canvas before using a tool.
- Choose a green first project.
- Review an AI project before it is reused.

### Materials

- Worksheet 7: Project Canvas.
- Worksheet 8: Project Menu.
- Worksheet 9: Project Review Checklist.
- Optional demo: paper prototype of a study quiz generator.

### Minute Plan

| Time | Segment | Facilitator Move |
|---|---|---|
| 0-8 | Recap | Ask which schoolwork rule parents expect will need the most discussion. |
| 8-18 | Automation vs autonomy | Explain more steps, more permissions, more need for review. |
| 18-30 | Project menu | Walk through green, amber, and red projects. Explain why red projects are out. |
| 30-45 | Project canvas | Demonstrate a project plan before touching a tool. |
| 45-55 | Human review points | Add checks before trust, sharing, submitting, sending, or reuse. |
| 55-65 | Parent practice | Parents draft one project canvas for their child's age band. |
| 65-72 | Showcase reset | Teach the child presentation questions: what it does, what it gets wrong, what data it uses, where a human checks. |
| 72-75 | Close | Assign final family lab and explain next-month reset. |

### Key Teaching Points

- A small useful project is better than a dramatic project that needs risky data or too much autonomy.
- Agentic workflows need boundaries: allowed inputs, allowed actions, checks, and stop conditions.
- First projects should not send, post, buy, message, scrape, or store private feelings.
- The child should be able to explain what they built and what could go wrong.

### Parent Script

"Before we build, we decide the job, the data, the steps, the checks, and the stop point. If the tool wants more access than the project needs, we change the project."

### Family Lab

Choose one green project and complete either:

- A paper prototype, if the parent does not want to use an AI tool yet.
- A supervised tool demo using invented or non-sensitive information.

The child then answers:

- What problem does this help with?
- What information did we give it?
- Where could it be wrong?
- What should a person check?
- Would we use it again, change it, or stop here?

### Watch Points

- Avoid public showcases.
- Avoid portfolio language that overstates independent work.
- Avoid any workflow that controls accounts, sends messages, or makes purchases.

## 14. Optional Bonus Session - Parent Q&A And Household Reset

**Length:** 45-60 minutes.

**Use case:** Live cohort, Concierge add-on, or school follow-up.

### Agenda

- Revisit the Family AI Agreement.
- Share anonymised project types, not child details.
- Discuss school policy questions.
- Review new tools parents have encountered.
- Re-run the private-data rule.
- Pick one next-month review habit.

## 15. Age-Band Adaptation

### Ages 9-11

**Posture:** Co-use.

**Adult role:** Parent stays in the session, chooses the tool, types where needed, and uses invented examples.

**Best projects:** Story prompt, quiz cards, explain-a-topic, hobby planner, "ask me questions" reading helper.

**Avoid:** Private accounts, AI companions, open-ended chat, uploading photos, any task involving classmates.

### Ages 12-14

**Posture:** Co-set.

**Adult role:** Parent and child agree boundaries together. Parent reviews prompts and outputs until the child has shown stable habits.

**Best projects:** Revision quiz, source-checking helper, reading companion, study planner, "explain at three levels" tool.

**Avoid:** AI-written final homework, private emotional journaling with AI, automated messages, tools that request personal data.

### Ages 15-17

**Posture:** Consult.

**Adult role:** Parent expects more independence but keeps clear rules for schoolwork, personal data, emotional support, and public sharing.

**Best projects:** Research plan, citation-checking workflow, project planner, prototype app, portfolio explainer, revision dashboard.

**Avoid:** Submitting AI-authored work, using AI to impersonate someone, automated emails or applications, public portfolio claims that overstate what the child built.

## 16. Project Menu

### Green First Projects

These are suitable as first projects with parent supervision:

- Study quiz generator for one topic.
- Reading companion that asks questions before offering answers.
- "Explain this three ways" learning helper.
- Family activity planner using invented or non-sensitive preferences.
- Creative story-world builder with parent-set boundaries.
- Source-checking worksheet helper.
- Revision timetable draft checked by parent and child.

### Amber Later Projects

These can work for older teens with more supervision:

- Research assistant for a school topic.
- Simple app prototype.
- Portfolio explainer.
- Email draft that is never sent automatically.
- Coding helper that explains changes before the child uses them.

### Red Projects

Do not use these in the first version:

- Any workflow that sends messages automatically.
- Any tool that stores private worries, emotional disclosures, or incident details.
- Anything involving classmates' data, images, messages, or voices.
- Public posting or public portfolio creation.
- Autonomous purchasing, account changes, downloads, or browser control.
- A companion-style persona for emotional support.

## 17. Parent Workbook

### How To Use This Workbook

Use this alongside the four AI Readiness Lab sessions. You do not need to complete every box. The aim is to leave with a few clear household rules, one useful prompt pattern, and a small project that has been checked by a person.

Do not write a child's full name, school, address, account details, private messages, health details, private worries, photos, voice recordings, or live-incident details in this workbook or in AI tools.

If something urgent is happening now, use the Bearings emergency signpost instead of this course.

### Worksheet 1 - Family AI Agreement v0.1

In our house, AI can be used for:

- [ ] Explaining ideas.
- [ ] Practice questions.
- [ ] Revision quizzes.
- [ ] Brainstorming.
- [ ] Feedback on a draft.
- [ ] Creative ideas.
- [ ] Small supervised projects.
- [ ] Other: ______________________________

AI should not be used for:

- [ ] Submitting work that is not your own.
- [ ] Pretending to be someone else.
- [ ] Making or editing images of real people without permission.
- [ ] Entering private information.
- [ ] Emotional support instead of talking to a person.
- [ ] Sending messages automatically.
- [ ] Buying, posting, downloading, or changing accounts automatically.
- [ ] Other: ______________________________

We do not put these into AI tools:

- Names, school, address, or location.
- Account details or passwords.
- Private messages.
- Photos or voice recordings of real people.
- Health details.
- Family problems or private worries.
- Details of anything happening right now that needs adult help.

Our own extra private-data rule:

```text

```

Ask a parent before using AI for:

- [ ] Homework that will be submitted.
- [ ] Anything involving another person.
- [ ] Images, video, or voice.
- [ ] Anything that asks for an account, upload, or permission.
- [ ] Anything that feels private, upsetting, secret, or too personal.

Before we trust, submit, send, post, or reuse AI output, we check:

- [ ] Is it true?
- [ ] Is it allowed by school rules?
- [ ] Is any private information included?
- [ ] Does it represent my own thinking honestly?
- [ ] Does a parent, teacher, or another person need to see it first?

Family opener:

"AI can be useful here, but we use it like a tool, not like a person. Private things stay private. Schoolwork still needs to be your own thinking. If an AI tool ever gets weird, pushy, too personal, or asks you to keep something secret, show me."

Our version in our own words:

```text

```

### Worksheet 2 - The Bearings Prompt Card

Use this when the goal is learning, not outsourcing.

```text
Goal: I am trying to learn...
Context: The topic is...
Boundary: Do not write the final answer for me.
My attempt: Here is what I think so far...
Help wanted: Give me hints / ask me questions / explain the mistake / quiz me.
Output: Keep it short and age-appropriate.
```

Prompt types:

| Prompt Type | Use It For | Starter |
|---|---|---|
| Explain | Understanding a topic | "Explain this in simple steps..." |
| Hint | Getting unstuck | "Give me one hint, not the answer..." |
| Quiz | Revision | "Ask me five questions, one at a time..." |
| Feedback | Improving a draft | "Tell me what is unclear, but do not rewrite it..." |
| Check | Finding weaknesses | "What might be wrong or missing here?" |
| Source | Verifying | "What claims should I check with a reliable source?" |

Weak prompt:

```text
Write my homework about __________________.
```

Better learning prompt:

```text
I am learning about __________________.
Here is what I think so far: __________________.
Do not write my final answer.
Ask me three questions that will help me improve my own answer.
```

### Worksheet 3 - Learning Prompt Builder

Topic:

```text

```

What I already know:

```text

```

What I am stuck on:

```text

```

The kind of help I want:

- [ ] Explain it simply.
- [ ] Give me a hint.
- [ ] Ask me questions.
- [ ] Quiz me.
- [ ] Check my draft.
- [ ] Show one example after I try.

My prompt:

```text

```

After using AI, explain back without looking:

```text

```

What still needs checking:

```text

```

### Worksheet 4 - Schoolwork Ladder

School policy checked?

- [ ] Yes.
- [ ] Not yet.
- [ ] I need to ask.

Our ladder:

| Level | Rule | Our Examples |
|---|---|---|
| No AI | School says no, or it is a test/controlled task. | |
| Ask first | The rule is unclear or it will be submitted. | |
| Allowed with acknowledgement | School allows it and the use is declared. | |
| Good for practice | Revision, explanations, quizzes, flashcards. | |

If unsure, the child should:

1. Pause.
2. Ask a parent or teacher.
3. Keep a record of what AI was used for.
4. Make sure the final work reflects their own thinking.

Our schoolwork rule:

```text

```

### Worksheet 5 - Synthetic Media Rules

Synthetic media means AI-generated or AI-edited images, video, audio, or voice.

Our rules:

- [ ] We do not make fake images, video, or voice of real people without permission.
- [ ] We do not use AI to embarrass, sexualise, impersonate, bully, or trick anyone.
- [ ] We do not upload private photos or voice recordings into AI tools.
- [ ] We label AI-generated creative work honestly where needed.
- [ ] We ask a parent before using image, video, or voice tools.

Scenario:

```text
A classmate asks your child to use an AI image tool to make a funny fake picture of another pupil.
```

What is the problem?

```text

```

What should your child say or do?

```text

```

Who should they tell if it has already happened?

```text

```

### Worksheet 6 - Source Check Sheet

Claim to check:

```text

```

Check questions:

- [ ] Is there a named source?
- [ ] Is the source real?
- [ ] Is it current enough?
- [ ] Is it relevant to the UK, if this is a UK question?
- [ ] Does another reliable source agree?
- [ ] Could the AI have invented or distorted this?

Result:

- [ ] Looks reliable enough for learning.
- [ ] Needs a better source.
- [ ] Do not use.
- [ ] Ask a teacher or parent.

Notes:

```text

```

### Worksheet 7 - Small Project Canvas

Project name:

```text

```

Problem it helps with:

```text

```

Who will use it?

```text

```

Allowed information:

```text

```

Information we will not use:

```text

```

Steps:

1. ________________________________________
2. ________________________________________
3. ________________________________________
4. ________________________________________

Human check points:

- [ ] Before entering information.
- [ ] Before trusting an answer.
- [ ] Before saving anything.
- [ ] Before sharing anything.
- [ ] Before using it again.

Stop conditions:

- [ ] Tool asks for private information.
- [ ] Tool asks for access it does not need.
- [ ] Output looks wrong, strange, or too personal.
- [ ] Project starts involving another real person.
- [ ] Child feels uncomfortable or secretive.

### Worksheet 8 - Project Menu

Green first projects:

- [ ] Study quiz generator for one topic.
- [ ] Reading companion that asks questions.
- [ ] "Explain this three ways" learning helper.
- [ ] Family activity planner using non-sensitive preferences.
- [ ] Creative story-world builder.
- [ ] Source-checking helper.
- [ ] Revision timetable draft.

Amber later projects:

- [ ] Research assistant for an older teen.
- [ ] Simple app prototype.
- [ ] Portfolio explainer.
- [ ] Email draft that is not sent automatically.
- [ ] Coding helper that explains changes.

Red projects for now:

- [ ] Automatic messaging.
- [ ] Private emotional journaling with AI.
- [ ] Classmate image, voice, or data projects.
- [ ] Public posting.
- [ ] Autonomous buying, downloading, or account changes.
- [ ] Companion-style persona for emotional support.

Chosen project:

```text

```

### Worksheet 9 - Project Review Checklist

Before reuse, ask:

- [ ] Can the child explain what the project does?
- [ ] Can the child explain what information it used?
- [ ] Can the child name where it might be wrong?
- [ ] Is any private information included?
- [ ] Is any other person involved?
- [ ] Does school need to know if this is for schoolwork?
- [ ] Is there a human check before any real-world action?
- [ ] Would we be comfortable explaining this project to a teacher?

Decision:

- [ ] Use again as-is.
- [ ] Change it first.
- [ ] Keep it as a learning experiment only.
- [ ] Stop using it.

What we will change:

```text

```

### Worksheet 10 - Next-Month Reset

Date for next check:

```text

```

Three questions:

1. What AI tools has the child used this month?
2. Did any school rules change?
3. Do any family AI agreement clauses need updating?

Notes:

```text

```

## 18. Parent Offer Page Copy

### Hero

**AI Readiness Lab for Families**

Help your child use AI with better judgement.

A four-part parent course on AI homework, prompts, privacy, deepfakes, companion apps, and small supervised projects. Built for parents who do not want to chase every new tool, but do want clear family rules and better conversations.

**CTA:** Join the next parent lab

Secondary CTA: See what is covered

### The Problem

AI has arrived in family life before most families have agreed what counts as sensible use.

Children are using AI for schoolwork, revision, images, coding, chat, and creative projects. Some of that is useful. Some of it is unreliable. Some of it raises real questions about privacy, school rules, synthetic media, and emotional dependence.

Most parents do not need a technical course. They need orientation: what matters, what to ignore, what to ask, and where to put a human check.

### What This Is

AI Readiness Lab is a parent-first course. You learn the concepts, then use short optional family activities to turn them into household rules.

You will build:

- A family AI agreement.
- A prompt card that supports learning rather than substitution.
- A schoolwork rule for homework and assessment.
- A synthetic-media rule for image, video, and voice tools.
- A source-checking habit.
- A small project canvas for one supervised AI project.
- A monthly reset habit for new tools.

### What This Is Not

This is not a coding bootcamp.

It is not monitoring software.

It does not create child accounts.

It does not ask for child-identifiable data.

It is not a school policy or legal advice.

It does not handle urgent online incidents. If something is happening now, use the emergency signpost.

### Who It Is For

Best fit for parents of children aged 11-16.

Also useful if:

- Your 9-11-year-old is beginning to ask about AI tools.
- Your older teen is using AI for revision, research, writing, or coding.
- Your school has mentioned AI but the family rules are still vague.
- You are worried about AI homework but do not want every conversation to become an accusation.
- You want a small supervised project that teaches judgement, not just tool use.

### The Four Sessions

**1. The AI Map And The Household Rules**

Understand chatbots, generative AI, assistants, agents, and automation. Draft your first family AI agreement.

**2. Prompting As Clear Thinking**

Learn a prompt pattern that asks for hints, questions, explanations, and feedback without hiding the child's thinking.

**3. Schoolwork, Creativity, And Synthetic Media**

Set rules for homework, acknowledgement, source-checking, AI images, deepfakes, voice tools, and consent.

**4. Small Projects, Agents, And Human Review**

Choose one small project and map the goal, data, steps, review points, and stop conditions before using a tool.

### Included Materials

- Four parent lessons.
- Parent workbook.
- Family AI Agreement.
- Prompt card.
- Schoolwork ladder.
- Source-check sheet.
- Synthetic-media rules.
- Small project canvas.
- Project review checklist.
- Next-month reset sheet.

### Parent Promise

You will leave with a clearer map of AI in family life, a practical household agreement, and a way to help your child use AI without handing over the thinking.

### FAQ

**Do I need to be technical?**

No. The course is designed for parents who want plain-English judgement, not a technical deep dive.

**Will children attend the sessions?**

The first version is parent-facing. Each session includes an optional family activity you can do at home.

**Will my child need their own AI account?**

No. The course is designed so parents can use their own accounts, paper prototypes, or tool-free examples.

**Which AI tools do you teach?**

The course is tool-agnostic. Examples can be adapted to the tools families already meet, but the main skill is knowing what to ask, what not to enter, and what to check.

**Does this replace school rules?**

No. School policy comes first for homework, coursework, and assessments. The course helps families ask better questions and set household expectations.

**What if I am worried something serious has happened?**

Use the Bearings emergency signpost or the appropriate authority. This course is education and planning, not incident support.

## 19. Pricing Options

### Recorded Add-On

**AI Readiness Lab recording + workbook**

Indicative price: GBP 29-49.

Best use: add to The System once the core product is live.

### Live Parent Cohort

**Four weekly parent sessions + workbook**

Indicative price: GBP 79-149.

Best use: test willingness to pay and collect real questions before producing polished recordings.

### School/PTA Parent Evening

**One live parent taster + take-home workbook sample**

Indicative price: GBP 300-750.

Best use: warm school/PTA introductions.

## 20. School/PTA Taster Session

### Title

AI At Home: Homework, Privacy, Deepfakes, And The Family Rules Parents Need Now

### Format

60 minutes live or recorded for parents/carers.

No child data collected. No child participation required. No school systems accessed.

### Session Promise

Parents leave with a plain-English AI map, a schoolwork ladder, and the first clauses of a family AI agreement.

### Agenda

| Time | Segment | Detail |
|---|---|---|
| 0-5 | Welcome | Set the tone: useful, calm, not technical. |
| 5-12 | The AI map | Chatbots, generative AI, assistants, agents, automation. |
| 12-22 | What parents should know | Inaccuracy, privacy, schoolwork, synthetic media, companion-style tools. |
| 22-32 | Homework boundaries | Help versus substitution. School policy first. |
| 32-42 | Private stays private | What not to enter into AI tools. |
| 42-50 | Synthetic media | Images, voice, consent, and what to say at home. |
| 50-56 | Family AI agreement | Parents draft three clauses. |
| 56-60 | Close | Where to go next, emergency signpost, optional full course. |

### Take-Home Handout

One A4 page:

- The schoolwork ladder.
- The private-data rule.
- Three family AI agreement clauses.
- One prompt pattern.
- Emergency signpost link.

### School Boundary Slide

This session is parent education. It does not replace the school's safeguarding lead, homework policy, malpractice policy, or assessment rules. Families should follow the school's current guidance on AI use in homework, coursework, and assessments.

## 21. School Outreach Email

**Subject:** Calm AI guidance for your parent community

Hi [NAME],

I run Bearings, a parent-facing digital-readiness service. We are developing a calm AI session for parents on the questions schools are now hearing at home: AI homework, privacy, deepfakes, companion-style tools, and what family rules should look like.

The session is practical rather than technical. Parents leave with a plain-English AI map, a schoolwork ladder, and the first version of a family AI agreement. It does not involve pupils directly, does not collect child data, and does not replace your safeguarding or assessment policies.

Would it be useful for me to send the one-page outline for [School]'s PTA or parent newsletter?

Best,

[NAME]

## 22. Parent Newsletter Blurb

**AI at home: a calm parent session**

Many families are now trying to work out what to do about AI tools: when they help with learning, when they cross a homework line, what not to put into them, and how to talk about AI images, voice tools, and online trust.

Bearings is offering a practical parent session on AI at home. It is not a coding course and does not involve children directly. Parents will leave with a simple AI map, a schoolwork ladder, and starter clauses for a family AI agreement.

[DATE / LINK]

## 23. Post-Purchase Email

**Subject:** Your AI Readiness Lab is ready

Hi [FIRST NAME],

Thanks for joining AI Readiness Lab.

Start with session 1 and the parent workbook. You do not need to be technical, and you do not need to create any child accounts. The course is built around plain-English judgement: what AI can help with, what stays private, when school rules matter, and where a human check belongs.

Before you begin, one simple rule: please do not enter your child's name, school, private messages, images, health details, account details, or any live concern into an AI tool or workbook activity.

Start here: [COURSE LINK]

Emergency signpost: [LINK]

Best,

[NAME]

## 24. Conversion Notes

Lead with parent relief:

- "I finally know what to say."
- "I know what counts as help versus doing it for them."
- "I know what we do not put into AI tools."
- "We have a family rule now."

Do not lead with:

- Career certainty.
- Earnings claims.
- "AI natives."
- Tool lists.
- Competitive pressure between children.
- Fear of being left behind.

## 25. Recording Plan

If producing this as a recorded course:

- Record the four sessions as 25-35 minute videos, not 75-minute webinars.
- Move parent practice into the workbook.
- Add one short demo video per session.
- Keep all demos tool-agnostic enough that they can be refreshed without re-recording the whole course.
- Add a last-reviewed date and a note that tools and terms change.

## 26. Pre-Launch Review

Before launch:

- Check the current DfE AI education page.
- Check the current JCQ assessment guidance.
- Check the current age restrictions and data settings of any tool used in a demo.
- Ask a school contact to review the homework/assessment wording.
- Run content lint.
- Run a separate guardrail pass if any child-facing version is proposed.

## 27. First Build Recommendation

Build the four-session parent version first. It is the fastest to sell, easiest to keep inside the current product boundary, and most aligned with the Bearings promise: orientation before urgency.

