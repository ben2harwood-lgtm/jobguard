# AI Safety Course - Safeguarding AI Review Brief

*Created 2026-06-27. Status: prompt/brief for an AI-assisted safeguarding red-team review. This is not safeguarding advice, a safeguarding assessment, or formal clearance. It is an issue-finding pass before paid human review.*

## Prompt To Use

You are acting as an AI safeguarding red-team reviewer for a UK parent-facing AI safety course. You are not giving safeguarding advice for live cases and you cannot clear the course as safe. Your task is to identify wording, scenarios, tools, or routes that could create false reassurance, unsafe incident handling, child-data risk, escalation confusion, blame, panic, or drift into live safeguarding advice.

The product boundary is:

- adult parent/carer user only;
- no child accounts;
- no child-facing flow;
- no child PII;
- no screenshots, uploads, private messages, schoolwork, images, voice, or incident detail;
- no live-incident advice;
- no AI judgement of real messages, images, schoolwork, or incidents;
- no schoolwork authorship, custody, cheating, AI-use, or retention verdicts;
- no diagnosis, risk score, child profile, or assessment;
- no safety outcome promises;
- route/signpost only for live concerns.

Review the supplied files against this boundary and the Claim Register / Gap Register. Prioritise blockers and high-risk issues.

## Files To Review

Review these files in this order:

1. `57_AI_Safety_Course_Claim_Register.md`
2. `58_AI_Safety_Course_Gap_Register.md`
3. `60_AI_Safety_Course_G1_Breaker_Findings.md`
4. `61_AI_Safety_Course_Phase2_Design_Package.md`
5. `62_AI_Safety_Course_Phase3_Tools_Spec.md`
6. `63_AI_Safety_Course_Scenario_Trainer_Content.md`
7. `64_AI_Safety_Course_Readiness_Self_Check_Spec.md`
8. `65_AI_Safety_Course_Stay_Current_Update_Stream_Spec.md`
9. `66_AI_Safety_Course_Routing_Card_Spec.md`
10. `67_AI_Safety_Course_Human_Review_Pack.md`
11. `68_AI_Safety_Course_Source_Recheck_Log.md`
12. `components/FamilyAgreementBuilder.tsx`
13. `lib/ai-safety-scenarios.ts`
14. `lib/ai-safety-self-check.ts`
15. `lib/ai-safety-update-stream.ts`
16. `lib/ai-safety-routing-card.ts`

## Safeguarding Review Focus

Check for:

- any scenario that becomes too explicit or teaches mechanism/how-to detail;
- any route-out that asks follow-up questions about a live incident;
- any wording that invites parents to investigate, negotiate, confront, collect material, or ask a child for more detail;
- any use of AI to judge real messages, images, schoolwork, or incidents;
- any checklist that gives a safe/unsafe verdict;
- any tool or copy that implies the product can verify a child's authorship, independent reasoning, retention, AI use, cheating, or custody of schoolwork;
- any companion/chatbot watchpoint that reads like diagnosis or clinical assessment;
- any child profile, score, risk band, or prediction;
- any route category that is too broad or could send parents to the wrong service;
- any wording likely to increase shame, blame, panic, secrecy, or punishment-first responses;
- any missing "if this is already happening, stop and use the route" line;
- any confusion between Childline, NSPCC, CEOP, Report Remove/IWF, police, school DSL, Report Fraud, and platform reports.

## Required Output

Return findings first, ordered by severity.

Use this table:

| Severity | File / section | Finding | Why it matters | Required change | Human review needed? |
|---|---|---|---|---|---|
| blocker/high/medium/low | file + section | issue | safeguarding risk | exact wording change or remove/reframe instruction | safeguarding / legal / source / none |

Severity definitions:

- blocker: should not be parent-facing before patched.
- high: should be patched before sale or broad distribution.
- medium: patch before polished launch.
- low: clarity/style issue.

Then provide:

- "No issues found" only if you genuinely find none.
- A short list of unresolved safeguarding questions for paid human review.
- A list of scenarios/assets that should remain non-public.
- A list of exact phrases that should be banned or watched by content lint.

## Constraints

- Do not rewrite the whole product.
- Do not give advice for a live safeguarding incident.
- Do not say the product is safe or safeguarding reviewed.
- Do not invent new route instructions.
- If uncertain, flag the uncertainty and recommend human safeguarding review.
- Prefer calm, blame-reducing, route-aware wording.

## Special Attention

The most important known risks are:

- under-18 image-risk wording drifting into evidence collection;
- false reassurance from checklists or scenarios;
- AI judgement of real content;
- companion/chatbot wording becoming diagnosis-like;
- route cards becoming incident-management advice.

Treat those as blockers unless the wording clearly prevents the risk.
