# Critical Branding & Copy Review (adversarial)

**20 Jun 2026.** A from-first-principles, behavioural-economics review commissioned because the brand ("Bearings") and its copy were accepted as canon **without** adversarial review. Method: a meta-copy audit, an adversarial critique of the name, a behavioural brief, then three fresh brand directions each independently stress-tested; key name conflicts web-verified.

---

## TL;DR — the verdict

1. **The copy problem is real and fixable.** The current copy is **meta** — it tells you what the words are *doing* instead of speaking to a frightened parent. The audit even found a literal copywriter instruction (*"Bearings should never sound like it is selling generic online-safety awareness"*) shipping live on the pricing page. **This is the single biggest, easiest win, and it's independent of the name.**
2. **Bearings is a safe-but-mediocre 6/10.** Premium and category-differentiated, but abstract (names the parent's *internal state*, not their problem), carries a "lost your bearings" negative, and collides with the dominant industrial "ball-bearings" meaning (SEO/domain pain). *Keep-conditionally.*
3. **None of the three new names survived.** All three generated genuinely *better, more concrete copy* — but each name has a **verified** real-world conflict (see §4). So on the **name** alone, none beats Bearings.
4. **Recommendation (§5):** adopt the de-meta'd copy **now**; keep **Bearings** as the name for now (it isn't the bottleneck — the copy was), pair it with a concrete tagline + category descriptor, and only run a fresh *screened* name round if a 5-parent test of Bearings comes back cold.

---

## 1. The meta-copy problem (before → after)

Every line below is currently customer-facing. The "after" speaks to the parent's situation, not the brand's strategy.

| Where | Current (meta) | Rewrite (customer-facing) |
|---|---|---|
| Pricing H1 | "Buy the judgement layer, not another content library." | **"One reviewed plan, a current library, and a year of updates."** |
| Pricing section | "Facts are free. Sequence is the product." | **"You already have the facts. What you don't have is the order to do things in."** |
| Pricing kicker | *"Bearings should never sound like it is selling generic online-safety awareness."* (an internal instruction left in the page) | **delete** → "Free articles tell you what's out there. They don't tell you what to do first for your child, or whether it's still true this month." |
| Home hero H1 | "Orientation before urgency." | **"Know what matters online for your child — before it becomes a crisis."** |
| Hero trust chip | "Orientation / currency / judgement" | **"Built for UK parents of 5–18s"** |
| "What you get" | "A finished advisory system, not a checklist of internet safety tips." | **"Everything you need to act this week — your plan, the guides for your apps, and the words to use."** |
| "The gap" | "Free facts are everywhere. The scarce thing is a confident order of operations." | **"Most parents aren't short of advice. They're short of time to work out what applies to their child — and what to do first."** |
| Positioning line | "Bearings sits between generic advice and surveillance software…" | **"It won't spy on your child, and it won't bury you in articles. It tells you what matters now, what's changed, and what's worth doing about it."** |
| FAQ heading | "The product has a position." (+ a *design-system note* shipped as copy) | **"Common questions — straight answers to what parents actually ask before buying."** |
| "The promise" | "No monitoring. No guarantees. Better judgement." | **"No spying. No scare tactics. Just a clear idea of what to do first."** |

**Principle:** stop naming the abstraction ("orientation", "judgement", "sequence", "a position"). Show the product working. The most persuasive copy already in the repo proves it — the sextortion line *"Stop replying. Don't pay. Don't delete. Tell me. You won't be in trouble."* **is** the product, demonstrated. Keep that energy everywhere.

---

## 2. The behavioural levers (use these in all copy)

1. **Choice-overload reversal** — sell the *finished state*, not the contents. "We read the 200 articles so you read one plan." Show one hero tier + a clear default; never pitch the library as a vast archive (re-triggers overwhelm).
2. **Self-efficacy / "capable parent" identity** — frame the buyer as already competent, just needing the right tool. "You don't need scaring — you need a clear plan." Sell *proportion* ("is this normal? when should you actually worry?"). Capable people buy quality tools → justifies premium.
3. **Trigger-moment / fresh-start effect** — anxiety is episodic; anchor to the moment: "Getting their first phone?" beats "Keep your child safe online." Distinct entry points per trigger (first tablet 5–10, first phone 11–13, post-incident).
4. **Anchoring via the Concierge** — always show the £650 *near* the £99 (compromise effect favours the middle). "A system, not an app" · "not a £40 PDF or a £30/yr tracker."
5. **Loss-aversion WITHOUT fear** — the thing at risk is the *parent's calm and evenings*, never the child. "Stop losing evenings to conflicting advice." Zero threat imagery in the sell.
6. **Authority / credibility** — named, cited UK sources + a real human early; *calm itself is the credential*; "kept current — reviewed [date]" as proof of live expertise.
7. **Commitment device + present-bias bridge** — make the next step tiny and now ("2 minutes, start with the quiz"); sell the plan as paced/finishable; the Family Agreement is the tangible "done" artefact.

---

## 3. Bearings — adversarial verdict: **6/10, keep-conditionally**

**Cons:** abstract (names the parent's internal state, not the threat/child/outcome) · zero category signal on its own (leans 100% on tagline) · "lose your bearings" is one negation from the exact feeling it claims to cure · dominant literal meaning is *machine parts* (industrial SEO/domain collision) · no inherent warmth · the mockups already over-explain it ("Orientation/currency/judgement" chip = the name needs a glossary).
**Risks:** clean `.com`/`.co.uk` almost certainly taken (industrial) → compound domain dilutes the one-word equity; common-word trademark is narrow/weak.
**If kept, do these 3 cheap checks before any print/legal spend:** (1) exact-domain availability; (2) UKIPO Class 41 word-mark search; (3) a "does this sound like online safety?" test on ~5 target parents. Keep a descriptive challenger on the bench if the parent test is cold.

---

## 4. The three directions (copy = strong; names = all failed)

> Honest framing: the **copy and positioning in all three are better and more concrete than the current site.** The **names** are the problem — each has a verified conflict. Treat these as *copy/positioning* options, not finished names.

### Direction A — *Competence & calm command* — name **"Levelhead"** ❌ name fails
- **Tagline:** "The calm, capable way to handle your kids online."
- **Hero:** "Be the calm, capable parent when your kid goes online."
- **Tiers:** The Plan · Done With You · Kept Current.
- **Critique:** copy concrete (8/10), behaviourally honest. **Name killed:** *Levelhead* is a live mindfulness app (Mindful Planet LLC, App Store + Google Play) + a registered US mark + a platformer game — and it drags into the **therapy/"Calm/Mindful" register the brand explicitly bans**. Verified. *Beats Bearings: No.*

### Direction B — *Sequence & the first move* — name **"First Thing First"** ❌ name fails
- **Tagline:** "Out of everything, here's what to do first."
- **Hero:** "You don't need to do everything. You need to do the first thing."
- **Sub:** "Answer a few questions about your child… we hand you back a short plan: the few things worth doing, in the order to do them, with the exact settings to change and the words to use. One step at a time, not all at once."
- **Tiers:** The Plan · Done With You · Keep It Current.
- **Critique:** **strategically the sharpest and most customer-concrete direction** (this is the positioning to win on). **Name killed:** a misspelt clone of Stephen Covey's world-famous *"First Things First"* (7 Habits) — zero distinctiveness, word-of-mouth misspell leak, and "first thing" under-frames the £650 Concierge + annual layer. *Beats Bearings: No (name) — but its **copy** is the best of the lot.*

### Direction C — *Stay ahead / current* — name **"Keep Pace"** ❌ name fails
- **Tagline:** "The apps keep changing. So do we."
- **Hero:** "You can't keep up with every app. We do that bit for you."
- **Tiers:** The Household System · Done With You · Stay Current.
- **Critique:** strong *currency* angle (the renewal engine), but the **name reads as a fitness tracker**, and **"Pace" was a UK child-sexual-exploitation charity** (now the Ivison Trust) — the exact harm-register to avoid. Verified. Copy also drifts fear-lite ("never the last to know", "six months stale") and is overstuffed. *Beats Bearings: No.*

---

## 5. Recommendation

**Fix the copy now; treat the name as a fast-follow, not a blocker.**

1. **Adopt the de-meta'd copy immediately** across the brand-mockups + landing + quiz (the §1 rewrites, in the §2 behavioural register). This is the real win and it's name-agnostic.
2. **Lead positioning with Direction B's "first thing first" idea** (the sharpest, most concrete, most behaviourally honest) — *without* the broken name. i.e. the **message** is "out of everything, here's what to do first for your child"; the **brand name** can still be Bearings.
3. **Keep "Bearings" for now**, but: drop the abstract "Orientation before urgency" tagline for a concrete one (e.g. **"Bearings — know what to do first, online, for your child"**), always pair the wordmark with a category descriptor, and run the three 30-minute checks in §3.
4. **Only commission a fresh name round if** the 5-parent test of Bearings is cold. If so, the round must screen *up front* for: existing apps/trademarks, the therapy/"Calm/Mindful" register (banned), child-harm-charity adjacency, and fitness/industrial collisions — the exact traps these three hit.

**Net:** Bearings + the new copy is a strong, shippable combination today. The branding wasn't the thing holding you back — the *meta copy* was, and that's now solved.

---

## 6. Keep verbatim (copy that already works)
- **"Stop replying. Don't pay. Don't delete. Tell me. You won't be in trouble."** — the single most persuasive line in the repo; the product demonstrated, zero meta.
- **"No. Bearings does not install anything on a child's phone, read messages, collect screenshots or create child accounts. It is parent education and planning."** — how to state no-surveillance: list what it *doesn't* do.
- The sample-plan actions ("Reset contact visibility on Snapchat and Instagram… Do this together, not secretly.") — show the product working.
- The quiz result bands ("nothing to panic about, but a focused hour would go a long way") — prevention-not-panic done right.
- The "what's changed" threat naming (sextortion / AI nudify / companion bots) — current, specific, no fear-mongering.

---

## 7. Screened name round — outcome (20 Jun 2026)

A fresh pool of ~20 candidates was generated across four territories, each self-screened against the §4 traps; the low-risk shortlist was then **web-verified** (because self-screens missed real conflicts last round).

| Name | Form | Web verdict |
|---|---|---|
| **Steadwise** | coined (steady + wise) | ✅ **Cleanest.** No competing product/app surfaced; on-voice (calm, capable guide); coined → ownable + likely clean domain. **Front-runner.** |
| Soonly | coined | Usable; no direct conflict found, but thin/lightweight meaning, `.com` likely taken. |
| Forthwise | coined | Usable; a small HK audio company shares the name (different sector) — slightly muddied. |
| Plainsail | compound | ❌ **Killed** — a real fintech/trust-admin company *PlainSail* (plainsail.je) + UK "PLAINSAIL LIMITED" share the exact spelling. |
| Tidewell | coined | ❌ **Killed** — *Tidewell Hospice* (established US healthcare charity); death-care register. |
| Clearstead / Kindra / Trailhead / Wayfinder / Northwell / Truenorth / Footing | various | Self-screened medium–high (US wealth firm / menopause brand / Salesforce / hospital system / heavily-used idiom). Not pursued. |

**Recommendation:** **Steadwise** is the strongest screened replacement and fixes Bearings' specific weaknesses — it's ownable (coined), has no industrial/SEO clash, no "lost your bearings" negative, and sits squarely in the calm-capable voice. But it's a genuine toss-up with Bearings; decide on the cheap tie-breakers before committing:
1. `steadwise.com` / `steadwise.co.uk` availability;
2. a **UKIPO Class 41** word-mark search;
3. a 5-parent test: *"which sounds more like trustworthy online-safety help — Bearings or Steadwise?"*

If Steadwise clears, switch (it's a one-pass global find-replace, as the Bearings fill was). If not, Bearings stays. **Either way the de-meta'd copy is the real win and carries the brand regardless of the name.**

---

## 8. Full name-candidate register (every name generated, with status)

Status: ✅ passed web-screen (still needs formal UKIPO + domain) · ⚠️ unverified or borderline · ❌ ruled out (verified conflict).

**✅ Usable**
- **Steadwise** — steady + wise; the calm, capable guide. *(front-runner)*
- **Stillwise** — still + wise; calm clarity (quieter twin of Steadwise).
- **Soonly** — coined; "the first thing, now" (lighter, thinner meaning).

**⚠️ Worth checking / borderline**
- **Forthwise** — forth + wise; the way forward *(small HK audio firm shares it)*.
- **Forepath** — "the path's already laid out" (coined; NOT web-checked yet).
- **Forewise** — foresight + wise (not web-checked).
- **Currently** — respell of "currently"; currency angle (real word; domain via alt-TLD).
- **Clearstead** — clear + homestead *(US wealth firm — Clearstead Advisors)*.
- **Kindra** — kin/kindred; warm *(US menopause brand; also leans wellness)*.
- **Steerwise** — a steady heading *(a consultancy; steerwise.com taken)*.

**❌ Ruled out (verified conflicts)**
- **Bearings** — incumbent; abstract + industrial "ball-bearings" SEO/domain clash (scored 6/10, "keep-conditionally").
- **Levelhead** — live mindfulness app + therapy register.
- **First Thing First** — Stephen Covey clone ("First Things First").
- **Keep Pace** — fitness clash + "PACE" was a UK child-exploitation charity (now Ivison Trust).
- **Plainsail** — a real fintech/trust-admin firm.
- **Tidewell** — Tidewell Hospice (US healthcare charity).
- **Forra** — a "Forra" wellness brand + phonetic clash with Fortra (cybersecurity).
- **Trailhead** — Salesforce's learning platform.
- **Wayfinder** — multiple apps (one in school-transport safety).
- **Northlight** — crowded (Salesforce partner + an AI app + studios).
- **Plotline** — a feature-flag/experimentation SaaS.
- **Waypost** — a marketing SaaS + a (dissolved) UK software co.
- **Outset** — Scarlett Johansson's skincare brand + a wellness app.
- **Truenorth** — heavily used (True North gyms/apps + the Bill George book).
- **Northwell** — Northwell Health (large US hospital system).
- **Plainstep** — a compliance-workflow SaaS.
- **Aheadly** — a salon/spa booking app.
- **Tellwise** — a sales-enablement SaaS.
- **Tendwise** — "Tend" is crowded (insights/dental/farm/garage apps).
- **Footing** — common word; French "footing" = jogging.

**Brainstormed, not pursued** (weaker / "-wise" fatigue): Setwise · Steadly · Sortwise · Marker · Knowell · Brightstep.

*Reality the rounds proved: clean names here are almost all **coined** — every real-word/metaphor name (path, direction, "true", etc.) is already taken in an adjacent space.*
