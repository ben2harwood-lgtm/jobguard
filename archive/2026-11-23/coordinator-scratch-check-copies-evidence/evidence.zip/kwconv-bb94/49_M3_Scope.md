# 49 — M3 Scope: Diagnose & Deliver (2026-06-21)

Scope + first build for **Milestone 3** (spec `21` §7.4, §7.5, §7.11, §11). M1 (shell/funnel) and M2 (pay & gate, 51-item library) are done. M3 turns a paid buyer's questionnaire into a personalised, **human-published** plan that deep-links into the library.

## The canon guardrail (don't drift)
`01` §2.3 and `07` are explicit: **plan generation is LLM-assisted with a mandatory human publish — NOT a deterministic scoring engine.** Do not build an answers→score engine before the format stabilises (~50 reports). The model drafts via the `07` prompt; a human edits and clicks Publish. **No path may deliver or email a plan without an admin Publish action** (spec §7.5 hard rule; acceptance criterion 4).

## The flow (target)
`buy` → magic-link → `/questionnaire` (25 PII-safe Qs) → store `questionnaires` row (+30d purge) → create `plans` row `status=draft` → **draft via `07` prompt (Claude)** → lands in `/admin` as `in_review` → admin edits, content-lint must pass → **Publish** → renders `/library/start` + PDF + delivery email → `status=delivered`, schedule feedback (+3d) & month-11 renewal nudge.

## Built this session (pure, brand-agnostic, canon-aligned)
1. **`lib/questionnaire-data.ts`** — the 25 structured questions from `01` §2.2 (sections A–F), typed like `quiz-data.ts`. PII-safe by construction: the only name field (Q3) and the free-text (Q25) are flagged `optional`/`pii`; no DOB/school/screenshot fields exist. Each question declares which of the **six exposure domains** it feeds (§2.3). Age-band Q1 includes the canonical `5-10` band (the product is 5–18; the raw `01` text predates that).
2. **`lib/plan-prompt.ts`** — assembles the `07` prompt for a questionnaire: injects the answers (human-readable), the **live slug table built from `lib/content.ts`** (so it always reflects the current 51-item library, incl. Wave 2), and the emergency signpost block; plus `recommendedLinks()` (ticked-platform guides + age-band hub + flagged-gap playbooks) and the medium-priority `count` to feed the prompt. `draftPlan()` calls Claude (`claude-opus-4-8`, adaptive thinking) via dependency-free `fetch`, gated on `ANTHROPIC_API_KEY` — returns `null` gracefully when unset (mirrors `lib/db.ts`), so the app still builds/runs without secrets. **It only drafts; it never delivers.**

## Next steps (need the founder / toolchain / credentials)
- **`/questionnaire` route + server action** — render the 25 Qs (design tokens), validate against `lib/pii.ts`, write `questionnaires`, create the draft `plans` row, fire `questionnaire_submit`, trigger `draftPlan()`. *(Higher-risk to author blind — best built with the local toolchain to iterate.)*
- **`/admin` (admin-gated)** — fulfilment queue, draft viewer/editor, content-lint gate, **Publish** button (the only path to `delivered`); briefing composer (M4).
- **DB**: add `questionnaires` + `plans` tables to `supabase/schema.sql` (model in spec §6). Needs a Supabase project (founder).
- **LLM**: set `ANTHROPIC_API_KEY` (founder). Draft generation should run as a **background job** (Vercel Cron / queue), not inline in the request — Opus drafting can exceed a serverless request timeout, and the human-review step means it needn't be synchronous.
- **Delivery**: `/library/start` plan renderer (MDX), branded PDF, `08` delivery email; feedback (+3d) and month-11 renewal triggers via Vercel Cron.
- **Retention cron**: null `child_firstname` / redact `free_text` where `purge_after < today` (§6).

## Verification owed (no local Node here)
Founder runs `npm test` + `npm run build`. New guardrail test to add (acceptance criterion 3): assert the questionnaire data contains **no** child-PII field keys (reuse `lib/pii.ts` `FORBIDDEN_FIELD_PATTERNS` against every question `key`).

## Files
`lib/questionnaire-data.ts` · `lib/plan-prompt.ts` · this scope. Sources: `01` (questions+scoring), `07` (the prompt), `02` (report format), `03` (signpost), `21` §6/§7.4/§7.5/§7.11.
