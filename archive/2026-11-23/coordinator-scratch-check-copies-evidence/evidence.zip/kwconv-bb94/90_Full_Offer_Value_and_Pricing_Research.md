# Full Offer Value And Pricing Research

*Created 2026-06-28. Status: working recommendation. This updates the offer thinking after the AI Readiness Lab, AI Safety Course tools, Control Centre, resource/evidence layer, and pricing research were reviewed. It does not supersede legal/safeguarding review gates in `57`, `58`, `62`, `65`, `67`, or the launch gates in `00`.*

## Short Answer

Yes, we did add customisable tools, but the newest Apple/editorial prototype pages were not showing them strongly enough.

The strongest version of the offer is not "a course plus lots of articles". It is:

1. A personalised household online-safety system.
2. A parent-led AI readiness/safety course.
3. A set of customisable tools and printable assets that turn the advice into household rules.
4. A public trust layer: resources, writing, evidence notes, and update/changelog signals.
5. A paid maintenance layer: Stay Current.
6. Optional live help: Concierge and school/PTA sessions.

The pricing should move from "cheap course" thinking to "high-density household system" thinking, while still treating demand and willingness-to-pay as unvalidated assumptions.

## Existing Customisable Tools

These are already in the repo/specs and should become first-class in product and sales copy.

| Tool | Source | Status | Purpose |
|---|---|---|---|
| Control Centre | `39_Offer_Value_Expansion.md`; `brand-mockups/control-centre.html`; themed variants | Prototype built | Parent home base for guidance, agreement building, and control setup. |
| Screen-time guidance by age | `39` | Prototype built | Select age to get a realistic starting point and what matters at that stage. |
| Family Agreement Builder | `39`; `21`; `62` | Prototype/spec | Builds a printable agreement from selected household rules. |
| Control Launchpad | `39` | Prototype built | Tick-along setup list linking to real Apple/Google/broadband/app controls. |
| Family AI Safety Agreement Builder | `62` | Build first after review | Parent chooses AI clauses: privacy, tool-not-person, verification, schoolwork, synthetic media, contact pressure, scams, route-out. |
| Readiness Self-Check | `64` | Draft, review-gated | Navigation-only course tool; no scores, child profile, diagnosis, or live-incident handling. |
| Scenario Trainer | `62`, `63` | Draft, review-gated | Rehearses authored scenarios only; deterministic feedback; no real message/image analysis. |
| Stay Current Update Stream | `65` | Internal workflow spec | Records changes, sources, owner, review status, affected assets, and parent summary. |
| Routing Card | `62`, `66` | Static/review-gated first | Official route signposting only; no live incident handling. |
| AI Readiness printable set | `54`, `75`, `76` | Draft/pilot | Prompt card, schoolwork ladder, source-check sheet, synthetic-media rules, project canvas, review checklist. |
| Same-evening and reset printables | `39` | Proposed/low effort | Fast-start card, Cue Cards, Carer Card, Weekend Setup Sheet, Household Map, Quarterly Reset Card, Age-Up Card. |

Important boundary: no tool should process a child's actual message, image, voice, schoolwork, account handle, screenshot, prompt, or incident detail. The tools are for planning, rehearsal, clauses, and routing.

## What Else The Offer Needs

### 1. Public Writing / Field Notes

Yes, add a blog-like section, but do not position it as the product.

Role:

- Trust and search discovery.
- Show judgement, restraint, and currency.
- Give parents a reason to return before buying.
- Feed email/newsletter and school/PTA outreach.

Recommended name: **Field Notes** or **Notes From The Digital Front Door**. Avoid generic "Blog" in the main nav if the brand stays premium.

Publishing cadence: one or two strong pieces per month is better than a weak weekly schedule.

Good topics:

- "What we changed this month and why."
- "AI homework: help, practice, feedback, or substitution?"
- "Why the family agreement matters more than another setting."
- "The first phone weekend: what to do first."
- "How to talk about AI without making it a panic lecture."

### 2. Resources Section

Yes. There should be a public resource section and a deeper paid resource library.

Public resources should be high-trust tasters:

- First Phone mini-guide.
- AI Homework one-page rule.
- Private Stays Private card.
- Family Agreement sample.
- Emergency/routing signpost.
- Sample household map.
- Sample "what changed" briefing.

Paid resources should be organised by need, not by content type:

- Age.
- Device/platform.
- Issue.
- AI and schoolwork.
- Conversation.
- Printables.
- Route/signpost.
- What's changed.

Reason: free competitors already offer huge libraries. Bearings wins by narrowing, sequencing, and personalising.

### 3. Evidence Section

Yes, this is essential. It should not feel academic or defensive, but it should be visible.

Recommended public layer:

- **How We Ground The Guidance** page.
- Claim/source register summary in plain English.
- "Last reviewed" dates on sensitive pages.
- Confidence/routing notes where needed.
- Source categories: official guidance, statutory/regulatory, safeguarding routes, research.
- Clear boundaries: education and planning, not legal advice, safeguarding advice, monitoring, crisis help, or safety guarantee.

Internal sources already exist in `57_AI_Safety_Course_Claim_Register.md`, `58_AI_Safety_Course_Gap_Register.md`, and `68_AI_Safety_Course_Source_Recheck_Log.md`. Do not publish the raw claim register as-is; translate it into a parent-facing evidence page.

### 4. "What Changed" / Changelog

Yes. This is the proof for Stay Current.

Public version:

- A few approved examples of recent changes.
- "Date checked" and "what to do" style.
- No unreviewed legal/route/platform claims.

Paid version:

- Household-relevant monthly briefing.
- Platform guide refreshes.
- AI tool update slot.
- Annual household re-run.
- Age-band reissue.

Use `65_AI_Safety_Course_Stay_Current_Update_Stream_Spec.md` as the operating model.

### 5. School/PTA Offer Page

Yes, but keep it as a second channel until one warm paid session proves it.

Offer:

- Parent briefing.
- Take-home workbook sample.
- Newsletter/comms pack.
- Optional community readiness offer.

Pricing remains a working range: GBP 300-750 for an initial parent evening, GBP 750-1,500+ for larger programmes after one paid school validates demand.

## Pricing Research Notes

Checked 2026-06-28. These are market anchors, not a direct pricing formula.

### Free Advice And Resource Ecosystems

Internet Matters offers extensive free advice by age, issue, activity, app/platform, parental controls, interactive tools, downloadable activities, latest articles, research, and a personalised digital toolkit. This means a paid product cannot be "we have articles" alone.

Common Sense Media has AI initiatives across research, AI-tool review/ratings, education, and advocacy. Again, the free/charitable resource layer is strong.

Implication: public resources and writing are trust builders. The paid product must be personalisation, sequencing, customisable assets, review, maintenance, and optional human help.

Sources:

- https://www.internetmatters.org/
- https://www.commonsensemedia.org/ai

### Online Safety Training Anchor

NSPCC Learning's online safety training is GBP 30 per person, online, 4 hours, CPD certified, with one-year access and updates. It is professional/safeguarding training, not a household product, but it creates a low-cost course anchor.

Implication: a recorded parent course at GBP 29-49 is plausible. A live parent cohort needs to justify more through live guidance, workbook completion, and practical household outputs.

Source:

- https://learning.nspcc.org.uk/training/online-safety

### Monitoring / Parental Control App Anchor

Monitoring and parental-control apps cluster roughly from about USD 40-120/year, depending on features and device count.

Examples checked:

- Canopy family plans show USD 8.33-9.99/month billed annually for family use, with filtering, app/website blocking, location alerts, screen-time management, and related support.
- TechRadar's 2025 reviews list Norton Family at USD 49.99 / GBP 29.99 per year, Qustodio Basic at USD 43.37 / GBP 33.95 per year and Complete at USD 89.36 / GBP 69.95 per year, and Bark Premium at USD 14/month or USD 99/year.

Implication: Bearings should not price like monitoring software, because it is deliberately not monitoring software. But these prices tell us that GBP 59/year for Stay Current is plausible and that GBP 99-149 for a richer household education/planning system is not outlandish.

Sources:

- https://canopy.us/pricing/
- https://www.techradar.com/reviews/norton-family-parental-control-software
- https://www.techradar.com/reviews/qustodio-parental-control-software
- https://www.techradar.com/reviews/bark

### AI Learning Course Anchor

Create & Learn's AI Explorers is child-facing, live, small-group instruction for grades 4-8. The full course shows USD 395.91 for 12 sessions after discount.

FutureLearn's "Artificial Intelligence for Everyone" is adult/generic, 8 weeks, 2 hours/week, with a one-off course price shown as CHF 94 or an Unlimited subscription at CHF 289.99/year in the page view checked.

Implication: the AI Readiness Lab is different from both: it is parent-led, safety/judgement-oriented, and household-rules focused. A recorded add-on at GBP 49 is easy to accept; a live four-session parent cohort at GBP 149-199 is defensible if it includes workbook completion and the Family AI Safety Agreement.

Sources:

- https://www.create-learn.us/ai-for-kids/ai-explorers
- https://www.futurelearn.com/courses/artificial-intelligence-for-everyone

## Recommended Consumer Pricing

### Launch Recommendation

| Offer | Launch price | Later price to test | Notes |
|---|---:|---:|---|
| Free resources | GBP 0 | GBP 0 | Quiz/snapshot, first-phone mini-guide, AI homework taster, sample Family Agreement, emergency signpost. |
| Household System | GBP 99 founding | GBP 129 | Keep GBP 99 if there are no testimonials yet. Raise once value and demand are proven. |
| AI Readiness Lab recorded add-on | GBP 49 | GBP 59-79 | Do not bury this at GBP 29 if it includes workbook, agreement, prompt card, schoolwork ladder, source check, project canvas. |
| System + AI Lab bundle | GBP 129 founding | GBP 149-169 | Best hero bundle if we want one high-value default purchase. |
| Live AI parent cohort | GBP 99-129 beta | GBP 149-199 | Four parent sessions plus workbook/assets. Use beta pricing only while feedback is part of the bargain. |
| Stay Current | Included year 1, then GBP 59/year | GBP 79/year test later | GBP 59 is plausible; only raise if AI updates, annual re-run, seasonal packs, and age-band reissue are actually delivered. |
| Concierge | from GBP 650 | from GBP 750 | Keep "from GBP 650" until a few calls prove scope. Add child/household/AI module uplifts only after scoping is reliable. |

### Cleanest Family Pricing Page

Do not show every possible product on one pricing grid. It will make the offer feel confused.

Recommended public structure:

1. **Household System - GBP 99 founding**
   - personalised plan;
   - Control Centre;
   - tool builders and printables;
   - platform guides;
   - scripts and playbooks;
   - first year of Stay Current.

2. **Best value bundle - GBP 129 founding**
   - everything in the System;
   - AI Readiness Lab recordings;
   - workbook and AI household tools.

3. **Concierge - from GBP 650**
   - guided setup call;
   - all-children written report;
   - follow-up;
   - optional AI rules module.

Then explain:

- Stay Current is included for year one and renews at GBP 59/year.
- Live AI cohort is offered separately when scheduled.
- School/PTA sessions are by enquiry.

## Recommended School/PTA Pricing

| Offer | Price |
|---|---:|
| Newsletter/comms pack | Free or low-cost |
| 60-minute parent briefing + workbook sample | GBP 350-500 |
| Parent briefing + recording + take-home pack + school newsletter copy | GBP 500-750 |
| Larger workshop/programme | GBP 750-1,500+ |

Keep the school channel as a warm-introduction test. Do not build a full B2B sales machine until one paid session happens.

## What To Add To The Prototype

The Apple-inspired and editorial-luxury pages should add these value signals:

1. **Tools you customise**
   - Control Centre.
   - Family Agreement Builder.
   - Family AI Safety Agreement.
   - Prompt Card.
   - Schoolwork Ladder.
   - Source Check Sheet.
   - Project Canvas.
   - Quarterly Reset.

2. **Evidence and resources**
   - Field Notes.
   - Resource Library.
   - Evidence Notes.
   - What Changed.

3. **Pricing refinement**
   - Keep the current GBP 99 System visible.
   - Add a clear "best value" System + AI Lab bundle at GBP 129 founding / GBP 149-169 later.
   - Keep AI Lab standalone as GBP 49 recorded add-on, not GBP 29-49.
   - Keep live cohort as a separate beta/test product.

## Guardrails

- No safety guarantees, outcome claims, "fully compliant", or "keeps children safe" language.
- No child-facing product flow.
- No child data in tools.
- No processing of real messages, images, screenshots, schoolwork, prompts, or incidents.
- No parent community/forum/comments.
- No live-incident advice; route-only signposting.
- No platform-specific AI settings claims unless checked through the living update process.
- No public claims that pricing or demand has been validated yet.

## Decision

The most valuable offer is a **household operating system for digital safety and AI judgement**, not a single course.

Recommended launch positioning:

> Start with the personalised Household System. Add the AI Readiness Lab if AI homework, privacy, deepfakes, or companion-style tools are already on your mind. Use the Control Centre and printables to turn it into household rules. Stay Current keeps the guidance maintained after year one.

