# Content Production Tracker

**Updated 20 Jun 2026.** Status of the System's content library and what's left (the bits only you can do).

## Done & verified

### Platform cards + video scripts (`27`, `28`)
10 platforms, each a printable quick-ref card + a record-this video script. Corrected against the content review (`31`): card↔script parity, source-accurate settings (Discord & Fortnite facts re-verified against the live help pages and `16` updated to match), confidence hedges restored, and printable-card emergency routing with real helpline numbers. YouTube regenerated after a batch hiccup.

### Masterclass scripts (`29`)
5 spoken-word masterclasses — **5–10 (new), 11–12, 13–14 (flagship), 15–16, 17–18.** Corrected: distress signpost added wherever mental-health / body-image / sleep harms are raised; missing priority conversations restored (11–12 phones-at-night; 15–16 nudes-pressure refusal); every helpline now carries contact details (incl. Revenge Porn Helpline); superlatives varied; library deep-links added.

### Age-band cards + weekend checklists (`32`)
One printable card per band (5–18), each ending with a "Do this weekend" checklist — the finishable artefact promised in `26` §3.

### New 5–10 "First Tablet" band
Band pack added to `19`; masterclass in `29`; per-age card in `32`; positioning + age-band enums updated across `07`/`10`/`14`/`15`/`21`/`23`/`26`. The product now spans **5–18**.

## Still to do (only you can)
- **Record the 10 platform videos** (`28`) + the **5 masterclasses** (`29`). Batch 1 first per `26` §5; the **5–10 "First Tablet"** and **13–14 flagship** are high priority.
- **Make the cards printable** (`27` + `32`) — style to PDF or drop into the gated library/Notion.
- **Fill placeholders** — `Bearings`, `[DATE]`, and the buy/quiz/library links — across all assets.
- **Re-verify every signpost number/URL** on launch day (and quarterly thereafter).

## Content batch 2 (built 20 Jun 2026)
- ✅ **Threat-playbook quick-ref cards (15)** → `34` (12 playbooks + 3 modules; distress signpost on the mental-health ones; real helpline routes; verified vs `18`/`03`).
- ✅ **Seasonal template packs (3)** → `35` (back-to-school reset · exam screen-time · holidays/new-device).
- ✅ **Printable platform cards** → `27_Platform_QuickRef_Cards_print.html` (print/PDF, mirrors `33`).
- 🔧 **Fix:** `27`/`28` had a card/script **scramble** (TikTok failed mid-run → Discord/WhatsApp/Fortnite/YouTube content shifted under the wrong platform headings). Rebuilt by matching each card to its platform **by content** and regenerating the missing TikTok; both files re-verified (heading = content for all 10).
- 🔧 **Mockups wired:** `brand-mockups/readiness-check.html` is now a working quiz (verified); every mockup footer carries the emergency signpost.

## Still not built (optional)
- The "do-it-this-weekend" cross-linked bundle — largely covered by the per-age weekend checklists in `32`.
- Printable HTML for the threat-playbook cards (`34`).

## Review artefacts
- Full content review: `31_Content_Review.md` (5 HIGH / 20 MEDIUM / 41 LOW — **all HIGH + MEDIUM now resolved**; LOW polish optional).
