# 107 — Naming Round 3: Persona & Expansion

**Date:** 5 July 2026 · **Status:** brainstorm + gut screen only — no whois/trademark checks this round (that is round 4)
**Feeds:** 106 (collision screen + Addendum B kill list) · **Scoring rubric:** school-gate / ownability / claims-safety / tone / stretch, each /5, total /25
**Incumbents to beat:** Bearings 22 · Steady 22 · Keepden 21 · Keepside 21

Five lenses were run generatively (≈135 raw candidates). Below: the 40 strongest, the persona verdict you asked for, a scored shortlist against the incumbents, and the five names worth paying for a proper collision screen.

---

## 1. The board — 40 strongest new candidates

### Lens 1 · The Named Guide (a warm human fronts the product)

- **Marlow** — steady old-hand navigator, seen every tide
- **Wren** — small, quick, quietly everywhere; unshowy competence
- **Nell** — no-nonsense grandmother, warm but straight-talking
- **Merryn** — Cornish sea-guide warmth; rare, ownable
- **Marnie** — warm northern aunt, practical, never flustered
- **Hazel** — calm, grounded, herbal-tea-and-a-plan energy
- **Otto** — dependable, methodical, unflappable engineer-uncle
- **Wilf** — gentle old boy, patiently explains things twice
- **Bea** — brisk, kind aunt who just sorts it
- **Fen** — quiet, watchful, knows the lay of the land

### Lens 2 · The Helper Archetype (guidance without watching)

- **Ballast** — steady weight against the household wobble
- **Mainstay** — the thing the family leans on
- **Keel** — keeps you upright, unseen, quietly working
- **Harbour** — gather your bearings, warm British spelling
- **Waypoint** — the next checkpoint on the route
- **Steward** — looks after what's yours, quietly
- **Mooring** — where the household ties up, settled
- **Lantern** — light you carry room to room

### Lens 3 · Family / Home / Hearth (warm, not twee)

- **Kinside** — the whole family, sorted from inside
- **Kinstead** — the family homestead in one word
- **Mantel** — the mantelpiece where order is set
- **Kinly** — kin-ish warmth, modern-soft, teen-safe
- **Kinfold** — kin gathered in one fold
- **Homeward** — the family, oriented home; directional warmth
- **Fireside** — where the family actually talks
- **Threshold** — the doorstep into digital life

### Lens 4 · Growing Up Online (forward, confident, no fear words)

- **Fledge** — they leave the nest ready
- **Wovn** — woven into connected life; sleek, ownable
- **Threadwell** — the thread through family digital life
- **Wayfound** — navigating the new, already found
- **Wingspan** — how far they go once ready
- **Firstlight** — first device, new dawn, handled
- **Throughline** — the calm thread through all of it
- **Setout** — set it out; set out together

### Lens 5 · Coined / Own-the-Category (said once, spelt right)

- **Corla** — coral-soft invented warmth, spells itself
- **Nera** — night-calm stillness; short, premium
- **Lumo** — a small lamp lit for you
- **Kessa** — soft-sea calm, steady, clean spelling
- **Fenn** — low green English land; grounded
- **Wenna** — small Cornish warmth, guide-persona ready

*Honest lens ranking: 1 and 3 produced the contenders; 2 produced one (Ballast); 4 produced one (Fledge); 5 produced colour, not contenders — a pure coinage says nothing to a worried parent at 11pm and a £49 product has no budget to load meaning into an empty word.*

---

## 2. The persona verdict

**Does personifying the product help? Qualified yes — as an execution layer. It does not automatically mean renaming the product.**

**The upside is real:**

- **Memorability.** "We use Marlow" beats "we use [abstract noun]" at the school gate. A human name is the single most repeatable kind of brand a parent passes to another parent.
- **Ownability.** Warm, slightly old-fashioned British first names are cheap to own — the category (Qustodio, Bark, Circle, Norton Family) is uniformly cold and techy. Nothing in the aisle sounds like a person. That is a genuinely open position.
- **The "Ask ___" frame.** "Ask Nell" / "Ask Marlow" does three jobs at once: it frames the product as *consultative* rather than protective (sidesteps every claims-lint landmine); it implies a knowledgeable person, not a promise; and it is the natural verb for the actual moment of need ("just ask Marlow"). It converts anxiety into consultation, which is precisely the product's job.

**Two hard honesty constraints — non-negotiable:**

1. **Not-a-bot.** The product is deterministic: editor-written plans, no live AI in delivery. A named character may be a warm *guide voice* fronting editorial content. It may never be presented, or plausibly misread, as "an AI assistant/agent". Watch the "Ask ___" frame here: with a tech-smooth name ("Ask Ada", "Ask Iris") it collapses into the Alexa/Siri assistant read — which re-implies the bot we don't have. Warm old-fashioned names *break* that read: "Ask Wilf" cannot be mistaken for a chatbot. This is why Ada and Iris are killed below.
2. **Not-a-safety-promise.** The persona is a **guide, never a guardian**. Permitted: "Ask Marlow — the calm household guide. Know what to check, set and say." Banned: "Marlow keeps your kids safe online" (safety claim); "Meet Marlow, the AI that protects your family" (bot + guarantee, double violation). "Safety" lives only in descriptor copy near the mark, never fused to the name or to a persona-does-the-protecting verb.

**Three ways to execute, if pursued:**

- **Route A — the product IS the person.** Legal/brand name is the first name (e.g. *Marlow*). Maximum differentiation and warmth; maximum commitment — the entire library, setup flow and update emails must hold a consistent in-character voice or it reads as a gimmick.
- **Route B — abstract name + mascot guide.** Keep an abstract mark (e.g. *Bearings*) and put a named character inside it fronting the scripts, printables and updates ("your guide, Nell"). Low risk, reversible, additive; captures most of the warmth without betting the brand.
- **Route C — "Ask ___" service framing.** The name lives in a verb lockup ("Ask Marlow") as the tagline/URL pattern, with the bare name as the mark. Strongest consultative framing, but the name must also survive standing alone on a logo — "Bea" and "Peg" lean on the scaffold; "Marlow" and "Wren" carry it solo.

**Recommendation:** Route B is the pragmatic default — Bearings already has a full designed front-end, and a named guide can be layered in without touching the mark. Route A (with C as the lockup, not the legal name) is the more differentiated play and the only version that genuinely changes the game — but take it **only if you are ready to write in character across the whole product, indefinitely**. If that sentence gives you pause, that is your answer: take Route B.

---

## 3. Scored shortlist — new candidates vs incumbents

Gut scores, British ear, same /25 rubric as 106. Collision flags are gut-only this round.

| Name | Lens | School-gate | Ownability | Claims-safe | Tone | Stretch | **/25** | Collision (gut) |
|---|---|---|---|---|---|---|---|---|
| **Marlow** | Guide | 5 | 4 | 5 | 5 | 3 | **22** | maybe — Marlow (Bucks), Marlowe, Philip Marlowe |
| **Kinside** | Family | 4 | 5 | 5 | 4 | 4 | **22** | n |
| **Fledge** | Growing-up | 4 | 4 | 5 | 4 | 5 | **22** | maybe — dev-tooling/adtech uses |
| **Ballast** | Helper | 4 | 5 | 5 | 4 | 3 | **21** | maybe — common nautical word, no dominant brand |
| **Wren** | Guide | 5 | 3 | 5 | 5 | 3 | **21** | maybe — **Wren Kitchens** (big UK ear problem) |
| **Nell** | Guide | 5 | 4 | 5 | 5 | 2 | **21** | n |
| **Kinstead** | Family | 4 | 5 | 5 | 4 | 3 | **21** | n |
| — *Bearings* | incumbent (106) | | | | | | **22** | screened, clear |
| — *Steady* | incumbent (106) | | | | | | **22** | screened, clear |
| — *Keepden* | incumbent (106) | | | | | | **21** | screened |
| — *Keepside* | incumbent (106) | | | | | | **21** | screened |

**Does anything new beat the incumbents? Honestly: no — but three tie them, and one adds something the incumbents cannot.**

- **Marlow (22)** ties Bearings/Steady and is the only name on the whole three-round board that carries a fully-formed persona and the "Ask Marlow" lockup. It ties on score but wins on *optionality* — it is the only candidate that unlocks Route A/C. Note the tension: Marlow only earns its tie if you take the persona route; as a plain abstract mark it is just a pleasant surname.
- **Kinside (22)** is the strongest abstract challenger: cleanest gut-collision profile of any 22-scorer, clears all four hard constraints, and stretches past "online safety" to whole-household digital life better than Keepden/Keepside.
- **Fledge (22)** is the warmest concept on the board (they leave the nest *ready* — the actual end-state a parent wants) but it centres the child's departure rather than the household's steadiness, and the dev-tooling collision needs a real check.
- **Ballast (21)** is telling rather than winning: it is drawn from the same nautical-steady well as Bearings, which confirms Bearings is already drinking from the best part of that well. Ballast is an audition to *replace* Bearings, not join it — you cannot run both.

---

## 4. Top 5 for the round-4 collision screen (full whois/trademark)

1. **Marlow** — the persona play; check Marlowe-adjacent marks, .co.uk/.com, and services classes
2. **Kinside** — strongest clean abstract challenger; check kinside.com (a US childcare-benefits startup used this name — priority check)
3. **Fledge** — check dev-tooling/adtech marks and fledge.co.uk
4. **Wren** — check whether Wren Kitchens' footprint makes UK class coexistence realistic; if not, kill fast
5. **Ballast** — check nautical/marine and fintech uses; ownable-word bet

*Reserves if any of the five die: Nell, Kinstead.*

---

## 5. Kill-list additions (append to the 106 kill list)

**Constraint breaches (not-a-bot / not-monitoring):**
- **Ada** — Lovelace = "mother of computing"; actively signals AI, fights the not-a-bot line; Ada is also an established support-bot brand
- **Iris** — Google Project Iris + crowded health/AI apps; "Ask Iris" reads as a voice assistant
- **Lookout, Marshal, Ranger** — uniform/watching tone; exactly the spyware register we position against
- **Signal** — Signal messenger owns it, and "signal" leans interception

**Obvious brand collisions:**
- **Sage** — Sage plc (UK FTSE accounting software); school-gate collision
- **Robin** — Robinhood + DC sidekick; also reads helper-to-someone-else, wrong hierarchy
- **Remy** — Ratatouille owns it; food-coded
- **Mabel** — granny-cottagecore trend-saturated; ubiquitous, hard to own
- **Compass, Beacon, Anchor, Ally** — deeply crowded trust-category words (property, health, banking); tone fine, ownability dead
- **Ledger** — crypto-wallet tainted
- **Playbook** — SaaS/fitness crowded
- **Sherpa** — crowded metaphor + cultural-appropriation exposure on a family brand
- **Runway** — Runway ML dominates the AI space; for a product with an AI-readiness module this is a hostile shadow, despite scoring 21 on paper
- **Nestwell, Kinnest** (and any Nest- formation) — Google Nest
- **Homestead** — website-builder brand + American-frontier register; *Kinstead* is the clean sidestep
- **Kindred** — heavily used (charity, care, fintech)

---

## 6. If forced to pick today

**Bearings stays the pick — it is whois-screened, scored 22, and already built into the mockups — with the round-3 persona insight applied as Route B (a named guide, e.g. Nell or Marlow, layered inside the Bearings brand); Marlow via Route A is the only rename worth doing, and only after it survives the round-4 collision screen and only if you will write in character forever.**
