# AI Safety Course - Founding Pilot Module Scripts

*Created 2026-06-27. Status: draft scripts for a conservative founding pilot. These scripts cover the lower-risk pilot scope from `72_AI_Safety_Course_PreRevenue_Paid_Pilot_Scope.md`: Modules 1-4 plus a family agreement close. They are not final sales/course scripts until AI legal/safeguarding review findings are run and patched.*

## Pilot Boundary

These scripts teach planning habits only:

- explain the basic safety map;
- keep private information out of AI tools;
- frame AI as a tool, not a person;
- practise verification before trust or action;
- end with the Family AI Safety Agreement.

They do not cover detailed synthetic-media/image-law content, live incident management, platform-specific current settings, or route-card publication. If a parent raises a live concern, stop the teaching flow and use the emergency signpost. [RTE-007]

## Shared Opening

Use this at the start of every pilot session:

> This course is parent education and household planning. It is not legal advice, safeguarding advice, monitoring, crisis help, or an assessment of your child. Please do not share names, school details, screenshots, messages, images, or incident details. If something is happening now, stop the course and use the emergency signpost.

[PRI-003, PRI-004, VBT-004, RTE-007, GAP-013]

## Module 1 - The AI Safety Map

**Purpose:** Give parents four simple facts that explain why household AI rules are needed.

**Claim IDs:** HAW-001, HAW-002, HAW-003, HAW-004, ORW-001, ORW-002, PRI-002, VBT-001.

**Time:** 20-25 minutes.

### Learning Outcome

By the end, a parent can explain:

- plausible does not mean true;
- AI is a tool, not a person;
- convincing media still needs source and context checks;
- private inputs can create data exposure.

### Script

**1. Name the worry**

Parents do not need to become AI experts before they set rules at home. The useful question is simpler: what does this technology change about trust, privacy, effort, and judgement?

The answer for a household is four habits:

1. Think before use.
2. Tool, not person.
3. Private stays private.
4. Human check before trust or action.

**2. Teach the safety fact**

Generative AI can produce text, images, audio, and video that looks confident or convincing. But the same system can be inaccurate, out of date, biased, fabricated, or missing context. So the safety habit is not "avoid all AI". It is "pause before trusting or acting."

AI also uses person-like language. It can sound warm, certain, or interested. That does not make it a friend, therapist, judge, or secret-keeper. The family rule is: people support people; tools produce outputs.

**3. Use an invented example**

Example:

A child says, "AI gave me a great explanation for homework, and it gave me a source." The useful parent response is not panic or blind trust. It is: "Good, now open the source. Does it really say that? How old is it? What does your school allow for this work?"

**4. Make the household decision**

Write the four habits into the Family AI Safety Agreement:

- We think before using AI.
- We do not treat AI as a private person.
- We keep private things out of tools.
- We check before believing, sharing, buying, submitting, or acting.

**5. Close with route boundary**

If a parent asks about a real incident, do not discuss details in the group or tool. Say:

> I cannot advise on a live situation here. Please use the emergency signpost or the appropriate qualified route.

### Take-Home Task

Open the Family AI Safety Agreement builder and tick the four baseline clauses.

## Module 2 - Private Stays Private

**Purpose:** Turn privacy from an abstract idea into concrete household categories.

**Claim IDs:** PRI-001, PRI-002, PRI-003, PRI-004, PRI-005, HAW-004.

**Time:** 20-30 minutes.

### Learning Outcome

By the end, a parent can name what counts as private information and set a default no-private-data rule for AI tools.

### Script

**1. Name the worry**

The privacy risk with AI is not only "do not type your full name." Children and teens can put a lot of revealing context into a tool without realising it: school details, family conflict, location, routines, account details, private messages, images, voice, health, schoolwork, and live-incident details.

**2. Teach the safety fact**

Families should assume private information does not belong in casual AI use unless an adult has checked the purpose, settings, terms, and need.

This course does not ask families to upload children's real prompts, images, voices, schoolwork, chats, screenshots, or incidents. That is a design boundary, not a legal-compliance claim.

**3. Use an invented example**

Example:

A child wants to paste a friendship problem into a chatbot because they want help wording a reply.

A stronger household rule is:

- do not paste the real message;
- do not include names, school, handles, locations, or private details;
- if practising wording, use a made-up example;
- if the real worry is upsetting, coercive, threatening, or already happening, bring it to a trusted person or qualified route.

**4. Make the household decision**

Create two lists:

Never enter:

- names;
- school;
- location;
- contact details;
- account details;
- private images or voice;
- private messages;
- health or family conflict;
- live-incident details.

Ask first:

- schoolwork;
- friendship dilemmas;
- photos;
- anything involving another person's private information;
- a new AI tool or account.

**5. Close with route boundary**

The course can help set privacy habits. It does not process private child content or live concerns.

### Take-Home Task

Print or save the Private Stays Private card and add the "never enter" rule to the Family AI Safety Agreement.

## Module 3 - Tool, Not Person

**Purpose:** Help parents set boundaries around companion-style and relationship-like AI use without panic or diagnosis.

**Claim IDs:** AIC-001, AIC-002, AIC-003, AIC-004, AIC-005, HAW-002, ORW-004.

**Time:** 25-30 minutes.

### Learning Outcome

By the end, a parent can explain why companion-style AI needs different boundaries from utility AI and can use watchpoints as prompts for conversation, not diagnosis.

### Script

**1. Name the worry**

Some AI tools are used like utilities: help me brainstorm, summarise, quiz myself, or check a draft. Others are designed to feel like a character, companion, or relationship. Those need a different family conversation because children may treat them as private, emotionally important, or more trustworthy than they are.

**2. Teach the safety fact**

The household rule is:

> AI can generate a response, but it does not know, care for, or understand a child in the way a person can.

So AI is not:

- a private friend;
- a therapist;
- a judge;
- a secret-keeper;
- a replacement for trusted people.

Use watchpoints only as calm conversation openers, not as a way to assess a child. For example:

- "Have you found yourself using it when you feel upset?"
- "Does it ever feel easier to talk there than to a person?"
- "Are you using it late at night or keeping it secret?"
- "Would you know who to go to if it said something upsetting or risky?"

These are prompts for a parent conversation. They are not a diagnosis, score, or profile.

**3. Use an invented example**

Example:

A teen says, "The AI character understands me better than people."

A calm parent response:

> I can see why it feels easier to talk there. I am not angry. But an AI tool is not a private person and it is not responsible for you. If something feels heavy, secret, upsetting, or risky, it comes to a trusted person.

**4. Make the household decision**

Add three boundaries:

- AI is not a private friend or therapist.
- Emotional worries go to trusted people.
- AI use happens at agreed times and places, not secretly late at night.

**5. Close with route boundary**

If a tool encourages secrecy, sexualised interaction, self-harm, eating-disorder content, threats, coercion, or isolation, stop the interaction and use qualified support or emergency routes.

### Take-Home Task

Add the Tool, Not Person clause to the Family AI Safety Agreement and choose one trusted-person route your child can use.

## Module 4 - Verify Before Trust

**Purpose:** Teach verification as a pause habit before belief, sharing, spending, submitting, or action.

**Claim IDs:** HCM-001, HCM-004, VBT-001, VBT-002, VBT-003, SCF-001, SCF-002, ORW-003.

**Time:** 25-30 minutes.

### Learning Outcome

By the end, a parent can teach the four verification questions and explain that verification supports judgement but does not produce a safety verdict.

### Script

**1. Name the worry**

AI can sound fluent and confident even when it is wrong. That matters for homework, money, health-ish claims, shocking images, urgent requests, and anything a child might share quickly.

**2. Teach the safety fact**

Verification means checking before believing, sharing, buying, submitting, or acting.

The four questions:

1. Who says this?
2. What evidence is there?
3. How current is it?
4. What happens if it is wrong?

This is not a promise that the answer becomes safe. It is a habit that slows down deception and overconfidence.

**3. Use invented examples**

Example 1: AI gives a homework quote.

Response:

> Open the source. Does it exist? Does it say that? Is this allowed for this task?

Example 2: A familiar-looking account asks for a code or urgent help with money.

Response:

> Do not reply in the same thread. Check through another trusted route before anyone acts.

Example 3: A dramatic image or voice note spreads quickly.

Response:

> Pause before forwarding. Check source and context. If it involves threat, sexual content, coercion, or immediate danger, use a qualified route rather than investigating through the course.

**4. Make the household decision**

Add the Verify Before Trust clause:

> Before we believe, share, buy, submit, or act on AI output or urgent messages, we check source, evidence, date, and consequence.

For schoolwork:

> School policy comes first. Try first, ask before assessed work, check sources, and do not submit hidden AI-authored work as your own.

**5. Close with route boundary**

The course does not decide whether a real message is safe, a scam, grooming, or a deepfake. It helps you pause and choose what to check or where to route.

### Take-Home Task

Print the Verify Before Trust sheet and use it on one low-stakes example this week.

## Family Agreement Close

**Purpose:** Turn the four modules into a household document.

**Claim IDs:** PRI-002, VBT-001, AIC-005, RTE-007.

### Script

The agreement is not a contract and not a monitoring tool. It is a short way to make expectations visible before there is pressure.

Start with eight clauses:

1. We think before using AI.
2. Private information stays out of AI tools unless a parent/carer has checked the purpose, settings, and need.
3. AI is a tool, not a person.
4. Worries, secrets, threats, or upsetting content move to trusted people.
5. We check source, evidence, date, and consequence before trust or action.
6. School policy comes first.
7. Unknown person plus secrecy, pressure, gifts, platform switching, threats, or sexualised contact means stop and show a trusted adult.
8. If something is already happening, we stop the course/tool and use the route.

Optional clause for older children and teens:

> We review this agreement after new tools, school-policy changes, or a Stay Current update.

### Closing Words

The goal is not to make every possible situation predictable. The goal is to make the first family response calmer, clearer, and less dependent on panic or guesswork.

## Pilot Feedback Questions

Ask only about clarity and usefulness:

1. Which rule felt easiest to explain at home?
2. Which rule still feels unclear?
3. Which asset would you actually use?
4. What wording felt too strong, too soft, or confusing?
5. What nearly stopped you buying or joining the pilot?

Do not ask whether the course made a child safer or reduced harm. That would be an unsupported outcome claim. [GAP-001]
