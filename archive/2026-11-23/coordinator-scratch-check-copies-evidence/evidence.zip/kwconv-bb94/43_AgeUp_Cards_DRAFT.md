# Age-Up Cards (DRAFT)

> These are unreviewed first drafts produced 2026-06-21. Every setting path, figure and link is marked for fact-check before publishing.


---

## Age-Up Cards — What Changes at Each Birthday Boundary

**DRAFT — fact-check every setting path, figure and link against the live source before publishing.**

Last drafted: 2026-06

# Age-Up cards — what changes at each birthday boundary

Most of online safety is steady work: the same calm habits, repeated. But a handful of birthdays genuinely shift the ground — a new app becomes relevant, a control you set years ago stops fitting, a conversation that was premature is suddenly overdue. These cards mark those moments. Each one is short on purpose: what actually changes around **7, 11, 13 and 16**, the posture shift that goes with it, the new conversation to have, and the settings worth revisiting.

They are anticipatory, not alarming. None of these boundaries is a cliff-edge — children develop at their own pace, and a birthday is a prompt to look again, not a deadline. Treat each card as a fifteen-minute review you do *around* the birthday, not on it.

A note on the ages. UK platform rules cluster around **13** (the minimum age for most mainstream social apps) and **18** (when child-specific reporting routes hand over to adult ones). The 7 and 11 boundaries are softer — they track school and developmental stages more than any rule. We have chosen four prompts that map onto the real transitions parents tell us about; your child may meet them earlier or later.

---

## Approaching 7 — from "in the room" toward "in the same house"

**What genuinely changes.** Around this age many children move from a fully shared family tablet to something a little more their own, and from co-watching everything to playing or watching alongside you while you do something else nearby. Reading opens up independent searching and typing. Roblox, Minecraft and YouTube Kids tend to feature more; school may introduce class apps or logins.

**The posture shift.** Still firmly **co-use** — you are close by, controls stay front-loaded — but you are starting to widen the leash slightly: same house rather than same sofa. The aim is to keep the device a shared, shared-room thing while letting a bit more independence in.

**The new conversation.** The first real version of *"tell me if anything is weird or scary — you won't be in trouble."* At 5 this is a simple rule; around 7 it can become a genuine two-way habit, because they can now describe what they saw. Reinforce it warmly and often. (See `/library/conversations`.)

**Settings to revisit.**
- Check **Apple Screen Time** or **Google Family Link** still fits — downtime, app limits and age/content ratings may need nudging up a notch as they take on new apps (`/library/platforms/apple-screen-time` · `/library/platforms/google-family-link`).
- Confirm **Ask-to-Buy / purchase approval** is still on now that they can type and tap independently.
- Recheck **YouTube Kids** content level and that autoplay is still off; the "older" content setting may now be tempting but is worth holding [verify the current YouTube Kids content-level labels].
- Confirm **SafeSearch** and the **broadband adult-content filter** are still active at the network level.

---

## Approaching 11 — the secondary-school step-up

**What genuinely changes.** Starting secondary school is the single biggest jump in this whole journey. A **first smartphone** often arrives around now; WhatsApp and group chats become the social backbone; gaming widens. Children walk to school, message friends and want more independence than they can yet self-manage. Per Ofcom's *Children and Parents: Media Use and Attitudes* research, smartphone ownership rises sharply across these years [verify the latest figure and report year before publishing].

**The posture shift.** Still **co-use**, but more deliberate: you are co-using a phone now, not just a tablet, and the gap between their desire for independence and their self-control is at its widest. Honest birthdays still matter — keep them, because age-specific protections depend on the real date of birth.

**The new conversation.** The **new-app check** becomes essential: talk any app through *before* it's downloaded, not after. Pair it with an early, plain version of the **strangers / who-messages-you** conversation. (See `/library/conversations`.)

**Settings to revisit.**
- Set up the **device layer on the new phone** before handover — Screen Time or Family Link with limits, downtime, Ask-to-Buy and content filters, locked with a passcode they don't know.
- Decide **where the phone charges overnight** (outside the bedroom) and set this as the norm from day one — it is far easier to start than to claw back later.
- Reconfirm **SafeSearch** and the **broadband adult-content filter** now they have a device that travels.
- If they use Roblox, recheck **parental controls and the spend cap** (`/library/platforms/roblox`). Roblox introduced age-based account types in 2026 — **Roblox Kids (5–8)** and **Roblox Select (9–15)**, announced 13 Apr 2026 and rolled out globally by mid-June 2026 — with curated catalogues, communication off by default for younger children, facial age-estimation, and parental controls extended through age 15. Check the official help page for the current menus.

---

## Approaching 13 — the threshold year

**What genuinely changes.** Thirteen is the minimum age for most mainstream social platforms [verify], so **Instagram, Snapchat and TikTok** can arrive legitimately and usually arrive fast. This is also the developmental peak of peer-influence and reward-seeking, which is why it is the most consequential boundary in this set. Identity and self-presentation intensify.

**The posture shift.** From co-use to **co-set**: less "here are the rules" and more "let's agree them together." The most protective thing you do here is not a setting — it is staying the calm, non-blaming person they would come to.

**The new conversation.** Two arrive together. **Sextortion — named plainly and early**, so it is not a shock if it ever lands. The NCA highlights financially-motivated sextortion as a significant and growing risk, hitting teenage boys particularly hard — its March 2025 national campaign specifically targeted boys aged 15–17. And the **cornerstone** — *"come to me, you won't be in trouble"* — moves from a young child's rule to the line that does the heaviest lifting through the teen years. (See `/library/conversations`.)

**Settings to revisit.**
- Make sure the **real birthday** is set on every app — most teen protections key off it.
- **Snapchat:** turn on Family Centre and **Ghost Mode**, and set Contact-Me to *Friends only* (`/library/platforms/snapchat`) [verify current control names].
- **Instagram:** link a **Teen Account** for supervision; confirm the profile is private with strict message defaults (`/library/platforms/instagram`) [verify].
- **TikTok:** set up **Family Pairing**; confirm under-16 no-DM and private defaults (`/library/platforms/tiktok`). TikTok moves menus often — check tiktok.com/safety if a path has shifted [verify].
- Keep the **device-layer limits** from age 11 running, and the phone-out-of-the-bedroom-at-night habit.

A handover note, not an incident note: if something does go wrong at this age, the routes are **999** in immediate danger, **CEOP** (ceop.police.uk) for online sexual pressure or grooming, **Report Remove via Childline** (childline.org.uk/remove) for a nude image of an under-18 shared or threatened, **NSPCC 0808 800 5000** for general worry, and **Childline 0800 1111** for the child. Keep these where you can find them fast; do not improvise a response.

---

## Approaching 16 — toward standing back

**What genuinely changes.** Use becomes heavier, more private and more woven into romantic and social life — Snapchat, Instagram, Discord, group chats. Self-control is catching up but reward-sensitivity is still high. They are increasingly self-governing, and approaching 17–18 they will start to age out of child-specific protections.

**The posture shift.** From co-set to **coach**: supervision *with* conversation, not control. You hand over day-to-day management and keep a backstop, rather than holding the controls yourself.

**The new conversation.** **Scams and money — including money-muling** ("never let anyone use your bank account for a fee; it's a crime, in your name"), and **mistakes and repair** — that they can tell you about a wrong turn and you will help fix it rather than punish it. This is also the moment to begin a light **digital-footprint** conversation ahead of jobs and applications. (See `/library/conversations`.)

**Settings to revisit.**
- **Hand the day-to-day screen-time tool to them** while keeping a parental backstop at the device layer — and agree a weekly five-minute review together rather than spot-checks.
- **Review privacy and contact settings *with* them, not over them** — who can message and find them.
- Set up **Discord Family Centre** if they use it — visibility of who and where, never message content (`/library/platforms/discord`) [verify].
- Keep **purchase controls** on as a scam and money-muling backstop.
- Begin shifting toward **account security** — two-factor authentication and unique passwords, following NCSC guidance — which becomes the headline at 17–18.

Menus move often; if a path has changed, the platforms' own family-safety pages carry the current routes [verify].

---

## How to use these cards

- Treat each card as a **prompt around the birthday**, not a hard deadline — children meet these stages at their own pace.
- The **review takes about fifteen minutes**: read the card, have the one new conversation, and revisit the listed settings against the live platform help pages.
- The **cornerstone line carries through every boundary** — it never expires, and it is the thread that links all four cards.
- For the full, age-tuned detail behind each boundary, see the relevant **age-band pack** and **quick-reference card** in the System.

*Cross-references: full settings paths in `/library/platforms`, full conversation scripts in `/library/conversations`, signposting routes at `Bearings/emergency`.*

---

## Sources

- Ofcom — *Children and Parents: Media Use and Attitudes* (annual report; for age-related device-ownership and platform-use trends). ofcom.org.uk [verify latest edition and figures]
- CEOP Education / NCA — guidance for parents and carers on online sexual abuse, grooming and financially-motivated sextortion. ceop.police.uk and nationalcrimeagency.gov.uk
- Childline — Report Remove (with the IWF) for nude images of under-18s. childline.org.uk/remove
- Internet Matters — age-by-age guidance and parental-controls setup guides. internetmatters.org
- NSPCC — Online Safety advice and helpline (0808 800 5000). nspcc.org.uk
- UK Safer Internet Centre / IWF — reporting routes for child sexual abuse imagery. saferinternet.org.uk · iwf.org.uk
- NCSC — Top tips for staying secure online (account security, 2FA, passwords). ncsc.gov.uk
- gov.uk — Online safety and Online Safety Act guidance for families. gov.uk
- Platform family-safety help pages — Apple Screen Time, Google Family Link, Snapchat Family Centre, Instagram Teen Accounts, TikTok Family Pairing, Discord Family Centre, Roblox parental controls, YouTube Kids (for current menu paths and control names — fact-check all paths against these before publishing).

