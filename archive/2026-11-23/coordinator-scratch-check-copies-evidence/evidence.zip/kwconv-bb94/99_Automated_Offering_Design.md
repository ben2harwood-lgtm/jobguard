# 99 — The Automated Offering: Design Blueprint

**For:** Ben · **Date:** 5 July 2026 · **Status:** Decision blueprint — the founder has decided: zero per-customer human labour, anywhere. This memo does not re-argue that decision (file 97 did; the door is closed). It answers the question that follows from it: **could a fully self-serve Keepwise still be worth the money, and what tools and resources make it worth it?**
**Scope rule honoured:** fixed, batched editorial labour (keeping content current) is in-scope. Per-customer labour of any kind — review, calls, voice notes, question credits — is out, permanently, at the base tier.
**Stance:** adversarial, no flattery. Every external figure sourced; inference flagged **[INF]**. UK, GBP. Where the automated product is genuinely weaker than the reviewed one, it is said in one plain sentence, each time.
**Naming note:** "Keepwise" is used throughout per files 95–98; the brand work (file 25, memory) says "Bearings". Reconcile once, everywhere, before the offer page ships.

---

## 1. The direct answer

**Conditionally yes.** The fully automated product can honestly be worth the money at **£49 one-off + £29/yr optional "Stay Current" renewal** — but only if three conditions hold, and it can **never** claim a human looked at anyone's family.

1. **The tools must do things, not tell things.** A parent pays £49 over Internet Matters' free personalised toolkit for guided Settings Checkup wizards with dated completion records, an instant app-checker, age-up drills and a personal change-watch — not for a document. If the product is experienced as a document, it is a £19–29 product losing a fight with free (files 95–97).
2. **The Changed-For-You Digest must carry the renewal.** It is the one asset that is structurally impossible for both ChatGPT (won't proactively tap you) and static free content (can't personalise the diff) — file 98's judged idea bank named it the best zero-human asset. If it can't hold £29/yr, the kept-current engine has no funding.
3. **The funnel must widen 2.5–3×.** At £49 the product earns roughly £45 net per customer against the reviewed product's £73–£110. At equal volumes the automated business makes less money — that sentence is not negotiable and Section 4 shows it. The pivot pays only because the impulse price, instant delivery and zero serve-cost open channels (paid social, SEO moments-of-need) the £99 reviewed product structurally could not use.

**What it can never claim:** "reviewed for you", "a person checked your plan", "human-reviewed", or anything a reasonable parent could read as "someone looked at my family". The honest claim — fully substantiable — is: **"written and checked by an editor, matched to your household instantly."** The two lines currently live on `app/pricing/page.tsx` ("a plan checked by a real person"; line 234: "No plan is sent until a person has checked it") are false in this scenario and must be deleted on day one.

**The honest one-line verdict:** it can be worth the money at £49 if — and only if — the tools do things a free clone can't; it has a higher ceiling and a lower floor than the reviewed business; and the architecture below keeps a paid human tier boltable later without rebuild, so this is a different product with a socket where a person could go, not an amputation.

---

## 2. The product: Block-Assembly Keepwise

### 2.1 The architecture in plain English

Every sentence a customer can ever receive is written, source-checked, dated and published by a human editor **once**, as a tagged content block — a fixed cost, paid up front. At runtime, deterministic software — **no LLM anywhere in the delivery path** — takes the 25-question diagnostic (age bands × platforms × devices × concern areas × household context; no child-identifiable data — the optional child-first-name field from `01_Readiness_Report_System.md` §2.2 Q3 is deleted from the form entirely) and selects, orders and splices the right published blocks into a household plan, delivered in under two minutes.

Personalisation is achieved by **selection and sequencing, never generation**. The only variables ever interpolated into text are declared facts: age band, ticked platform and device names, sibling count. No AI writes, rewrites or improvises a single word of advice at runtime. This is Internet Matters' free-toolkit architecture executed at roughly 30× the depth, with provenance — which is exactly the fight files 95–97 said structure, UK-specificity and currency must win, because the words alone cannot.

**The authoring trap, avoided:** the diagnostic axes multiply to ~2,400 combinations (5 age bands × 19 platforms × 25 concerns). Nobody authors combinations. The design rule is that **each block varies on at most one axis** (usually age), and combining is the assembler's job. That collapses the authoring bill to **~220 blocks (range 200–280)** across ten classes: age-band skeletons, "your first three moves" priority verdicts, platform blocks (~3 age tiers each), concern blocks, device/environment blocks, conversation starters, "find this out" actions (a Don't-know answer never raises an exposure band — it becomes a task, preserving spec §7.5.1's rule), "don't panic about" de-escalation blocks, the locked crisis constant, and library/renewal pointers.

**Raw material:** the 51 fact-checked MDX items in `content/` (19 platform guides, 25 playbooks, 5 age-band packs, conversation and currency layers) supply an estimated 80–85% of the words. Authoring is slicing into second-person plan voice, tagging and source-stamping — not writing from scratch.

**The bill, honestly [INF]:** ~40 minutes all-in per block (AI-drafted slice, human edit, source-check, date-stamp, tag, lint) × 220 blocks ≈ 150 hours, plus taxonomy design, assembly-rule spec and adversarial QA of ~20 assembled persona plans (three kids across opposing bands; all-Don't-know; single platform + high concern) ≈ 45 hours. **Total ≈ 180–220 founder-hours — about five months at 10 hrs/wk, or six weeks full-time.** Phaseable: an MVP pool of ~140 blocks (4 bands × 12 platforms × 12 concerns) ships in ~110 hours and covers ~90% of real households [INF], with long-tail blocks authored from live diagnostic data ("12% of buyers tick Twitch — author its 13–15 block next").

**Maintenance:** every block carries a `review_by` date (platform blocks 6-monthly, concern blocks annually, crisis constant monthly per file 84's protocol). ~450–550 block-reviews/yr × 10–15 min ≈ **110–140 hrs/yr of batched editorial** — inside file 96 §2.3's currency-layer envelope, and it *replaces* that layer rather than adding to it, because block refresh IS the currency layer now.

### 2.2 Assembly rules (deterministic, auditable)

1. Answers → six exposure domains → Lower/Moderate/Higher per `01` §2.3's transparent scoring (already specified and defensible).
2. Domain levels + declared platforms/devices → block selection; domain ranking → ordering; the top-3 actions are the highest-level domains' priority blocks.
3. Multi-child households get one plan, sectioned per band via splice connectors — the Whole-Household frame (file 98 #4) survives automation intact at zero marginal cost.
4. Every plan embeds the crisis constant verbatim, a de-escalation section, and deep-links into the gated library.
5. **The assembler may only select blocks with `status='published'` and `review_by` in the future.** A stale block is auto-withdrawn, its slot filled by a designated evergreen fallback, and the editor gets a queue alert. No stale sentence can ship.

### 2.3 The locked crisis-signpost constant

The `SIGNPOST` block (`lib/plan-prompt.ts` line 45: 999/101, CEOP, Report Remove, NSPCC 0808 800 5000, Childline 0800 1111) becomes a **single hash-pinned constant**: hand-verified against files `03`/`84`, hash-checked at build time and again at render time; any diff fails the deploy. No template, no interpolation, no model within a mile of it. This is the direct answer to commit `7df540c` (the wrong-crisis-number incident file 97 §3 documents): the failure mode "an LLM emits a plausible-but-wrong helpline at volume" becomes *architecturally impossible*, not procedurally discouraged.

### 2.4 Spec 21 §7.5 — the replacement rule, verbatim

The old per-plan publish gate is not deleted; it moves upstream from plan to block:

> **§7.5 (revised) — Block-gated plan assembly (deterministic, human-published content).**
> 1. Every content block requires an admin **Publish** action before entering the assembly pool: editor reads, edits, passes content lint (§10.3), confirms sources and sets `review_by`, then publishes. The publish event writes an immutable log row (block id, version hash, author, checker, sources, timestamp).
> 2. The assembler is deterministic. **No path may deliver a plan containing any block that is not `status='published'` with `review_by` in the future, and no path may generate, rewrite or interpolate advice text at runtime.** Permitted interpolation: declared age band(s), ticked platform/device names, sibling count only.
> 3. The crisis-signpost block is a locked constant: hash-verified at build and delivery; changes require manual re-verification against `03`/`84` and a fresh publish.
> 4. Every delivered plan writes an **assembly log** (plan id → ordered block-version hashes → timestamp), sufficient to reconstruct exactly what any customer received.
> 5. This replaces the per-plan admin publish. It remains a guardrail, not a preference — and changing *this* rule requires the same safeguarding re-review the original did. The `plans.status` state machine retains an `in_review` state so a paid human-review tier can later insert a review step between assembly and delivery **without rebuild**.

### 2.5 What the parent sees

Two minutes after the 25 questions: a plan titled for *their* household ("Your plan: a 9-year-old and a 13-year-old, Roblox, YouTube, WhatsApp, first phone this year"), opening with their top three moves and why, platform sections only for apps they ticked, a "don't panic about" section that visibly reflects what they said they'd already covered, conversation starters, the locked emergency page, and — the honesty signature — **every section footed with "Written by [editor], checked [date], sources: [NSPCC/Ofcom/…]"**, plus one line up top: *"How this plan was made: our editor wrote and checked every block; software matched the right ones to your answers. No AI wrote any of this."* The date-stamps and named sources do the trust work the reviewer's note used to do.

### 2.6 The worth-it tool bundle, ranked by value-per-build-effort

Build effort = specification + iteration hours for an AI-assisted non-technical founder, not hand-coding. Running costs near-zero throughout: no runtime LLM; Vercel + Supabase + Resend + Stripe ≈ £0–70/month to low thousands of customers (verify current tiers before commit [INF]); Stripe 1.5% + 20p UK cards.

| # | Tool | What it does / honest claim | Why it beats free | Build [INF] |
|---|---|---|---|---|
| 1 | **Instant Household Plan** (§2.1) | The hero. "Editor-written, matched to you in minutes, dated" | 25 questions deep vs the free clone's ~10-minute questionnaire; prioritised sequencing, not a resource pack | ~60–80 hrs engine (authoring in §2.1) |
| 2 | **Settings Checkup wizards** (top 10 platforms/devices) | Click-by-click guided setup from `16`/`27`, ending in a **dated completion record** — "checked and completed [date]", never "pass"/"safe" | A tool that *does*; free content tells. Completion dates feed the re-check | ~25 hr framework + ~2 hr/flow ≈ 45 hrs |
| 3 | **Changed-For-You Digest** | Monthly email diffing published block versions against *your* declared bands/platforms; most months honestly "nothing changed for your household". Never "we noticed on Snapchat" | File 98's judge: "structurally impossible for ChatGPT". Automated after build; editorial input = block refreshes already being done | ~30–40 hrs |
| 4 | **New App? Ask Keepwise** | Type an app → calm one-screen brief tuned to age band, from the human-maintained library (~50 UK apps); unmistakable "not yet covered" fallback; **no verdicts, ever** | Sits on the exact "is this OK?" moment; also an SEO surface | ~20 hr build + ~40 hr authoring 30 short app-cards |
| 5 | **Family Agreement builder** | Already in spec (§7.10); clause menus per band, printable PDF, stores nothing about the child | Tangible artefact on the fridge | ~10 hrs to finish |
| 6 | **Age-Up kits + First-Phone 72-hour sequence** | Trigger from declared band + parent-declared "first phone coming" (no DOBs): drill pack + 3-email setup sequence | First phone = the highest-WTP moment in the market (file 98 #9) | ~25 hrs (content exists: `32`/`43`) |
| 7 | **AI-homework family-policy generator** | Clause-menu generator from the `ai-schoolwork` playbook + file 53 | Timely; nobody free does it well | ~15–20 hrs |
| 8 | **Quarterly re-check** | Score-free diagnostic diff: "since March: 2 of your blocks updated; your eldest's band changes next year; 3 checkups not done" | Renewal heartbeat; reuses digest engine | ~15 hrs |
| 9 | **Printables pack** | Fridge emergency card (`03`, every link hand-verified), quick-ref cards, checklists | Tangibility without postage | ~5 hrs bundling |

**The "worth £49" bundle — seven things from one diagnostic:** Plan + Checkup wizards + Digest (year one bundled) + App lookup + Agreement builder + First-phone/Age-up kits + Printables. Incremental build over the engine: **~150–170 hrs**; whole product ~350–400 founder-hours. The arithmetic a parent runs at the offer page: one instant personal plan + guided setup of every device in the house + a year of watching + an app-checker in the pocket ≥ £49; a document alone never is. **Design onboarding so at least three tools are used in week one** — the £49-was-obvious feeling comes from the second and third tool, not from the plan.

**What dies with the human:** the posted plan with a handwritten line, the voice note, the one-question credit, the £149 call tier, the "not a chatbot" wedge *as positioning*, the annual human re-review renewal framing, and plausibly the £650 Concierge (founder call — per-customer labour by definition). Section 6 disposes of each.

**Guardrails unchanged:** no monitoring, no child data, no child-facing surfaces, no user-to-user features, signpost-only emergencies, no safety guarantees, no AI judging real content.

---

## 3. The selling sentence and the claims table

**The new #1 selling sentence:**

> **"Answer 25 questions about your household — get your family's plan for online life in two minutes: every word written, checked and dated by our editor, matched to your children's ages and apps, and kept current all year."**

Proof stack directly beneath it: a real sample plan · the public changelog · a dated block-footer screenshot · "Meet the editor" page (a visible human as *author* — fixed cost, recovers a slice of the person-premium without per-customer labour) · the seven tools as icons · 14-day guarantee. The page sells **instant + editor-made + kept-current + tools that do things**; it never mentions review, checking-for-you, or safety outcomes.

| **TRUE and usable** | **BANNED** |
|---|---|
| "Every word written and checked by our editor — nothing in your plan is AI-generated" | "Reviewed for you" / "a person checked your plan" / "human-reviewed" |
| "Matched to your household in minutes" | Anything implying individual attention to *your* family |
| "Dated and sourced, section by section — see the changelog" | "Safe" / "protected" / "pass" / "certified" / "safeguarding review" |
| "Built on NSPCC, Ofcom, Internet Matters and gov.uk guidance, organised for your family" | "We monitor" / "we noticed" (the digest watches the *public landscape*, never the child) |
| "We only email you about changes that touch your ages and apps" | The "not a chatbot" wedge as positioning (the authorship line is permitted copy; implying a person looked at your family is not) |
| "Meet the editor" (authorship, not review) | Safety outcomes of any kind; "whatever launched last week" |

**ASA substantiation record (CAP 3.7):** two immutable tables held *before any ad runs* — the **block authorship log** (block id, version hash, author, checker, sources, checked date, review-by) and the **per-plan assembly log** (which block versions composed which plan, when). Together they prove every sentence any customer ever saw had a named human author, a check date and cited sources. The consumer-understanding test is the discipline: "editor-checked" must always sit next to "matched by software", never in a sentence a reasonable parent could read as "someone read my answers."

---

## 4. The economics

### 4.1 The anchor moved — and it matters

File 97's price ceiling was pinned to Huckleberry's algorithm-only $29.99 one-off. **That one-off no longer exists.** As of July 2026 Huckleberry is subscription-only: Free / Plus $68.88-yr / Premium $119.88-yr, with expert-designed plans folded into Premium ([huckleberrycare.com/pricing](https://huckleberrycare.com/pricing)). The best comparable for "algorithmic child-help sold once" has migrated to recurring — which supports the hybrid structure below, not the bare one-off file 97 leaned on.

### 4.2 Recommended structure: £49 one-off + £29/yr "Stay Current" renewal

Three candidates were judged; the hybrid wins:

- **£49 one-off, no renewal** — rides subscription fatigue (41% of consumers report it; UK ~10M unwanted subs, £1.6bn/yr) but **kills the kept-current engine's funding**: the digest, the one structurally uncopyable asset, is a recurring service with nothing recurring to pay for it.
- **Pure £39–49/yr subscription** — matches where the category now sits (Huckleberry $68.88/yr, Kinedu ~$60/yr, Wonder Weeks ~$34.99/yr) but **the purchase trigger is a one-off moment, not a habit**: a parent buys when the first phone lands or Year 7 looms, and asking for an ongoing commitment at that anxious moment adds friction exactly where you want none. RevenueCat 2025: annual-plan month-1 cancellation ~30%, retention falls as price rises.
- **£49 + £29/yr hybrid** ✅ — the one-off matches the trigger and gives the anxiety purchase what it wants (*closure*, not a standing reminder of an open wound); the renewal is opt-in, sold to a warm customer *after* the digest has proved itself ("most months: nothing changed — enjoy the quiet; then Snapchat moved a setting on your 14-year-old's app and we told you first"). £29 < £49 reads as fair because it genuinely is less. Downside bounded: if nobody renews you still have a healthy one-off business; the renewal is upside, not load-bearing for survival. And a one-off base + renewal ladder leaves obvious room above it for the future human tier.

**Why £49 and not £29:** the £29 anchor is gone (§4.1); file 96 §11 already priced the self-serve tool-bearing product at £49 "with the full tool pack visible — do not bury at £29"; Gumroad's how-to premium band runs $19–49 with a ~$51 average sale. **Launch £39, test £49 with the full seven-tool bundle visible at checkout; £49 is the ceiling, not the floor** — above it collides with Qustodio Complete at £75.95/*yr* and reads absurd.

**What the £29/yr honestly buys (Keepwise Current):** (a) the Changed-For-You Digest, monthly; (b) the quarterly re-check; (c) age-up triggers — when your declared band rolls over, the kit and refreshed plan sections arrive; (d) the **living plan** — re-renders against current published blocks any time, "plan current as of [today]"; (e) continued app-lookup and wizard access; (f) 4–6 batched "house briefs" a year when a genuinely national story breaks (fixed editorial, 2–4 hrs each, one-to-many — the one file-98 LATER item that survives because it is batched; promise "a calm brief when a big story breaks", never a 48-hour contract). What it may **not** be called: a re-review, an MOT, or an annual check by anyone.

### 4.3 Unit economics at £49

| Price | Stripe fee (1.5% + 20p) | Net after ~6% refunds |
|---|---|---|
| **£49** | £0.94 | **~£45.20** |
| £39 | £0.79 | ~£35.90 |
| £29 | £0.64 | ~£26.60 |

No £13–22 per-plan review cost — contribution *rate* rises to ~92% (vs ~74% reviewed), but contribution *per sale* falls: ~£45 on £49 vs ~£73 on £99. **Break-even CAC ≈ £45 on the one-off alone; ≈ £52 with modest renewal LTV (25% renew once [INF]).** For the first time in this project, that puts paid acquisition in reach: the reviewed product's ceiling was £32 at £49.

**The fixed-cost cliff did not move.** The kept-current promise costs ~£25k/yr at arm's length [INF, file 96 §2.3]: at 300 customers/yr that is £83 per customer — more than the price; at 1,000 it is £25 — viable but tight; at 5,000, £5 — healthy. **Removing the review did not remove the structural problem at low volume; it shifted it from per-plan labour to editorial fixed cost, and the automated product needs *more* volume than the reviewed one because each sale is worth less.**

### 4.4 Which channels open at an impulse price

- **Paid social (Meta/Instagram/TikTok):** UK Meta CPC median ~£1.11 → at a £45 CAC ceiling you can afford ~40 clicks per sale, i.e. you need ≥2.5% cold-click-to-purchase. Plausible for a direct paywall with a sharp first-phone/Year-7 creative — **break-even-to-marginally-positive**, not a money fountain, but *reachable*, which £99-with-review never was [INF]. The renewal LTV tips it profitable, so protect the renewal.
- **SEO / moments-of-need:** "how to set up a child's first phone UK", "is [app] safe for my 12-year-old", "Year 7 phone rules". Instant delivery means this traffic converts *now* rather than hitting a review queue; the New-App brief is itself an SEO surface. Slow, compounding, near-zero marginal cost — the best channel for this product.
- **Free quiz tripwire:** the existing free Readiness Quiz (`10_Free_Readiness_Quiz.html`) becomes the natural PLG on-ramp — real value free, convert at the moment the parent sees their gaps. Already built.
- **App store:** year-2+ option only; freemium consumer conversion is 1–5% and a web direct paywall will out-convert it for this audience. Don't chase it for its own sake.

### 4.5 Three-year scenarios vs the with-review business (file 96 §7)

Assumptions: £49 one-off (~£45 net); £29 renewal at 25–30% year-1 uptake, 60% persistence [INF]; editorial £25k/yr from year 2 (year 1 founder-sweat); funnel wider than the reviewed product, per-visitor conversion on the free objection weaker.

| | Conservative | Base | Strong |
|---|---|---|---|
| Automated: Y1/Y2/Y3 new customers | 150 / 400 / 800 | 400 / 1,200 / 2,800 | 800 / 3,000 / 8,000 |
| **Automated: Y3 revenue (incl. renewals)** | **~£45k** | **~£155k** | **~£440k** |
| Automated: 3-yr cumulative | ~£74k | ~£238k | ~£631k |
| With review (96 §7): Y3 revenue | ~£33k | ~£135k | ~£350k |
| With review: 3-yr cumulative | ~£55k | ~£200k | ~£500k+ |
| Editorial covered? | No — founder-sweat or the claim dies | Yes from Y2 | Fully funded, <10% of net |
| Founder-hours | ~300–550/yr, zero per-customer | ~600–800/yr, zero per-customer | + growth/contractor, zero per-customer |

**Which makes more money — brutally:** on these assumptions the automated business beats the reviewed one in every column at year 3 — **but only because it assumes ~2.5–3× more customers.** Each automated customer is worth ~£45 vs ~£73–£110. **At identical volumes, the automated business makes less money — the pivot halves the price and bets everything on width.** If the funnel does not widen, file 97's verdict was simply correct. The honest characterisation: **higher ceiling, lower floor.** Its strong case beats the reviewed strong case (£631k vs £500k); both conservative cases are side projects (£74k vs £55k); the base case wins if and only if the funnel-widening thesis holds. What differs in *kind*: no throughput ceiling, no serve cost, founder workload scales like a software business, and the result is a sellable asset rather than a job.

**The free-clone collision, said plainly:** Internet Matters' free "My Family's Digital Toolkit" is live in July 2026 — 10-minute questionnaire, per-child advice, optional ongoing updates, £0, from a charity with ~31% parent brand awareness. It is a structural near-clone of the automated core. Without the human wedge, per-visitor conversion on the free objection is lower than the reviewed product could achieve — the moat is genuinely thinner here. The automated answer is not a better argument; it is a wider funnel asking a smaller, faster yes — and it depends entirely on the tools feeling like *doing* rather than *telling*.

---

## 5. What changed vs file 97's verdict — designed for automation, not amputated

File 97 said: *do not remove the human; the no-review product is a £29 amputation on a shelf where a charity gives away a clone.* The founder has since specified a **different product** — block-assembly, a tool suite, a preserved upgrade slot. The honest ledger:

**Objections that dissolve:**
1. **"It collapses to a prompt wrapper / it IS the chatbot."** Block-assembly means no LLM generates advice at runtime — ever. The wedge survives in a narrower, true form: not "a person reviewed you" but "a person wrote every word you're reading, and no AI is improvising about your child." ASA-substantiable via the authorship log.
2. **The crisis-safety tail-risk.** Defused *by construction*: crisis blocks are locked hash-pinned constants no model touches. File 97 was right that prompt guardrails are drafting instructions, not enforcement; the deterministic gate is stronger for this risk because it cannot have a bad day. Residual risk = "is the constant correct?" — a batched editorial QA task, not a per-plan runtime gamble.
3. **False claims on removal day.** No claims to falsify: the honest claim set is written for automation from the start, and the two false pricing-page lines are deleted before launch, not after.
4. **The orphaned ladder.** Now coherent: £0 free tools → £49 automated System (+£29/yr) → **[upgrade slot: paid human-review tier, boltable later]**. Nothing human is claimed at the base, so nothing dangles.

**Objections that stand — one plain sentence each:**
1. The free-clone collision is undiminished, and the plain plan alone still loses to free — the moat now rests entirely on the tools and the digest, not the plan.
2. The low-volume editorial cliff is unchanged: below ~500 customers/yr the kept-current promise is founder-sweat or dead, and the £25k does not care that the reviewer is gone.
3. The re-anchoring risk stands in weakened form: launching at £49 anchors the retail brand cheaper, and a future £149 human tier will read as an upsell from £49, not a flagship — a real cost Ben is accepting, managed (not defeated) by the upgrade slot.
4. Per-visitor conversion on the free objection is weaker without the human wedge; the pivot's answer is funnel width, and that is a deliberate bet, not a refutation.

**The upgrade slot, concretely:** the `plans.status` state machine keeps `in_review`; §7.5 (revised) clause 5 lets a paid human-review step insert between assembly and delivery without rebuild; the ladder keeps the £49-satellite slot from file 96 §4. Huckleberry's own shape — algorithmic cheap on-ramp, human premium upsell — is the template. The door stays ajar by design; nothing has to be re-architected the day Ben wants the human back.

---

## 6. The pivot plan — what changes if Ben confirms this direction

**Spec and code (in order):**
1. **`21_MASTER_BUILD_SPEC.md` §7.5** — replace per-plan publish with the block-gated rule in §2.4 above. This is a guardrail change, so it triggers the spec's own condition: **a safeguarding re-review of the new architecture is mandatory before the first plan is sold.** File 97's non-waivable condition 5 (a replacement safety architecture before the first unreviewed plan ships) is satisfied by design here, not waived — the re-review verifies that design. Scope: block taxonomy, assembly rules, the crisis constant and its verification chain, the claims set, and the content lint applied at block level (§10.3).
2. **`lib/plan-prompt.ts`** — extract `SIGNPOST` (line 45) into a hash-pinned constant module verified at build and render. The LLM plan-generation path is retired from delivery entirely; the prompt file survives only as an *authoring* aid for drafting block slices that a human then edits and publishes.
3. **`app/pricing/page.tsx`** — delete "a plan checked by a real person" and line 234 "No plan is sent until a person has checked it" on day one; replace with the §3 claims. **`lib/pricing.ts`** — retire the £99/£79/£59/£650 token defaults; new tokens: £49 one-off, £29/yr renewal.
4. **Diagnostic form** — delete the optional child-first-name field (`01` §2.2 Q3). No child-identifiable data anywhere.
5. **New tables** — content blocks (id, version hash, status, `review_by`, author, checker, sources), block authorship log, per-plan assembly log. `plans.status` retains `in_review`.
6. **Naming** — reconcile Keepwise vs Bearings once, everywhere, before the offer page ships.

**Build sequence (~350–400 founder-hours total, phaseable):** MVP block pool (~110 hrs) → assembly engine (~60–80 hrs) → wizards, digest, app lookup, agreement builder, kits, printables (~150–170 hrs) → adversarial QA of persona plans → safeguarding re-review → soft launch at £39 through the free-quiz funnel → test £49.

**The drafted £49 course pilot (files 50–55):** survives **only in its fully self-serve delivery mode** — per file 96 §11 and addendum 11, any cohort, feedback or graded variant is per-customer labour and dies. The self-serve AI Readiness Lab becomes a £49 satellite product beside the System, sharing the honest-claims regime; the AI-homework policy generator (tool 7) is its bridge.

**The £650 Concierge:** dies. It is founder per-customer labour by definition. Remove it from the ladder and the pricing page; the slot above the base remains reserved for the future human-review tier, unpriced and unannounced until Ben chooses to build it.

**The pilot itself:** the planned reviewed-pilot design is replaced by an automated pilot with different success metrics — the Section 7 triggers below are the pilot's instrumentation. Decide nothing on fear; decide on those numbers at six months.

---

## 7. The break-glass condition — written down now, so a future cut is data not fear

Any **two** firing within six months of launch = drop to £29 one-off (or free-plan + £29 premium). Any **three** = the automated product cannot hold a paid price at all; the honest move is free-tool funnel + a paid human tier as the only thing anyone pays for.

1. **Cold conversion below ~1.5%** on paid-social traffic *after* the tools ship and the copy leads with "does things, not tells things" (paid-social break-even needs ~2.5%, §4.4).
2. **Refund/chargeback above ~12%** with the dominant reason "I could get this free / this is organised free advice" — the market saying the tools didn't feel like doing. (Budget 6%; double it and the £49 net collapses.)
3. **Renewal opt-in below ~15%** once the first digests have gone out — if the one uncopyable asset can't hold £29, the editorial fixed cost sinks the model at every volume below ~5,000.
4. **Paid-social CAC above ~£45 and not falling** across a genuine test (≥£1–2k spend, multiple creatives).
5. **SEO/moments traffic converting below ~2%** at the highest-intent moments ("is [app] safe", "first phone setup") — if they won't pay £49, no colder traffic will.

**The tell that means DON'T cut** (mirror of file 95 §5.4): buyers saying *"the wizard actually walked me through it and I've got the certificate on the fridge"* or *"the digest told me about the Snapchat change before I'd heard of it."* That praise says the tools carry the £49 — hold the line. Praise that says *"cheaper than faff"* says you're holding a £29 convenience product — cut.

---

## 9. Addendum (4 July) — "could the program set the child's device up autonomously?"

Ben asked whether the product could go further: parent selects ages/devices/settings/agreement → software configures the machines itself. **Verified answer: the fully autonomous version cannot be built honestly — the platforms have deliberately left no door.** Per surface: the social/gaming apps expose no settings APIs (automation would require the child's credentials + UI-driving — ToS breach and a direct child-data guardrail violation); Apple's Screen Time APIs (FamilyControls/ManagedSettings/DeviceActivity) require a special entitlement and only let an app *become its own* parental-control app — they cannot configure Apple's Screen Time or other apps on a parent's behalf (developer.apple.com/documentation/familycontrols, verified 4 July); Google Family Link has no official API (support.google.com/families/answer/9204736); consoles/routers are fragmented. The one legal route — MDM/device-management — means becoming Qustodio: the crowded £30–76/yr shelf against free Family Link, plus the **liability inversion** (when our software performs the setup, we own every miss — the education posture that keeps this product insurable dies) and a positioning collision with everything the brand stands against.

**What survives — and elevates tool #2 into the bundle's co-hero:** the **Guided Setup Session**. From the diagnostic, generate the household's own setup session — exact click-paths, screen by screen, for their specific device models and choices, "phone in one hand, this in the other, ~25 minutes", ending in the dated completion record. Plus real automation at the edges where platforms genuinely permit it: a **tap-to-install home filter profile** (generated configuration pointing devices/router DNS at a family-safe resolver, set from their diagnostic — a true "program that sets up the machine", transparent, reversible, no child data, no credentials), OS deep-links straight into the right settings screens, and printed per-device cards for the manual remainder. Offer-page line: *"It doesn't just tell you what to do — it walks you through every toggle on your exact devices, and automates the parts that can be automated."* **Safeguarding/legal note:** the DNS profile is the closest this product comes to technical control; its claims wording ("filters common adult content — not a guarantee, and never monitoring; we see nothing") goes through the professional review before sale.

## 8. Sources

**External:** Huckleberry pricing (subscription-only, July 2026) — huckleberrycare.com/pricing · Internet Matters free personalised toolkit (live July 2026) — internetmatters.org/digital-family-toolkit · Stripe UK 1.5% + 20p — stripe.com/gb/pricing · RevenueCat State of Subscription Apps 2025 — revenuecat.com · UK Meta CPC 2025 (~£1.11 median) — superads.ai · subscription fatigue (41%; UK ~10M unwanted subs/£1.6bn) — themarketingblog.co.uk, influencers-time.com · freemium 1–5% vs direct paywall — firstpagesage.com, userpilot.com · Gumroad one-off band ($19–49, ~$51 avg) — insightraider.com · comparators: Wonder Weeks ~$34.99/yr (neurensics.com), Kinedu ~$60/yr (courses.kinedu.com), Mealime $49.99/yr / PlateJoy $99/yr (finvsfin.com) · Vercel/Supabase/Resend pricing pages (verify before commit) · ASA CAP 3.7 substantiation — asa.org.uk.

**Internal:** `95_Pricing_WTP_Assessment.md` · `96_Price_Scale_Strategy.md` (§2.3, §4, §7, §11 + addenda) · `97_No_Review_Scenario.md` · `98_Value_Expansion_Ideas.md` · `21_MASTER_BUILD_SPEC.md` (§7.5, §7.10, §10.3) · `01_Readiness_Report_System.md` (§2.2–2.3, §7.5.1) · `lib/plan-prompt.ts` · `app/pricing/page.tsx` · `lib/pricing.ts` · `10_Free_Readiness_Quiz.html` · `content/` (51 MDX items) · files `03`/`84` (crisis verification) · `16`/`17`/`27`/`32`/`43`/`53` (tool source content).

---

**Bottom line for Ben:** Yes, conditionally — a fully self-serve Keepwise can honestly be worth **£49 one-off + £29/yr**, because block-assembly makes it editor-written by construction, the crisis path is architecturally incapable of the file-97 failure, and the seven-tool bundle gives a parent things that *do* rather than tell. It is weaker than the reviewed business on moat and per-customer value — each sale is worth ~£45 vs ~£73–£110, and at equal volumes it earns less. It is better on scalability, channels, workload and exit — no throughput ceiling, ~£45–52 break-even CAC that makes paid social and SEO reachable for the first time, and zero per-customer hours forever. The whole bet is funnel width: 2.5–3× the customers, won by the wizards, the digest and the first-phone moment. Never claim a human looked at anyone. Keep the `in_review` socket so the human tier can return the day you want it. Break glass to £29 only on the Section 7 numbers, not on nerves.
