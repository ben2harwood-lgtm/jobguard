# Threat-Playbook Quick-Reference Cards (System library)

**Generated 20 Jun 2026 from `18`, each guardrail-verified against `18` + the `03` signpost. Printable threat cards (12 playbooks + 3 modules) with real helpline routes. Fill `[DATE]`.**

---

# Sextortion (financially-motivated)

Bearings · Threat card · Updated [DATE]

## What it is
Someone obtains (or claims to have) a nude or intimate image and threatens to share it unless they are paid. It is financially-motivated and most often targets teen boys aged 14–17. It overlaps heavily with self-generated imagery and AI "nudify" fakes. (Source: IWF.)

## Warning signs
- Sudden secrecy, panic or fear around the phone, especially after a new online contact.
- A new, online-only "relationship" that moves fast and then turns to demands.
- Requests for money, gift cards or top-ups, or distress after a payment.
- A fast escalation from a friendly chat to threats to "send this to everyone."

## Reduce the exposure
- Review privacy and who can contact or message your teen, app by app, together — see /library/platforms (settings move; check each app's official help page).
- Agree early that if something goes wrong they can come to you and won't be in trouble — the fear of your reaction is what offenders exploit. See /library/conversations.
- Talk through the pattern: a stranger who turns warm-then-threatening is the script. Build the plan *before* it happens.

## If it is already happening
Stay calm. This is not your child's fault, and paying tends to invite more demands. Sextortion can leave a young person feeling trapped, ashamed or in crisis — keep them company and take any talk of self-harm seriously.
1. **Stop all contact.** Don't pay.
2. **Don't delete anything** — it's evidence. Deactivate rather than delete accounts. Screenshot the threats.
3. **Tell a trusted adult.**
4. **Report to CEOP:** ceop.police.uk/Safety-Centre · call **101**, or **999** if your child is at immediate risk.
5. **To get an image removed (under-18):** Report Remove (Childline + IWF) — **childline.org.uk/remove**.

If your child is struggling to cope: Childline **0800 1111** · Shout (text) **85258** · Samaritans **116 123** · Papyrus HOPELINE247 **0300 102 2470** · full list Bearings/emergency.

Bearings signposts only — we point you to the right authority and do not investigate or intervene. Full list: Bearings/emergency.

## Official sources
CEOP (National Crime Agency) — ceop.police.uk/Safety-Centre

---

# AI deepfake / "nudify" images

*Bearings · Threat card · Updated [DATE]*

## What it is

AI tools that take an ordinary photo of a child and generate a fake nude or sexual image. Any photo can be turned into a fake nude, and making one of a classmate is a crime. A fake image of an under-18 is treated as illegal child sexual imagery even though no real photo was ever taken.

## Warning signs

- Sudden distress, withdrawal or shame after being online, with no obvious cause
- A child mentions an image "of them" they don't remember taking, or that "isn't real"
- Talk of an image circulating in a class or year-group chat
- Someone demanding money or contact under threat of sharing an image (this is sextortion/blackmail)

## Reduce the exposure

- Keep social profiles private and limit who can see and download your child's photos — review settings together (see /library/platforms; menus move, so check the platform's own official settings page)
- Agree early they can show you anything without losing the device — silence usually comes from fear of confiscation
- Talk through what to do if a faked image of them or a friend appears, before it happens (see /library/conversations)
- Reinforce that a faked image is never the child's fault and is the other person's wrongdoing

## If it is already happening

Stay calm. This is the other person's crime, not your child's fault.

1. Don't pay anyone, and don't delete anything — keep it as evidence (deactivate rather than delete accounts).
2. Report the image to **Report Remove** (Childline + Internet Watch Foundation), which helps under-18s get a nude image — including fake/AI-generated "nudify" ones — removed or pre-emptively blocked: **childline.org.uk/remove**. You can also use **Take It Down** (NCMEC): takeitdown.ncmec.org
3. Report it to the platform where it appeared.
4. If someone is threatening to share an image, or an adult is involved, report to **CEOP**: ceop.police.uk/Safety-Centre · call **101**, or **999** if your child is at immediate risk.
5. For an adult (18+): **StopNCII.org** or the **Revenge Porn Helpline** 0345 6000 459.

If your child is distressed or at risk: Childline 0800 1111 · Shout (text) 85258 · Samaritans 116 123 · Papyrus HOPELINE247 0300 102 2470 · Beat (eating disorders) 0808 801 0677 where relevant · full list Bearings/emergency.

## Official sources

CEOP (National Crime Agency) — ceop.police.uk/Safety-Centre

---

# Grooming & coerced app migration

*Bearings · Threat card · Updated [DATE]*

## What it is
An adult builds trust with a child — often through games or DMs — then steers them onto private or disappearing-message apps where there is less oversight, before manipulating them. "Let's move to another app" is the warning behaviour. (NSPCC)

In the UK, recorded Sexual Communication with a Child offences reached 7,263 in 2024/25, up 89% since 2017/18; where the platform was known, around 40% were on Snapchat, and 81% of victims were girls. (NSPCC, 2025)

## Warning signs
- A new online contact asks to **move to a private, secret or disappearing-message chat** — the single clearest red flag.
- A relationship that started **inside a game or in DMs** quickly pushes toward another app.
- Secrecy around who they are talking to, or accounts you weren't aware of.
- A contact who steers conversation away from platforms where messages are visible, toward encrypted or disappearing channels.

## Reduce the exposure
- Teach your child that **anyone asking to move to a private, secret or disappearing chat is a warning sign** — name it together before it happens.
- Turn on the **platform family tools** on the apps they actually use (see /library/platforms — settings may have moved; check the platform's official help page).
- Keep the relationship **non-judgemental** so your child tells you early — fear of blame keeps children silent (see /library/conversations).
- Know the route to report: CEOP for suspected grooming; the NSPCC Helpline for worries. *This card helps you spot and respond — it does not detect or monitor grooming.*

## If it is already happening
1. **Stay calm.** It is not the child's fault.
2. **Report suspected grooming to CEOP:** ceop.police.uk/Safety-Centre
3. **Call 999** if the child is in immediate danger; **101** if it is urgent but not life-threatening.
4. **For the child:** Childline **0800 1111**.
5. **Worried and unsure where to start?** NSPCC Helpline **0808 800 5000**.

Full list: Bearings/emergency

## Official sources
- NSPCC — nspcc.org.uk
- CEOP Safety Centre — ceop.police.uk

*Numbers and links may change — re-verify against the official sources above.*

---

# Scams, fraud & money-muling

*Bearings · Threat card · Updated [DATE]*

**What it is.** Scams and fraud aimed at young people, plus **money-muling** — where a teen is recruited to move criminal money through their own bank account in exchange for "easy money." Letting your account be used this way is a crime committed in the child's name.

## Warning signs

- Offers of "easy money for using your account" — the classic mule-recruitment line.
- Unexplained cash, transfers in and out, or a sudden new "side hustle" they're vague about.
- Pressure or secrecy around banking details, cards, or who has access to their account.
- Requests to "just receive and pass on" payments for someone they've met online.

## Reduce the exposure

- Talk openly that "easy money for using your account" is **mule recruitment** — and that it's a crime in the child's name, not a favour or a job.
- Keep banking details private; nobody else should ever use their account.
- Treat unexpected money offers from online contacts as a red flag to check with you first.
- Build the habit early that they can bring a "too good to be true" offer to you without trouble. See the conversation guides at **Bearings/library/conversations**.

## If it is already happening

Stay calm — this is about routing to the right people, not panic.

1. If money moved through a bank account, **contact the bank immediately**.
2. **Report to Action Fraud** (England, Wales, Northern Ireland): reportfraud.police.uk · **0300 123 2040**.
3. In **Scotland**, report to **Police Scotland on 101**.
4. If you're worried about the child more generally, **NSPCC Helpline 0808 800 5000**; the child can speak to **Childline 0800 1111**.
5. If a child is in immediate danger, call **999**.

*Bearings points you to the right authority — we don't investigate or intervene.*

## Official sources

Action Fraud (NCA / City of London Police) — reportfraud.police.uk · 0300 123 2040. Scotland: Police Scotland 101. Full signpost list: **Bearings/emergency**.

*Re-verify every number and URL at publish and quarterly.*

---

# AI companions & chatbots

Bearings · Threat card · Updated [DATE]

**What it is**
AI "companion" apps and chatbots that act like a friend, partner or confidant. The risks are emotional dependency and unsafe advice — and a bot that feels like a person but isn't.

**Warning signs**
- Long, secretive conversations with an app treated like a close friend or partner
- Leaning on a bot for emotional support, advice, or as a stand-in therapist
- Distress, irritability or withdrawal when they can't access it
- Acting on guidance from a chatbot that seems off, unsafe, or out of character

**Reduce the exposure**
- Reinforce the core message: AI isn't a friend or a therapist — it can sound caring and confident while being wrong.
- Keep the conversation open so they'll tell you what a bot has said, rather than hiding it.
- Note the direction of travel: under-18 romantic/companion bots are being restricted to 18+ under recent UK law — a legislated measure, but some provisions commence on later dates, so it isn't fully in force yet. Parents still carry the load in this transition period.
- For app-by-app privacy and contact settings, see the relevant guide in /library/platforms (menus and settings move — check the platform's own current help page for the latest steps).

**If it is already happening**
1. Stay calm and curious, not alarmed — open with what you've noticed.
2. Talk about how these tools are designed to feel personal, and why a chatbot can't replace real support.
3. Report the platform / use **Report Harmful Content** (reportharmfulcontent.com, for users 13+) for harmful material.
4. If a chatbot has touched on self-harm, suicide or eating, or your child is distressed, signpost: **Childline 0800 1111** · **Shout (text) 85258** · **Samaritans 116 123** · **Papyrus HOPELINE247 0300 102 2470** · **Beat (eating disorders) 0808 801 0677** · call **999** if their life is at risk · full list Bearings/emergency.

**Official sources**
Online Safety Act, child-protection duties live since 25 July 2025 (Ofcom) — ofcom.org.uk

*Bearings signposts to the right authority or helpline; we don't monitor, investigate, or intervene. Re-check every number and URL at publish and quarterly.*

---

# Cyberbullying & peer-on-peer abuse

*Bearings · Threat card · Updated [DATE]*

## What it is
Bullying through phones, games and social media — nasty group chats, exclusion, rumours, impersonation, pile-ons, harassment — and peer sexual harassment and coercion.

## Warning signs
- Sudden reluctance to use the phone, or compulsive checking with visible distress
- Withdrawing from friends; a mood crash after going online; faking illness to avoid school
- Deleting accounts, or creating secret ones
- Unexplained anger or tears

## Reduce the exposure
- Agree early that they can show you anything **without losing the device** — fear of confiscation is the single biggest reason teens stay silent (the most evidence-aligned move).
- Set up blocking and reporting on each app *together*. Menus move — check your app's current path against the official help pages. See `/library/platforms`.
- Model not retaliating, and keep group-chat drama in perspective. See `/library/conversations/bullying-group-chat`.
- Know the school's anti-bullying policy before you need it.

*UK picture: 39% of 8–17s have experienced bullying; of those, 84% experienced it on a device. Prevalence roughly doubles from age 11 to 15. Bullying was the single biggest reason children contacted Childline (6,617 sessions in 2024/25). Sources: Ofcom; NSPCC/Childline.*

## If it is already happening
1. **Screenshot first — don't delete.** Evidence vanishes when you block.
2. **Then block and report in-app.**
3. **Don't reply or retaliate.**
4. **Tell the school** if classmates are involved — schools have a duty to prevent bullying and can act even when it happens off-site.
5. **Report Harmful Content** (reportharmfulcontent.com, for users 13+, run by SWGfL) helps remove non-criminal harmful content.
6. If it crosses into **harassment, threats or hate → police 101** (999 if immediate).

If your child is distressed or at risk: **Childline 0800 1111 · Shout (text) 85258 · Samaritans 116 123 · Papyrus HOPELINE247 0300 102 2470 · Beat (eating disorders) 0808 801 0677** where relevant · full list Bearings/emergency. Call **999** if their life is at risk.

*This card signposts only — it points you to the right authority or helpline, it does not replace them.*

## Official sources
- Report Harmful Content (SWGfL/UK Safer Internet Centre): reportharmfulcontent.com

---

# Self-harm, suicide & eating-disorder content

*Bearings · Threat card · Updated [DATE]*

*Signpost only — no bespoke crisis intervention. This is a sensitive topic; if you're personally affected, the helplines below are there for you too.*

**What it is**
Online content that depicts, encourages or normalises self-harm, suicide, or eating disorders — including "pro-ana"/"pro-mia" communities that frame an eating disorder as a lifestyle. A teen may *encounter* it, or may be *seeking* it because they're already struggling.

**Warning signs**
- Covering arms/legs in warm weather; unexplained cuts or burns; withdrawal, hopelessness; giving away possessions.
- Big changes in eating, secrecy around food, excessive exercise, frequent bathroom trips after meals.
- Following accounts using coded ED/self-harm language.
- Context: now a named harm category under the Online Safety Act — since 25 July 2025 platforms likely accessed by children must use highly effective age assurance to keep under-18s from this content (enforcement ramping but incomplete). Ofcom found about 9% of internet users had seen eating-disorder content in the past four weeks, rising to around 15% of 13–17s; among teens, girls were far more likely than boys to have seen it (Ofcom, Online Nation 2024).

**Reduce the exposure**
- Turn on sensitive-content controls *with* them. Settings move — check the platform's official help page if a menu has moved. See /library/platforms.
- Talk openly — asking about suicidal feelings does not plant the idea. See /library/conversations.
- Keep means of self-harm less accessible; build offline coping and connection.
- Goal is reducing *harmful* exposure, not policing all discussion of feelings — some peer content is genuinely supportive.

**If it is already happening**
1. Stay calm and non-judgemental — open with curiosity ("I've noticed… I'm here, not angry").
2. Don't force instant deletion of a community a struggling teen leans on — work on safer settings and reducing harmful feeds.
3. Report the harmful content in-app.
4. Signpost by severity — immediate danger to life: **999**. Urgent mental-health crisis: **NHS 111 (select option 2 for mental health, 24/7)** or A&E. Non-urgent route to CAMHS: via the **GP**.
5. Distress signpost: **Childline 0800 1111** · **Shout (text) 85258** · **Samaritans 116 123** · **Papyrus HOPELINE247 0300 102 2470** · **Beat (eating disorders) 0808 801 0677** · full list **Bearings/emergency**.

**Official sources**
NHS 111 (mental health, 24/7) · Samaritans 116 123 · Beat 0808 801 0677 · Childline childline.org.uk · Online Safety Act / age assurance: Ofcom — ofcom.org.uk

*Re-verify every number and URL at publish and quarterly.*

---

# Pornography exposure

*Bearings · Threat card · Updated [DATE]*

## What it is
Teens encountering pornography — increasingly **by accident** via feeds and links — where violent or degrading content shapes their expectations about sex, consent and bodies.

## Warning signs
- Often *not* signalled by obvious behaviour change — much exposure is accidental, so prevention rests on conversation, not surveillance.
- Parroting degrading attitudes about sex or consent.
- Newly cleared browser history.
- Distress after "something they saw."

## Reduce the exposure
- Start age-appropriate conversations *before* 11–13; frame it as "porn isn't a documentary about real sex," with consent at the centre.
- Set network-level filters: broadband adult-content filter, **SafeSearch**, restricted modes. (Settings menus move — check the provider's current official page if a toggle has moved.) See `/library/platforms`.
- Reassure that **accidental exposure isn't their fault**, so they'll tell you. See `/library/conversations`.
- Use the new age-check era as a natural hook: under the Online Safety Act, Ofcom-mandated age-checks for porn sites came into force **25 July 2025** (social feeds and VPNs remain sideways routes).

## If it's already happening
1. **Don't shame or punish** — especially for accidental exposure; shame makes silence far more likely.
2. **Have the conversation, not the lecture:** what did they see, how did it feel, what questions do they have.
3. **Tighten filters** on network and devices together.
4. **Signpost:** Internet Matters and Childnet have age-banded scripts; CEOP/Thinkuknow for harmful sexual behaviour. If a child was *sent* porn by an adult, or shows harmful sexual behaviour toward another child → safeguarding: **CEOP** (ceop.police.uk/Safety-Centre) / school DSL / **NSPCC 0808 800 5000**.
5. **If your child is distressed:** Childline **0800 1111** · Shout (text) **85258** · Samaritans **116 123** · Papyrus HOPELINE247 **0300 102 2470** · full list **Bearings/emergency**. If a child is in immediate danger, call **999**.

## Official sources
Children's Commissioner; Ofcom · nspcc.org.uk · ceop.police.uk/Safety-Centre

---

# Gambling, loot boxes & in-game spending

*Bearings · Threat card · Updated [DATE]*

**What it is.** Gambling-style mechanics reaching teens — loot boxes (paying for a randomised reward), skins betting, in-game currencies — plus underage betting. The harm is both money lost and conditioning toward gambling. *(Source: Gambling Commission, via Bearings Threat Playbook.)*

---

### Warning signs
- Money disappearing, or requests for gift cards or top-ups; unexplained card charges.
- Secrecy about spending; selling things for in-game currency.
- Distress or chasing behaviour after gaming.
- Talk of "wins," "odds," or owing other players.

---

### Reduce the exposure
- Turn off in-app purchases, or require a password for every purchase (Apple Screen Time, Google Play, console family settings). Remove stored cards; use prepaid or allowance models. *Settings menus may have moved — check the official Apple, Google, or console family-settings pages.*
- Talk about how loot boxes are *designed* to feel like a near-miss win.
- Check PEGI ratings and the "in-game purchases (random items)" descriptor.
- See the platform set-up steps in /library/platforms and the conversation starters in /library/conversations.

*Context (Gambling Commission): gambling among 11–17s rose to 30% in 2025 (from 27%); 1.2% are problem gamblers. 23% of 11–16s have paid to open loot boxes, associated with 4.4× higher odds of problem gambling. Loot boxes are not currently regulated as gambling in the UK, so this gap is parent-managed.*

---

### If it is already happening
1. Remove the payment method and audit recent transactions.
2. Check refunds — Apple, Google, and console stores can sometimes refund child or unauthorised purchases; the bank may dispute charges.
3. Don't just confiscate — talk about *why* it pulled them in.
4. Signpost (we point you to the right service; we don't intervene):
   - GambleAware / National Gambling Helpline 0808 8020 133 — 24/7, supports under-18s and worried parents. YGAM and GamCare also offer youth resources.
   - Worried about a child in general and unsure where to start: NSPCC Helpline 0808 800 5000 · help@nspcc.org.uk
   - If a child is distressed or at risk of self-harm or suicide: Childline 0800 1111 · Shout (text) 85258 · Samaritans 116 123 · Papyrus HOPELINE247 0300 102 2470 · full list Bearings/emergency. Call 999 if their life is at risk.

---

**Official sources.** Gambling Commission — gamblingcommission.gov.uk · National Gambling Helpline (GambleAware) — 0808 8020 133. Re-check every number and URL on launch day and quarterly.

---

# Sexting & peer image-sharing ("nudes")

*Bearings · Threat card · Updated [DATE]*

## What it is
Young people creating or sharing nude/sexual images of themselves — often consensually with a partner — that can then be forwarded, leaked, or used to coerce. A nude image of an under-18 is technically illegal indecent imagery even if the teen took it themselves.

## Warning signs
- Secrecy or panic around the phone; a new, older, or online-only "boyfriend/girlfriend."
- Sudden fear of a specific person.
- Distress after a breakup.
- Mentions of an image "getting out."

## Reduce the exposure
- Explain the law and permanence ("once it's sent, you've lost control of it") without fear-mongering — see the prevention conversation at /library/conversations.
- Make clear that if it goes wrong they can come to you and won't be in trouble: UK police use **Outcome 21** to avoid criminalising children in consensual-sharing cases, so the reassurance is honest.
- Teach that requests for images are a red flag.
- Teach that re-sharing someone else's image is itself harmful and potentially illegal.

*Self-generated imagery now dominates what the IWF tackles: ~85% of actioned reports in 2025 contained at least one self-generated image. Report Remove had 1,894 child reports in 2025 and is rising; it overlaps heavily with sextortion (IWF). Settings and menus may have moved — check the official source below.*

## If it is already happening
1. **Stay calm — do not blame the child.** Their fear of your reaction is exactly what predators exploit.
2. **Screenshot threats** (don't delete) — but do **not** save or forward the image itself.
3. **Use Report Remove** (childline.org.uk/remove) — an under-18 can report their own nude image to have it taken down and pre-emptively blocked.
4. **Report the platform.** If an adult, or coercion/blackmail, is involved → **CEOP** (ceop.police.uk/Safety-Centre) and **101**, or **999** if a child is at immediate risk.
5. **Reassure:** children are **not** prosecuted for being a victim.

If your child is distressed, or at risk of self-harm or suicide:
**Childline 0800 1111 · Shout (text) 85258 · Samaritans 116 123 · Papyrus HOPELINE247 0300 102 2470** · full list Bearings/emergency. Bearings signposts only — we route you to the right authority, we do not handle incidents.

## Official sources
- **Report Remove** (Childline + IWF), to remove a nude image of an under-18 — childline.org.uk/remove
- **CEOP** (online child sexual abuse & grooming) — ceop.police.uk/Safety-Centre

---

# Radicalisation & extremist content

*Bearings · Threat card · Updated [DATE]*

## What it is

Online content and communities pulling young people toward extremist ideologies or a fixation with violence — increasingly mixed, nihilistic, gore-and-violence-obsessed subcultures rather than one clear cause.

**The UK picture (2025–26).** Prevent referrals rose to 142 per million, with education making 36% of referrals. (Source: gov.uk Prevent statistics, year ending March 2025.) MI5 has said investigations into under-18s have tripled in three years — including young people radicalised online with no fixed ideology, just a fixation with violence. (Source: MI5 Director General threat update.)

## Warning signs

- Sudden absolutist "us vs them" language; demonising a group; new secrecy about online groups.
- Fixation with violence, weapons, or mass-casualty events.
- Switching to encrypted or fringe platforms; withdrawal.
- Conspiracy-thinking tipping over into extremism (see also: critical thinking & misinformation — /library/conversations).

## Reduce the exposure

- Keep dialogue open and non-judgemental — debate, don't shut down. (See /library/conversations.)
- Build critical-thinking habits so claims get questioned, not absorbed.
- Know who they talk to and where — settings and menus may have moved, so check the platform's official help pages (/library/platforms).
- Don't over-react to an edgy phase, but don't ignore genuine escalation. Use the gov.uk **Educate Against Hate** resources.

## If it is already happening

1. Don't confront aggressively or cut off their relationships abruptly — isolation deepens it.
2. Keep talking, and note what you're seeing (platforms, content).
3. Signpost to **ACT Early** — the police service for worried families: **actearly.uk** / **0800 011 3764** (confidential; support, not prosecution, in most cases).
4. Call **999** if there is an imminent threat to life.

This world overlaps with self-harm and nihilistic distress. If a young person is struggling, the right routes are: Childline 0800 1111 · Shout (text) 85258 · Samaritans 116 123 · Papyrus HOPELINE247 0300 102 2470 · full list Bearings/emergency.

*Bearings points you to the right authority — we don't monitor, investigate, or intervene. Full list: Bearings/emergency.*

## Official sources

- ACT Early (Counter Terrorism Policing) — actearly.uk · 0800 011 3764
- Educate Against Hate (gov.uk) — educateagainsthate.com

---

# Screen-time, sleep & digital wellbeing

*Bearings · Threat card · Updated [DATE]*

## What it is

Not one "threat" but the everyday battleground — how much, *what kind* of use, and the knock-on effects on sleep, mood, attention and real-world connection. Usually the topic that brings parents through the door.

## Warning signs

- Persistent tiredness, falling asleep in class, dropping grades.
- Irritability or anxiety when offline; phone in the bedroom overnight.
- Meals, hobbies and family time quietly displaced by screens.
- "Five more minutes" becoming a recurring conflict.

## Reduce the exposure

- **Charge phones outside the bedroom overnight** — the highest-impact single habit. Enable Sleep / Do Not Disturb and bedtime modes.
- Set different limits for school vs non-school nights, and co-create the rules together.
- Protect "green time" and family meals; swap passive scroll for active use.
- Use Apple Screen Time / Google Family Link for *visibility*, not just blocking — see `/library/platforms`. Menus move, so check the provider's official help pages if a setting has shifted.

## If it is already happening

This is wellbeing, not an emergency — there is no crisis line for screen time. Work through it calmly:

1. **Start with sleep** — apply the bedroom-charging rule first; sleep loss amplifies every other harm.
2. Use the device's own reports to see *what kind* of use is happening, then adjust limits together.
3. For everyday guidance, signpost **Internet Matters** screen-time hub and **NHS** teen sleep advice (search the official nhs.uk and internetmatters.org sites).
4. **If screen use is masking anxiety or depression, route via the GP.**
5. If your child becomes distressed or at risk of self-harm: **Childline 0800 1111 · Shout (text) 85258 · Samaritans 116 123 · Papyrus HOPELINE247 0300 102 2470 · Beat (eating disorders) 0808 801 0677 where relevant** · full list at Bearings/emergency. Call **999 if their life is at risk.**

## Official sources

NHS teen sleep advice — nhs.uk · Internet Matters screen-time hub — internetmatters.org

---

# Privacy, data & digital footprint

*Bearings · Threat card · Updated [DATE]*

## What it is
What teens reveal online — location, school, routines, oversharing — and the long tail of a permanent digital footprint. Location is the sharp end.

## Warning signs
- Precise location showing on **Snap Map** (it is off by default, but only the child can disable it from their account — Family Centre lets you *see* who they share with, not switch it off).
- Posts that show uniform, address, real-time location, or holiday plans.
- Many apps holding location permission, often without the child realising.
- "Who can see / contact me" settings left open to anyone.

## Reduce the exposure
- Turn on **Ghost Mode** (Snap) and disable precise location app-by-app. Settings move — re-check against the platform's own help page (Snap: parents.snapchat.com, UK: /en-GB/parental-controls). See `/library/platforms`.
- Review which apps have location permission; remove it where it isn't needed.
- Lock down "who can see / who can contact me."
- Talk it through: don't post uniform, address, real-time location or holiday plans. See `/library/conversations`.

*Context: accidental location-sharing is "super risky," and ~40–48% of Sexual Communication with a Child offences occur on Snapchat (NSPCC; Internet Matters).*

## If it is already happening
For **stalking, or an adult tracking a child**, route to the authorities — don't try to handle it yourself:

1. If a child is in **immediate danger, call 999**. If it's urgent but not life-threatening, call police on **101**.
2. Report to **CEOP** (online child sexual abuse and grooming): ceop.police.uk/Safety-Centre
3. For account security, see **NCSC** (ncsc.gov.uk); general guidance, **Get Safe Online** and **Internet Matters** privacy guides.

Full list: Bearings/emergency.

## Official sources
NSPCC · Internet Matters · NCSC (ncsc.gov.uk) · CEOP — ceop.police.uk/Safety-Centre · Snap — parents.snapchat.com

---

# Critical thinking & misinformation

*Bearings · Threat card · Updated [DATE]*

## What it is
Helping teens spot false, manipulated or conspiratorial content — now supercharged by AI-generated images and video. This is media literacy, not a crisis: the aim is a calm, sceptical habit of mind, not panic.

## Warning signs
- Sharing or repeating claims as fact without checking who is saying it or why.
- Strong reactions to outrage-driven posts — algorithms reward outrage, so the loudest content surfaces first.
- Treating AI-generated images or video as automatically real.
- Conspiracy interest hardening into fixed, us-versus-them beliefs (this can tip toward extremism — see below).

## Reduce the exposure
- Teach lateral reading: before believing a post, check who is saying it and cross-reference against other sources.
- Talk together about how algorithms reward outrage, and why the most emotional content is not the most reliable.
- Treat AI-generated media with healthy scepticism — assume an image or clip may be manipulated until checked.
- Use trusted UK literacy resources — Ofcom "Making Sense of Media," the Internet Matters fake-news hub, and Childnet. Pair with your platform settings: see /library/platforms and /library/conversations. (Menus may have moved — check the official page.)

## If it is already happening
There is no crisis helpline for misinformation itself — it is media literacy, so keep the dialogue open and non-judgemental.

Escalate only if conspiracy interest tips into extremism or radicalisation:
1. Stay calm and keep talking — debate, don't shut down.
2. If you are worried a young person is being drawn toward extremism, contact **ACT Early on 0800 011 3764** (signpost only — we don't investigate or intervene).
3. If a child is in immediate danger, call **999**.

If a young person becomes distressed: Childline **0800 1111** · Shout (text) **85258** · Samaritans **116 123** · Papyrus HOPELINE247 **0300 102 2470**. Full list: Bearings/emergency.

## Official sources
Ofcom UK media-use and attitudes data ("Making Sense of Media") — ofcom.org.uk

*Figures: Ofcom 2025–26. Misinformation is the single most-encountered online harm — 41% of UK users 13+ saw it in the past four weeks; ~4 in 10 children 9–16 are unsure whether what they see is true; 16–17s' confidence in spotting fake news fell to 75%.*

---

# Livestreaming safety

*Bearings · Threat card · Updated [DATE]*

## What it is

Live video on platforms like Twitch, YouTube Live and TikTok Live: no editing, real-time stranger contact, and the risk of a child being talked into doing things on camera. Under the new UK measures, livestreaming is expected to be unavailable for under-16s and off by default for 16- and 17-year-olds.

## Warning signs

- Requests for your child to "go live" privately, or to move to webcam
- Strangers contacting or commenting on streams, or pressure to do things on camera
- Younger teens with live features switched on and open privacy settings
- The IWF has documented large numbers of children groomed or coerced into livestreaming their own abuse

## Reduce the exposure

- Review privacy settings and who can contact or comment, together with your child — see /library/platforms (settings may have moved; check the platform's official help pages)
- Turn off live features for younger teens
- Talk through what to do if someone asks them to "go live" privately or switch to webcam — see /library/conversations
- This sits alongside grooming, nudes/sextortion and screen-time — work them together, not in isolation

## If it is already happening

Coercion to stream is grooming/sextortion. Stay calm and route it to the right place.

1. **If a child is in immediate danger, call 999 now.**
2. Stop the contact. Don't delete anything — it's evidence.
3. Report online child sexual abuse and grooming to **CEOP**: ceop.police.uk/Safety-Centre · or call the police on **101** (**999** if at immediate risk).
4. To remove a nude image of an under-18: **Report Remove** (Childline + Internet Watch Foundation) — childline.org.uk/remove
5. If your child is distressed or at risk: Childline 0800 1111 · Shout (text) 85258 · Samaritans 116 123 · Papyrus HOPELINE247 0300 102 2470 · full list Bearings/emergency.

Bearings signposts only — we don't monitor, investigate, or intervene.

## Official sources

- gov.uk — UK online safety measures: gov.uk
- Internet Watch Foundation (IWF): iwf.org.uk

---
