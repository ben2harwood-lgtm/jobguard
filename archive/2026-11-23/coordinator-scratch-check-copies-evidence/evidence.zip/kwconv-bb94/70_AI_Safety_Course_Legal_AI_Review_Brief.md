# AI Safety Course - Legal AI Review Brief

*Created 2026-06-27. Status: prompt/brief for an AI-assisted legal red-team review. This is not a request for legal advice and cannot produce legal sign-off. It is an issue-finding pass before paid human review.*

## Prompt To Use

You are acting as an AI legal red-team reviewer for a UK parent-facing AI safety course. You are not giving legal advice or formal clearance. Your task is to identify legal-risk wording, unsupported claims, missing caveats, and places where the material should be changed or escalated to paid human legal review.

The product boundary is:

- adult parent/carer user only;
- no child accounts;
- no child-facing flow;
- no child PII;
- no screenshots, uploads, private messages, schoolwork, images, voice, or incident detail;
- no live-incident advice;
- no AI judgement of real messages or images;
- no safety, efficacy, or compliance guarantees;
- route/signpost only for live concerns.

Review the supplied files against this boundary and the Claim Register / Gap Register. Prioritise blockers and high-risk issues.

## Files To Review

Review these files in this order:

1. `57_AI_Safety_Course_Claim_Register.md`
2. `58_AI_Safety_Course_Gap_Register.md`
3. `60_AI_Safety_Course_G1_Breaker_Findings.md`
4. `61_AI_Safety_Course_Phase2_Design_Package.md`
5. `62_AI_Safety_Course_Phase3_Tools_Spec.md`
6. `63_AI_Safety_Course_Scenario_Trainer_Content.md`
7. `64_AI_Safety_Course_Readiness_Self_Check_Spec.md`
8. `65_AI_Safety_Course_Stay_Current_Update_Stream_Spec.md`
9. `66_AI_Safety_Course_Routing_Card_Spec.md`
10. `67_AI_Safety_Course_Human_Review_Pack.md`
11. `68_AI_Safety_Course_Source_Recheck_Log.md`
12. `components/FamilyAgreementBuilder.tsx`
13. `lib/ai-safety-scenarios.ts`
14. `lib/ai-safety-self-check.ts`
15. `lib/ai-safety-update-stream.ts`
16. `lib/ai-safety-routing-card.ts`

## Legal Review Focus

Check for:

- any wording that implies legal advice, legal determination, or legal clearance;
- any wording that says or implies the product is compliant, fully reviewed, safe, or protective;
- any under-18 image wording that implies parents should save, screenshot, copy, download, forward, request, or retain suspected nude or sexual images;
- any blurring of adult-scoped intimate-image provisions and under-18 image offences;
- any exact legal status claim that is too certain for a fact-specific scenario;
- any Online Safety Act wording that implies platform duties make outcomes assured or shift responsibility to this course;
- any data/privacy wording that turns data-minimising design into a legal compliance conclusion;
- any schoolwork/assessment wording that overrides school, centre, JCQ, or assessment rules;
- any marketing or offer wording that makes an efficacy claim;
- any route wording that looks like incident-management advice rather than signposting.

## Required Output

Return findings first, ordered by severity.

Use this table:

| Severity | File / section | Finding | Why it matters | Required change | Human review needed? |
|---|---|---|---|---|---|
| blocker/high/medium/low | file + section | issue | risk | exact wording change or remove/reframe instruction | legal / safeguarding / source / none |

Severity definitions:

- blocker: should not be parent-facing before patched.
- high: should be patched before sale or broad distribution.
- medium: patch before polished launch.
- low: clarity/style issue.

Then provide:

- "No issues found" only if you genuinely find none.
- A short list of unresolved legal questions for paid human counsel.
- A list of claims that should stay in the Gap Register.
- A list of exact phrases that should be banned or watched by content lint.

## Constraints

- Do not rewrite the whole product.
- Do not invent new legal claims.
- Do not provide advice for a live incident.
- Do not say the product is legally safe or compliant.
- If uncertain, flag the uncertainty and recommend human legal review.
- Prefer conservative wording that routes to qualified services.

## Special Attention

The most important known risk is under-18 nude/sexual image wording. Treat any generic "preserve evidence", "save it", "screenshot it", "send it to yourself", "ask them to resend", "copy the image", "download it", or "forward it" wording as a blocker unless it is explicitly negated in the same context.
