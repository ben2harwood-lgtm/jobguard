# Incident & Disclosure Scripts (DRAFT)

> These are unreviewed first drafts produced 2026-06-21. Every setting path, figure and link is marked for fact-check before publishing.


---

## Incident & disclosure scripts — the first 60 seconds

**DRAFT — fact-check every setting path, figure and link against the live source before publishing.**

Last drafted: 2026-06

When a child tells you something has gone wrong online — a shared image, a stranger making contact, blackmail, bullying — the first sixty seconds matter more than anything you'll do afterwards. Not because there's a perfect thing to say, but because how you react in that first minute decides whether they keep talking to you or close the door. This page gives you the words for that minute, and only that minute. After that, you hand off to the official report routes and the matching playbook. Bearings does not handle incidents, investigate, or advise on the specifics of a case — it points you to the people who do.

The single most important finding behind all of this: what a parent knows about their child's online life depends far more on the child *choosing to tell them* than on any monitoring (Kerr & Stattin's research on parental knowledge). A calm reaction in the first minute is what keeps that channel open. CEOP's own guidance is built on staying calm and non-judgemental so a child feels safe to keep talking [verify — CEOP/Thinkuknow parent guidance].

---

## The rule for the first 60 seconds

Whatever they've told you, the first minute has the same shape every time:

1. **Stay calm — out loud.** Your face and voice are the message. Panic or anger teaches them they were right to be scared to tell you.
2. **Thank them for telling you.** "I'm really glad you told me" does more work than any other sentence.
3. **Say it's not their fault, and they're not in trouble.** This is the line that keeps them talking. CEOP's cornerstone message is exactly this [verify — CEOP].
4. **Ask one open question, then listen.** "What happened? Talk me through it." Not "why did you…".
5. **Don't act yet — and don't delete anything.** Tell them you'll sort it together, then move to the right report route below.

That's it. You are not expected to fix it in the room. Your only job in the first minute is to keep them talking and avoid the reactions that shut them down.

---

## What NOT to do in the first minute

These are the reactions that reliably close a child down. They feel natural, which is why they need naming.

- **Don't show panic or anger** — even if you feel it. Step away for a breath if you need to.
- **Don't grab the phone or threaten to take it.** "If anything happens, telling me won't cost you your phone" is the pact that keeps them coming back [verify — NSPCC].
- **Don't ask "why did you…".** Ask "what happened?".
- **Don't blame them, or anyone** ("how could you be so naive?"). These scams and pressures are designed to fool adults too.
- **Don't delete messages, images or accounts**, and don't tell your child to. They may be evidence — deactivate rather than delete if needed (standard NCA messaging) [verify — NCA/CEOP].
- **Don't promise secrecy you can't keep.** "I'm going to help you, and that might mean asking other people who can help too."

---

## The scripts, by what they've just told you

Each script is scaffolding, not lines to read out. Use your own words. Every one ends the same way: stay calm, then go to the matching report route. **Bearings gives no further incident-handling steps beyond stay-calm and signpost.**

### "Someone's threatening to share a nude of me unless I pay" (sextortion)

> "Okay. I'm really glad you came to me — this is exactly the right thing to do. This is a scam that's done to thousands of people, including adults, and it is not your fault. We're going to sort it together. Don't pay anything, don't reply, and don't delete anything yet — let's just stop and work out the next step together."

The agreed safety messaging for sextortion is: **stop contact, don't pay, don't delete, block, and tell someone** — this is standard NCA/CEOP messaging, not bespoke advice [verify — NCA/CEOP]. Then go to the report route.

→ **Report route:** CEOP Safety Centre (online child sexual abuse), and **999** if your child is at immediate risk, or **101** if urgent but not life-threatening. To get an image removed, see the image script below. *(See the Bearings sextortion playbook.)*

### "There's a naked picture of me out there" / "someone made a fake nude of me" (a shared or threatened intimate image of an under-18)

> "Thank you for telling me — that took guts. This happens to a lot of young people and there's a service that exists just to get these taken down. You're not in trouble and we'll deal with it together. Let's not delete anything for now, and let's look at the reporting route together."

This covers real images and fake/AI-generated "nudify" images.

→ **Report route:** **Report Remove** (Childline + Internet Watch Foundation) helps an under-18 get a nude image removed or pre-emptively blocked — search "Childline Report Remove", or **childline.org.uk/info-advice/bullying-abuse-safety/online-mobile-safety/report-remove/** [verify URL resolves]. For an adult (18+), the routes differ (StopNCII.org / Revenge Porn Helpline) — see the Emergency Signpost. *(See the Bearings image-sharing playbook.)*

### "Someone I don't know has been messaging me" / "they want me to move to another app" (suspected grooming or stranger contact)

> "I'm really glad you showed me. You haven't done anything wrong. People online aren't always who they say they are, and the bit where they wanted to move to a private app is the thing that makes me want to get the right people to look at this. Let's not block or delete just yet — let's look at it together first."

The key red flag worth knowing: anyone who wants to move the chat to a private, secret, or disappearing app [verify — NSPCC/Internet Matters].

→ **Report route:** **CEOP Safety Centre** for online sexual abuse or grooming; **999/101** if the child is in immediate or urgent danger. *(See the Bearings grooming/stranger-contact playbook.)*

### "People are being horrible to me online" / "the group chat turned on me" (bullying)

> "Thank you for telling me — that sounds genuinely horrible and I'm glad you don't have to carry it on your own. I'm not going to take your phone or go storming in. Can you show me what's been happening, and then we'll figure out the smart move together?"

Reassure them you won't confiscate the phone or react explosively — that's what keeps them showing you [verify — NSPCC].

→ **Report route:** report it to the platform first; if that doesn't resolve it, **Report Harmful Content** (for users 13+) at reportharmfulcontent.com [verify]. Note this service has run on a limited basis since April 2025, so responses may be slower or limited. If it's connected to school, contact the school's **Designated Safeguarding Lead (DSL)**. *(See the Bearings bullying playbook.)*

### If they're distressed, frightened, or talking about hurting themselves

Stay with the calm, "I'm glad you told me, we'll get through this together" posture — and reach for support rather than handling it alone.

→ **Childline** (under-19s): **0800 1111** · childline.org.uk. **Samaritans** (anyone, 24/7): **116 123**. **Call 999 if their life is at risk.**

---

## After the first minute: where to go

Bearings is not part of the response. Once you've kept them talking, the right people are:

- **Immediate danger or risk to life — call 999.** Urgent but not life-threatening — **101**.
- **CEOP Safety Centre** — online child sexual abuse, grooming, sextortion: ceop.police.uk/ceop-reporting/ [verify].
- **Report Remove** (Childline + IWF) — remove a nude image of an under-18: childline.org.uk/info-advice/bullying-abuse-safety/online-mobile-safety/report-remove/ [verify URL resolves].
- **NSPCC Helpline** — worried and not sure where to start: **0808 800 5000** (phone Mon–Fri 10am–4pm; email any time at help@nspcc.org.uk).
- **Childline** — for your child to talk to someone directly: **0800 1111**.

Then open the matching Bearings playbook for the calm, step-by-step routing — but the playbooks signpost too; they don't replace the police, your child's school safeguarding lead, social services, or any helpline.

---

## Notes for whoever builds this

- This screen and the Emergency Signpost must never contradict each other. Re-verify both together. Keep the routing splits exact: Report Remove = **under-18**; CEOP ≠ bullying/hacking; bullying/fake accounts/hacking → platform then Report Harmful Content.
- **Do not** add "what to do" steps beyond stay-calm and the standard stop/don't-pay/don't-delete/tell-someone safety messages. Those are standard NCA messaging, not bespoke advice. No bespoke incident-handling, ever.
- Pair each script with a one-tap link to its report route and its matching playbook.
- Re-verify every number, URL and setting reference on launch day and quarterly, against the sources below. All paths marked [verify] must be checked against the live source before publishing.

---

## Sources

- **CEOP / Thinkuknow (National Crime Agency)** — parent guidance on staying calm and keeping a child talking; sextortion safety messaging; CEOP Safety Centre reporting route. ceop.police.uk/ceop-reporting/ · thinkuknow.co.uk [verify]
- **Childline + Internet Watch Foundation — Report Remove** — removing a nude image of an under-18. childline.org.uk/info-advice/bullying-abuse-safety/online-mobile-safety/report-remove/ [verify URL resolves]
- **NSPCC** — talking to children about online safety; non-judgemental, no-confiscation, open-question approach; Helpline 0808 800 5000 (phone Mon–Fri 10am–4pm; email 24/7). nspcc.org.uk [verify]
- **Childline** — 0800 1111 · childline.org.uk
- **Internet Matters** — stranger contact and grooming red flags; age-tuned conversation guidance. internetmatters.org [verify]
- **Report Harmful Content (SWGfL / UK Safer Internet Centre)** — reporting bullying and harmful content for users 13+; running on a limited basis since April 2025 (funding ended), so responses may be limited. reportharmfulcontent.com [verify]
- **Samaritans** 116 123 · **Shout** text SHOUT to 85258 — distress and crisis support.
- Research basis for "disclosure beats monitoring": Kerr & Stattin on parental knowledge and child disclosure [verify — academic reference].
