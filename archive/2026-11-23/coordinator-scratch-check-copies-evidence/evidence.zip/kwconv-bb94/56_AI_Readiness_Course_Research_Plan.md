# AI Readiness Lab - Research Plan

*Created 2026-06-27. Purpose: design the second Bearings offer from first principles before polishing, filming, or selling it.*

---

## 1. The Decision This Research Must Support

We are designing the second offer beside the household digital-safety system:

**AI Readiness Lab for Families** - a parent-led course that helps families decide how AI is allowed at home, school, and online.

The research must answer five practical questions:

1. **What must parents understand?** The minimum useful map of AI, schoolwork, privacy, deepfakes, companions, source checking, and agents.
2. **What should families actually do?** The household rules, prompts, routines, and small projects that make the course useful in real life.
3. **How should the course be structured?** The right modules, sequence, age adaptations, and optional family activities.
4. **How should it be delivered?** Recorded, live cohort, school/PTA taster, Concierge enhancement, or bundle inside The System.
5. **What makes it engaging rather than worthy-but-dull?** Scenarios, decision games, demos, short labs, printable tools, and visible progress.

The output is not just a research report. The output is a **course design package** ready to build:

- Final course architecture.
- Module-by-module content map.
- Taster session outline.
- Parent workbook outline.
- Demo and activity menu.
- Include / exclude decisions.
- Delivery and pricing recommendation.
- Pre-launch fact-check and legal/safeguarding review list.

---

## 2. First-Principles Starting Point

The course exists because families are facing a new practical problem:

> AI is already inside homework, chat, search, image tools, revision, friendship, entertainment, and productivity. Parents do not need to become technical experts. They need a calm way to decide what is allowed, what is private, what needs school permission, what must be checked, and what should stay human.

From first principles, the course should teach four habits:

1. **Think before using the tool.** Define the task, decide what information is allowed, try the first step yourself, then ask for help.
2. **Treat AI as a tool, not a person.** Do not outsource emotional judgement, friendship, identity, or final responsibility to a system.
3. **Keep private things private.** No names, schools, addresses, health worries, family conflict, private images, screenshots, messages, or live incidents in prompts.
4. **Put a human check before trust or action.** Before anything is believed, submitted, shared, sent, posted, bought, or automated, a person checks it.

Everything else in the course should serve those habits.

---

## 3. Guardrails

The course must stay inside the existing Bearings product boundary unless Ben explicitly decides to create a separate child-facing product:

- Parent is the purchaser and primary learner.
- No child accounts created by Bearings.
- No child-identifiable data collected by Bearings.
- No public student showcase, community, comments, peer review, or messaging.
- No automated assessment, scoring, ranking, prediction, or profiling of a child.
- Family activities happen at home under parent supervision.
- School policy comes first for homework, coursework, exams, and assessment.
- Urgent issues route to the emergency signpost only.
- No promises of safety, academic improvement, exam advantage, future-proofing, employability, or career advantage.

This lets us build something useful without accidentally creating an education platform, safeguarding service, tutoring product, or child-data product.

---

## 4. Research Workstreams

### Workstream A - Parent Jobs To Be Done

**Question:** What are parents really hiring this course to do?

We need to learn the real anxieties and moments of need, not just the topics we think matter.

Research questions:

- What AI situations have already come up at home?
- What do parents feel behind on?
- What do they fear most: cheating, safety, deepfakes, privacy, overreliance, emotional attachment, scams, or being unable to advise?
- What do they want permission to allow?
- What do they want permission to say no to?
- What would make them feel they had a practical household plan?
- What do they find boring, patronising, too technical, or too alarmist?

Method:

- 12 to 18 parent interviews, 30 minutes each.
- Split by age band:
  - 4 to 6 parents of 9-11s.
  - 4 to 6 parents of 12-14s.
  - 4 to 6 parents of 15-17s.
- Include a mix of:
  - AI-curious parents.
  - AI-anxious parents.
  - Parents who already use ChatGPT or similar tools at work.
  - Parents who do not feel technical.
  - Parents with children at schools that have already sent AI guidance.

Key prompts:

- "Tell me about the last time AI came up at home."
- "What would you allow today? What would you not allow?"
- "Where do you feel you are guessing?"
- "What would make a course worth paying for?"
- "What would make you stop watching after ten minutes?"
- "What would you want to take away and put on the fridge?"

Output:

- Parent need map.
- Top 10 practical questions parents ask.
- Language bank: phrases parents naturally use.
- List of course promises that feel valuable without overclaiming.

---

### Workstream B - Child Reality, Without Becoming Child-Facing

**Question:** What are children actually doing with AI, as understood through parents, schools, and existing evidence?

We should not run a child-facing research programme inside Bearings V1. But we do need a grounded map of likely behaviours.

Research questions:

- What AI tools are children encountering in homework, phones, search, social apps, games, and creative tools?
- How do children distinguish "help" from "doing it for me"?
- What shortcuts do they use?
- What makes them more likely to hide AI use?
- What age differences matter?
- What situations become social or emotional rather than purely academic?

Method:

- Parent interviews from Workstream A.
- 6 to 8 teacher / tutor / safeguarding lead conversations.
- Desk research from Ofcom, NSPCC, DfE, JCQ, ICO, and platform guidance.
- Review existing Bearings content:
  - `content/platforms/ai-chatbots.mdx`
  - `content/playbooks/ai-schoolwork.mdx`
  - `content/playbooks/ai-nudify.mdx`
  - `content/playbooks/ai-companions.mdx`
  - `content/playbooks/critical-thinking.mdx`
  - `content/playbooks/disclosure-scripts.mdx`

Output:

- "What children are likely doing" map, by age band.
- "Where parents misread the situation" list.
- Age adaptation rules for the course.

---

### Workstream C - Schoolwork, Integrity, And Assessment Rules

**Question:** What must the course say about AI and schoolwork?

This is likely the highest-converting topic and the easiest place to get the tone wrong.

Research questions:

- What is okay for homework practice?
- What is not okay for submitted work?
- How should families handle coursework, GCSE/A-level/IB/AP/entrance exams, and assessed tasks?
- What should parents ask schools?
- What is the minimum practical guidance that respects school policy without becoming legalistic?
- How should the course explain acknowledgement?

Required source check:

- DfE generative AI in education guidance.
- DfE generative AI product safety standards.
- JCQ AI Use in Assessments guidance.
- Current school-facing policies from a small sample of UK independent/state/international schools, if available publicly.

Research method:

- Build a "schoolwork ladder" and test it with parents and educators:
  - Red: no AI.
  - Amber: ask first.
  - Green with acknowledgement: allowed support, school policy permitting.
  - Practice: AI encouraged for revision, explanation, quizzing, feedback after attempt.
- Run 5 scenario tests:
  - "Child asks AI to write the paragraph."
  - "Child asks AI to quiz them."
  - "Child asks AI to rewrite their essay in adult language."
  - "Child uses AI for coursework planning."
  - "Child uses AI to generate an image for a school project."

Output:

- Final schoolwork ladder.
- Parent script: "What to ask the school."
- Family rule clauses.
- Course scenarios for session 3.

---

### Workstream D - Deepfakes, Synthetic Media, Consent, And Image Risk

**Question:** What should families understand about deepfakes without making the module frightening or incident-handling-heavy?

Research questions:

- What do parents need to know about AI-generated/altered nude images?
- What should children understand before group chats, image sharing, and school peer pressure situations?
- How do we explain fake images, voice cloning, and impersonation in plain English?
- What is the right boundary between prevention education and live incident response?
- How do we teach consent without creating a fear module?

Required source check:

- CEOP/NCA guidance.
- Childline/IWF Report Remove guidance.
- UK legal position on sexually explicit deepfakes, including Data (Use and Access) Act 2025.
- Existing Bearings emergency signpost and AI-nudify playbook.

Research method:

- Create 8 scenario cards:
  - Fake image shared in a group chat.
  - Voice note made to imitate someone.
  - "It was only a joke" image edit.
  - AI-generated celebrity/peer image.
  - Pressure to send a real photo.
  - Threat to share an image.
  - Classmate's face used in an image tool.
  - Parent discovers a tool in browser history.
- Test parent comprehension:
  - What would you say first?
  - What would you avoid saying?
  - Where would you go if it had already happened?

Output:

- Synthetic media mini-module.
- Prevention-only family rules.
- Signpost-only incident routing slide.
- "What not to say" card for AI image incidents.

---

### Workstream E - AI Companions, Chatbots, And Emotional Overreliance

**Question:** How do we teach the "AI is a tool, not a person" point in a way that lands?

Research questions:

- How are children using AI companions or character chatbots?
- What makes these different from homework tools?
- What private information might a child disclose?
- How do parents respond without mocking or shaming?
- What boundaries should families set around emotional support, loneliness, relationship-style bots, and late-night use?

Research method:

- Desk research from NSPCC, Ofcom, DfE product safety standards, and platform policies.
- Parent interviews: "Has your child used or mentioned AI chatbots or character apps?"
- Review existing Bearings AI companions content.
- Draft and test parent scripts:
  - "I get why that feels helpful."
  - "A tool can respond, but it is not a friend or therapist."
  - "Private worries need a real person."

Output:

- Companion/chatbot module.
- Private-worries rule.
- Parent conversation script.
- "Tool, not person" activity.

---

### Workstream F - Privacy, Data, And Prompt Hygiene

**Question:** What is the minimum memorable privacy model a family can actually use?

Research questions:

- What do parents and children not realise they are putting into AI?
- How do we make "no private data" concrete?
- Which examples make the rule stick?
- What should families do with photos, screenshots, documents, voice, schoolwork, names, and location?

Method:

- Build a "Private Stays Private" card.
- Test with parents:
  - Is this clear?
  - What examples are missing?
  - Could your child remember it?
  - Would you put it near the computer?

Output:

- Privacy module.
- Printable card.
- Prompt hygiene checklist.
- Demo rules for every course recording.

---

### Workstream G - Source Checking, Hallucinations, And Critical Judgement

**Question:** How do we make source checking feel like a useful habit, not a school lecture?

Research questions:

- What claims should children check?
- How do we show that fluent answers can be wrong?
- What is a source, in a practical family context?
- What should a child do when AI says "I am not sure" or cites something that does not exist?
- How do we avoid making parents feel they must fact-check everything forever?

Method:

- Create 5 short "AI said this" examples:
  - One true but needs a source.
  - One plausible but false.
  - One outdated.
  - One biased or incomplete.
  - One that should not be answered without context.
- Test a three-step source-check routine:
  - What is the claim?
  - Where else can we check it?
  - What would change our mind?

Output:

- Source-check sheet.
- Session demo.
- Parent/child activity.
- "When not to trust the answer" checklist.

---

### Workstream H - Prompting As Clear Thinking

**Question:** What prompt pattern gives families a useful skill without turning the course into prompt-engineering theatre?

Research questions:

- What prompt structure is simple enough to remember?
- How do we reinforce "try first"?
- Which prompt types are genuinely useful for learning?
- How do we avoid normalising final-answer generation?

Candidate pattern:

1. Goal.
2. Context.
3. Boundaries.
4. My attempt.
5. Help wanted.
6. Output format.

Prompt types to test:

- Explain this at three levels.
- Ask me questions before answering.
- Give me hints, not the answer.
- Quiz me one question at a time.
- Give feedback on my attempt.
- Show a different worked example.
- Help me check sources.

Output:

- Bearings Prompt Card.
- Learning Prompt Builder.
- Prompt examples by age band.
- Red-flag prompt list.

---

### Workstream I - Small Projects, Agents, And Automation

**Question:** How do we give the course an optimistic, creative centre without opening risky automation?

Research questions:

- What "build with AI" projects are genuinely useful for families?
- Which are safe enough for a first project?
- What should be avoided?
- What is the simplest project canvas?
- How do we explain automation versus autonomy?

Project menu to test:

Green first projects:

- Study quiz generator.
- Reading companion that asks questions before offering answers.
- Explain-this-three-ways helper.
- Family activity planner using invented preferences.
- Creative story-world builder with parent-set boundaries.
- Source-checking worksheet helper.
- Revision timetable draft checked by parent and child.

Amber later projects:

- Research assistant for a school topic.
- Simple app prototype.
- Portfolio explainer.
- Email draft that is never sent automatically.
- Coding helper that explains changes before the child uses them.

Red projects for now:

- Automated messages.
- Anything storing private worries, disclosures, or incident details.
- Anything using classmates' data, images, messages, or voices.
- Public posting or public portfolio creation.
- Autonomous purchasing or account changes.
- Browser control, downloads, or private account access.
- Companion-style emotional support persona.

Output:

- Project menu.
- Project canvas.
- Parent review checklist.
- "Human check before..." rule.

---

## 5. Engagement Research: How To Make It Not Boring

The course should not feel like a compliance briefing. It should feel like a parent getting a usable map and leaving with tools.

Research question:

What formats make parents say, "I understand this now, and I know what to do tonight"?

Formats to test:

1. **Scenario cards**
   - "Your child says everyone uses AI for homework."
   - "A fake image appears in a group chat."
   - "They are using a chatbot as a late-night confidant."
   - "They want to use AI to build a revision app."

2. **Decision games**
   - Green / amber / red sorting.
   - Help / practice / cheating sorting.
   - Private / okay / ask first sorting.

3. **Before-and-after prompts**
   - Weak prompt to better prompt.
   - "Do it for me" to "help me think."

4. **Short demos**
   - Fluent wrong answer.
   - Good hint prompt.
   - Source-checking demo.
   - Synthetic image consent scenario, without showing explicit content.

5. **Family lab outputs**
   - Family AI Agreement.
   - Schoolwork ladder.
   - Private Stays Private card.
   - Source-check sheet.
   - Project canvas.

6. **Tiny wins**
   - Every session should end with one thing the parent can say, set, or print that night.

Engagement test:

- Run a 45-minute prototype taster with 6 to 10 parents.
- Measure:
  - Which moments got attention?
  - Which bits dragged?
  - What did they remember 24 hours later?
  - What did they actually discuss with their child?
  - Would they pay for the full course?

Output:

- Engagement principles.
- Activity format ranking.
- Final session rhythm.

Recommended session rhythm:

1. 5 minutes - calm problem opener.
2. 10 minutes - simple map.
3. 10 minutes - scenario or decision game.
4. 10 minutes - demo.
5. 15 minutes - worksheet or rule-building.
6. 5 minutes - what to do this week.

---

## 6. Delivery Research

We should test four possible formats.

### Format 1 - Recorded Add-On

Best for:

- Low-friction purchase.
- Included inside The System.
- Easy to sell after the household plan.

Research questions:

- Will parents complete recorded modules?
- How short must each segment be?
- Does a workbook increase completion?
- Is GBP 29-49 credible as an add-on?

Likely shape:

- Four sessions broken into 8-12 minute chapters.
- Downloadable workbook.
- No child data.
- Optional family labs.

### Format 2 - Live Parent Cohort

Best for:

- Higher value perception.
- Faster learning from real parents.
- Stronger testimonials.

Research questions:

- Will parents attend four weekly evening sessions?
- Is GBP 79-149 credible?
- Should sessions be recorded?
- How much Q&A is needed?

Likely shape:

- Four weekly parent sessions.
- 60 minutes teaching + 15 minutes Q&A.
- Workbook.
- No child attendance required.

### Format 3 - School/PTA Parent Evening

Best for:

- Lead generation.
- Trust borrowing from school/PTA context.
- Testing message at scale.

Research questions:

- Do schools want AI homework only, or broader AI family rules?
- What language will schools accept?
- What must be excluded to avoid policy conflict?
- Is GBP 300-750 credible?

Likely shape:

- 60-minute parent taster.
- Take-home AI agreement starter.
- School boundary slide.
- Optional full course CTA.

### Format 4 - Concierge Enhancement

Best for:

- Families already paying for high-touch setup.
- AI-specific worry.
- Personalised household rules.

Research questions:

- Does AI deserve a separate paid add-on inside Concierge?
- What can be personalised without collecting child data?
- What does the family need after the call?

Likely shape:

- 45-minute AI rules call.
- Parent receives family AI agreement, prompt card, and project menu.

Output:

- Delivery recommendation.
- Pricing recommendation.
- First launch sequence.

---

## 7. Content Architecture To Test

The working hypothesis is:

### Core Course

**AI Readiness Lab for Families**

1. The AI Map And Household Rules.
2. Prompting As Clear Thinking.
3. Schoolwork, Creativity, And Synthetic Media.
4. Small Projects, Agents, And Human Review.

### Standalone Mini-Courses

1. AI Homework: Help, Practice, Or Cheating?
2. Deepfakes, Nudify Tools, Voice Cloning And Consent.
3. AI Companions, Chatbots And Emotional Overreliance.
4. Private Stays Private: Data, Photos, Prompts And AI.
5. Source Checking And Hallucinations.
6. Prompting As Thinking.
7. Small Supervised AI Projects.
8. Agents, Automation And What Not To Automate.
9. Age-By-Age AI Rules.

Research should decide whether these are:

- Separate paid modules.
- Bonus chapters inside the flagship.
- Printable packs.
- School taster variants.
- Stay Current monthly topics.

---

## 8. Research Participants

Minimum viable sample:

- 12 to 18 parents.
- 6 to 8 educators / tutors / safeguarding or pastoral staff.
- 3 to 5 school/PTA decision-makers.
- 2 to 3 legal/data/safeguarding reviewers, even if informal at first.

Avoid collecting:

- Child names.
- School names if not public.
- Specific incidents involving identifiable children.
- Screenshots, messages, images, or live cases.

Recruitment prompt:

> We are designing a parent course about children and AI: homework, privacy, deepfakes, AI companions, source checking, and small supervised projects. We are not asking about your child's private data or any incident details. We want to understand what parents need explained clearly and what would make the course genuinely useful.

---

## 9. Desk Research Source List

Primary sources to review and re-check before launch:

- DfE - Generative artificial intelligence in education.
- DfE - Generative AI product safety standards.
- JCQ - AI Use in Assessments.
- ICO - AI and data protection guidance.
- Ofcom - Children and parents: media use and attitudes.
- NSPCC - Generative AI and children's safety.
- CEOP/NCA - online child sexual abuse and grooming reporting.
- Childline/IWF - Report Remove.
- UK legislation and government notes on sexually explicit deepfake offences.
- Platform help pages for AI features and age settings where demonstrated.

Secondary sources may be useful for market language and parent concerns, but course claims should be grounded in primary or official guidance wherever possible.

---

## 10. Analysis Framework

For every possible course topic, score it against five questions:

1. **Parent urgency:** Do parents already worry or ask about this?
2. **Practical action:** Can we give them something to do, say, print, or decide?
3. **Age relevance:** Does it adapt cleanly across 9-11, 12-14, and 15-17?
4. **Guardrail fit:** Can it stay parent-led, no child data, no child accounts, no incident handling?
5. **Engagement potential:** Can it be taught through a scenario, demo, decision game, or family lab?

Use this to decide:

- Core course topic.
- Bonus module.
- Printable only.
- Stay Current update.
- Exclude for now.

---

## 11. Prototype Sequence

### Prototype 1 - Content Map

Build:

- One-page course map.
- Module list.
- Learning outcomes.
- "What you leave with" list.

Test with:

- 5 parents.
- 2 educators.

Decision:

- Is this the right promise?
- Which modules feel essential?
- Which feel optional?

### Prototype 2 - Taster Session

Build:

- 45-60 minute school/PTA-style parent taster.
- Includes:
  - AI map.
  - Schoolwork ladder.
  - Private Stays Private rule.
  - Deepfake/synthetic-media boundary.
  - One prompt demo.
  - One family agreement starter.

Test with:

- 6 to 10 parents.

Decision:

- What lands?
- What drags?
- What questions repeat?
- What do parents remember and use?

### Prototype 3 - Workbook Pack

Build:

- Family AI Agreement.
- Prompt Card.
- Schoolwork Ladder.
- Synthetic Media Rules.
- Source Check Sheet.
- Project Canvas.
- Parent Review Checklist.

Test with:

- 5 families using it at home for one week.

Decision:

- Which worksheets get used?
- Which need simplifying?
- What do families actually keep?

### Prototype 4 - Paid Offer Test

Build:

- Landing page section.
- Pricing options.
- Short module preview.
- Email waitlist or checkout-intent button.

Test:

- Existing Bearings reviewers.
- School/PTA contacts.
- Parent networks.

Decision:

- Recorded add-on first, live cohort first, or school taster first.

---

## 12. Success Criteria

The research is successful if we can confidently say:

- Parents understand the course promise in one sentence.
- At least 70% of interviewed parents can name one immediate action they would take after the taster.
- Parents describe the tone as calm, practical, and useful, not alarmist or too technical.
- Educators do not flag the schoolwork guidance as misleading or overreaching.
- The course can be delivered without child accounts, child data, or child-facing infrastructure.
- The workbook contains at least five assets parents say they would actually use.
- The first paid format is clear: recorded add-on, live cohort, school taster, or Concierge enhancement.

Do not use these as marketing claims until properly validated. They are internal go/no-go criteria.

---

## 13. Timeline

### Week 1 - Desk Research And Interview Setup

- Review official guidance.
- Review existing Bearings AI content.
- Draft interview guide.
- Recruit parents and educators.
- Build first content map.

Deliverable: research brief + interview script + first course map.

### Week 2 - Parent And Educator Interviews

- Run 12 to 18 parent interviews.
- Run 6 to 8 educator/tutor/safeguarding conversations.
- Extract recurring questions, worries, language, and objections.

Deliverable: insight map + topic priority matrix.

### Week 3 - Prototype Taster And Workbook

- Build 45-60 minute taster.
- Build workbook v0.1.
- Run one small taster with 6 to 10 parents.
- Collect feedback after 24 hours.

Deliverable: tested taster + workbook edits.

### Week 4 - Course Architecture And Offer Decision

- Finalise module structure.
- Decide delivery route.
- Draft offer page.
- Draft school/PTA version.
- Produce launch checklist.

Deliverable: course build spec + go/no-go recommendation.

---

## 14. Final Outputs

At the end of this research phase, produce:

1. **Course Research Findings** - what parents need, what educators flagged, what official guidance requires.
2. **Course Architecture** - final module sequence and age adaptations.
3. **Content Matrix** - topic by module, source anchor, activity, takeaway asset.
4. **Taster Session** - 45-60 minute parent session.
5. **Workbook v1** - ready to design and package.
6. **Offer Page Copy** - parent and school/PTA variants.
7. **Delivery Recommendation** - recorded, live cohort, school/PTA, Concierge, or bundle.
8. **Pre-Launch Review List** - facts, legal/safeguarding, data, platform age restrictions, claims.

---

## 15. Current Best Guess Before Research

The strongest launch path is probably:

1. **Free/taster:** AI Homework: What Is Fine, What Is Not, And What To Say At Home.
2. **Paid core:** AI Readiness Lab for Families - four parent sessions + workbook.
3. **Included mini-modules:** deepfakes, AI companions, privacy, source checking.
4. **School/PTA version:** 60-minute parent evening.
5. **Concierge enhancement:** family AI rules and project review.

But the research should be allowed to disprove this. If parents mostly want schoolwork, lead with schoolwork. If schools mostly want a taster, start there. If families love the project canvas, make the course feel more creative. The point is to make the course genuinely useful, not merely comprehensive.

