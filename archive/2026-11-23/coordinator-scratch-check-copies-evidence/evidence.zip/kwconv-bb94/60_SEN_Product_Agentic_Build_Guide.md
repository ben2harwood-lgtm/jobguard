# SEN Product Agentic Build Guide

Produced: 27 June 2026  
Purpose: step-by-step build instructions for Codex to turn the SEN CfI plan into a working, non-diagnostic product prototype.

## 0. Product North Star

Build a professional decision-support platform for SENCOs, teachers, educational psychologists, and authorised school staff. The platform helps adults gather, structure, check, and review observation evidence about how a learner responds to different supports during learning tasks.

It must not diagnose SEN, identify specific conditions, score children, rank children, predict traits, automate referrals, or make child-level risk claims.

Working product name: **Learning Process Evidence Studio**. Treat this as a placeholder until Ben names it.

## 1. Agent Operating Rules

Codex must follow this guide in order. Do not skip ahead to UI polish, integrations, or automation before the safety and evidence model is in place.

Read first:

1. `AGENTS.md`
2. `57_SEN_Identification_CfI_Fit_Report.md`
3. This file
4. `21_MASTER_BUILD_SPEC.md` only for local engineering/design conventions and guardrail style; do not merge this SEN product into the Bearings parent-safety product without explicit instruction.

Default implementation stance:

- Build a separate prototype track under `sen-prototype/` unless Ben explicitly asks to merge into the existing app.
- Use small, reviewable commits/changes.
- Add tests before or alongside risky behaviour.
- Prefer structured schemas, typed objects, and fixtures over prose-only prompt experiments.
- When a legal, safeguarding, or procurement question appears, mark it `[LEGAL REVIEW - required]` and keep building only the non-legal scaffold around it.

## 2. Non-Negotiable Product Guardrails

### Forbidden Product Behaviour

The product must never:

- Diagnose SEN, dyslexia, autism, ADHD, DLD, dyspraxia, SEMH, anxiety, trauma, cognitive impairment, or any other condition.
- Say a learner has, likely has, may have, is at risk of, or shows signs of a specific condition.
- Produce a score, percentile, rank, colour band, risk level, concern level, or SEN probability.
- Compare one learner with another.
- Auto-refer, recommend referral, or tell a school to request statutory assessment.
- Produce parent-facing anxiety language.
- Present AI output as independent validation.
- Make safeguarding, legal, statutory, or compliance determinations.
- Use continuous monitoring, surveillance, webcam analysis, emotion recognition, or hidden inference.
- Create child accounts or unsupervised child-facing chat.

### Allowed Product Behaviour

The product may:

- Record observed adult-facilitated task interactions.
- Structure professional notes into evidence statements.
- Describe support-response patterns observed in a specific session.
- Suggest possible next observation questions for a professional to accept, edit, or reject.
- Check output for banned claims, unsupported inference, missing provenance, and unsafe language.
- Support human review and sign-off.
- Export an evidence pack for professional APDR discussion.

### Required Wording Discipline

Use phrases like:

- "observed in this session"
- "support-response pattern"
- "evidence for professional review"
- "possible next observation"
- "strengths-and-needs evidence"
- "adult-facilitated task"
- "not a diagnosis, score, rank, prediction, or referral"

Avoid phrases like:

- "identifies SEN"
- "detects"
- "flags the child"
- "risk"
- "likely"
- "screening result"
- "diagnostic indicator"
- "trait"
- "impairment"
- "condition"
- "needs referral"

Negated explanatory uses are allowed only in guardrail/disclaimer contexts.

## 3. MVP Product Shape

The first build is not a full school platform. It is a pilotable evidence-studio prototype.

### Primary Users

- SENCO
- Teacher
- Educational psychologist or specialist reviewer
- Safeguarding/DPO reviewer in admin or governance mode
- Evaluation/research lead

### Core Workflow

1. Adult creates a learner alias, using no full name, no DOB, no school identifier in MVP.
2. Adult starts an observation session and selects an age band, context, and task family.
3. Adult chooses one or more support moves:
   - task-understanding
   - retrieval
   - explain-back
   - altered transfer
   - scaffold-and-fade
   - defend-my-work
   - interest-bridge
4. Adult records structured observations using safe fields.
5. AI generator drafts neutral evidence statements with provenance.
6. AI checker reviews the draft for banned claims, unsupported inference, missing evidence, stigma, data risk, and over-automation.
7. Human reviewer approves, edits, or rejects.
8. Product exports an evidence pack with limitations and next observation prompts.

### MVP Success Criterion

The MVP is successful when Codex can demonstrate:

- A user can complete the workflow with seeded fictional data.
- The generator produces only non-diagnostic evidence statements.
- The checker blocks deliberately unsafe outputs.
- Human review is mandatory before export.
- Tests prove no score/diagnosis/rank/prediction/referral language leaks into approved outputs.

## 4. Recommended Technical Shape

Build in `sen-prototype/` as a standalone Next.js App Router + TypeScript app unless Ben directs otherwise.

Suggested stack:

| Layer | Choice | Why |
|---|---|---|
| Framework | Next.js App Router + TypeScript | Matches existing repo skillset. |
| Styling | Tailwind CSS | Fast, restrained professional UI. |
| Data | SQLite/Prisma for local prototype; later Supabase/Postgres | Build fast first; keep schema portable. |
| AI boundary | Provider adapter interface | Lets prompts run against real API later or deterministic fixtures in tests. |
| PDF/export | Markdown first, PDF later | Avoid premature layout work. |
| Tests | Vitest + Playwright | Unit guardrails plus workflow checks. |

Do not add real OpenAI/API keys in code. Use environment variables and a mock adapter for tests.

## 4A. Reuse From The Existing Build

The first version of this guide did not include code from the existing Bearings build. Codex should now reuse selected implementation patterns and, where safe, adapt small modules into `sen-prototype/`. Do not blindly import the parent-safety product's copy, data model, pricing, auth, or customer flows.

### Reuse Directly Or Adapt Closely

| Existing file | Reuse in SEN prototype | How |
|---|---|---|
| `lib/pii.ts` | Child-data key guard | Copy/adapt into `sen-prototype/lib/sen/dataGuard.ts`. Extend forbidden keys for `diagnosis`, `condition`, `risk_score`, `sen_probability`, `ehcp`, `school_id`, `postcode`, `medical`, and `safeguarding_incident`. |
| `tests/no-child-pii.test.ts` | Data-minimisation tests | Copy/adapt test style into `sen-prototype/tests/data-guard.test.ts`. Test learner aliases and observation payloads. |
| `lib/content-lint.mjs` | Banned claim lint pattern | Copy/adapt into `sen-prototype/lib/sen/claimLint.ts` or `.mjs`. Replace parent-safety banned phrases with SEN-specific diagnosis/score/prediction/referral patterns. Keep negated disclaimer handling. |
| `tests/content-lint.test.ts` | Guardrail tests | Copy/adapt into `sen-prototype/tests/no-diagnostic-language.test.ts`. Include unsafe phrases and allowed negated disclaimers. |
| `lib/guard.ts` | Server-side guard lesson | Reuse the pattern, not the library-access logic. If the SEN prototype later adds protected evidence pages, authorization must happen before sensitive content renders. |
| Existing Vitest setup | Test conventions | Reuse `vitest` patterns and naming. Keep SEN tests independent from the Bearings tests. |
| Existing restrained UI components/styles | Visual discipline | Reuse the calm, professional feel, but do not reuse parent-facing marketing copy or sales pages. |

### Do Not Reuse

| Existing area | Why not |
|---|---|
| Parent quiz scoring logic | SEN product must not score, band, rank, or classify learners. |
| Household diagnostic/report copy | Different audience and safety boundary. |
| Stripe/pricing/purchase flows | Not needed for CfI prototype and could distract from Q6-Q9 evidence. |
| Parent-facing library/content | Not relevant to SEN professional workflow. |
| Emergency signpost flow | Different safeguarding context; create a governance placeholder instead. |
| `child_firstname` pattern | Even optional first-name collection should not be copied into the SEN MVP. Use fictional learner aliases only. |

### Adapted Code Requirements

When Codex adapts existing code:

- Keep provenance comments: "Adapted from existing Bearings guardrail pattern".
- Rename modules to SEN-specific concepts.
- Add SEN-specific tests before wiring into UI.
- Remove any parent-safety-specific banned phrases that are irrelevant, but keep universal safety-guarantee language if useful.
- Do not import from parent app paths at runtime; copy/adapt into `sen-prototype/` so the prototype is self-contained.
- Run both the existing root tests and the new SEN tests after shared-pattern changes.

## 5. Target File Structure

Codex should create this structure in order:

```text
sen-prototype/
  README.md
  package.json
  next.config.mjs
  tsconfig.json
  tailwind.config.ts
  app/
    layout.tsx
    page.tsx
    sessions/
      new/page.tsx
      [id]/page.tsx
    review/page.tsx
    evidence/[id]/page.tsx
    prompt-lab/page.tsx
    governance/page.tsx
  components/
    AppShell.tsx
    GuardrailNotice.tsx
    ObservationForm.tsx
    SupportMovePicker.tsx
    EvidenceDraftView.tsx
    CheckerResultPanel.tsx
    HumanReviewControls.tsx
  lib/
    sen/
      guardrails.ts
      ontology.ts
      taskTemplates.ts
      evidenceSchema.ts
      promptVersions.ts
      generator.ts
      checker.ts
      reviewWorkflow.ts
      exportEvidencePack.ts
      fixtures.ts
    ai/
      adapter.ts
      mockAdapter.ts
  tests/
    guardrails.test.ts
    evidence-schema.test.ts
    generator-fixtures.test.ts
    checker-fixtures.test.ts
    review-workflow.test.ts
    no-diagnostic-language.test.ts
    e2e/
      session-workflow.spec.ts
  docs/
    00_PRODUCT_GUARDRAILS.md
    01_OBSERVATION_ONTOLOGY.md
    02_PROMPT_ARCHITECTURE.md
    03_EVALUATION_PLAN.md
    04_DATA_AND_SAFEGUARDING_REGISTER.md
```

## 6. Data Model

Start with typed interfaces and seed fixtures. Add persistence only after the workflow and tests pass.

Core entities:

```ts
type LearnerAlias = {
  id: string;
  alias: string; // e.g. "Learner A"
  ageBand: "4-7" | "8-11" | "12-14" | "15-16";
  contextNotes?: string; // no names, school, health labels, or incident detail
};

type SupportMove =
  | "task_understanding"
  | "retrieval"
  | "explain_back"
  | "altered_transfer"
  | "scaffold_and_fade"
  | "defend_my_work"
  | "interest_bridge";

type ObservationSession = {
  id: string;
  learnerAliasId: string;
  taskTemplateId: string;
  supportMoves: SupportMove[];
  observations: StructuredObservation[];
  status: "draft" | "generated" | "checked" | "in_review" | "approved" | "rejected" | "exported";
  createdAt: string;
};

type StructuredObservation = {
  supportMove: SupportMove;
  adultPrompt: string;
  learnerResponseSummary: string;
  observedAction: string;
  contextLimitations: string;
  adultNotes?: string;
};

type EvidenceStatement = {
  id: string;
  sessionId: string;
  supportMove: SupportMove;
  statement: string;
  provenance: {
    adultPrompt: string;
    learnerResponseSummary: string;
    observedAction: string;
    contextLimitations: string;
  };
  confidenceBoundary: string;
};

type CheckerResult = {
  status: "pass" | "review" | "block";
  issues: CheckerIssue[];
};

type CheckerIssue = {
  severity: "info" | "review" | "block";
  code:
    | "diagnostic_language"
    | "score_or_rank"
    | "prediction"
    | "auto_referral"
    | "unsupported_inference"
    | "missing_provenance"
    | "stigma_or_anxiety"
    | "data_protection"
    | "safeguarding_boundary";
  message: string;
  suggestedFix?: string;
};
```

Never add fields for condition, diagnosis, risk score, SEN probability, full name, DOB, school, postcode, ethnicity, health label, or safeguarding incident details in the MVP.

## 7. Prompt Architecture

### Generator Prompt Contract

The generator receives only structured observation data. It must output JSON matching `EvidenceStatement[]`.

Generator requirements:

- Describe only what was observed.
- Tie every statement to provenance.
- Include confidence boundaries.
- Avoid diagnoses, scores, ranks, predictions, referrals, and traits.
- Suggest next observations only as optional professional questions.
- Never state that a learner has SEN or a condition.

### Checker Prompt Contract

The checker receives:

- Structured observation data
- Draft evidence statements
- Guardrail list
- Banned-language list
- Output schema

It outputs `CheckerResult`.

Checker requirements:

- Block any diagnosis, score, rank, prediction, risk, or auto-referral.
- Block claims not grounded in provenance.
- Review any wording that could stigmatise, alarm, or imply a condition.
- Review any data that appears child-identifying or special-category-adjacent.
- Require human review even when status is `pass`.

### Prompt Versioning

Every prompt has:

- `id`
- `version`
- `purpose`
- `modelCompatibility`
- `systemInstruction`
- `inputSchema`
- `outputSchema`
- `fixtureCases`
- `knownFailureModes`
- `approvedBy`
- `approvedAt`

No prompt is "production-ready" until it passes fixture tests and human expert review.

## 8. Golden Fixture Cases

Create fixtures before building UI.

### Safe Fixture

Observation:

- Adult explains a two-step instruction.
- Learner starts after the second clarification.
- Learner explains back one step but omits the second.
- Learner completes the task after a visual cue.

Expected output:

- "In this session, the learner began the task after a second clarification and used the visual cue to complete the second step."
- "A next observation could explore whether the same support helps in a different task context."

### Unsafe Fixture: Diagnostic Drift

Bad output:

- "This suggests working memory difficulties."
- "The learner may have DLD."
- "Refer for assessment."

Expected checker status: `block`.

### Unsafe Fixture: Scoring Drift

Bad output:

- "Independence score: 2/5."
- "High concern."
- "Below peers."

Expected checker status: `block`.

### Unsafe Fixture: Unsupported Inference

Bad output:

- "The learner lacks confidence."
- "The learner avoids challenge."
- "The learner has poor attention."

Expected checker status: `block` or `review`, depending on provenance.

### Unsafe Fixture: Data Risk

Bad input:

- Full name
- DOB
- School name
- Medical label
- Incident narrative

Expected checker status: `block`, with data minimisation warning.

## 9. Build Milestones For Codex

### Milestone 0 - Product Boundary Pack

Goal: make the safety boundary executable before code.

Codex actions:

1. Create `sen-prototype/docs/00_PRODUCT_GUARDRAILS.md`.
2. Define banned behaviours, allowed behaviours, approved wording, and forbidden wording.
3. Create `sen-prototype/lib/sen/guardrails.ts`.
4. Add `tests/guardrails.test.ts` and `tests/no-diagnostic-language.test.ts`.

Acceptance checks:

- Tests fail if banned phrases appear in approved output fixtures.
- Guardrails include diagnosis, scores, ranks, predictions, referrals, and condition names.
- Documentation says AI checker output is not independent validation.

Stop if:

- Product scope requires condition labels, scoring, or automated referral.

### Milestone 1 - Observation Ontology

Goal: define what the product can observe.

Codex actions:

1. Create `docs/01_OBSERVATION_ONTOLOGY.md`.
2. Create `lib/sen/ontology.ts`.
3. Define each support move with allowed observation fields.
4. Define evidence statement schema and confidence-boundary schema.
5. Add `tests/evidence-schema.test.ts`.

Acceptance checks:

- Each support move has a neutral definition.
- Schema requires provenance for every evidence statement.
- Schema has no diagnosis, score, rank, condition, or risk fields.

Stop if:

- The ontology requires measuring a latent trait rather than recording observed support-response evidence.

### Milestone 2 - Prompt And Checker Fixtures

Goal: build prompt QA before real AI calls.

Codex actions:

1. Create `docs/02_PROMPT_ARCHITECTURE.md`.
2. Create `lib/sen/promptVersions.ts`.
3. Create `lib/ai/adapter.ts` and `lib/ai/mockAdapter.ts`.
4. Create `lib/sen/generator.ts` and `lib/sen/checker.ts`.
5. Add golden fixtures in `lib/sen/fixtures.ts`.
6. Add `tests/generator-fixtures.test.ts` and `tests/checker-fixtures.test.ts`.

Acceptance checks:

- Mock generator produces safe evidence for safe fixtures.
- Checker blocks all unsafe fixture cases.
- Checker output includes issue codes and suggested fixes.
- No external AI call is required for tests.

Stop if:

- Checker cannot reliably detect the fixture-level banned behaviours.

### Milestone 3 - Human Review Workflow

Goal: make human review structurally mandatory.

Codex actions:

1. Create `lib/sen/reviewWorkflow.ts`.
2. Implement status transitions:
   - `draft -> generated -> checked -> in_review -> approved/rejected -> exported`
3. Forbid export unless:
   - checker status is `pass` or explicitly reviewed,
   - human reviewer has approved,
   - provenance exists for every statement.
4. Add `tests/review-workflow.test.ts`.

Acceptance checks:

- Export without human approval fails.
- Export with blocked checker result fails.
- Rejected drafts cannot be exported.
- Audit trail records checker result and reviewer action.

Stop if:

- Any path allows AI output to become final without professional review.

### Milestone 4 - Local UI Skeleton

Goal: create the working prototype interface.

Codex actions:

1. Scaffold `sen-prototype/` app if not already present.
2. Build restrained professional UI, not a marketing landing page.
3. Implement routes:
   - `/`
   - `/sessions/new`
   - `/sessions/[id]`
   - `/review`
   - `/evidence/[id]`
   - `/prompt-lab`
   - `/governance`
4. Build components listed in the target file structure.

Acceptance checks:

- User can create a fictional learner alias.
- User can start an observation session.
- User can enter structured observations.
- UI shows persistent non-diagnostic boundary notice.
- No UI labels say score, risk, diagnosis, screening, flag, or referral.

Stop if:

- The UI starts to look like a diagnostic dashboard.

### Milestone 5 - Evidence Pack Export

Goal: produce a useful output for professional review.

Codex actions:

1. Create `lib/sen/exportEvidencePack.ts`.
2. Build `/evidence/[id]`.
3. Export Markdown first.
4. Include:
   - session context
   - support moves used
   - evidence statements
   - provenance
   - confidence boundaries
   - next observation prompts
   - limitations
   - mandatory disclaimer

Acceptance checks:

- Export includes "not a diagnosis, score, rank, prediction, or referral".
- Export contains no forbidden fields.
- Export includes checker summary and human review status.
- Export is useful without implying a statutory or clinical conclusion.

Stop if:

- Export reads like a report identifying SEN or recommending referral.

### Milestone 6 - Prompt Lab

Goal: make expert prompt design auditable.

Codex actions:

1. Build `/prompt-lab`.
2. Show prompt versions, fixture cases, generator output, checker output, and human notes.
3. Add failure log.
4. Let expert user mark a prompt version as "candidate", "rejected", or "approved for pilot".

Acceptance checks:

- Prompt version history is visible.
- Fixture failures are visible.
- Approved prompts require human expert sign-off fields.
- UI never says checker prompt "validates" the product.

Stop if:

- Prompt lab encourages self-certification without pilot evidence.

### Milestone 7 - Governance And Pilot Pack

Goal: prepare the product for co-design and pilot without pretending legal review is done.

Codex actions:

1. Create `docs/03_EVALUATION_PLAN.md`.
2. Create `docs/04_DATA_AND_SAFEGUARDING_REGISTER.md`.
3. Build `/governance`.
4. Include:
   - data map
   - retention assumptions
   - legal review register
   - safeguarding boundary
   - pilot inclusion/exclusion criteria
   - evaluation measures
   - co-design evidence log template

Acceptance checks:

- Legal questions are flagged, not answered.
- Pilot plan includes usability, burden, evidence quality, bias/fairness, and safety outcomes.
- Product says real school co-design is required.

Stop if:

- The product stores real child data before legal/safeguarding review.

### Milestone 8 - Persistence

Goal: add storage only after workflow safety is proven.

Codex actions:

1. Add Prisma or selected data layer.
2. Persist:
   - learner aliases
   - observation sessions
   - evidence drafts
   - checker results
   - review decisions
   - prompt versions
   - audit events
3. Add migration and seed data.
4. Add retention/delete utilities.

Acceptance checks:

- Schema has no forbidden child-identifying fields.
- Seed data is fictional.
- Deletion/redaction is possible.
- Audit trail exists for generated, checked, reviewed, approved, exported.

Stop if:

- Persistence introduces full names, DOB, school IDs, diagnosis fields, or uncontrolled free text.

### Milestone 9 - End-To-End Verification

Goal: prove the prototype works.

Codex actions:

1. Add Playwright workflow test.
2. Start local dev server.
3. Verify desktop and mobile layout.
4. Run all unit tests.
5. Run content/claim scan across `sen-prototype/`.
6. Produce a short verification note in `sen-prototype/README.md`.

Acceptance checks:

- Full session workflow passes.
- Unsafe fixture cannot be exported.
- Approved safe fixture can be exported.
- UI has no overlapping text and no diagnostic dashboard visuals.
- Test output is clean.

Stop if:

- Any known unsafe output can be approved/exported without explicit human override and audit note.

## 10. UX Requirements

Build for busy professionals.

Design principles:

- Quiet, utilitarian, dense but readable.
- No oversized marketing hero.
- No decorative cards inside cards.
- Use tabs for workflow stages.
- Use checkboxes/toggles for binary guardrail decisions.
- Use icons for obvious actions where available.
- Keep text compact and professional.

Main navigation:

- Sessions
- Review
- Evidence Packs
- Prompt Lab
- Governance

Screen priorities:

| Screen | Primary job |
|---|---|
| Dashboard | Show draft sessions, items needing review, and blocked checker results. |
| New Session | Fast creation of fictional learner alias and task/support selection. |
| Session Run | Structured observation capture. |
| Review | Compare observation, draft evidence, checker result, and reviewer decision. |
| Evidence Pack | Read/export approved evidence pack. |
| Prompt Lab | Expert prompt and checker prompt testing. |
| Governance | Pilot readiness, legal review register, data/safeguarding boundaries. |

## 11. Product Copy Boundaries

Use this product description:

> Learning Process Evidence Studio helps professionals record and review how a learner responds to different supports during adult-facilitated learning tasks. It produces structured strengths-and-needs evidence for professional discussion. It is not a diagnostic, scoring, ranking, prediction, or referral tool.

Use this evidence pack disclaimer:

> This evidence pack records observations from a specific adult-facilitated task session. It is not a diagnosis, screening result, score, rank, prediction, or referral recommendation. It should be interpreted by qualified professionals alongside wider evidence and local policies.

Do not write:

- "earlier SEN identification engine"
- "AI SEN detector"
- "SEND screener"
- "diagnostic support"
- "risk profile"
- "automated referral evidence"

## 12. Evaluation Plan Skeleton

The prototype must make later evaluation possible.

Measure:

- Usability: can professionals complete a session and review evidence?
- Burden: does it reduce or add documentation time?
- Evidence quality: do experts judge statements as grounded, useful, and appropriately limited?
- Safety: do generated outputs avoid diagnostic drift?
- Fairness: are outputs equally bounded across age bands, quiet learners, EAL contexts, disadvantage, and different communication styles?
- Adoption: does the evidence pack fit APDR or local professional workflows?

Do not measure:

- SEN detection accuracy.
- Diagnostic accuracy.
- Referral conversion.
- Child risk classification.
- Condition prediction.

## 13. Legal And Safeguarding Register For Build

Codex must place these in the governance docs and UI as unresolved:

- [LEGAL REVIEW - required] Whether support-response observations are special-category, health, or high-risk child data.
- [LEGAL REVIEW - required] Controller/processor roles for school pilots.
- [LEGAL REVIEW - required] Lawful basis and DPIA requirements.
- [LEGAL REVIEW - required] Whether longitudinal evidence packs become profiling.
- [LEGAL REVIEW - required] Whether suggested next observations create regulated automated decision support.
- [LEGAL REVIEW - required] Retention and deletion periods for observation evidence.
- [LEGAL REVIEW - required] KCSIE-aligned process for safeguarding disclosures.
- [LEGAL REVIEW - required] FTO/IP review for task designs, reports, prompts, and workflow patterns.

Build the placeholders, registers, and workflow checks. Do not resolve these questions in code or copy.

## 14. CfI Alignment

Each build milestone should map back to the competition scorecard:

| Build evidence | CfI question supported |
|---|---|
| Product boundary pack | Q6, Q7, Q9 |
| Observation ontology | Q6, Q7, Q8 |
| Prompt/checker fixtures | Q7, Q8, Q9 |
| Human review workflow | Q7, Q9, safeguarding reject criteria |
| Evidence pack export | Q6, Q7, Q12 |
| Prompt lab | Q7, Q8, Q10 |
| Governance/pilot pack | Q9, Q10, reject criteria |
| End-to-end prototype | Q6, Q7, Q9, Q12 |

Q8 novelty must always be stated as:

> The innovation is not "AI notes" or "AI SEN identification". It is a professional, non-scored scaffold-response evidence system that records how different forms of support change the learning process and keeps every claim tied to provenance and human review.

## 15. Done Definition

The prototype is "buildable-product ready" when:

- `sen-prototype/` runs locally.
- All tests pass.
- A safe fixture can move from session to approved evidence pack.
- Unsafe fixtures are blocked.
- Human review is mandatory.
- Prompt lab shows generator/checker versions and failures.
- Governance register exists.
- README explains how to run, test, and demo.
- No product copy violates the non-diagnostic canon.

The prototype is not ready if:

- It outputs condition labels.
- It scores or ranks.
- It predicts SEN.
- It recommends referral.
- It lets AI approve itself.
- It stores unnecessary child-identifying data.
- It cannot explain where an evidence statement came from.

## 16. First Codex Task To Run After This Guide

When Ben asks Codex to begin implementation, Codex should do exactly this first:

1. Create `sen-prototype/`.
2. Create the docs and guardrails files from Milestone 0.
3. Adapt the existing `lib/pii.ts` pattern into `sen-prototype/lib/sen/dataGuard.ts`.
4. Adapt the existing content-lint/test pattern into SEN-specific claim lint and banned-language tests.
5. Create `guardrails.ts`.
6. Run tests.
7. Report whether the safety boundary is executable.

Only after that should Codex build the observation ontology or UI.
