# AI Readiness Course Proposal

*Competitive inspiration: AI Ready School, "Agentic AI for Kids" public landing page, reviewed 24 June 2026.*

## Short verdict

Yes, this is a useful basis for a course direction, but not something to copy or "extract" wholesale.

Use it as a market signal: parents and schools are being sold practical AI fluency for children, not just online-safety guidance. The public page shows a clear structure: explain agentic AI, let students experience AI tools, build workflows/apps, then finish with a showcase. That shape is commercially useful.

For Bearings, the better opportunity is to re-engineer it into a parent-led, safety-literate AI readiness offer: less hype, more judgement, more family context, more privacy discipline, and a clearer distinction between "using AI well" and "handing agency to a system".

## Important boundary

We should not copy their copy, slides, lesson materials, tool setup, brand names, images, proprietary worksheets, LMS flows, or any non-public material. We can use the visible public structure as competitive research and create an original course from first principles.

There is also a product-scope issue. The current Bearings V1 guardrail says: no child accounts and nothing child-facing. A direct kids' course would be a new product line and needs a separate legal/safeguarding/data review. A parent-only or parent-mediated course can fit much more cleanly.

## What the public course appears to contain

Based on the landing page, the AI Ready School offer is:

- Audience: grades 7-9.
- Format: four weeks, 1.5 hours per day, five days per week.
- Week 1: understanding agentic AI, AI and careers, human vs AI thinking, real-world examples.
- Week 2: hands-on exposure to AI systems and tools, including Claude-style prompting and AI-assisted building.
- Week 3: planning AI projects, automating tasks, building apps, and linking tools into workflows.
- Week 4: final projects and showcase, including a study agent, personal assistant, AI app, presentation, certificate, and portfolio.
- Delivery claims: small cohorts, individual tool accounts, LMS, expert trainers.

## What is strong about it

- It sells building, not passive tool use.
- The four-week arc is easy for a parent to understand.
- The final showcase gives the course a clear end point.
- The project list is concrete enough to feel useful.
- It treats "agentic AI" as a new literacy, which is a stronger frame than "prompting tips".

## What we should improve

- Make it less tool-dependent. Their page leans on specific tools and their own product suite. Bearings should teach transferable judgement, workflows, and habits.
- Add a parent layer. Parents need to understand what the child is doing, what data is being entered, and when an AI output should be questioned.
- Add safety and ethics as practical design constraints, not a one-off lecture.
- Avoid career-hype claims and shaky stats. We can talk about changing skills without making overconfident future-work claims.
- Separate automation from autonomy. Kids should learn that an agent needs boundaries, review points, and "stop conditions".
- Build in academic integrity. The offer should help families and schools distinguish help, practice, drafting, and cheating.
- Include deepfake, AI companion, privacy, and source-checking literacy.
- Age-band the activities. A 10-year-old, 13-year-old, and 16-year-old need different autonomy levels.
- Make the parent-facing promise calm: confidence, proportion, and better conversations, not "future-proofing" or panic.

## Recommended Bearings offer

### Working title

**AI Readiness Lab for Families**

Alternative names:

- AI Fluency for Families
- The Family AI Lab
- AI Sense, Safely
- Build With AI: A Parent and Teen Lab

### Positioning

A practical family course that helps parents and young people understand, question, and build with AI. It is not a coding bootcamp and not an online-safety scare session. It teaches clear thinking, safe setup, source checking, privacy habits, and small useful projects.

### Best initial format

Start with a parent-mediated format so it sits closer to current Bearings guardrails:

- Four weekly parent sessions, 60-75 minutes each.
- One optional family activity after each session, 20-45 minutes.
- Parent owns any accounts and supervises tool use.
- No child data collected by Bearings.
- No public student profiles, community, comments, or peer messaging.
- Optional school/PTA delivery as a parent evening plus take-home activities.

This can later become a direct parent-child workshop, but only after a separate scope review.

## Course outline

### Module 1: What AI Is Good At, And What It Is Bad At

Parent outcome: understand what large AI tools are doing in plain language, without mystique.

Family activity: compare three AI answers to the same question and mark what is helpful, vague, invented, or needs checking.

Core topics:

- AI as pattern prediction, not a person.
- Why confident answers can still be wrong.
- The difference between assistant, chatbot, agent, and automation.
- The family's "AI use agreement": what can go into AI tools, what stays private, and when a human checks.

### Module 2: Prompting As Clear Thinking

Parent outcome: know how to help a child ask better questions without outsourcing the thinking.

Family activity: turn a messy homework question into a better learning prompt, then ask the child to explain the final answer back without AI.

Core topics:

- Role, goal, context, constraints, and output format.
- Prompting for explanation, practice, feedback, and revision.
- How to ask AI to show uncertainty and sources.
- What counts as help versus doing the work for them.

### Module 3: AI For Learning And Creativity

Parent outcome: identify healthy, useful use cases and spot when AI starts flattening effort or originality.

Family activity: build a study pack: summary, flashcards, quiz questions, and a "what I still do not understand" list.

Core topics:

- Study assistant, quiz maker, writing feedback, language practice.
- Image/audio/video tools and synthetic media basics.
- Deepfakes, nudify tools, voice cloning, and consent.
- Academic integrity and school rules.

### Module 4: Building Small AI Workflows

Parent outcome: understand how simple agentic workflows work and how to set boundaries around them.

Family activity: design a simple workflow on paper before using tools: goal, inputs, steps, checks, stop condition, and what must never be automated.

Core topics:

- Planning before prompting.
- Breaking a task into steps.
- Human review points.
- Privacy and permissions.
- Why some tasks should stay manual.

### Module 5: Build Week

Parent outcome: guide a child through one small project without needing to be technical.

Family activity: build one project from a safe menu.

Project menu:

- Personal study helper for one school topic.
- Revision quiz game.
- Reading companion that asks questions instead of giving answers.
- Family meal or activity planner using non-sensitive preferences.
- Creative story-world generator with parent-set boundaries.
- Misinformation/source-checking helper.
- "Explain this to me at three levels" learning tool.

Avoid as first projects:

- Emailing teachers or other children automatically.
- Anything that logs personal feelings, live worries, or private incidents.
- Scraping classmates' or friends' data.
- Public posting.
- Autonomous purchasing, messaging, or account changes.

### Module 6: Showcase And Reset

Parent outcome: know how to review the project and decide what changes before the child uses it again.

Family activity: child presents what they built, what it gets wrong, what data it needs, and where a human must check it.

Core topics:

- "What problem did this solve?"
- "Where could this go wrong?"
- "What should the AI never decide?"
- "What would we change before using it for real?"
- Family AI agreement refresh.

## Age bands

### Ages 9-11

Focus: co-use, curiosity, simple rules, no private accounts, no open-ended AI companion use.

Good projects: story generator, quiz cards, explain-a-topic, hobby planner.

### Ages 12-14

Focus: schoolwork boundaries, source checking, synthetic media, privacy, early workflow thinking.

Good projects: study helper, revision quiz, source-checking helper, reading companion.

### Ages 15-17

Focus: stronger autonomy, academic integrity, portfolio projects, automation boundaries, future skills without hype.

Good projects: research assistant with citations, project planner, simple app prototype, revision dashboard.

## Parent-facing promise

By the end, parents should have:

- A plain-English understanding of how their child is likely to use AI.
- A family AI agreement.
- A safer setup for AI accounts and data habits.
- A practical way to talk about homework help, cheating, privacy, and synthetic media.
- One small family-reviewed AI project.
- A repeatable review habit for new tools.

Avoid promising a certain risk outcome or future-proof career advantage.

## How it fits the existing Bearings product

Best fit as an add-on or lead magnet, not the V1 core:

- Free taster: "AI homework help: what is fine, what is not, and what to say at home."
- Paid add-on to The System: a recorded AI Readiness Lab with worksheets.
- School/PTA option: parent evening plus take-home family lab.
- Stay Current benefit: monthly "what changed in AI tools children use" briefing.

This strengthens the current AI exposure content without turning Bearings into a child-facing platform.

## Build next

1. Turn this proposal into a one-page offer for parents.
2. Draft the four-session MVP version.
3. Create the Family AI Agreement worksheet.
4. Create the project menu and project review rubric.
5. Add one school/PTA taster session outline.
6. Run a guardrail review before selling anything child-facing.
