# AI Safety Course - Founding Pilot Email Templates

*Created 2026-06-27. Status: draft email templates for the founding pilot. Do not send until AI legal/safeguarding review blockers are patched, first-sale terms/privacy basics are ready, and the emergency signpost link is live and verified.*

## Email 1 - Purchase Confirmation

**Subject:** Your Keepwise AI Safety pilot place

Hi [FIRST NAME],

Thank you for joining the Keepwise AI Safety Course founding pilot.

This is a parent education pilot. It helps you set household AI rules, keep private information out of tools, and practise checking before trust or action. It is not legal advice, safeguarding advice, monitoring, crisis help, or an assessment of your child.

Please do not send names, school details, screenshots, messages, images, account handles, or incident details. If something is happening now, use the emergency signpost: [EMERGENCY LINK]

What happens next:

1. I will send the pilot materials to you within [TIMEFRAME].
2. You will get four short parent modules and the printable starter assets.
3. I will ask for feedback on clarity and usefulness after you have had a chance to look through them.

Purchase summary:

- Product: Keepwise AI Safety Course - Founding Parent Pilot.
- Price paid: GBP 49.
- Provider: [TRADING NAME].
- Contact: [EMAIL].
- Terms: [TERMS LINK OR ATTACHED COPY].
- Privacy notice: [PRIVACY LINK OR ATTACHED COPY].
- Refund/cancellation: [INSERT CHOSEN WORDING].
- Digital delivery: [INSERT DELIVERY TIMING AND DIGITAL-CONTENT ACKNOWLEDGEMENT IF USED].

Thank you for helping shape this carefully.

Ben

## Email 2 - Pilot Materials Delivery

**Subject:** Your AI Safety pilot materials

Hi [FIRST NAME],

Here are your founding pilot materials:

- Module 1: The AI Safety Map - [LINK]
- Module 2: Private Stays Private - [LINK]
- Module 3: Tool, Not Person - [LINK]
- Module 4: Verify Before Trust - [LINK]
- Pilot asset pack - [LINK]
- Family AI Safety Agreement starter - [LINK]
- Emergency signpost - [EMERGENCY LINK]

Suggested order:

1. Watch or read Module 1.
2. Complete the Four Habits card.
3. Use Module 2 and the Private Stays Private card.
4. Add the starter clauses to your Family AI Safety Agreement.

Please remember the pilot boundary: do not send child details, screenshots, messages, images, school details, account handles, or live-incident details. If something is already happening, use the emergency signpost rather than replying with details.

Thank you,

Ben

## Email 3 - Non-Submission / Gentle Nudge

**Subject:** Your AI Safety pilot materials are ready when you are

Hi [FIRST NAME],

Just a gentle nudge that your AI Safety pilot materials are ready here:

[MATERIALS LINK]

The simplest start is Module 1 and the Four Habits card. It should take about 20 minutes.

No need to send anything back unless you want to ask a non-urgent question or share feedback on clarity.

Ben

## Email 4 - Boundary Reply For Live Concerns

**Subject:** Please use the emergency signpost

Hi [FIRST NAME],

I am sorry this is happening. I cannot advise on a live situation or review incident details through this pilot.

Please use the emergency signpost here:

[EMERGENCY LINK]

If there is immediate danger or a crime in progress, use 999.

Please do not send screenshots, messages, images, attachments, names, school details, account handles, or further incident details by email. If anything like that has already been sent, I will not open, review, copy, forward, or comment on it through this pilot.

Ben

## Email 5 - Feedback Request

**Subject:** Quick feedback on the AI Safety pilot

Hi [FIRST NAME],

Thank you again for joining the founding pilot.

I am trying to learn whether the material is clear and useful. Could you reply with quick answers to these?

1. Which rule felt easiest to explain at home?
2. Which rule still felt unclear?
3. Which asset would you actually use?
4. What wording felt too strong, too soft, or confusing?
5. What nearly stopped you joining?

Please do not include child names, school details, screenshots, messages, images, or incident details.

Thank you,

Ben

## Email 6 - Refund Confirmation

**Subject:** Refund confirmed

Hi [FIRST NAME],

I have refunded your founding pilot payment. Stripe usually takes a few working days to return the money to your card.

Thank you for giving it a look. If you are willing to share one sentence about what did not feel right, I would be grateful - but please do not include child details or incident information.

Ben

## Email 7 - Thank You / Close The Loop

**Subject:** Thank you for the pilot feedback

Hi [FIRST NAME],

Thank you for the feedback. It is useful, and I will use it to improve the material before the pilot widens.

The main things I am checking are clarity, tone, and whether the assets are practical enough to use at home.

Thanks again,

Ben

## Send Rules

- Use the boundary reply for any live concern.
- Do not ask follow-up questions about live situations.
- Do not accept screenshots, messages, images, school details, child names, account handles, or incident details.
- Do not open, preview, download, save, copy, screenshot, forward, or upload unsolicited images, screenshots, messages, attachments, or incident material.
- If suspected under-18 nude or sexual material is received, stop the pilot channel, do not handle the material further, use the verified signpost/qualified route, and seek legal/safeguarding advice before any further action.
- Log only the boundary issue type in `80_AI_Safety_Course_Founding_Pilot_Tracker.md`; remove identifying details.
- Do not promise outcomes.
- Do not say the pilot is legally reviewed, safeguarding reviewed, expert approved, or professionally signed off.
- Keep the emergency signpost link in purchase, delivery, and boundary emails.
