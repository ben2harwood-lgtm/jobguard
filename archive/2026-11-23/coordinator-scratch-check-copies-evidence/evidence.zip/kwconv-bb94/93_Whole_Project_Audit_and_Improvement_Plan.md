# 93 — Whole-Project Audit & Improvement Plan

*Created 2026-07-03. This is the master plan for the full Fable + Opus validation of the whole project and the improvement programme that follows it. It wraps and extends `92_Fable_Audit_Readiness_and_Brief.md` (which remains the operating charter for the app audit) to cover everything 92 scopes out: the course/pilot pack, the evidence layer, strategy/pricing coherence, ops/deployment, external live surfaces, and the sequencing to first revenue.*

---

## 0. Executive summary

**What we are doing.** A two-model, adversarially-verified audit of all three product lines, followed by a triaged improvement programme: mechanical fixes applied and test-verified immediately; judgment calls (legal wording, positioning, money decisions) put to Ben in a single decision register; professional-review dependencies named explicitly and never substituted by AI sign-off.

**Why now.** The platform passed its own gates on 2026-07-02 (typecheck, content-lint 0/92 files, 286 tests, build with 24 routes). Per file 92 it is *audit-ready but not sale-ready*. The founding pilot is one decision-log away from a payment link; the SEN bid has a 10 July internal gate. This is exactly the moment a full sweep pays for itself — before money, before outreach, before anything is hard to walk back.

**Prior review generations this builds on (do not re-litigate):**
1. **2026-06-21** — library fact-check (45 items vs live sources) + Wave-2 QA (all 19 new items SHIP) + dead `9-10` age-band fix.
2. **2026-06-27** — course pre-revenue AI reviews (`73`: 34 findings, 0 blockers remaining, 7 high tracked) + claim register (`57`) + gap register (`58`, 16 open gaps).
3. **2026-06-28** — `audit/keepwise-full-adversarial/` (offer/skins audit; its backlog drove the `/start` funnel build).
4. **2026-07-02** — emergency signpost line-check (`84`), first-sale legal pack (`85`–`88`), and the Fable brief (`92`).

**The headline risks going in** (seeded from the scouts — the audit must confirm, refute, or extend):
- **R1 — Crisis-line accuracy is self-verified only.** `app/emergency/page.tsx` was edited: CEOP → `/ceop-reporting/`, **Papyrus HOPELINE247 changed to 0300 102 2470 + "text HOPE to 88247"**, under-18-image non-preservation carve-out added. The only verification is the project's own recheck log. A wrong crisis number is the most severe copy bug this product can have. **External re-verification is Priority 0.**
- **R2 — Child-PII residual vector.** Both enquiry APIs run `checkNoChildPii()`, but free-text `message` fields (concierge form, schools API) cannot be key-checked; mitigation is a placeholder asking users not to include child details. Also `supabase/schema.sql` has **no RLS statements** anywhere, now including the new `enquiries` table (adult contact data).
- **R3 — Pilot layer carries the dead brand.** The decision log (`88`) drafts the product name as "**Bearings** AI Safety Course – Founding Parent Pilot"; the app is Keepwise. The pilot copy layer (74–89) needs a brand-consistency sweep before any outreach.
- **R4 — Pricing drift across surfaces.** V3 canon (`26`): System £99 / founding £79 / Concierge from £650 / Stay Current £59-yr. File `90` recommends: System £99 founding / AI Lab £49 / bundle £129 founding / Concierge from £650 — no £79 anywhere. The app, the pilot sales page (£49), the old live brand-review site, and the canon all need reconciling to ONE ladder.
- **R5 — Deployment risk.** `app/skins/[skin]/route.ts` reads `brand-design/*.html` from `process.cwd()` at request time; on Vercel, output-file-tracing may not bundle dynamically-resolved files → 404s in production that never appear locally.
- **R6 — Portfolio focus.** Three product lines (Keepwise system, AI Safety Course pilot, SEN CfI bid) + one founder + a 10 July SEN gate + a pilot wanting outreach = the biggest strategic risk in the project. An audit cannot fix this; it can only put the trade-off in front of Ben with honest numbers. It will.
- **R7 — Stale public surface.** `bearings-brand-review.netlify.app` is still live with four old brand worlds (including three losers and the dead Bearings name), and its feedback button mails an address that may not be watched. Decide: take down, or keep deliberately as a historical artefact.

---

## 1. Baseline — the project as of 2026-07-03

**Product lines**

| # | Product | State | Next gate |
|---|---|---|---|
| P1 | **Keepwise app** (Household System £99) — Next.js, 24 routes, 51-item gated MDX library, `/start` click-only safety check, checkout handoff shells, concierge/schools enquiry, M3 draft modules (questionnaire + plan-prompt, not yet routed) | All local gates green 2026-07-02. Not sale-ready: no Stripe links, no auth, no admin publish, legal placeholders | Audit → fix → wire commerce → legal sign-off |
| P2 | **AI Safety Course / AI Readiness Lab** (£49 pilot) — curriculum complete, claim register (83 claims), 4 module scripts, printable pack, sales/outreach/email copy, first-sale legal scaffolds | AI-red-teamed (0 blockers, 7 high tracked); decision log `88` = **NO-GO** (7 owner decisions open); no professional review booked | Ben's decisions + solicitor/safeguarding review → 5-buyer pilot |
| P3 | **SEN prototype** (CfI bid) — fit report + 843-line build guide, `sen-prototype/` not yet coded | Conditional fit; 10 unresolved legal questions | **Internal go/no-go 10 July** (team credentials + 2–4 school co-design partners); CfI deadline 5 Aug 11:00 |

**Working tree.** ~105 uncommitted paths implementing the Bearings→Keepwise rebrand, the `91` site assimilation, commerce wiring, the `/start` funnel, emergency corrections, +165 lines of new guardrail tests, and the deploy pipeline (Vercel, allow-listed package). Verified green. **First action of this plan: commit it as the audit baseline** so audit fixes are cleanly separable.

**Toolchain.** Node v24.17.0 is installed and working on this machine. Typecheck, content-lint, and the 286-test suite can now be run in-session — which means audit code-fixes can be *applied and proven*, not just recommended. This removes the old "author blind, founder verifies" constraint.

---

## 2. Audit charter

**Mission (from 92, extended to the whole portfolio):**
> What are the smallest high-leverage changes that make the whole offering clearer, more valuable, more trustworthy, and safer to pilot — while preserving the product boundaries?

**Non-negotiable guardrails — flag breaches, never optimise around them:**
- No safety guarantees ("keeps children safe", "prevents harm", "fully compliant", "safe by design").
- No monitoring, surveillance, child accounts, child-facing flows, user-to-user features.
- No child-identifiable data anywhere (age band only; no names/DOB/school/screenshots/messages/incident detail).
- Emergencies signpost-only: public, ungated, non-monetised; no bespoke incident-handling steps.
- No AI judging real messages, images, schoolwork, incidents, or whether a child is safe.
- No claims of legal/safeguarding/clinical/compliance approval unless separately evidenced.
- Human review stays bounded (age fit, gaps, priority order, source dates, over-claiming) — never incident handling or professional advice.

**Do NOT audit as broken** (92's deferred list): live Stripe completion, webhooks/subscriptions, magic-link auth, admin fulfilment/publish, the routed 25-question diagnostic, Resend lifecycle, retention cron, DSR route, production persistence, domain/support/ICO setup. Audit instead whether the app is **honest** that these aren't live.

**Source hierarchy:** `21` (guardrails/behaviour) → current code → `91` (offer direction) → `audit/keepwise-full-adversarial/` + `73`/`83`/`84`/`85` (prior findings) → this plan. Bearings-era docs are historical.

**Corrected facts of record** (from the June fact-check — auditors must not "fix" these backwards): CEOP = `ceop.police.uk/ceop-reporting/`; deepfake creation offence = Data (Use and Access) Act 2025 (not the OSA); OSA child-safety duties live 25 July 2025; KCSIE 2025 = statutory guidance; NSPCC 0808 800 5000 is Mon–Fri 10–4 (not 24/7); PEGI administered by the Games Rating Authority; National Gambling Helpline operated by GamCare; Internet Matters harm figure 67% (not 77%); loot boxes 27% of 11–17s (2024); under-16 social-media ban = announced policy, not in force (~Spring 2027).

---

## 3. What to audit — seven surfaces × eight dimensions

### The surfaces

| # | Surface | Contents | Depth |
|---|---|---|---|
| S1 | **App code & tests** | `lib/*`, `app/api/*`, route/server logic, `tests/`, `supabase/schema.sql`, `deploy.sh`, env handling | Full static review + in-session gate runs |
| S2 | **App journey & copy** | `/` → `/start` → recommendation → checkout/enquiry/emergency; pricing, sample, how-it-works, for-schools, concierge, quiz, privacy/terms, locked library states | Full (92 passes 1–3, 5) |
| S3 | **Library content** | 51 MDX items + the 4 staged-but-unrouted `lib/ai-safety-*.ts` content libs (1,130 lines) | Spot-verify high-risk facts + currency + cross-links (full fact-check done 06-21; don't repeat it) |
| S4 | **Course & pilot pack** | 50–89: curriculum, module scripts, printables, sales/outreach/email copy, tracker, legal scaffolds, pre-payment page | Execute briefs `70`+`71` against the files `73`'s slice did NOT cover (the 57–68 evidence layer, 81, 89); re-check 74–80 for drift; verify the 2 open highs; brand-consistency sweep (R3) |
| S5 | **Strategy & pricing** | `90`/`91` vs app vs pilot vs V3 canon vs old surfaces | Reconcile to one ladder (R4); portfolio-focus analysis (R6) |
| S6 | **Ops, deployment & data protection** | Vercel pipeline, skins tracing (R5), RLS (R2), env/secrets, ICO position, retention, support inbox | Full |
| S7 | **External live surfaces** | `bearings-brand-review.netlify.app` (R7); **every crisis number/URL re-verified against the live external source** (R1) | Full, with web verification |

### The dimensions (what "validate" means)

**A. Safety & guardrails** — banned-claim sweep (negation-aware); signpost-only invariants; child-PII vectors including free-text fields; the under-18-image non-preservation carve-out present everywhere it must be; emergency ungated/non-monetised and linked from every footer.

**B. Legal & regulatory (UK)** — flag-for-professional, never sign off: distance-selling/pre-contract info + digital-content cancellation (Consumer Contracts Regs 2013); refund policy honesty; CPRs on "founding" scarcity claims; UK GDPR lawful bases, retention, processor list, ICO fee position; privacy notice vs *actual* data flows (forms → tables); terms enforceability; correct statute citations (DUAA 2025, OSA); safeguarding-adjacent wording per brief `70`.

**C. Factual accuracy & currency** — external web re-verification of every crisis route (Priority 0 = Papyrus 0300 102 2470 / text HOPE to 88247, CEOP path, Childline, Samaritans, Shout, NSPCC hours, Report Remove, Report Fraud, Report Harmful Content status); spot-check statistics against the corrected facts of record; last-reviewed stamps where the premium "kept current" claim needs proof.

**D. Code correctness & security** — access-gate leak hunting; API input validation; PII enforcement depth (R2); schema/RLS; the skins tracing risk (R5); event-tracking completeness vs funnel; M3 module correctness (`questionnaire-data`, `plan-prompt`); test-coverage gaps for high-risk copy and flows.

**E. Spec & honesty drift** — spec `21` §12 acceptance criteria status; every not-live feature honestly presented (checkout shells, locked library, "human-reviewed" process claims vs what exists today); no page that pretends.

**F. Conversion, UX, mobile, accessibility** — 92 pass 5 + June-28 carryover: mobile CTA visibility, cognitive load at the offer moment, "what happens after you buy" sequence, focus states/labels/contrast (static analysis; runtime checks listed for the preview pass), risk-reversal wording.

**G. Strategy & portfolio coherence** — one pricing ladder everywhere; System/AI Lab/bundle/Stay Current/Concierge architecture per `90`/`91`; the three-product focus question put honestly (R6); what the site should stop showing (stale surfaces, R7).

**H. Improvement synthesis** — not just defects: for each of 92's nine improvement areas (category clarity, value stack, copy, journey, trust/evidence, architecture, UX, code hygiene, pilot ops), the smallest high-leverage changes, each sized (S/M/L) and risk-rated.

---

## 4. How — the two-model audit machinery

**Design principles.** (1) Fable leads — finders, verification, synthesis. (2) Opus runs the same finder dimensions *independently* — two models, union of findings, because diverse lenses catch what redundancy can't. (3) Every finding is adversarially verified before anyone acts on it. (4) Mechanical content fixes are applied by agents; **code fixes are applied only in the main session where the test suite proves them**; legal/positioning/money calls go to Ben untouched. (5) The whole run is resumable — Fable session limits are a known hazard (they killed the 07-02 attempt), so finders fall back to Opus automatically and the workflow journal allows cheap resume.

**Phases**

| Phase | What happens | Model |
|---|---|---|
| **F0 — Baseline** | Commit the working tree as the audit baseline; confirm gates green in-session | main session |
| **F1 — Find** | ~10 finder dimensions × 2 models (Fable + Opus independently), each scoped to a surface×dimension slice with seeded context (known risks R1–R7, prior-generation findings, corrected facts) | Fable + Opus |
| **F2 — Verify** | Findings grouped by file; one adversarial verifier per file-batch tries to refute each finding against the actual code/copy; only CONFIRMED survives, with corrected fixes where the proposal was imprecise | Fable (fallback Opus) |
| **F3 — Apply (safe lane)** | Mechanical fixes in content/docs/HTML applied by agents; then in the main session: safe code fixes applied one-by-one with `tsc` + vitest + content-lint run after each | agents + main session |
| **F4 — Synthesise** | The 92-requested outputs written to `94_Whole_Project_Audit_Findings_Register.md`: ranked issues; before-pilot checklist (blocker/high/medium); concrete copy rewrites; code recommendations; test plan; pilot-readiness verdict + the human/legal/safeguarding dependency list | Fable |
| **F5 — Decide** | Ben works the decision register (this plan §7 + the `88` log + audit judgment calls) in one sitting | Ben |

**Rate-limit contingency.** Finders attempt Fable first; a limit-killed agent returns null and is retried once on Opus (tagged, so the register shows which model found what). If Fable dies wholesale mid-run, the run still completes on Opus and a Fable-only verification tranche is resumed after the limit window. Nothing blocks on a single model being throttled again.

**Cost envelope.** Expect roughly 2–5M subagent tokens across both models (order of £30–80 API-equivalent). Sanctioned by the "full sweep" decision; not re-asked.

**What no model may do in this run:** mark anything as legally/safeguarding-approved; touch the emergency page without external-source proof; apply any fix to `app/`, `lib/`, `components/`, `tests/`, or `supabase/` outside the main-session verified lane; invent testimonials, credentials, sources, or efficacy claims; weaken any cautious wording.

---

## 5. What to make better — the seeded improvement backlog

The audit will refine, confirm and extend this list; these are the improvements already visible. Sizes: S (&lt;1h), M (half-day), L (multi-day).

### 5.1 Before the first paid pilot (the £49 course route) — blockers
1. **Ben completes the `88` decision log** — trading name/contact/address, digital-content option A/B, refund window, processor list, lead-retention period, ICO fee position, delivery timing. *(Ben, S–M)*
2. **Rebrand the pilot layer to Keepwise** (R3) — every instance in 74–89 incl. the drafted product name. *(mechanical, S)*
3. **External crisis-route verification** (R1) — every number/URL on the emergency page and in course routing cards, against live sources, logged in `68`. *(audit run, S)*
4. **Founder inbound-handling protocol** for unsolicited child data / suspected under-18 images arriving by email or DM — the open `83` blocker; must exist before any outreach channel opens. *(Ben + template from audit, S)*
5. **`FamilyAgreementBuilder.tsx` verification** — prove no transmission/storage/persistence of child-adjacent input (the other open `83` high). *(main-session code review + test, S)*
6. **Close the two open highs in `73`**; remove "school" from the tracker's allowed sources (conflict with `72`/`78` gating). *(S)*
7. **Book the paid professional review** using `67` as the scope — solicitor (terms/privacy/cancellation/under-18-image wording/ICO) + safeguarding professional (routes, scenarios, disclosure wording). *(Ben; the audit prepares the exact briefing pack)*
8. **Stripe payment link with required checkboxes** (18+, terms/privacy, digital-content acknowledgement per chosen option) — only after 1–7. *(Ben + guide `87`, S)*

### 5.2 Keepwise app & site
9. **One pricing ladder** (R4): adopt `90`'s recommendation (System £99 founding · AI Lab £49 · bundle £129 founding hero · Stay Current incl. yr-1 then £59 · Concierge from £650), update `26` as canon, sweep every surface. *(M)*
10. **RLS on every table** + confirm service-role isolation; add a schema test. *(M)*
11. **Fix the skins tracing risk** (R5): `outputFileTracingIncludes` for `brand-design/**/*.html` (or import-manifest the files) + a post-deploy smoke check of `/skins/*`. *(S–M)*
12. **Free-text PII mitigation** (R2): server-side redaction/refusal heuristics on `message` fields (name+school patterns), plus the notice; log-and-purge policy. *(M)*
13. June-28 carryover still open: **reviewer-process block** ("how review works: who, what's checked, what isn't, SLA"), **sample Evidence Note card**, **"what we ask / never ask" data block beside pricing**, **"what happens after you buy" timeline**, **mobile nav = logo + primary CTA**. *(each S–M)*
14. **Honesty pass on not-live features** — checkout shells, library lock, human-review claims all clearly staged. *(S)*
15. **`/tools`, `/evidence`, `/ai-readiness`, `/resources` pages** per `91` phase 2–3 — the value-stack made visible. *(L)*
16. **Accessibility & mobile runtime pass** — preview-server walk of every route: focus, labels, tap targets, overflow, contrast. *(M)*

### 5.3 Library & content
17. **Last-verified stamps rendered in the UI** per item (the premium "kept current" proof). *(M)*
18. **Quarterly re-verification cadence** — extend `68` to cover the app library; name an owner and a date. *(S to schedule)*
19. **AI toolkit category** in the library + cross-links from the AI-safety course content when it clears review. *(M)*
20. **"This weekend" starter bundle** inside the library (June-28 + 92 both want it). *(S–M)*

### 5.4 M3 completion (now unblocked by the local toolchain)
21. Route the 25-question diagnostic (`lib/questionnaire-data.ts` exists); write `questionnaires`/`plans` rows; PII gate on submit. *(L)*
22. `/admin` review-and-publish flow — the mandatory human gate; content-lint on publish. *(L)*
23. Draft-generation background job (`lib/plan-prompt.ts` exists) + delivery email + `/library/start` renderer. *(L)*

### 5.5 Strategy & ops
24. **Portfolio focus decision** (R6): the audit will model the founder-hours each line needs in July; Ben picks the sequence (suggested frame: SEN gate is 10 July — decide it first, then pilot, then app commerce). *(Ben)*
25. **Retire or archive the old Netlify brand-review site** (R7); if kept, fix the feedback address. *(S)*
26. **Support inbox + non-urgent boundary auto-reply** (uses `79`'s locked wording). *(S)*
27. **Error monitoring + uptime check** on the deployed app before pilot traffic. *(S–M)*
28. **Numbered-file hygiene**: resolve the duplicate 57/60 filenames into a single sequence; add an index doc. *(S)*

---

## 6. Sequencing & gates

| Stage | Window | Work | Exit gate |
|---|---|---|---|
| **0 — Baseline** | today | Commit WIP; launch F1 (both models); external crisis-route verification lands first | Baseline commit + Priority-0 verdict on R1 |
| **1 — Audit & safe fixes** | this week | F1–F4 complete; mechanical fixes committed; verified code fixes applied with tests; `94` register written | Gates green; register in Ben's hands |
| **2 — Decisions** | this week | Ben: `88` log + judgment register + portfolio call (R6). **SEN go/no-go 10 July runs in parallel — it is a founder-credentials/partners question, not an audit output** | Decision log complete; one pricing ladder chosen |
| **3 — Professional review** | next 1–2 weeks | Solicitor + safeguarding review booked and run on the `67` scope; findings patched; ICO position recorded | Written professional sign-off on the pilot pack |
| **4 — Pilot** | after 3 | Stripe link live with checkboxes; warm outreach only (per `72`); max 5 buyers; boundary log kept | 5 buyers or stop-condition; feedback in |
| **5 — Scale prep** | after pilot | M3 build-out (§5.4), `91` site phases, Stay Current operationalisation, wider launch legal review | Spec-21 acceptance criteria all green |

**Standing stop-conditions** (any of these pauses the stage immediately): a crisis route found wrong on a live surface; any child-PII found stored; any copy found claiming professional approval; a guardrail breach reaching a public page.

---

## 7. Decisions this plan needs from Ben (beyond the audit's own register)

1. The seven `88` decision-log items (trading details, digital-content option, refund window, processors, retention, ICO, delivery timing).
2. Portfolio sequence for July (SEN bid vs pilot vs app commerce) — decide at the 10 July SEN gate at the latest.
3. Adopt the `90` pricing ladder as the new canon (supersedes V3's £79 founding)? 
4. Old brand-review site: retire or archive-with-notice.
5. Professional reviewers: who (solicitor with digital-consumer + data experience; safeguarding consultant), and budget.

---

## 8. Success criteria — when this audit is "done"

- Every crisis number/URL on every surface externally verified, with sources logged in `68`.
- Zero HIGH findings open in `94` (fixed, or explicitly accepted by Ben with a reason).
- All app gates green after every applied fix (typecheck, content-lint, 286+ tests, build).
- Every user-visible factual claim traceable to a source or removed; every not-live feature honestly presented.
- One pricing ladder across every surface; no Bearings branding on anything customer-facing.
- The before-pilot checklist reduced to items only humans can close (decisions + professional review) — with each one named, owned and dated.
- Ben can answer, for any line on any page: *"why is this true, and why is it safe to say?"*

---

*Machinery reference: the audit runs as a resumable background workflow (script retained in the session workspace); findings land in `94_Whole_Project_Audit_Findings_Register.md`; fixes land as separable commits on `feat/milestone-2`.*
