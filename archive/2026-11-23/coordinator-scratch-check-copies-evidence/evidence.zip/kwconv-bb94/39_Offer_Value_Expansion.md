# 39 — Offer Value Expansion

*How to make the £99 Household System feel like an obvious steal — without breaking a single guardrail.*
Research: 6 parallel lenses (printables, tools, library depth, access/assurance, competitor teardown, value framing) → 65 candidate ideas → synthesised. Date: 2026-06-21.

---

## The one-line takeaway

> The biggest lever is a calm, restrained **"what you're getting" value stack** on the pricing page (named components, each with an honest anchor price, totalling ~£480, "yours for £99 / founding £79"), paired with **same-evening proof of value** — so the parent feels the deal *and* gets a win before the human review even lands.

Two things do most of the work: (1) make the value **visible** (it's already there — we just don't show it), and (2) close the "I paid, now I wait" gap with something they can act on tonight.

---

## Flagship addition — the Control Centre  ✅ BUILT (prototype)

Decision (founder, 2026-06-21): parents want **control and instant access**. We give them that as a *control centre, not control software* — we never install anything or monitor the child; we orchestrate the controls that already exist. Live prototype: `brand-mockups/control-centre.html` (themes into all 4 worlds; `…/control-centre.html`). Three working tools:

1. **Screen-time guidance by age** — pick the child's age → a calm, realistic starting point + what matters most at that stage (not a stopwatch rule).
2. **Family agreement builder** — set a few rules (devices-down time, phone-free zones, weekend flex) → a clean, printable agreement with the no-judgement cornerstone clause. No child data.
3. **Control launchpad** — a tick-along list that links straight to the *real* free controls (Apple Screen Time, Google Family Link, broadband filters, SafeSearch, per-app privacy) with the exact menu path, progress saved locally.

Why it works: it's the single feature that makes the product feel *active* ("I can do something right now") instead of *passive* ("I have to read"). It's the "instant access" answer to the human-review wait. **To finalise:** verify the deep-link URLs before launch; the per-app launchpad row points into our own library.

---

## Quick wins — best value-per-effort, buildable now

All of these are mostly **repackaging content we already have** (files 16/17/09/20) into something tactile and high-perceived-value:

| Addition | What it is | Effort |
|---|---|---|
| **Same-evening fast-start card** | The 5 highest-impact device settings to "do tonight while we hand-review your plan" — closes the post-purchase wait, seeds testimonials, prevents refunds | Low (from file 16) |
| **Conversation Cue Cards** | A printable cut-out deck — one chat per card (opener, the one red flag, say-this/not-this) | Low (recut of 17) |
| **"What not to say" card** | The phrases that shut a child down + the calmer alternative — screenshot-shareable, doubles as marketing | Low (in 17) |
| **Carer Briefing Card** | A fillable A5 for grandparents/sitters/sleepover hosts — extends the household standard without a lecture | Low |
| **Weekend setup sheet** | The 10 guides collapsed into ONE ordered tick-box checklist for *this* household | Low (assembles 16) |
| **Quarterly Reset Card** | The 10-minute "settings drift" check (re-tick the things that silently switch off) | Low (from 20) |
| **The Household Map** | A one-page fridge wall chart mirroring the plan (per child: age, apps, rules, where devices sleep) — the most "I'm on top of this" object in the house | Low–med |
| **Named value-stack panel** | The pricing-page framing below — the highest-leverage behavioural move | Low (copy + design) |

---

## The £99 value stack (for the pricing page)

Calm, restrained presentation — **no strikethroughs, no countdown timers** (that fights the premium brand). Each line is a real included component with a defensible anchor price:

| What you get | Honest value |
|---|---|
| Your personalised, human-reviewed Household Plan (top-3 actions + exposure map, checked by a real person) | £90 |
| Your child's age-band pack | £40 |
| Platform setting guides with step-by-step videos | £60 |
| Threat playbooks + foundations modules | £70 |
| Conversation library + "what not to say" card + printable Cue Cards | £40 |
| A recorded masterclass for your stage | £35 |
| **Your Control Centre** — screen-time guidance, agreement builder, control launchpad | £40 |
| Printable quick-reference pack (Household Map, weekend checklist, Carer Card, Quarterly Reset) | £25 |
| The designed, signable Family Agreement (poster + pocket card) | £25 |
| Year-1 Stay Current included (monthly briefing, personal setting-change alerts) | £59 |
| **Total value** | **~£484** |
| **Yours today** | **£99 (founding cohort £79)** |

Strapline: *"Built for you, checked by a real person, kept current for a year."*

---

## Additions by tier

**Household System (£99 / £79)** — Control Centre · fast-start card · Household Map · Cue Cards + "what not to say" · Carer Card · weekend setup sheet · designed/signable Family Agreement (poster + pocket card) · "First 30 minutes with a new phone" run-sheet · per-platform setup-video sequence · "what these controls can and can't see" honesty table · Quarterly Reset Card · "Is this normal?" proportion guide (population-level, *not* an assessment of your child) · Room-by-Room home setup walkthrough · 2nd wave of platform guides (router, consoles, Minecraft, AI tools, Reddit/Twitch/Steam, school device) · 6 new threat playbooks · incident/disclosure scripts (signpost-first) · Age-Up Card · **value/usefulness guarantee** ("if your plan doesn't give you 3 things you hadn't already done, full refund and keep the plan" — strictly a value promise, never safety).

**Concierge (from £650)** — printed-and-posted **Household Folio** (physical keepsake) · genuinely bespoke whole-household report template · "how the call works" walkthrough (we guide, you click, we never access accounts, signpost-only) · co-parent/second-household consistency plan · satisfaction backstop (redo or refund the call portion) · optional split-pay (no surcharge) · *honest* slot-scarcity ("3 of 4 places left") **only if the cap is real**.

**Stay Current (£59/yr)** — personal app-targeted **setting-change alerts** (90-sec re-recorded video + the one thing to re-check) · "what's changed since you set up" delta view · quarterly changelog digest · **annual household re-run** (fresh readiness check + new reviewed plan) · **free age-band re-issue** when a child crosses a band ("your plan grows with your child") · new-app request line · seasonal packs (Back-to-School, Exam-Season, Holiday/New-Device) · founding-cohort renewal rate locked.

**Free lead magnet** — "Get ready for the first phone" mini-guide (device layer + one demo video) · **Emergency Wallet Card** (signpost-only routing) · upgraded 2-min quiz "Snapshot" (3 do-tonight tasks) · blank Household Map + one-clause agreement tasters · 3-card Cue Cards taster · "New app — is it OK?" decision helper (taster).

---

## What we deliberately will NOT build (guardrail rejections)

The research filter rejected these — keep them rejected; they're where similar products get into trouble:

- ❌ **A "is my worry proportionate?" tool that scores the reader's own child** — reads as a safeguarding assessment; we keep only the *general, population-level* "Is this normal?" guide.
- ❌ **A live-concern "triage"/symptom-picker** — edges into live-incident handling; keep a static, signpost-first playbook finder that routes and never assesses.
- ❌ **A "completion certificate"** worded as "complete/completed" — implies safety achieved; only OK as "plan made & reviewed [date], next review [date]".
- ❌ **Any "keeps your child safe / prevents / guaranteed safe or money back" risk-reversal** — banned efficacy language; the guarantee is **value/usefulness only**.
- ❌ **Parent-to-parent community/forum/sharing** — breaches the OSA no-user-to-user guardrail; only one-to-one "forward a copy", capped at one extra household.
- ❌ **Carer-card / incident-script "if something's wrong" steps that give bespoke incident handling** — must stay signpost-only.
- ❌ **Fake scarcity** on the Concierge — only if the ~4/month cap is genuinely real.

---

## My recommendation — what to do first

1. **Ship the Control Centre** (done in prototype) — it's the differentiator and it's already built; finalise the deep-links.
2. **Add the value-stack panel to the pricing page** — near-zero effort, biggest perceived-value lift. (I can wire this into the four worlds now.)
3. **Produce the 6 "quick win" printables** — they're recuts of existing content (16/17/09/20), so cheap, and they make the box feel full.
4. **Add the value/usefulness guarantee** (risk reversal) — a strong closer, fully guardrail-safe.
5. **Defer** the heavy lifts (2nd wave of guides, 6 new playbooks, full video suite, annual re-run plumbing) until *after* the parent test confirms which world/positioning wins — don't build depth for a brand you haven't validated.

Everything above respects the hard guardrails: no monitoring, no child data, no parent-to-parent community, no efficacy/safety claims, human-in-the-loop, signpost-only emergencies.
