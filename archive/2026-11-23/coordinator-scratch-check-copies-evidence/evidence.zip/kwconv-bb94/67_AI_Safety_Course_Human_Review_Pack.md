# AI Safety Course - Human Review Pack

*Created 2026-06-27. Status: handoff pack for human legal, safeguarding, and source-currency review across Phase 1, Phase 2, and Phase 3. This pack does not make the course canonical or sellable. It defines the review work needed before launch.*

## Review Objective

Clear the AI Safety Course for controlled parent-facing use by checking:

- legal wording;
- safeguarding wording;
- live-incident routing boundaries;
- under-18 image-risk wording;
- data/privacy statements;
- schoolwork and assessment wording;
- route names, URLs, phone numbers, eligibility, and jurisdiction notes;
- any time-sensitive legal, platform, or policy claims.

The review should preserve the product boundary: parent education, household planning, assets, and signposting only. No child-facing flow, no child accounts, no child PII, no live-incident advice, no AI judgement of real content, no scores/profiles, and no safety outcome promises. [PRI-003, PRI-004, GRM-002, VBT-004, RTE-007, GAP-001, GAP-013]

## Files In Scope

| File | Review purpose |
|---|---|
| `57_AI_Safety_Course_Claim_Register.md` | Source-grounded claims and review flags. |
| `58_AI_Safety_Course_Gap_Register.md` | Excluded or unresolved claims that must not leak into copy/tools. |
| `60_AI_Safety_Course_G1_Breaker_Findings.md` | Cross-model Breaker findings and patched blocker. |
| `61_AI_Safety_Course_Phase2_Design_Package.md` | Course positioning, modules, asset pack, delivery shape, and pre-launch review list. |
| `62_AI_Safety_Course_Phase3_Tools_Spec.md` | Interactive tool boundaries and build order. |
| `63_AI_Safety_Course_Scenario_Trainer_Content.md` | Authored scenarios, choices, feedback, and route-outs. |
| `64_AI_Safety_Course_Readiness_Self_Check_Spec.md` | Navigation-only self-check prompts, results, and route-outs. |
| `65_AI_Safety_Course_Stay_Current_Update_Stream_Spec.md` | Update workflow, review statuses, backlog, and publication gates. |
| `66_AI_Safety_Course_Routing_Card_Spec.md` | Route-only printable card wording and route categories. |
| `components/FamilyAgreementBuilder.tsx` | First implemented tool: default clauses, no-storage behaviour, and image-risk carve-out. |
| `lib/ai-safety-scenarios.ts` | Draft static scenario data, not public. |
| `lib/ai-safety-self-check.ts` | Draft static self-check data, not public. |
| `lib/ai-safety-update-stream.ts` | Draft internal update workflow data, not public. |
| `lib/ai-safety-routing-card.ts` | Draft route-card data, not print-ready. |

## Legal Review Questions

| Area | Questions | Files |
|---|---|---|
| Under-18 image wording | Does the no-save/no-screenshot/no-copy/no-download/no-forward wording accurately avoid unsafe advice while remaining understandable to parents? Does any scenario or asset imply the parent should obtain or retain material? | `57`, `61`, `62`, `63`, `66`, `components/FamilyAgreementBuilder.tsx`, `lib/ai-safety-routing-card.ts` |
| Legal seriousness language | Is "may be illegal" / "legally serious" phrasing accurate without adjudicating a specific case? | `57`, `61`, `63`, `66` |
| Adult vs under-18 image law | Does the course keep adult-scoped intimate-image provisions separate from under-18 image offences? | `57`, `58`, `61`, `66` |
| Data/privacy wording | Does the product describe data-minimising design without claiming legal compliance as a conclusion? | `57`, `61`, `62`, `64` |
| Online Safety Act / platform duties | Does wording frame platform duties as platform responsibility, not a promise by the course or platform? | `57`, `61`, `65`, `content/currency/whats-changing.mdx` |
| Schoolwork / assessments | Does wording align with current JCQ/DfE baseline while deferring to school and assessment rules? | `57`, `61`, `63`, `64` |
| Terms/marketing claims | Does landing/pricing/email copy avoid safety outcome promises and legal-compliance claims? | Before launch: landing, pricing, email, terms, course sales page |

## Safeguarding Review Questions

| Area | Questions | Files |
|---|---|---|
| Route boundaries | Do all live concerns terminate course/tool flow and route to qualified services? | `61`, `62`, `63`, `64`, `66` |
| Scenario Trainer | Are all scenarios non-explicit, prevention-framed, and free of mechanism/how-to detail? Are route-outs clear enough without becoming live advice? | `63`, `lib/ai-safety-scenarios.ts` |
| Companion/chatbot watchpoints | Does wording avoid diagnosis, clinical assessment, dependency claims beyond the evidence, or child profiling? | `57`, `61`, `63`, `64` |
| Contact pressure/grooming | Does wording avoid verdicts on real messages while still giving parents clear show-a-trusted-adult rules? | `57`, `61`, `63`, `64`, `66` |
| Harmful content/wellbeing | Does wording route self-harm, eating-disorder, extremist, sexual, threat, coercion, and emergency concerns appropriately? | `57`, `61`, `63`, `64`, `66` |
| What Not To Say | Does disclosure wording reduce blame/panic without promising outcomes or giving incident-management advice? | `61`, `63`, `66` |
| School-linked concerns | Is school DSL wording appropriate and current? | `57`, `61`, `63`, `64`, `66` |

## Source And Route Re-Check

These items must be checked immediately before sale or publication.

| Item | What to re-check | Related claims/files |
|---|---|---|
| CEOP | Scope, route wording, URL, and whether wording still fits online sexual abuse/grooming route. | RTE-002; `66` |
| Report Remove / IWF / Childline | Eligibility, under-18 route, now-18+ route, wording, and URLs. | RTE-003; GAP-011; GAP-016; `66` |
| Police routes | 999/101 wording and any jurisdiction note. | RTE-001; `66` |
| Report Fraud / Police Scotland | England/Wales/Northern Ireland route and Scotland route wording. | RTE-005; `65`; `66` |
| NSPCC / Childline | Adult/child support route, URL, and any hours/eligibility detail. | RTE-004; `66` |
| KCSIE / school DSL | Current edition and school safeguarding terminology. | RTE-006; `61`; `66` |
| JCQ / DfE schoolwork | Current AI-in-assessments guidance and DfE education guidance. | ORW-003; VBT-002; GAP-010 |
| DfE product-safety guidance | Exact title, URL, status, and relevance. | S02-dependent rows; GAP-016 |
| Ofcom / OSA child duties | Current duties, codes, dates, and non-overclaim wording. | HCM-002; RTE-008 |
| Platform-specific claims | Any AI companion, privacy, retention, age restriction, or setting detail. | GAP-006; GAP-008; GAP-014 |

## Review Output Template

Each reviewer should return decisions in this format:

| Review item | Decision | Required wording change | Severity | Cleared for parent-facing use? |
|---|---|---|---|---|
| File + section + line or phrase | approve / change / remove / needs source re-check | Exact replacement or instruction | blocker / high / medium / low | yes / no |

Severity definitions:

- blocker: must be fixed before any parent-facing use.
- high: must be fixed before sale or broad distribution.
- medium: should be fixed before polished launch.
- low: clarity or style improvement.

## Current Internal Status

| Area | Status |
|---|---|
| Phase 1 claim register | Breaker blocker patched; still needs human legal/safeguarding review. |
| Phase 2 course package | Drafted; not canonical or sellable. |
| Family AI Safety Agreement builder | Implemented as first tool; still needs wording review before sale. |
| Scenario Trainer | Draft static data only; not public. |
| Readiness Self-Check | Draft static data only; not public. |
| Stay Current update stream | Draft internal workflow only; not public. |
| Routing card | Draft static data only; not print-ready. |
| Public currency page | Needs source and route re-check before sale because it contains time-sensitive claims. |

## Build Lock

Do not make the Scenario Trainer, Readiness Self-Check, Stay Current update stream, or routing card public until:

- relevant review items are cleared;
- route/source re-checks are complete;
- any required copy changes are patched;
- structural guardrail tests still pass;
- content lint passes;
- the final course sales copy is checked against the Claim Register and Gap Register.

At this point, the next non-model gate is human review. More code can be prepared, but parent-facing release should stop here until review decisions are available.
