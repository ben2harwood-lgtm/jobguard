# AI Readiness Lab for Families - Curriculum Spec

*Draft 1.0. Created 24 June 2026. Parent-facing, UK-oriented, designed to sit beside the Bearings household digital-safety system.*

## 1. Decision

Build an original Bearings course inspired by the market signal behind "agentic AI for kids", but do not copy that course's content, copy, tools, worksheets, images, or delivery model.

The course should not start as a child-facing camp. Bearings V1 is adult-only and parent-facing, so the cleanest first product is a parent-mediated course: parents learn the concepts, then run short optional family activities at home.

## 2. Working Offer

**Name:** AI Readiness Lab for Families

**One-line description:** A calm practical course that helps parents understand how children are using AI, set sensible household boundaries, and guide one small family-reviewed AI project.

**Positioning:** This is not a coding bootcamp, not a surveillance tool, and not a scare session. It teaches judgement: what AI is useful for, when it is unreliable, what not to put into it, how to use it around schoolwork, and how to keep a human review point in every workflow.

**Best first format:** Four weekly parent sessions, each 60-75 minutes, with one optional 20-45 minute family lab after each session.

**Core buyer:** Parents of 11-16s who are hearing about ChatGPT, AI homework, deepfakes, AI companions, and "agentic" tools, but do not yet know what to allow, what to check, or how to talk about it.

**Adjacent buyers:**

- Parents of 9-11s preparing for the first AI-enabled homework years.
- Parents of 15-17s dealing with revision, coursework, and portfolio pressure.
- Schools/PTAs that want a calm parent evening and take-home activities.

## 3. Product Boundary

This course is designed to remain inside the current Bearings guardrails:

- Parent is the purchaser and learner.
- Bearings collects no child-identifiable data.
- Family activities happen at home, supervised by the parent.
- No child accounts are created by Bearings.
- No public student profiles, peer community, comments, messaging, or showcase gallery.
- No automated assessment of a child.
- No live-incident handling. Any urgent concern routes to the existing emergency signpost.

A direct kids' workshop, live child cohort, student portfolio, school LMS, or child account flow would be a separate product line and needs a fresh legal/safeguarding/data review before sale.

## 4. Design Principles

### Principle 1: Think First, AI Second

The course should repeatedly teach: define the task, decide what information is allowed, try the first step yourself, then use AI for support.

### Principle 2: AI Is A Tool, Not A Person

Avoid personifying AI. Use language like "the tool generated" or "the system suggested", not "it understood", "it cares", or "it knows you".

### Principle 3: No Private Data In Demo Prompts

All examples use invented information. Families are told not to enter names, schools, addresses, personal worries, health details, private photos, private messages, or live-incident details.

### Principle 4: Help, Practice, Feedback, Not Substitution

The course should show parents how AI can explain, quiz, give feedback, or offer a worked example after an attempt. It should not normalise a child asking AI to produce the final school submission.

### Principle 5: Human Review Points

Every workflow has at least one human check before anything is trusted, shared, submitted, sent, posted, bought, or used to make a real decision.

### Principle 6: Calm Proportion

The course should name real issues: hallucination, bias, academic integrity, privacy, deepfakes, companion apps, scams, and overreliance. It should do so without panic or career-hype.

## 5. Guidance Anchors

These sources should guide copy, lesson content, and disclaimers:

- DfE, "Generative artificial intelligence (AI) in education", updated 12 August 2025. Key implications: evidence on pupil use is still emerging; pupil-facing use needs care, supervision, safeguarding, data protection, and critical judgement; generative AI output can be inaccurate, inappropriate, biased, out of date, unreliable, or affected by intellectual-property issues. https://www.gov.uk/government/publications/generative-artificial-intelligence-in-education/generative-artificial-intelligence-ai-in-education
- DfE, "Generative AI: product safety standards", updated 19 January 2026. Key implications: do not exaggerate capabilities; child-facing AI products need clear purpose, privacy, filtering, monitoring, governance, cognitive-offloading safeguards, and should avoid anthropomorphising or relationship-forming patterns. https://www.gov.uk/government/publications/generative-ai-product-safety-standards/generative-ai-product-safety-standards
- JCQ, "AI Use in Assessments", 30 April 2025. Key implications: students must submit their own work for qualification assessments; AI use should be acknowledged where relevant; schools should communicate risks and expectations to parents/carers. https://www.jcq.org.uk/knowledge-hub/ai-use-in-assessments-your-role-in-protecting-the-integrity-of-qualifications/
- ICO AI and data protection guidance. Key implications: personal data, transparency, fairness, accountability, and risk assessment matter when AI systems process information about people. https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/artificial-intelligence/
- Existing Bearings content: `01`, `02`, `06`, `17`, `18`, `19`, `20`, `29`, and `50`.

## 6. Course Outcomes

By the end, a parent should have:

- A plain-English map of what generative AI, chatbots, assistants, agents, and automation are.
- A household AI agreement drafted for their child's age band.
- A prompt pattern that supports thinking rather than replacing it.
- A way to talk about schoolwork, plagiarism, and acknowledgement.
- A private-data rule for AI tools.
- A source-checking habit for AI answers.
- A basic understanding of synthetic media, AI companions, and emotional overreliance.
- A small AI project reviewed through a parent checklist.
- A "what we will re-check next month" routine.

The course should not promise a certain risk outcome, academic improvement, exam advantage, career advantage, or future earning uplift.

## 7. Course Structure

### Session 1: The AI Map And The Household Rules

**Parent question:** What are my child and their friends actually using, and what rules should we have at home?

**Parent learns:**

- The difference between search, chatbot, generative AI, assistant, and agent.
- Why fluent AI answers can still be wrong.
- Why AI companion-style tools are different from homework tools.
- The household "private stays private" rule.

**Family lab:** Draft the first household AI agreement.

**Deliverable:** Family AI Agreement v0.1.

### Session 2: Prompting As Clear Thinking

**Parent question:** How do I help my child use AI without letting it do the thinking?

**Parent learns:**

- The Bearings prompt pattern: goal, context, boundaries, attempt, help wanted, output.
- The "try first" habit.
- How to ask for hints, explanations, examples, quizzes, and feedback.
- How to spot overconfident nonsense.

**Family lab:** Turn one school topic into a learning prompt and quiz.

**Deliverable:** Prompt card plus "show your thinking" routine.

### Session 3: Schoolwork, Creativity, And Synthetic Media

**Parent question:** What is okay around homework, images, voice, and creativity?

**Parent learns:**

- A practical schoolwork ladder: no AI, ask first, AI allowed with acknowledgement, AI encouraged for practice.
- How to talk about "your own work" without turning every homework task into a fight.
- Deepfakes, nudify tools, voice cloning, consent, and why private images stay private.
- The difference between creative support and misrepresentation.

**Family lab:** Build a source-checked study pack from non-sensitive material.

**Deliverable:** Schoolwork and synthetic-media rules for the family agreement.

### Session 4: Small Projects, Agents, And Human Review

**Parent question:** How can my child build something useful without handing too much agency to the tool?

**Parent learns:**

- Automation versus autonomy.
- The project canvas: goal, inputs, allowed data, steps, check points, stop conditions.
- What must never be automated as a first project.
- How to review an AI project before it is reused.

**Family lab:** Build or paper-prototype one small AI-assisted project.

**Deliverable:** Project canvas plus parent review checklist.

## 8. Age-Band Adaptation

### Ages 9-11

**Posture:** Co-use.

**Adult role:** Parent stays in the session, chooses the tool, types where needed, and uses invented examples.

**Best projects:** Story prompt, quiz cards, explain-a-topic, hobby planner, "ask me questions" reading helper.

**Avoid:** Private accounts, AI companions, open-ended chat, uploading photos, any task involving classmates.

### Ages 12-14

**Posture:** Co-set.

**Adult role:** Parent and child agree boundaries together. Parent reviews prompts and outputs until the child has shown stable habits.

**Best projects:** Revision quiz, source-checking helper, reading companion, study planner, "explain at three levels" tool.

**Avoid:** AI-written final homework, private emotional journaling with AI, automated messages, tools that request personal data.

### Ages 15-17

**Posture:** Consult.

**Adult role:** Parent expects more independence but keeps clear rules for schoolwork, personal data, emotional support, and public sharing.

**Best projects:** Research plan, citation-checking workflow, project planner, prototype app, portfolio explainer, revision dashboard.

**Avoid:** Submitting AI-authored work, using AI to impersonate someone, automated emails or applications, public portfolio claims that overstate what the child built.

## 9. Project Menu

### Green Projects

These are suitable as first projects with parent supervision:

- Study quiz generator for one topic.
- Reading companion that asks questions before offering answers.
- "Explain this three ways" learning helper.
- Family activity planner using invented or non-sensitive preferences.
- Creative story-world builder with parent-set boundaries.
- Source-checking worksheet helper.
- Revision timetable draft checked by parent and child.

### Amber Projects

These can work for older teens with more supervision:

- Research assistant for a school topic.
- Simple app prototype.
- Portfolio explainer.
- Email draft that is never sent automatically.
- Coding helper that explains changes before the child uses them.

### Red Projects

Do not use these in the first version:

- Any workflow that sends messages automatically.
- Any tool that stores private worries, emotional disclosures, or incident details.
- Anything involving classmates' data, images, messages, or voices.
- Public posting or public portfolio creation.
- Autonomous purchasing, account changes, downloads, or browser control.
- A companion-style persona for emotional support.

## 10. MVP Assets To Create

### Must Have

- Course landing-page copy block.
- Four facilitator lesson plans.
- Parent workbook.
- Family AI Agreement.
- Prompt card.
- Schoolwork ladder.
- Source-check sheet.
- Small project canvas.
- Project review checklist.
- School/PTA taster outline.

### Nice Next

- Recorded slide deck.
- Five-minute demo videos.
- Printable "Private stays private" card.
- Age-band project menus.
- School newsletter copy.
- Stay Current monthly AI update slot.

## 11. Pricing And Packaging

### As System Add-On

**AI Readiness Lab recording + workbook:** include inside The System once the core product has enough perceived value, or sell as a low-friction add-on.

Indicative add-on price: GBP 29-49 if recorded; GBP 79-149 if cohort-based for parents.

### As School/PTA Session

**Parent evening:** 60 minutes live or recorded, plus take-home workbook.

Indicative price: GBP 300-750, consistent with `13`.

### As Concierge Enhancement

Use it as a structured module in the Concierge call for families specifically worried about AI homework, AI companions, or project-based AI tools.

## 12. Copy Guardrails

Use:

- "AI judgement"
- "family rules"
- "human review"
- "source-checking"
- "privacy habits"
- "schoolwork boundaries"
- "small supervised project"

Avoid:

- "future-proof your child"
- "AI-proof your child"
- "guaranteed advantage"
- "certain safety outcomes"
- "stops bad things happening"
- "AI native"
- "superpowers"
- "your child's personal AI friend"
- "set and forget"

## 13. Open Decisions

- Final name: AI Readiness Lab for Families vs Family AI Lab vs Build With AI.
- Whether the MVP is included in The System or sold as a separate add-on.
- Whether to publish as recorded-only first or run one live parent cohort.
- Whether schools get the full four-part course or only the taster until demand is proven.
- Which AI tools, if any, to demonstrate. This must be rechecked near launch for age restrictions, data settings, and training opt-outs.

## 14. First Build Recommendation

Build the four-session parent version first. It is the fastest to sell, easiest to keep inside the current product boundary, and most aligned with the Bearings promise: orientation before urgency.
