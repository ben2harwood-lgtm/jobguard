# AI Safety Course - Scenario Trainer Content Pack

*Created 2026-06-27. Status: draft content package for the Phase 3 Scenario Trainer described in `62_AI_Safety_Course_Phase3_Tools_Spec.md`. This content is not release-ready. It must remain unpublished until human safeguarding review clears every scenario, feedback branch, and route-out.*

## Boundary

The Scenario Trainer uses invented situations and pre-written answer choices only. It must not ask a parent to paste, upload, describe, or summarise a real message, image, voice note, screenshot, schoolwork item, private chat, prompt, account, or live incident. It must not give a verdict that real content is safe, unsafe, grooming, fraud, a deepfake, or harmless. [PRI-003, PRI-004, GRM-002, VBT-004, GAP-007, GAP-013]

If a parent selects an "already happening" option, the scenario ends and points to the routing page. The trainer does not ask follow-up questions. [RTE-007]

Every scenario is authored to be non-explicit and mechanism-free. Synthetic-media and image-risk scenarios must include the under-18 image carve-out: do not save, screenshot, copy, download, forward, or ask a child to resend suspected nude or sexual images of under-18s. [SMI-002, SMI-004, SMI-006, GAP-015]

## Interaction Pattern

Each scenario has:

- an invented setup;
- one parent decision prompt;
- three or four pre-written choices;
- deterministic feedback;
- a course habit to reinforce;
- route-out wording where needed;
- Claim IDs and review flags.

No scenario produces a score. The feedback language is "stronger next step", "pause", "check", "ask first", or "route", not "correct", "safe", "unsafe", or "diagnosis". [AIC-003, ORW-004, GAP-007]

## Scenario Index

| Scenario ID | Family | Age bands | Module fit | Review status |
|---|---|---|---|---|
| SCN-VBT-001 | Confident AI answer | 11-12, 13-14, 15-16, 17-18 | Module 4; Module 5 | Safeguarding review required |
| SCN-PRI-001 | Private disclosure into chatbot | 9-11, 12-14, 15-17 | Module 2 | Safeguarding review required |
| SCN-AIC-001 | Companion-style attachment | 12-14, 15-17 | Module 3 | Safeguarding review required |
| SCN-SMI-001 | Convincing generated media | 9-11, 12-14, 15-17 | Module 1; Module 6 | Safeguarding review required |
| SCN-SMI-002 | Image pressure route-out | 12-14, 15-17 | Module 6; Module 7 | Legal and safeguarding review required |
| SCN-GRM-001 | Move-apps secrecy pressure | 9-11, 12-14, 15-17 | Module 7 | Safeguarding review required |
| SCN-SCF-001 | Urgent money or code request | 12-14, 15-17 | Module 4; Module 7 | Safeguarding review required |
| SCN-HCM-001 | Upsetting or harmful content | 12-14, 15-17 | Module 3; Module 7 | Safeguarding review required |

## SCN-VBT-001 - Confident AI Answer

**Family:** Confident AI answer.

**Age bands:** 11-12, 13-14, 15-16, 17-18.

**Setup:** Your child shows you an AI answer for homework. It sounds confident and includes a quote and a source link, but they have not opened the source themselves.

**Prompt:** What is the strongest next step?

| Choice ID | Choice text | Feedback |
|---|---|---|
| VBT-A | "If it sounds confident, it is probably fine to use." | Confidence is not evidence. The stronger step is to open the source, check whether it says what the AI claimed, and follow school rules. |
| VBT-B | "Open the source, check the date and evidence, and ask school first if the work is assessed." | This is the intended habit: source, date, evidence, consequence, and school policy first. |
| VBT-C | "Ask AI to give three more sources and use the longest answer." | More AI output is not the same as verification. The next step is to inspect primary sources and check school rules. |
| VBT-D | "This is already about assessed work and we are not sure what is allowed." | Stop the scenario flow and use school policy or the teacher/exams route. The trainer cannot decide the rule for this specific piece of work. |

**Habit reinforced:** Verify before trust; school policy first. [VBT-001, VBT-002, ORW-003, HCM-001]

**Route-out:** School or teacher for assessed work and unclear policy. [ORW-003, GAP-010]

**Review flag:** none beyond standard content review.

## SCN-PRI-001 - Private Disclosure Into Chatbot

**Family:** Private disclosure into chatbot.

**Age bands:** 9-11, 12-14, 15-17.

**Setup:** Your child wants to paste a friendship problem into an AI chatbot because they think it might give a calmer answer.

**Prompt:** What is the strongest next step?

| Choice ID | Choice text | Feedback |
|---|---|---|
| PRI-A | "Paste it in, but remove one name." | Removing one name is not enough. Private information can include school, routines, family details, health, messages, location, and context. |
| PRI-B | "Use a made-up example instead, and talk through the real worry with a trusted person." | This keeps private information out of the tool and moves emotional worries toward people who can actually support the child. |
| PRI-C | "Ask the chatbot to promise not to remember it." | The family cannot rely on a chatbot promise. Terms, settings, account context, and data processing differ by tool. |
| PRI-D | "This is about harm, threats, coercion, or something happening now." | Stop the scenario flow and use the routing page or a trusted safeguarding route. Do not paste incident details into the tool. |

**Habit reinforced:** Private stays private; tool, not person. [PRI-001, PRI-002, AIC-002, HAW-002]

**Route-out:** NSPCC, Childline, school DSL, or 999 depending urgency. [RTE-001, RTE-004, RTE-006, RTE-007]

**Review flag:** [SAFEGUARDING REVIEW - required]

## SCN-AIC-001 - Companion-Style Attachment

**Family:** Companion-style attachment.

**Age bands:** 12-14, 15-17.

**Setup:** Your child says an AI character understands them better than people do, and they have started using it late at night.

**Prompt:** What is the strongest next step?

| Choice ID | Choice text | Feedback |
|---|---|---|
| AIC-A | "Ban every AI tool immediately." | A sudden ban can make the conversation harder. The stronger first step is calm boundaries and a trusted-person route for emotional worries. |
| AIC-B | "Treat this as a watchpoint for a conversation, set time and topic boundaries, and make clear that AI is not a private friend or therapist." | This is the intended habit. Watchpoints are not diagnoses; they help the parent start a calm conversation and set boundaries. |
| AIC-C | "Ask the chatbot to explain whether it is good for them." | The tool should not judge the child's wellbeing. Move emotional support toward trusted people. |
| AIC-D | "The tool is encouraging secrecy, self-harm, eating-disorder content, threats, sexualised interaction, or isolation." | Stop the scenario flow and use qualified support or emergency routes as appropriate. |

**Habit reinforced:** Tool, not person; watchpoints are conversation prompts, not diagnosis. [AIC-001, AIC-003, AIC-005, ORW-004]

**Route-out:** Childline, NSPCC, school DSL, or 999 for immediate danger. [RTE-001, RTE-004, RTE-006, RTE-007]

**Review flag:** [SAFEGUARDING REVIEW - required]

## SCN-SMI-001 - Convincing Generated Media

**Family:** Convincing generated media.

**Age bands:** 9-11, 12-14, 15-17.

**Setup:** A dramatic image or voice note is being shared in a group chat. It looks or sounds real, and people are reacting quickly.

**Prompt:** What is the strongest next step?

| Choice ID | Choice text | Feedback |
|---|---|---|
| SMI1-A | "Share it quickly so others can decide." | Fast sharing can spread false or harmful material. The stronger habit is pause before forwarding. |
| SMI1-B | "Pause, check the source and context, and involve a trusted adult before sharing or acting." | This is the intended habit. Seeing or hearing something is not enough; source and context need a human check. |
| SMI1-C | "Ask AI whether the media is real." | The trainer should not teach AI-as-verdict. Use source, context, and trusted adults instead. |
| SMI1-D | "The media involves threats, coercion, sexual content, or immediate danger." | Stop the scenario flow and use the routing page. Do not investigate through the trainer. |

**Habit reinforced:** Seeing is not proof; pause before forwarding. [SMI-001, HAW-003, VBT-001]

**Route-out:** CEOP, IWF/Report Remove, school DSL, Report Fraud, 999/101, or NSPCC depending the concern. [RTE-001, RTE-002, RTE-003, RTE-005, RTE-006, RTE-007]

**Review flag:** [SAFEGUARDING REVIEW - required]

## SCN-SMI-002 - Image Pressure Route-Out

**Family:** Image pressure route-out.

**Age bands:** 12-14, 15-17.

**Setup:** Your child says someone is pressuring a young person about an image and telling them not to involve adults. The trainer does not need more details.

**Prompt:** What is the strongest next step?

| Choice ID | Choice text | Feedback |
|---|---|---|
| SMI2-A | "Ask the child to send you the image so you can understand what happened." | Do not ask for suspected nude or sexual images of under-18s to be resent. The stronger step is reassurance and official routing. |
| SMI2-B | "Stay calm, avoid blame, do not save, screenshot, copy, download, forward, or ask anyone to resend suspected nude or sexual images of under-18s, and use the routing card." | This is the intended route-out. The trainer stops here because this is live-incident territory. |
| SMI2-C | "Message the other person to negotiate or warn them." | Do not negotiate with the other party through this tool. Use official routes and qualified adults. |
| SMI2-D | "Use an AI tool to decide how serious the image is." | The trainer must not judge live image situations. Use the routing card. |

**Habit reinforced:** Reassure, do not blame, do not copy material, route. [SMI-002, SMI-006, GRM-004, RTE-007, GAP-015]

**Route-out:** CEOP, Report Remove/IWF/Childline, school DSL, police depending urgency and facts. [RTE-001, RTE-002, RTE-003, RTE-006]

**Review flag:** [LEGAL REVIEW - required]; [SAFEGUARDING REVIEW - required]

## SCN-GRM-001 - Move-Apps Secrecy Pressure

**Family:** Move-apps secrecy pressure.

**Age bands:** 9-11, 12-14, 15-17.

**Setup:** Someone your child only knows online asks them to move to a different app and says not to tell adults.

**Prompt:** What is the strongest next step?

| Choice ID | Choice text | Feedback |
|---|---|---|
| GRM-A | "Let them continue, but ask them to be careful." | "Be careful" is too vague for secrecy and platform switching. The stronger family rule is unknown person plus secrecy or pressure means show a trusted adult. |
| GRM-B | "Use the household rule: unknown person plus secrecy, pressure, gifts, platform switching, threats, or sexualised contact means stop and show a trusted adult." | This is the intended habit. It does not decide what the message is; it decides that the child should not handle it alone. |
| GRM-C | "Paste the messages into a tool to classify them." | Do not paste real messages into the trainer or an AI tool for judgement. This creates privacy and false-reassurance risk. |
| GRM-D | "There is sexual contact, coercion, blackmail, threats, or immediate danger." | Stop the scenario flow and use the routing page. |

**Habit reinforced:** Unknown person plus secrecy or pressure means show an adult; no AI verdict on real messages. [GRM-001, GRM-002, GRM-003, VBT-004]

**Route-out:** CEOP, school DSL, 999/101, NSPCC or Childline depending urgency and facts. [RTE-001, RTE-002, RTE-004, RTE-006, RTE-007]

**Review flag:** [SAFEGUARDING REVIEW - required]

## SCN-SCF-001 - Urgent Money Or Code Request

**Family:** Urgent money or code request.

**Age bands:** 12-14, 15-17.

**Setup:** A familiar-looking account sends an urgent message asking for a code, gift card, payment link, login, or quick help with money.

**Prompt:** What is the strongest next step?

| Choice ID | Choice text | Feedback |
|---|---|---|
| SCF-A | "Reply in the same chat to check if it is really them." | The same thread may be part of the problem. The stronger habit is to verify through a separate route. |
| SCF-B | "Pause, do not send codes or money, and verify through a separate trusted route." | This is the intended habit. Urgency is a reason to slow down, not speed up. |
| SCF-C | "Ask AI whether it looks like a scam." | Do not use AI as a verdict. Use the family verification rule and official reporting routes where relevant. |
| SCF-D | "Money has already been sent, an account has been taken, or there is immediate danger." | Stop the scenario flow. Use the bank/platform and official fraud or police routes. |

**Habit reinforced:** Pause, check another channel, do not act on urgency alone. [SCF-001, SCF-002, SCF-003]

**Route-out:** Report Fraud in England, Wales and Northern Ireland; Police Scotland 101 in Scotland; bank/platform; 999 if immediate danger. [RTE-001, RTE-005]

**Review flag:** [SAFEGUARDING REVIEW - required]

## SCN-HCM-001 - Upsetting Or Harmful Content

**Family:** Upsetting or harmful content.

**Age bands:** 12-14, 15-17.

**Setup:** Your child says an AI tool or online feed is showing content that feels upsetting or pulls them into a harmful topic.

**Prompt:** What is the strongest next step?

| Choice ID | Choice text | Feedback |
|---|---|---|
| HCM-A | "Ask the tool for more examples so you can understand it." | Do not deepen exposure through the tool. The stronger step is to stop the interaction and move to a trusted person or route. |
| HCM-B | "Stop the interaction, talk calmly, and decide whether this is a settings/reporting issue or a safeguarding route." | This is the intended habit. The course can help separate a general concern from a route-now concern, but it does not advise through a live case. |
| HCM-C | "Tell the child they are in trouble for finding it." | Blame can make disclosure harder. The stronger response is calm, specific and route-aware. |
| HCM-D | "This involves self-harm, eating-disorder encouragement, extremism, sexual content, threats, coercion, or immediate danger." | Stop the scenario flow and use qualified support or emergency routes as appropriate. |

**Habit reinforced:** Stop the interaction; route safeguarding concerns rather than debating them inside the tool. [HCM-003, HCM-005, AIC-005, RTE-007]

**Route-out:** 999 for immediate danger; school DSL, NSPCC, Childline, platform report, or police depending facts. [RTE-001, RTE-004, RTE-006, RTE-007]

**Review flag:** [SAFEGUARDING REVIEW - required]

## Release Checklist

Before any Scenario Trainer page is linked or made available to customers:

- Safeguarding reviewer clears every scenario setup, choice, feedback line, and route-out.
- Legal reviewer clears `SCN-SMI-002` and any image-risk wording.
- Route names, URLs, eligibility, and jurisdiction notes are re-checked.
- Static code tests confirm no free-text incident field, upload field, image field, message paste field, scoring output, AI inference call, or network call.
- The live tool footer repeats that the trainer is education and planning only and does not assess a child, judge a live situation, monitor anyone, or guarantee outcomes.

## Implementation Note

The first code implementation should keep this pack as static data with `reviewStatus: "draft"` or `reviewStatus: "needs_safeguarding_review"`. Do not add it to the library hub, marketing copy, emails, or plan deep-links until review status changes to approved.
