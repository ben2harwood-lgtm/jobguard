# AI Safety Course - Pre-Revenue AI Review Workflow

*Created 2026-06-27. Status: interim review workflow for pre-revenue / early-customer validation. This does not replace paid legal or safeguarding sign-off. It creates a disciplined AI-assisted stress test so the course can keep moving while the commercial signal is still being proven.*

## Operating Decision

Until there are paying customers or a clear paid-customer pipeline, use AI-assisted legal and safeguarding review as a **red-team and issue-finding layer**, not as formal clearance.

AI review may:

- identify wording risks;
- find missing carve-outs;
- flag unsupported claims;
- compare copy against the Claim Register and Gap Register;
- produce a fix list;
- help prepare a professional-review brief.

AI review may not:

- give legal advice;
- give safeguarding advice for live cases;
- clear the product as compliant;
- clear the product as safe;
- replace route re-checks;
- approve public launch of high-risk tools;
- remove the need for paid human review once the product has paying traction.

## Practical Gate

| Stage | Review level | What may happen |
|---|---|---|
| Internal build | Codex + cross-model AI red-team | Specs, draft data, private prototypes, content lint, guardrails. |
| Founder preview | AI legal/safeguarding review plus source re-check | Founder can inspect course flow and low-risk assets. No broad public release. |
| Small founding validation | AI review complete, route/source re-check logged, founder manually reviews every output | Conservative paid/manual pilot only, with no live-incident handling, no child data, no public Scenario Trainer/Self-Check/Routing Card unless narrowed and reviewed. |
| Repeatable paid signal | Paying customers, low refund risk, actual demand signal | Pay for human legal/safeguarding review before scaled sale or public tooling. |
| Public/scaled launch | Human review decisions patched and tests passing | Parent-facing public course/tools can ship within approved scope. |

## AI Review Roles

Run two separate AI reviews. Do not let one model combine the roles casually.

### AI Legal Reviewer

Focus:

- under-18 image wording;
- legal seriousness language;
- adult vs under-18 image-law boundaries;
- data/privacy statements;
- Online Safety Act / platform duty wording;
- schoolwork and assessment wording;
- marketing/efficacy/compliance claims.

Output:

- blocker/high/medium/low findings;
- exact phrases to change;
- "needs human legal review" flags;
- unsupported claims to remove or move to Gap Register.

Use `70_AI_Safety_Course_Legal_AI_Review_Brief.md`.

### AI Safeguarding Reviewer

Focus:

- route boundaries;
- live-incident stop logic;
- scenario wording;
- companion/chatbot watchpoints;
- contact pressure/grooming wording;
- harmful content/wellbeing routing;
- disclosure wording;
- school-linked concerns.

Output:

- blocker/high/medium/low findings;
- exact phrases to change;
- "needs human safeguarding review" flags;
- places where the content drifts into incident advice or false reassurance.

Use `71_AI_Safety_Course_Safeguarding_AI_Review_Brief.md`.

## Review Inputs

Send the AI reviewers these files:

- `57_AI_Safety_Course_Claim_Register.md`
- `58_AI_Safety_Course_Gap_Register.md`
- `60_AI_Safety_Course_G1_Breaker_Findings.md`
- `61_AI_Safety_Course_Phase2_Design_Package.md`
- `62_AI_Safety_Course_Phase3_Tools_Spec.md`
- `63_AI_Safety_Course_Scenario_Trainer_Content.md`
- `64_AI_Safety_Course_Readiness_Self_Check_Spec.md`
- `65_AI_Safety_Course_Stay_Current_Update_Stream_Spec.md`
- `66_AI_Safety_Course_Routing_Card_Spec.md`
- `67_AI_Safety_Course_Human_Review_Pack.md`
- `68_AI_Safety_Course_Source_Recheck_Log.md`
- relevant implemented files:
  - `components/FamilyAgreementBuilder.tsx`
  - `lib/ai-safety-scenarios.ts`
  - `lib/ai-safety-self-check.ts`
  - `lib/ai-safety-update-stream.ts`
  - `lib/ai-safety-routing-card.ts`

## Pass / Fail Rules

AI review is treated as failed if it finds any:

- instruction to save, screenshot, copy, download, forward, or request suspected under-18 sexual/nude images;
- request for child PII or incident detail;
- AI judgement of real messages, images, schoolwork, or incidents;
- safety guarantee, efficacy claim, or compliance conclusion;
- public route-card or scenario wording that gives live incident advice;
- unreviewed legal conclusion;
- unsupported platform-specific claim;
- route that is materially wrong or too broad.

If failed, patch the issue, rerun content lint, and rerun the AI review on the affected file(s).

## Review Log

Record review outputs in a new findings file:

`72_AI_Safety_Course_PreRevenue_AI_Review_Findings.md`

Use this table:

| Reviewer | File / section | Finding | Severity | Required change | Status |
|---|---|---|---|---|---|
| legal AI / safeguarding AI | file + section | issue | blocker/high/medium/low | exact change | open/patched/accepted risk/defer to human |

## What AI Review Can Clear For Now

AI review can clear internal movement to:

- refine scripts;
- refine worksheets;
- keep the Family Agreement builder as a draft/preview tool;
- prepare a pre-revenue pilot pack;
- prepare a no-code/manual fulfilment flow;
- prepare the paid human review pack.

AI review cannot clear:

- scaled public launch;
- a claim that the product is legally reviewed;
- a claim that the product is safeguarding reviewed;
- a print-ready routing card;
- scenario or self-check tools that route parents through live concerns;
- platform-specific current settings without source re-check.

## Trigger For Paid Human Review

Book paid human review when any one of these is true:

- first 5 paying customers are likely or achieved;
- a school/PTA wants to circulate the material;
- any parent-facing route card, scenario trainer, or self-check is about to go live;
- a sales page makes a concrete legal, route, platform, or schoolwork claim;
- a customer asks whether the product is legally/safeguarding reviewed;
- before the first broad email launch or public paid campaign.

Until then, keep AI review language internal. Do not say "legally reviewed", "safeguarding reviewed", or "expert approved" in customer copy.
