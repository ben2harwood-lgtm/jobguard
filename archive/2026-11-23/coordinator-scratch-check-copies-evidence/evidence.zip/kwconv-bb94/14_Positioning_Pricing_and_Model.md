# Positioning, Pricing & Model — V2 (research-backed)

**This supersedes the £39 thin-report positioning. It settles the canon decision you delegated to research: what we are, who we're for, what we charge, and the revenue model.** Confidence tags: `[V]` verified, `[PV]` partly verified, `[NV]` needs verification, `ASSUMPTION` = planning call to test.

---

## The headline

We stop selling a £39 report and start selling a **premium, done-for-you household digital-safety system** — a deep, personalised, kept-current resource library plus a tailored plan — for **parents of children and teenagers (5–18)**. The £39 price actively signalled "cheap / inferior" and competed with free. The research supports charging materially more **if** the offering is genuinely richer, personalised, and current. That's the whole move.

---

## The market gap we're taking (competitor research)

The UK market is **barbelled**: free at one end (Internet Matters, NSPCC, Parent Zone, Childnet — broad but shallow, and they leave all the work to the parent), monitoring software at the other (Qustodio, Norton, Life360 at ~£15–£70/yr; Bark and Aura aren't even available to UK consumers). `[V]`

Three gaps fall out of that:

1. **Nobody owns premium, prevention-framed, done-for-you guidance that isn't surveillance.** The one true UK analogue — Safer Online's "Parents Portal" at **£79 / £129 / £249/yr** — proves the price points transact, but it's generic and templated, leaving room to win on depth, teen-specificity and credibility. `[V]` price points; `[NV]` whether it actually converts well.
2. **"Concierge / done-for-you family-tech-safety" as a branded UK consumer service does not exist.** Today that need is met only by gig handymen and router tools. That's our most defensible differentiator and the anchor for a premium tier. `[V]` (absence)
3. **Free resources create the "why pay?" problem** — so the paid edge has to be the things free content does badly: **personalisation, curation against overwhelm, ongoing currency, and conversation help.** `[V]`

**Positioning line:** *"We don't hand you 200 articles or spy on your kid. We give you a finished, personalised safety system for your specific children — and we keep it current."*

**Position against overwhelm, not ignorance.** Parents aren't short of information; they're short of time, proportion, and currency. Over a third of UK parents don't know where to go for support; children are online ~23 hrs/week and it changes faster than parents can track. Lead with *"we keep up so you don't have to,"* and *"the bit that applies to your child, right now."* `[V]`

---

## Who pays (segments)

| Segment | Why they pay | Priority |
|---|---|---|
| **Parents of 5–10s getting a first tablet** | The first "managed device" moment — family iPad, YouTube Kids, first Roblox; acute early anxiety, under-served by teen-focused advice. | **Hero-adjacent** (added Jun 2026, see `26`) |
| **Parents of 11–13s getting a first phone / first social media** | Highest-intensity, time-bound decision; actively searching; 140k+ have joined Smartphone Free Childhood. Best acquisition wedge. | **Hero** `[V]` moment |
| **Anxious-but-engaged (often affluent) parents** | The "premium" tier is the largest, fastest-growing UK parental-controls segment; these parents pay to offload effort. | **Core** `[PV]` |
| **Post-incident parents** | Just had a scare (sextortion threat, something found); high intent, will pay more, but harder to reach at the moment and they churn after resolution. | High-value, lower-volume `[PV]` |
| Time-poor professionals | Plausibly pay to offload, but no hard UK WTP data. | Test `[NV]` |

---

## Pricing — the honest version

**The two pricing studies disagree, and I'm not going to paper over it.** The competitor study says £149 core (anchored on Safer Online's £129–£249 tiers). The willingness-to-pay study says UK parents anchor on £15–£70/yr tools and free education, putting a one-off "hard ceiling" nearer £79 without strong proof. Both are partly right: a £149 price point *exists* in the market, but there's no evidence it *converts* at volume, and free is a real gravitational pull.

So **price is a launch experiment, not a research output.** We commit to premium, set a sensible opening ladder, and let real conversion find the ceiling (the decision-gate tracker already supports this).

### Recommended opening ladder

| Tier | What it is | Price | Role |
|---|---|---|---|
| **Free** | 2-minute readiness quiz + snapshot | £0 | Top of funnel, email capture |
| **The System** (hero) | Personalised plan + full library: platform guides **with setup videos**, playbooks, age-band pack, conversation scripts, family-agreement builder, quick-reference cards, a stage masterclass | **£99** (founding price **£79**) | The core paid product |
| **The Concierge** | Everything in The System + a live done-*with*-you setup/audit call, a bespoke all-children report, a follow-up + 12-mo priority email | **from £650** (scoped per household; ~4 slots/mo) | High-margin scarcity; fills the empty UK concierge gap; anchors £99 down. *(Revised 20 Jun 2026 from a £179 setup tier — see `26`.)* |
| **Stay Current** membership | Monthly threat briefings, platform-setting update alerts, refreshed playbooks, continued access | **£59/yr** (or £6.50/mo); **year 1 bundled** into The System | Renewal / currency layer |

**Test band:** £79 ⇄ £149 on the core. Start at £99 (founding £79 for the first cohort to seed testimonials), push toward £129–£149 only once personalisation depth, named credibility, and testimonials are in place. `ASSUMPTION` — validate against live conversion.

### Why this shape (grounded in the research)
- **It clears the monitoring-app band (£15–£70) decisively**, signalling "different, higher-value category — a system, not an app." `[V]`
- **Three tiers use the anchor psychology** Safer Online and Qustodio both rely on: the **from-£650 Concierge** makes £99 read as a no-brainer. `[V]`
- **One-off first, membership second.** Online-safety anxiety is **episodic** (spikes at first phone, at incidents) — structurally hostile to cold monthly subscriptions. Capture the high-intent moment with a one-off; let "keep it current" be the renewal layer. Every premium competitor justifies *annual* renewal on content freshness, which is honest here because threats/settings genuinely change. `[V]`
- **Bundle year-1 currency into the core** so renewal feels natural rather than like a second sell.

### What justifies charging premium (put these in the copy)
Done-for-you (not DIY) · personalisation to *this* family's kids/ages/platforms · ongoing currency · trust/authority (named, cited, calm) · optional human access (the setup tier). `[V]`

---

## Revenue model in one line

**Free quiz → £99 one-off "System" (founding £79) as the hero → "The Concierge" (from £650, scoped) as high-margin scarcity for the affluent/post-incident buyer and the empty concierge niche → £59/yr "Stay Current" membership (year 1 bundled) as the renewal layer.** Lead one-off; subscription is the currency upsell, never the cold ask. *(Top tier revised 20 Jun 2026 — see `26`.)*

---

## What this means for the build (carried into `15`)

1. **Per-platform settings = the spine** (83% of parents want it; revealed demand). `[V]`
2. **Age-banded conversation scripts = the differentiator** — free sources do settings; the paid edge is "how to raise sextortion with a 13-year-old without scaring them," defusing the documented 32% "fear of overreacting." `[V]`
3. **Build around 5 age bands** (adding a 5–10 "first tablet" on-ramp), with **13–14 as the flagship** (legal onboarding to social media, sextortion peak, peak peer-influence). `[V]`
4. **Sell proportion/reassurance explicitly** — "is this normal? when should I actually worry?" is under-served by alarmist free content. `[PV]`
5. **The "what's changing in the law" + monthly briefing = the renewal hook**, framed as part of the bundle, not the headline (WTP evidence for paying *specifically* for alerts is thin). `[PV]`
6. **Lead on credibility** to beat free: named sources, citations, a calm premium experience.

*Old V1 assets (00–13) aren't wasted: the signpost, emails, tracker, sample-report shell and lean manual-fulfilment model all carry forward. What changes is the depth of the product they wrap, and the price.*
