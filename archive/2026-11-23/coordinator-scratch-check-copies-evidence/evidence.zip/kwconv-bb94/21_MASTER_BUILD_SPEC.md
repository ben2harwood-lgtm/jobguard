# MASTER BUILD SPEC — Household Digital-Safety System

**A single, self-contained specification for a coding agent to build the V1 product.** It is written to be handed to a capable coding agent (e.g. Claude Code) working in this repo. The prose *content* of the product already exists as files `00`–`20` in this folder; this spec defines the application that delivers it, and points to each content file as the source of truth.

> Working brand: `Bearings` (shortlist: Bearings · Household Ready · Outset — see `06`). Replace throughout. Currency: GBP. Market: UK.

---

## 0. How to use this document (agent: read first)

1. **Content is already written — do not invent it.** Product copy and resources live in files `00`–`20` (index in §13). Ingest them; don't rewrite them. Where this spec and a content file differ on *copy*, the content file wins; where they differ on *behaviour/architecture*, this spec wins.
2. **The guardrails in §2 are hard constraints, not styling.** They have legal/safeguarding force. Treat a guardrail violation as a build failure.
3. **Build in the milestone order in §11.** Each milestone is shippable. Do not build deferred items in §3.
4. **Human-in-the-loop is mandatory for the personalised plan** (§7.5). No AI-generated plan is ever sent to a customer without an admin clicking "publish". This is a guardrail, not a preference.
5. **When unsure, prefer the lean option.** This product wins on content depth, not engineering. No feature should be built "for scale" before sales exist.

---

## 1. Product context & goals

**What it is.** A premium, prevention-framed "household digital-safety system" for UK parents of children and teenagers (5–18): a short diagnostic produces a personalised action plan that unlocks a deep, kept-current resource library (platform setting guides, threat playbooks, age-band packs, conversation scripts, family-agreement builder), plus an optional ongoing "what's changed" membership. Strategy: `14`; architecture: `15`.

**Audience & positioning.** Parents of 5–18s; hero moments are the first tablet (5–10) and the first phone (11–13), plus anxious-but-engaged parents. Position **against overwhelm, not ignorance**: "we keep up so you don't have to; here's the bit that applies to *your* child, right now." It is **not** monitoring/surveillance software.

**Primary goal of V1.** Take real money for the System, deliver a genuinely useful personalised plan + library, and convert a minority into the membership — while staying inside the regulatory guardrails. Success metrics and decision gates: `00` §7 and tracker `12`.

---

## 2. NON-NEGOTIABLE GUARDRAILS (build constraints)

These come from the regulatory go/no-go (`00`) and data notice (`05`). The product's legal "GO" depends on them staying true.

**Architecture / scope guardrails**
- **No user-to-user features.** No messaging between users, no forum, no comments, no public profiles, no chat. (Any of these would pull the product into Online Safety Act scope.) Reviews/testimonials must be provider-published only, never user-submitted-and-displayed.
- **No child accounts and nothing child-facing.** Only the adult parent is a user. No login, content, or interaction designed for or directed at under-18s.
- **Adult-only, soft-gated.** A lightweight "I confirm I am 18+ and a parent/carer" checkbox at signup/checkout. Not full age verification.

**Data guardrails (enforce in forms + schema)**
- **Collect the least data possible. Never collect child-identifiable data:** no child full name, DOB, school, photos, screenshots, message uploads, or incident detail. Child age is captured as a **band only** (e.g. "13–14"), never a date of birth.
- The questionnaire's single optional "child first name / initial" field defaults to empty/skipped and is **purged within 30 days** of plan delivery (cron job). No special-category (health) data; the one free-text field carries a visible "no names/school/incident detail" notice and is reviewed/redacted before storage.
- Lawful bases: contract (delivery) + legitimate interests (improvement/security); marketing email consent is a **separate** opt-in (PECR). Privacy notice copy: `05`.

**Content / claims guardrails (enforce with an automated lint, §10.3)**
- Prevention, not panic. No fear-based selling.
- **No efficacy or safety guarantees.** Banned phrases include "keeps your child safe", "prevents [grooming/harm]", "protects your child from…", "child-safe by design", "fully compliant", "never worry again", and any claim the product detects/monitors/guarantees. (Negated/disclaimer uses — "we do **not** monitor" — are allowed.)
- **No schoolwork/authorship/custody verdicts.** The product may teach ask-first rules, explain-back habits, source checking, and school-policy boundaries, but it must not claim to verify a child's authorship, independent reasoning, retention, AI use, cheating, or whether a piece of work is "theirs".
- No "coaching" framing for the membership; it is an automated content/currency layer (the "Stay Current" plan), never a person advising.
- Regulatory/threat claims in content carry confidence tags and cite UK authorities (already done in the content files).

**Emergencies = signpost only**
- The emergency signpost (`03`) is **ungated** (reachable without login/purchase), **non-monetised** (no upsell on it), and routing-only (no bespoke incident advice). Linked in the global footer and inside every plan/library page.

---

## 3. Scope — build now vs defer

**Build now (V1):**
marketing site · free quiz · 3-tier Stripe checkout + annual membership · passwordless (magic-link) auth · purchase-gated content library (from `16`–`20`) · diagnostic questionnaire · **assisted** personalised plan generation with admin review · email lifecycle · monthly briefing sending · family-agreement builder · ungated emergency signpost · privacy/terms/age-gate · analytics + funnel events · minimal admin.

**Explicitly DO NOT build (deferred — see `00`/`15`):**
native mobile app · password accounts / social login · automated plan generation that sends without human review · any scoring "engine" beyond the simple quiz · the rehearsal engine · any child-facing flow · any schoolwork custody/authorship/attestation/verdict system, cold-check flow, or assignment-processing workflow · community/forum/messaging/comments · a CMS (start with in-repo MDX) · multi-language · paid-ads infrastructure. Building any of these now is out of scope and, for the child-facing/U2U/schoolwork-verdict items, a guardrail breach.

---

## 4. Recommended tech stack

Chosen for: mainstream + well-documented (agent-friendly), cheap to run, low-maintenance for a solo non-technical founder. `ASSUMPTION` — swap any layer if you have a strong preference; keep the shape.

| Layer | Choice | Notes |
|---|---|---|
| Framework | **Next.js (App Router) + TypeScript** | SSR/SSG; one codebase for site + API routes |
| Styling | **Tailwind CSS** | Calm/premium design tokens in §5.1 |
| Hosting | **Vercel** | Zero-config Next.js deploy |
| DB | **Postgres via Supabase** (or Neon) | Also gives auth + storage |
| Auth | **Passwordless magic-link** (Supabase Auth or Auth.js email provider) | No passwords. Gate = active purchase, not just login |
| Payments | **Stripe** (Checkout + Customer Portal + webhooks) | Products/prices in §7.3 |
| Email | **Resend** (transactional) + scheduled sends via Vercel Cron | Templates from `08`; briefings from `20` |
| Content | **MDX files in repo** + frontmatter tags | Files `16`–`20` become MDX; see §7.6 |
| PDF | **@react-pdf/renderer** or Playwright "print to PDF" | Personalised plan + printable family agreement |
| Analytics | **Plausible** (cookieless) + server-side `events` table | Avoids a cookie banner for analytics; funnel in §7.12 |

**Even-leaner no-code alternative** (note for the founder, not this build): Carrd/Framer + Tally + Stripe Payment Links + ConvertKit + gated Notion/PDF. Faster to launch, less flexible. This spec assumes the coded app.

---

## 5. Information architecture & routes

### 5.1 Design tokens — Bearings brand (source of truth: `brand-mockups/styles.css`)
Canvas `#f8f5ee` · surface `#ffffff` · ink `#171b18` · text `#343833` · muted `#697069` · line `#ded8ca`. Primary **cedar** `#23483f` (dark `#172f2a`); accents **copper** `#9b553f`, **source-blue** `#2b5b75`, **plum** `#4b3f58`; **emergency** `#8f3434` (restrained, emergency page only). Fonts: **Source Serif 4** (display/headlines) · **IBM Plex Sans** (body) · **IBM Plex Mono** (eyebrows/labels). Cards radius 8px, generous whitespace, warm-paper feel. Brand line: *"Orientation before urgency."* The fully-designed reference site lives in **`brand-mockups/`** (home, pricing, readiness-check, guidance-library, household-plan, stay-current, privacy, terms, emergency + desktop/mobile screenshots) — treat it as the canonical visual system. *(The earlier plain palette in `03`/`04`/`10`/`23` predates the brand and is superseded.)*

### 5.2 Routes

| Route | Gate | Purpose / source |
|---|---|---|
| `/` | public | Landing — copy from `04`, repackaged to premium tiers per `14` |
| `/quiz` | public | Free readiness quiz — logic from `10` |
| `/how-it-works` | public | The 3 steps + what's inside |
| `/pricing` | public | 3 tiers + membership (§7.3) |
| `/sample` | public | A sample plan (from `02`, upgraded) to build trust |
| `/for-schools` | public | School/PTA note + enquiry form — `13` |
| `/emergency` | **public, ungated, no upsell** | Signpost — render `03` |
| `/privacy`, `/terms` | public | From `05` (+ solicitor-reviewed ToS placeholder) |
| `/login` | public | Magic-link request |
| `/checkout/[tier]` → Stripe → `/checkout/success` `/cancel` | public | §7.3 |
| `/questionnaire` | gated (purchased) | Diagnostic — questions from `01` |
| `/library` | gated | Library hub, navigated by age band |
| `/library/start` | gated | The personalised plan (the diagnostic output) |
| `/library/age/[band]` | gated | Age-band pack — `19` |
| `/library/platforms/[slug]` | gated | Platform guide — `16` |
| `/library/playbooks/[slug]` | gated | Threat playbook — `18` |
| `/library/conversations` | gated | Conversation library + "what not to say" card — `17` |
| `/library/family-agreement` | gated | Interactive builder (§7.10) |
| `/library/whats-changing` | gated | Currency explainer — `20` |
| `/account` | gated | Membership status, Stripe portal link, data requests |
| `/admin/*` | admin only | Fulfilment queue, plan drafting, briefing sender (§7.11) |
| `/api/*` | — | `quiz`, `checkout`, `stripe/webhook`, `questionnaire`, `plan`, `briefing`, `dsr` |

---

## 6. Data model

Postgres. No child-identifiable columns anywhere.

```
users(id, email UNIQUE, marketing_consent bool default false,
      is_admin bool default false, created_at)

purchases(id, user_id FK, tier enum['system','concierge'],
          stripe_session_id, stripe_payment_intent, amount_pence,
          status enum['paid','refunded'], purchased_at,
          updates_until date)          -- purchased_at + 12 months

subscriptions(id, user_id FK, stripe_subscription_id,
              status enum['active','canceled','past_due'],
              current_period_end)       -- 'Stay Current' £59/yr

quiz_responses(id, email NULLABLE, answers_jsonb, score int,
               band enum['good','opportunities','focus'], created_at)

questionnaires(id, user_id FK, answers_jsonb,        -- structured, no child PII
               child_age_band text,                  -- '5-10'|'11-12'|'13-14'|'15-16'|'17-18'
               -- child_firstname REMOVED 2026-07-04 (99 §6, F5/F35): no child-
               -- identifiable columns, no exceptions; personalise by band only
               free_text text NULLABLE,               -- reviewed/redacted
               submitted_at, purge_after date)        -- submitted_at + 30 days

plans(id, user_id FK, questionnaire_id FK,
      status enum['draft','in_review','delivered'],
      content_mdx text, pdf_url, delivered_at)

briefings(id, month text, subject, body_mdx, sent_at)

events(id, type, user_id NULLABLE, session_id, props_jsonb, created_at)
   -- funnel: 'visit','quiz_start','quiz_complete','email_capture',
   --         'checkout_start','purchase','questionnaire_submit',
   --         'plan_delivered','feedback_submit','membership_start',
   --         'membership_renew','referral'

feedback(id, plan_id FK, usefulness int, took_action bool,
         calmer enum['calmer','same','worried'], recommend int, notes text)
```

**Access rule (single source of truth, implement as `hasLibraryAccess(user)`):** user has a `purchases` row with `status='paid'`. **"Current" entitlement** (briefings/alerts/refreshed content) = `updates_until >= today` **OR** an `active` subscription. Library *content* itself does not expire once purchased; only currency does.

**Retention cron (daily):** redact/clear `free_text` and purge working `answers_jsonb` detail where `purge_after < today`; keep order records for statutory period. *(The former `child_firstname` null-out is obsolete — the field no longer exists.)*

---

## 7. Feature specifications

### 7.1 Marketing site & landing
Render the structure and copy from `04`, **repackaged to the premium positioning and tiers in `14`** (drop the £39 framing). Keep: headline A/B variants, "what this is / isn't" block (guardrail-critical), objections accordion, email-capture, footer with `/emergency` + `/privacy`. Add a tiers comparison (System / Concierge / Stay Current) from `15`.

### 7.2 Free quiz (`/quiz`)
Port `10_Free_Readiness_Quiz.html` **exactly** — 8 questions, additive scoring, three calm result bands (`good` ≤4, `opportunities` 5–9, `focus` ≥10), snapshot copy as written. On completion: write `quiz_responses` + emit `quiz_complete`; email capture is optional and emits `email_capture` (separate marketing-consent checkbox). CTA → `/pricing`. No localStorage.

### 7.3 Pricing & checkout
Stripe products/prices (create in dashboard or via script; store IDs in env):

| Tier | Stripe object | Price | Grants |
|---|---|---|---|
| **System** | one-time price | **£99** (founding £79 via coupon/secondary price) | library access + 12 months "current" |
| **The Concierge** | invoice / scoped quote | **from £650** | as System + a live done-with-you setup/audit, bespoke all-children report, follow-up + priority email (manual fulfilment); ~4 slots/mo |
| **Stay Current** | recurring price | **£59 / year** | continues "current" entitlement |

Flow: `/checkout/[tier]` → Stripe Checkout (collect email + 18+/parent consent + optional marketing opt-in) → success. **`/api/stripe/webhook`** on `checkout.session.completed`: upsert `user`, insert `purchase` (set `updates_until = now()+12mo`), send magic-link + confirmation + questionnaire link (`08` email 1), emit `purchase`. For Stay Current: manage via `subscriptions` + Customer Portal. **The Concierge is an enquiry → manual scoped Stripe invoice, not self-serve Checkout** (scoping rubric in `26` §6); no `STRIPE_PRICE_CONCIERGE` env needed. Test mode first; verify a live £-purchase and a refund before launch.

### 7.4 Diagnostic questionnaire (`/questionnaire`)
Port the 25 structured questions from `01` §2.2. **Form-level guardrails:** no field for ANY child name/DOB/school/screenshots (the former optional first-name question was removed 2026-07-04 — personalisation is by age band only); the final free-text shows the "no names/school/incident detail — if it's happening now, see the emergency signpost" notice. On submit: write `questionnaires` (set `purge_after = now()+30d`), emit `questionnaire_submit`, create a `plans` row `status='draft'`, trigger draft generation (§7.5).

### 7.5 Personalised plan generation (AUTOMATED block-assembly — rewritten 2026-07-04, blueprint `99`)
This is the hero deliverable. **Per-customer human review is retired; per-BLOCK human review replaces it.** No model output ever reaches a customer plan.

1. **Author (human, once):** the plan is assembled from a library of content BLOCKS (sliced largely from `content/` + `02`). Every block is human-written, source-checked, dated and individually **published** by an admin — the per-block publish gate is the successor to the old per-plan publish. Unpublished blocks cannot be selected by the assembler. `07`/`lib/plan-prompt.ts` may be used to DRAFT candidate blocks for human editing; never for delivery.
2. **Assemble (deterministic, instant):** on questionnaire submit, a rules engine — no LLM at runtime — maps answers → six exposure bands → top-3 actions → selects and sequences published blocks, deep-linking the library (age band `/library/age/[band]`, a guide per ticked platform, playbooks per flagged gap). A "Don't know" answer never raises a band — it becomes a "find this out" action. Every assembly writes an **assembly log** (block IDs + versions + rule trace) sufficient to reconstruct any delivered plan; this log is also the CAP-code substantiation record for "editor-written" claims.
3. **The crisis-signpost block is a LOCKED CONSTANT** (`lib/signpost.ts`): hash-verified at build (test suite) and at delivery (`verifySignpost()`); any change requires manual re-verification against `03`/`84`/`68` and an updated pinned hash in the same commit.
4. **Deliver (instant):** render to `/library/start` + PDF → delivery email → set `status='delivered'`, emit `plan_delivered`, schedule the feedback email (+3d) and the renewal nudge at month 11. `plans.status` RETAINS the `in_review` state as a dormant socket so a paid human-review tier can bolt on later without rebuild.

**Hard rule (rewritten):** no block may be selectable by the assembler without an admin per-block publish; the signpost constant must pass hash verification at build and delivery; no LLM output in any delivery path. **Gate:** the block library and assembly rules require a professional safeguarding review before first sale — it replaces, and must be at least as strict as, the review the old per-plan gate provided.

### 7.6 Content library (`/library/**`)
- Author each content file as **MDX** with frontmatter: `title, type[platform|playbook|ageband|conversation|module|currency], ageBands[], platforms[], topics[], updatedAt, sources[]`.
- Ingest: `16` → 10 platform guides; `18` → 12 playbooks + 3 modules; `19` → 5 age-band packs; `17` → conversation library + "what not to say" card; `20` → `/library/whats-changing`. `02` informs the plan template.
- **Navigation spine = age band** (`19`): the hub surfaces the buyer's band first, everything else one tap away. Cross-link playbooks ↔ platform settings ↔ conversation scripts (the "do it this weekend" bundle).
- Gate all `/library/**` behind `hasLibraryAccess`. Show a "last updated / what's changed" stamp (currency = the premium signal).

### 7.7 Emergency signpost (`/emergency`)
Render `03_Emergency_Signpost_Screen.html` as a route. **Ungated, no nav upsell, no tracking beyond a plain pageview.** Linked in global footer and from every plan/library page. Numbers/links must match `03`; add a build test that the page is reachable when logged out.

### 7.8 Email lifecycle
Templates from `08` (adapted: the old "£7/mo Plan invite" becomes "explore your library / your membership year is included", and a **month-11 renewal** offer for Stay Current). Triggers:

| Trigger (event) | Email |
|---|---|
| purchase | confirmation + magic link + questionnaire link |
| questionnaire not submitted +48h | nudge |
| plan published | delivery (PDF) |
| plan_delivered +3d | feedback request → `/feedback` (writes `feedback`) |
| plan_delivered +7d (non-member context) | library onboarding |
| updates_until −30d (month 11) | Stay Current renewal offer |
| refund | refund confirmation |
| inbound message detected as live incident | **manual holding reply** (`08`) — never automate incident advice |
| monthly | briefing to "current" users (§7.9) |

Implement scheduled triggers with Vercel Cron scanning for due events.

### 7.9 Membership & monthly briefings
Stay Current = the `subscriptions` table + Stripe. A user is "current" if within 12 months of a System purchase **or** has an active sub. **Briefing composer in `/admin`:** pick a topic from the backlog in `20`, draft (structure from `20`), preview, send to all "current" users; record in `briefings`, emit nothing PII. Setting-change alerts reuse the same sender. Do not automate sending until manual sends prove opens/actions (tracker `12`).

### 7.10 Family-agreement builder (`/library/family-agreement`)
Interactive: choose age band → tick suggested clauses (clause menus per band from `19`/`09`) → optionally edit → **generate a printable PDF** "Our Family Online Agreement" (template in `09` §G). Pure client-side + PDF render; stores nothing about the child.

### 7.11 Admin (`/admin`, admin-gated)
Minimal internal tooling: (a) **fulfilment queue** of paid questionnaires and plan drafts with the review/edit/publish flow (§7.5); (b) **briefing composer/sender** (§7.9); (c) **concierge bookings** list for Concierge buyers; (d) a **funnel snapshot** (§7.12). No fancy CMS.

### 7.12 Analytics & funnel
Plausible for traffic; the `events` table for the funnel in `12`/`00` §6: visitor → email → paid → questionnaire → plan delivered → membership → renewal, plus refund and feedback. Expose a read-only `/admin` dashboard or export CSV to feed the `12` tracker. Track the decision-gate metrics in `00` §7.

---

## 8. Content-ingestion map (where each file goes)

| File | Becomes / used in |
|---|---|
| `00` execution plan + go/no-go | Source of guardrails (§2), gates/metrics (§7.12) — not user-facing |
| `01` report system | `/questionnaire` questions + plan template (§7.4/7.5) |
| `02` sample report | `/sample` page + plan reference design |
| `03` signpost (.md/.html) | `/emergency` route (§7.7) |
| `04` landing page (.html) | `/` marketing site (§7.1) |
| `05` privacy & data notice | `/privacy` + data model/retention rules (§6) |
| `06` threat & naming reference | Internal sourcing for playbooks; brand shortlist |
| `07` report-generation prompt | Plan draft engine (§7.5) |
| `08` email templates | Email lifecycle (§7.8) |
| `09` Planner month-1 content | Family-agreement template + early member content |
| `10` free quiz (.html) | `/quiz` (§7.2) |
| `11` feedback form | `/feedback` (§7.8) |
| `12` funnel tracker (.xlsx) | Funnel/metrics target shape (§7.12) |
| `13` school/PTA pack | `/for-schools` (§5.2) |
| `14` positioning/pricing/model | Pricing & messaging (§7.1/7.3) |
| `15` architecture blueprint | This product's structure |
| `16` platform settings library | `/library/platforms/*` (§7.6) |
| `17` conversation library | `/library/conversations` (§7.6) |
| `18` threat playbook library | `/library/playbooks/*` (§7.6) |
| `19` age-band packs | `/library/age/*` — the nav spine (§7.6) |
| `20` currency layer | `/library/whats-changing` + briefings (§7.9) |

---

## 9. Compliance implementation checklist (code-level)
- [ ] 18+/parent consent checkbox at checkout/signup; store with purchase.
- [ ] No child-identifiable fields anywhere; server-side validation rejects them.
- [ ] 30-day purge cron for questionnaire working data + optional first name.
- [ ] Separate marketing-consent opt-in (PECR); transactional email always allowed.
- [ ] `/privacy` (from `05`) + `/terms` (solicitor-reviewed placeholder) live and linked.
- [ ] Data-subject-request route (`/api/dsr`): email-triggered access/erasure.
- [ ] Cookieless analytics (Plausible) → no analytics cookie banner; if any non-essential cookie is added later, add consent.
- [ ] Stripe handles all card data (no PAN touches the app).
- [ ] `/emergency` reachable logged-out; no upsell; no extra tracking.
- [ ] Content lint passes (no banned efficacy/fear phrases) in CI.
- [ ] Ops (not code): ICO data-protection fee paid (~£52), HMRC registration, solicitor sign-off on marketing copy + disclaimer + ToS before launch (`00` §10).

---

## 10. Environment, setup & tests

### 10.1 Env vars
`DATABASE_URL`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_PRICE_SYSTEM`, `STRIPE_PRICE_SYSTEM_FOUNDING`, `STRIPE_PRICE_MEMBERSHIP`, `RESEND_API_KEY`, `AUTH_SECRET`, `PLAUSIBLE_DOMAIN`, `ADMIN_EMAILS`, `APP_URL`.

### 10.2 Setup steps
1. Scaffold Next.js + Tailwind; add design tokens (§5.1). 2. Provision Postgres; run schema (§6). 3. Create Stripe products/prices/webhook. 4. Configure Resend domain + magic-link. 5. Convert `16`–`20` to MDX with frontmatter; seed. 6. Wire Plausible.

### 10.3 Automated guardrail tests (CI — must pass)
- **Content lint (negation-aware — a naive `grep` is NOT sufficient):** Scan all seeded MDX + rendered page copy for the banned patterns below. A match is a **violation** and fails the build **unless** it is negated/disclaimed or explicitly allow-listed. This nuance is mandatory: the required "what this isn't" disclaimers legitimately contain these substrings (e.g. `04`/`10`: "…or a guarantee of safety"; `04` footer: "it does **not** monitor children or guarantee safety"; `02`: "it does **not** monitor your child") and must NOT fail CI — a line-level `grep` would false-fail on the very copy the guardrails require.
  - **Banned patterns (case-insensitive):** `keeps? (your|them) safe` · `guarantee.{0,12}saf` · `child-safe by design` · `fully compliant` · `prevents? (grooming|harm|sextortion)` · `never worry again` · `\bcoach(ing)?\b`.
  - **Negation/disclaimer exemption:** a match is exempt if, within the **same sentence** and *before* the match, there is a negation marker — `\b(no|not|never|without|cannot|can't|won't|don't|doesn't|isn't|aren't|nor)\b` or an `n't` contraction — or it sits under a "what this is**n't** / what we do **not** do" disclaimer block. Implement by sentence-splitting and testing the text preceding each match, not by line-grep.
  - **Allow-list:** a checked-in `content-lint.allow.json` (file path + matched phrase + reason) for the handful of legitimate disclaimer lines, and for `coach` used as the **age-band parenting-posture** term (co-use → co-pilot → coach → consult) in `type: ageband` MDX only. `coaching` as **membership/service** framing is never exempt (guardrail §2).
  - **Behaviour:** fail the build, printing `file:line` + matched phrase + reason, on any non-negated, non-allow-listed match. On the **current** content this lint PASSES (verified); a naive grep would FALSE-FAIL on `02`/`04`/`10` disclaimers and the `15`/`19` posture term — closing that gap is the point of this spec.
- **No-child-PII test:** assert questionnaire/quiz schemas contain no `child_name|dob|school|screenshot` fields; server rejects such payloads.
- **Gating tests:** `/library/**` → 302/403 when logged-out or unpurchased; `/emergency` → 200 logged-out.
- **Plan-safety test:** no code path sets `plans.status='delivered'` without an admin publish call.
- **Stripe webhook test:** signed `checkout.session.completed` grants access and sends the magic link.

### 10.4 Manual pre-launch checks
Live £-purchase + refund; magic-link round-trip; a full draft→review→publish→delivery of one plan; every signpost number/link re-verified; retention cron dry-run.

---

## 11. Build sequence (milestones — each shippable)

- **M1 — Shell & top-of-funnel.** Next.js scaffold, design tokens, `/`, `/how-it-works`, `/pricing`, `/sample`, `/for-schools`, `/privacy`, `/terms`, `/emergency` (ungated), `/quiz` (full logic), Plausible + `events`. *Done:* a visitor can take the quiz and reach the emergency page; analytics fire.
- **M2 — Pay & gate.** Stripe System checkout + webhook, magic-link auth, `hasLibraryAccess`, library shell, MDX ingestion of `16`–`20`, age-band navigation. *Done:* a test purchase unlocks the full library.
- **M3 — Diagnose & deliver.** `/questionnaire` (PII-safe), plan draft via `07`, `/admin` review/publish, plan PDF, delivery + confirmation + nudge + feedback emails. *Done:* buy → questionnaire → admin publishes → customer gets a personalised plan linking into the library.
- **M4 — Retain & expand.** Stay Current subscription + Customer Portal, briefing composer/sender, month-11 renewal email, family-agreement builder, the Concierge tier + concierge booking. *Done:* a member receives a monthly briefing; the agreement builder outputs a PDF.
- **M5 — Instrument & harden.** Admin funnel dashboard/export, DSR route, retention cron, full guardrail CI suite (§10.3), accessibility + responsive pass, compliance checklist (§9). *Done:* all CI guardrail tests green; funnel matches `12`.

---

## 12. Acceptance criteria (definition of done)

1. A visitor can complete the quiz and get a calm snapshot; the result and email capture are recorded.
2. A parent can buy the System (test + live), receives a magic link, and lands in a gated library navigable by their child's age band.
3. The questionnaire collects **no** child-identifiable data and the build proves it (test).
4. A personalised plan **cannot** be delivered without an admin publishing it; once published it renders on `/library/start`, as a PDF, and by email, and deep-links to the right age band/platforms/playbooks.
5. `/emergency` is reachable logged-out, has no upsell, and every number/link matches `03`.
6. The content lint passes — no banned efficacy/fear phrases; no "coaching" framing.
7. Stay Current bills annually; "current" entitlement and the month-11 renewal email work; a member receives a briefing.
8. The family-agreement builder outputs a printable PDF and stores nothing about the child.
9. Retention purge nulls the optional first name + working data at +30 days.
10. The funnel events populate and reconcile with the `12` tracker's metrics.

---

## 13. Source-of-truth index (the canon)

Files in this repo the agent must read. **Content files are authoritative for copy; this spec is authoritative for behaviour.**

`00` execution plan + regulatory go/no-go · `01` readiness report system · `02` sample report · `03` emergency signpost (.md/.html) · `04` landing page (.html) · `05` privacy & data notice · `06` threat & naming reference · `07` report-generation prompt · `08` email templates · `09` Planner month-1 content · `10` free quiz (.html) · `11` feedback form · `12` funnel tracker (.xlsx) · `13` school/PTA pack · `14` positioning/pricing/model · `15` architecture blueprint · `16` platform settings library · `17` conversation library · `18` threat playbook library · `19` age-band packs · `20` currency layer · **`21` this build spec.**

---

## 14. Open decisions for the founder (don't block M1–M2 on these)
- **Final price point** — launch ladder is £99/£79 core · **Concierge from £650 (scoped invoice)** · £59-yr (`26`, supersedes `14`); core test band £79–£149. Set the Stripe prices before M2.
- **Brand name + domain** — pick from `06` shortlist; needed for deploy, not for local build.
- **Solicitor sign-off** — marketing copy, disclaimer, ToS, and a final OSA-scope confirmation before going live (`00` §10). Not a code blocker; a launch blocker.
- **Plan delivery: web-only vs web+PDF** — spec assumes both; drop PDF for M3 speed if needed.
