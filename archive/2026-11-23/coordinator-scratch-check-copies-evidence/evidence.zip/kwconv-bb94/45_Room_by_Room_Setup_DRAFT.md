# Room-by-Room Home Setup (DRAFT)

> These are unreviewed first drafts produced 2026-06-21. Every setting path, figure and link is marked for fact-check before publishing.


---

## Room-by-Room Home Setup Walkthrough

**DRAFT — fact-check every setting path, figure and link against the live source before publishing.**

Last drafted: 2026-06

The app-by-app guides cover the phone in your teen's pocket. This one covers everything else — the kit that sits in the rooms of your home and connects to the internet throughout the day. The router in the hall cupboard. The tablet the younger ones share. The console in the lounge. The smart TV. The speaker on the kitchen counter. None of these have a "parent" their app guide tells you to set up, so they tend to get missed. This is a calm walk through the house, room by room, so the shared infrastructure is set the way you'd choose rather than the way it came out of the box.

A note before you start, the same one that runs through the Platform Settings Library: **menus move.** Manufacturers rename and relocate settings often, and home kit varies enormously by make, model and the network you're on. Where a path below doesn't match your screen, search the setting name in the device's app or menu, or use the official help link. Treat every specific path here as **[verify]** until you've checked it against your own device — that is exactly what the fact-check pass is for. None of these settings is a guarantee; they reduce the obvious gaps and give you sensible defaults, and they work best alongside the conversations, not instead of them.

**Do this in roughly this order** (most leverage first): the **router** governs the whole house at the network level, so start there → then the **shared tablet** (the device most likely to be handed round) → then **console**, **smart TV** and **smart speaker**, which you can do in any order as you move through the house.

---

## The hall cupboard — your router and home broadband

**What it is.** Your router is the one device every other device talks to. Controls set here apply to the whole network — phones, tablets, consoles, the lot — which makes it the natural backstop when an individual app's controls get bypassed (for example, a child using a mobile browser instead of an app).

**Two layers live here, and it helps to know which is which:**

- **Network-level filtering from your broadband provider.** Most UK providers offer free, account-level parental controls and family filters you switch on in your online account or their app — Sky Broadband Shield, BT Parental Controls / Family app, TalkTalk HomeSafe, Virgin Media Web Safe and similar. These are **on or off at the account level**, offered by all the major providers and set at the account level, under the broadband filtering commitments. `[verify which providers, exact product names and whether on by default]`
- **Controls in the router itself.** Many routers (and mesh systems like Google Nest Wifi, Amazon eero, BT's Smart Hub/Complete Wi-Fi) have their own app with per-device pause, schedules and category filters. Look in the router's app for a section named something like *Family*, *Parental controls*, *Profiles* or *Devices*. `[verify section names per major router]`

**Worth setting:**
- **SafeSearch enforcement, network-wide.** The single most useful router-level setting is forcing SafeSearch on for the whole network so explicit results are filtered in Google and Bing regardless of device. Some providers and routers do this for you; some need a public DNS service that enforces it (for example a family-filtering DNS). Look for a *SafeSearch* or *Safe browsing* toggle, or a DNS / family-filter setting. `[verify exact mechanism — provider toggle vs DNS]`
- **A bedtime / downtime schedule** that pauses internet to chosen devices overnight. Catches the "device in the bedroom at 1am" pattern without you policing it nightly.
- **A device profile per child** if your router app supports it, so a phone, tablet and console can be grouped and paused together.
- **The router admin password.** Change it from the default printed on the sticker, and don't reuse the Wi-Fi password for the admin login — otherwise older children can simply log in and switch everything off. `[verify]`

**The honest limits.** Network filtering only applies on your home Wi-Fi — it does nothing when a phone is on mobile data or on a friend's Wi-Fi. A VPN, or DNS changed on the device itself, can route around it. This is why the device layer (Apple Screen Time or Google Family Link, in the Platform Settings Library) matters too: the router is the floor, not the ceiling. Ofcom and Internet Matters both frame network filters as one layer among several rather than a complete answer.

> **Why SafeSearch is the priority here.** Google's own guidance describes three SafeSearch states — *Filter*, *Blur* and *Off* — and notes that when it's locked at the network or account level a child can't simply switch it off. Locking it for the whole house means it holds on the shared tablet and the smart TV browser too, not just one phone. `[verify Google's current SafeSearch state names]`

---

## The kitchen table — the shared family tablet

**What it is.** The device most likely to be picked up by a five-year-old and a fifteen-year-old on the same afternoon. The single most useful idea for a shared tablet is to stop treating it as one device for everyone and give it **separate profiles or a child mode**, so the controls match whoever is holding it.

**On an iPad (Apple).** A shared iPad doesn't have full multi-user profiles, so the realistic options are:
- **A child's Apple Account in Family Sharing** plus **Screen Time** locked with a passcode the child doesn't know — the full setup is in the Platform Settings Library, section 1. `[verify]`
- **Guided Access** for a young child using one app at a time: it locks the iPad to a single app until you enter a passcode. Look in *Settings → Accessibility → Guided Access*. Useful for handing a toddler a drawing app without them wandering off into the browser. `[verify path]`
- **Content & Privacy Restrictions** to set the web-content level and require approval for installs and purchases. `[verify]`

**On an Android tablet.** Android handles shared tablets more directly:
- **A child's supervised Google Account with Family Link** (Platform Settings Library, section 2) for app approval, content filters and screen time. `[verify]`
- **A restricted profile or kids space** — many Android tablets offer a separate space for a child with its own approved apps and limits, sometimes branded *Kids Space* or a *restricted user*. Look in *Settings → Users* or for a *Kids* mode. `[verify availability varies by maker]`

**On an Amazon Fire tablet.** Fire tablets have **Amazon Kids / Amazon Kids+** built in: per-child profiles, age filters, time limits and a curated content library, managed from the *Parent Dashboard*. If a Fire tablet is the family device, setting up a child profile here is the main job. `[verify product names and dashboard location]`

**Worth doing on any shared tablet:**
- **Set the home web browser's SafeSearch / safe-browsing** even if the router enforces it, as a belt-and-braces second layer.
- **Require a password or approval for app installs and in-app purchases** — accidental and not-so-accidental spending on a shared tablet is one of the most common parent complaints.
- **Decide where the tablet sleeps.** A shared device that lives in a kitchen drawer or on the kitchen counter overnight is a quieter decision than one that migrates to a bedroom.

---

## The lounge — the games console

**What it is.** Modern consoles (PlayStation, Xbox, Nintendo Switch) all have a proper family/parental system, usually managed from a **phone app** rather than the console itself. The console is often shared, so as with the tablet the goal is a **child account** with its own limits, not one adult account everyone uses.

**PlayStation (Family Management).** Create a **family** with you as family manager, add a child account, and manage from the *PlayStation App* or account website: play-time limits and schedules, age-level for games and apps, communication and user-generated-content settings, and a monthly spending limit. `[verify current menu names — PlayStation 5 family settings]`

**Xbox (Family Settings app).** The **Xbox Family Settings app** manages a child's account: screen time across Xbox and Windows, age-appropriate content filters, who they can communicate and share with, and spending approval. `[verify app name and feature list]`

**Nintendo Switch (Parental Controls app).** The **Nintendo Switch Parental Controls app** links to the console over the internet: daily play-time limits with an optional auto-suspend, software age restrictions, and controls over posting screenshots and social features. `[verify app name and features]`

**Worth setting on any console:**
- **Age level for games.** This filters by PEGI rating, the UK's statutory games age-rating system, administered by the Games Rating Authority (GRA), formerly the Video Standards Council. Setting it to match your child's age stops 18-rated titles launching on a child account. Internet Matters and the GRA / PEGI both explain how the ratings map to ages. `[verify PEGI as the UK system reference]`
- **Communication and voice/text chat** — decide whether they can chat with everyone, friends only, or no one. Open chat with strangers is the part of console gaming most worth a deliberate choice.
- **Spending controls** — require approval for purchases and set a limit; in-game and add-on spending is a recurring surprise on a shared console.
- **Play-time limits and a schedule**, set from the app so they apply even when you're not in the room.
- **In-game platforms have their own controls on top of the console's.** Roblox in particular sits inside its own account, separate from the console family settings. From April–June 2026 Roblox introduced age-based account types — *Roblox Kids* (5–8) and *Roblox Select* (9–15) — with age estimation and expanded parental controls through age 15, so it's worth setting Roblox's own age and parental controls as well as the console's. `[verify against 2026 Roblox controls]`

**The honest limit.** Console controls govern the console account, not a child logging in under an adult profile or on a second device. Keep the adult account password to yourself, and lean on the router schedule for the overnight backstop.

---

## The lounge — the smart TV and streaming sticks

**What it is.** A smart TV and the sticks plugged into it (Fire TV, Roku, Apple TV, Chromecast/Google TV, Sky) are really several things at once: a set of **streaming apps**, an **app store**, and often a **web browser**. Each layer has its own controls, and they don't talk to each other — a PIN on the TV doesn't set one inside Netflix.

**The TV / streaming device itself.** Look in *Settings* for *Parental controls*, *Restrictions* or a *PIN* option to:
- **Lock the app store** so new apps need a PIN to install.
- **Restrict by content rating** at the device level where supported.
- **Set up a kids profile or mode** if the platform offers one (Fire TV, Google TV and Apple TV all have kid-oriented profiles or restrictions). `[verify per platform]`

**Inside each streaming app — this is the bit most often missed.** Netflix, Disney+, Amazon Prime Video, YouTube and the UK broadcasters (BBC iPlayer, ITVX, Channel 4) each have **their own profiles, maturity levels and PINs**, set inside that app or its website, not on the TV:
- **Create a Kids profile** in each service your family uses, and set the **maturity rating** on each child or general profile.
- **Set a profile lock / PIN** on adult profiles so a child can't switch into unrestricted content with the remote.
- **Check autoplay** and the "continue watching" rows, which can surface content from an adult's viewing onto a shared screen.

For YouTube on the TV, the realistic controls are the same as elsewhere — **YouTube Kids** for under-13s, or a supervised account — as set out in the Platform Settings Library, section 10.

**Worth doing:**
- **One profile per child** in each streaming service, with the maturity level matched to their age, rather than everyone sharing the main profile.
- **A device PIN on the app store and on adult streaming profiles**, so the controls can't be undone with the remote in thirty seconds.

---

## The kitchen counter — the smart speaker and voice assistant

**What it is.** An Alexa, Google Assistant or Siri/HomePod device is a microphone, a music player, a shopping channel and a web-answers machine that anyone in the room can use by speaking. The two things worth setting are **what it will play or answer for a child** and **whether it can spend money**.

**Amazon Alexa / Echo.** In the **Alexa app**, look for the *Parental controls* / *Voice* settings and **Amazon Kids on Alexa** (sometimes *Amazon Kids+*):
- **Explicit-content / explicit-language filter** for music. `[verify path]`
- **A child profile or Amazon Kids** so answers and content are age-appropriate, with optional time limits / a "do not disturb" overnight. `[verify]`
- **Voice purchasing** — turn it off or require a confirmation code so a child can't order by voice. `[verify path]`

**Google Assistant / Nest speakers.** Managed through **Family Link** and the **Google Home** app:
- **A child's voice profile** and the family-friendly content / filters settings. `[verify]`
- **Filters for music, video and news** via Family Link's content controls. `[verify]`
- **Block or confirm purchases** by voice. `[verify]`

**Apple HomePod / Siri.** Siri's responses follow the device's **Screen Time / Content & Privacy Restrictions** — including explicit-language filtering and web-content limits set there. There's no separate "Siri parental controls" panel; it inherits the device's settings. `[verify]`

**Worth doing on any smart speaker:**
- **Turn off or lock voice purchasing.** This is the setting most likely to cause a surprise.
- **Set the explicit-content / language filter** so song lyrics and answers are age-appropriate when the kids are in the room.
- **Know the mute button.** Every smart speaker has a physical microphone mute. It's a simple, visible way to switch listening off — useful to know it's there and where it is.

---

## A ten-minute walk-round (the recap)

A short circuit of the house, in order:

1. **Hall cupboard / router** — provider family filter on; SafeSearch enforced network-wide; overnight schedule set; admin password changed. `[verify]`
2. **Shared tablet** — separate child profile or kids mode; installs and purchases need approval; SafeSearch on in the browser.
3. **Console** — child account created; PEGI age level set; chat and spending decided; play-time schedule on. `[verify]`
4. **Smart TV** — device PIN on the app store and adult profiles; a kids profile and maturity level inside each streaming app.
5. **Smart speaker** — voice purchasing off or locked; explicit-content filter on.

**Then leave it for a term.** Like the app settings, home kit changes with firmware updates and new features, so a short re-check each school term keeps it current. The two things that quietly undo a home setup are an unchanged admin/account password (so the controls can be switched off) and a device that migrates into a bedroom overnight — both are worth a glance when you do the round.

**If something has already gone wrong** — a worrying message, contact or image involving your child — this walkthrough is not the place for it. In an emergency, or if a child is in immediate danger, call **999**. You can report online child sexual abuse or grooming to **CEOP** (the National Crime Agency's Child Exploitation and Online Protection command) at ceop.police.uk. To get a sexual image or video of an under-18 removed, use **Report Remove**, run by Childline and the Internet Watch Foundation. For advice, the **NSPCC helpline** is **0808 800 5000**, and children and young people can contact **Childline** free on **0800 1111**.

---

## Sources

- Ofcom — guidance and research on parental controls, network-level filtering and online safety: ofcom.org.uk `[verify specific page]`
- Internet Matters — broadband and home-network parental-controls guides, console, smart TV and smart speaker set-up guides: internetmatters.org `[verify specific guides]`
- NSPCC — online safety advice and the NSPCC Helpline (0808 800 5000): nspcc.org.uk `[verify]`
- CEOP Education / CEOP reporting (National Crime Agency): ceop.police.uk and ceopeducation.co.uk `[verify]`
- Internet Watch Foundation and Childline — Report Remove: iwf.org.uk and childline.org.uk/info-advice/bullying-abuse-safety/online-mobile-safety/remove-nude-image-shared-online `[verify URL]`
- gov.uk — broadband providers' family-filter commitments and Online Safety Act guidance: gov.uk `[verify specific page]`
- Apple — Screen Time, Guided Access and Content & Privacy Restrictions: support.apple.com `[verify]`
- Google — Family Link, SafeSearch states and Google TV / Nest controls: support.google.com `[verify]`
- Amazon — Amazon Kids on Alexa, Fire tablet Parent Dashboard and Fire TV restrictions: amazon.co.uk help pages `[verify]`
- Sony PlayStation, Microsoft Xbox and Nintendo — official family / parental-control pages: playstation.com, xbox.com, nintendo.co.uk `[verify]`
- PEGI / Games Rating Authority (GRA), formerly the Video Standards Council — UK statutory games age-rating system: pegi.info `[verify]`
- Streaming services' own help pages for profiles and maturity settings — Netflix, Disney+, Amazon Prime Video, BBC iPlayer, ITVX, Channel 4 `[verify each]`

*Items most likely to have moved since June 2026 and worth re-verifying: provider family-filter product names and whether they are on by default, the exact SafeSearch enforcement mechanism (provider toggle vs DNS), console family-app names and menu paths, per-platform smart-TV kids-profile availability, and the smart-speaker voice-purchasing and content-filter paths.*
