# Platform Quick-Reference Cards (System library)

**Updated 20 Jun 2026 — corrected against review `31`, verified vs `16`, and re-aligned after an assembly mismatch (each card matched to its platform by content). Printable one-pagers; fill `[DATE]`.**

---

## Apple Screen Time (iPhone/iPad)

**[BRAND]** · Settings library · Updated [DATE]

---

**What it is:** Device-level control for iPhone/iPad, set up through Family Sharing. It governs every app, install and website on the device at once — which is why it's the first thing to set, before any individual app. For a child under 18, Communication Safety and web-content limits are **on by default**, so some of this may already be working.

**What it can and can't do:**
- It gives you genuine *controls* — limits, blocks, approvals — not just a dashboard.
- Communication Safety blurs nude images on-device with guidance; **Apple can't see the photos**, and this is not message-reading or monitoring *(current behaviour as of [DATE] — check the official help link)*.
- It won't catch everything, and it isn't a substitute for talking — treat it as one layer, not a guarantee.

---

**The settings that matter most** *(Settings → Screen Time → your child's name; paths may have moved — search the setting name or use the official help link):*

- **Lock Screen Time with a passcode** your child doesn't know — *Settings → Screen Time*. Do this first, or every other setting can simply be switched off.
- **Downtime** — *Screen Time → Downtime*. Hours when only allowed apps and calls work (overnight, homework).
- **App Limits** — *Screen Time → App Limits*. Daily limits by category (e.g. Social) or a single app.
- **Content & Privacy Restrictions** — *Screen Time → Content & Privacy Restrictions*. Block age-inappropriate web/apps/music, and **lock "Share My Location"** so it can't be changed.
- **Communication Limits** — *Screen Time → Communication Limits*. Who your child can contact during allowed time and downtime.
- **Communication Safety** — on by default under 18. Confirm it's on.
- **Ask to Buy** — your approval required for purchases and downloads.

**Age:** Under-13s use a parent-created Child Apple Account. 13–17s can have their own account you manage via Screen Time.

**2025–26:** Your child can request more time and you approve it from your phone. Apple has also signalled new age-range / age-assurance features in recent iOS updates; the exact UK behaviour is still settling, so check the official help link for what's live on your device.

---

**If something's wrong:** immediate danger — **999**. A nude image of your child has been shared or is being threatened — **Childline Report Remove** (to get an image taken down): 0800 1111 · childline.org.uk/remove. Someone is pressuring your child for images or sextorting them — **CEOP**: ceop.police.uk. Full list: **[BRAND]/emergency**. For a worry about content or contact, see **/library/playbooks/** for the relevant threat.

**Talk about it too:** **/library/conversations** · Full guide: **/library/platforms/apple-screen-time**

**Official help:** support.apple.com/en-us/108806

---

## Google Family Link (Android/Chromebook)

**[BRAND] Quick-Reference Card — Google Family Link (Android / Chromebook)** · Updated [DATE]

**What it is.** A device-level control app for your child's *supervised* Google Account. Because it sits at the device layer, it governs every app, install and website at once — set this one first, before any individual social app. *Haven't created the supervised account or linked the device yet? Start there — the official help link below and our full guide walk you through it.* Source: settings guide → `/library/platforms/google-family-link`.

**What it can and can't do.**
- *Can:* set screen-time limits and schedules, approve or block apps, filter content (SafeSearch, Chrome, Google Play maturity, YouTube), approve contacts (Android) and require approval for Play Store purchases.
- *Can't:* read your child's messages. Family Link is genuine *controls* (blocks, limits, approvals) — not a message-reader, and it does not detect or monitor what's said. No tool, including this one, can guarantee your child's safety; it reduces risk and gives you sensible defaults.

**The settings worth your time** *(menus may have moved — search the setting name in-app or use the official link below)*
- **Daily limits & schedules** — *Screen time* tab → time limits / weekly schedule.
- **Downtime / bedtime & School time** — *Screen time* tab → set quiet hours; School time should now work on phones and tablets, not just Chromebooks — if you don't see it on your device, check the official help link.
- **App management** — *Controls* tab → approve/block apps, per-app limits; mark educational apps as unlimited.
- **Content filters** — *Controls* tab → SafeSearch, Chrome, Google Play maturity ratings, YouTube.
- **Approved contacts (Android)** — approve who your child can call or text (newer feature).
- **Purchase approval** — require your OK for the Play Store.
- **On a Chromebook** — the same supervised account carries these controls across to your child's Chromebook; manage them from the Family Link app or at *families.google.com*.

**Age, in plain English.** For under-13s, you create the supervised account (a credit-card consent check confirms you're the adult). At 13 your teen can take the account over — you can keep supervision running until they choose to remove it, at which point you're notified and the device briefly locks. Get the *real* date of birth right in the account: most protections key off it.

**One thing to talk about.** Agree the screen-time schedule together rather than imposing it — a short, calm conversation lands better than a silent change. Openers: `/library/conversations`.

**If something's wrong.** Worried about contact from strangers or risky content? See the relevant playbook at `/library/playbooks/*`. If a child may be at immediate risk, this card is not for live incidents — call **999**. For worries about contact, content or a distressed child: **Childline 0800 1111** (free, 24/7). Sextortion or an adult pressuring a child: **CEOP** (ceop.police.uk). Full list: **[BRAND]/emergency**.

**Official help:** support.google.com/families/answer/7101025 · Full guide: `/library/platforms/google-family-link`

---

## Snapchat

**[BRAND]** · Updated [DATE] · Settings: `/library/platforms/snapchat`

---

**What it is.** Snapchat's parent tool is **Family Centre** — you and your child both need accounts and both have to opt in. Minimum age is **13+** (self-declared with **no verification** — worth re-checking, as Snapchat's age handling is still changing), so the most useful thing you can do is make sure the birthday on the account is real. 13–17-year-olds get stricter defaults.

**What Family Centre can and can't see.**
- **Can:** their friends list, and *who* they've messaged or called in the last 7 days; set content restrictions; disable the My AI chatbot; share location as a family.
- **Can't:** read the *content* of messages. It shows you who, not what — it is not a message-reader and does not monitor on your behalf.

**The settings worth checking (highest value first).** The Family Centre setup below is done from your phone; the rest live in your **child's own Settings** on their device, not in your Family Centre dashboard — so set them up together.

- **Set up Family Centre** — Profile → ⚙️ Settings → *Privacy Controls* → **Family Centre** → select child → send invite. *Both accounts must opt in.*
- **Contact Me → Friends** — Settings → set to **Friends** (not "Friends and Contacts") so people who aren't friends can't message them.
- **Snap Map → Ghost Mode** — Map → ⚙️ → **Ghost Mode** — hides live location. Recommended on for under-18s.
- **View My Story → My Friends or Custom** — Settings — limits who can see their Story.
- **My AI** — Settings → clear My AI data / disable the chatbot. *Full removal needs Snapchat+.*
- **Two-Factor Authentication** — Settings → Two-Factor Authentication — protects the account login.

**What changed (Jan 2026).** A recent (Jan 2026) Family Centre update is rolling out daily **time-spent** (broken down by feature), **"trust signals"** on new friends, and an embedded **safety course** — check whether yours shows them yet, as this is still arriving for some accounts.

**One thing to talk about.** Why Ghost Mode and "Friends only" are reasonable, not a punishment. Conversation starters: `/library/conversations`.

**If something's wrong.** Unwanted contact, location, or shared-image concerns — see the relevant playbook at `/library/playbooks/*`. This is signpost-only, not a service. **Immediate danger: call 999.** A nude image of an under-18 shared or threatened: **Childline Report Remove — 0800 1111** (helps get images taken down). Sexual messages, pressure or sextortion from an adult: **report to CEOP** (ceop.police.uk). Full list: **[BRAND]/emergency**.

*Menus move — app makers rename and relocate settings often. If a path doesn't match your screen, search the setting name in the app. All paths checked June 2026.*
**Full guide:** `/library/platforms/snapchat` · **Official help:** parents.snapchat.com (UK: /en-GB/parental-controls)

---

## Instagram (Meta)

**[BRAND] Quick-Reference Card — Instagram (Meta)** · Updated [DATE]

**What it is + minimum age.** A photo/video and messaging app, **13+**. Under-18s are automatically placed into **Teen Accounts** with protective defaults switched on. Under-16s need your permission (through supervision) to loosen any of them — so much of the work is already done for you.

**What the controls can / can't see** (set expectations honestly):
- **Can:** show you *who* your teen messaged in the last 7 days (not the content), let you set time limits, and schedule "off" periods.
- **Can't:** read message content, and no setting can guarantee anything. Instagram's Family Centre is mostly an **activity view, not a message-reader** — treat it as one layer, alongside the conversation.

**The settings worth your time** (most of these are already on for Teen Accounts — your job is to confirm):
- **Set up supervision** — Settings → **Family Centre** → invite/accept *(may have moved — look for "Family Centre" or "Supervision")*. Unlocks the activity view, time limits and off-periods.
- **Verify the real birthday** — most protections key off age. Note: switching an account to 18+ triggers an **ID or face age check**.
- **Confirm the Teen-Account defaults** — private account · strictest messaging (only people they follow) · most-restrictive sensitive-content + Hidden Words · 60-minute time-limit nudge · **Sleep Mode** muting notifications 10pm–7am.
- **Under-16 locks** — can't go Live or turn off DM nudity-blur without your permission. Good to know these hold.
- **Limited Content (optional, stricter)** — removes comments and filters more mature material.

**2025–26 to know.** Meta uses **AI age-assurance** (live in the UK) and from **May 2026, AI visual age estimation** to move suspected-teen accounts into protections even when an adult birthday is listed.

**One thing to talk about.** Pair this with a conversation, not just a setting → **/library/conversations**.

**If something's wrong.** Unwanted contact or content → **/library/playbooks** (start with stranger-contact and sextortion). This is signpost-only — don't troubleshoot a live incident in-app:
- **Immediate danger:** call **999**.
- **A nude or sexual image of your child is out, or someone is threatening to share one (sextortion):** report to **CEOP** (ceop.police.uk) and, for under-18s, use **Childline Report Remove — 0800 1111** (childline.org.uk/remove) to get the image taken down.
- **Full list of routes:** **[BRAND]/emergency**.

**Full guide:** /library/platforms/instagram · **Official help:** help.instagram.com/995996839195964 · familycenter.meta.com

*Menus move. If a path looks different, the menu name is your anchor — and the official link above always has the current route. All paths checked [DATE].*

---

## TikTok

**Bearings Quick-Reference Card — TikTok** · Updated [DATE] · Settings: `/library/platforms/tiktok`

**What it is + minimum age.** A short-video and messaging app, **13+** (self-declared, no verification). TikTok's parent tool is **Family Pairing** — you link your own account to your teen's to manage screen time, content, search, direct messages and privacy from your phone. Because age is self-declared, the most useful thing you can do is make sure the real birthday is on the account: under-16s get stricter defaults, and TikTok now forces **suspected under-16 accounts to private**.

**What the controls can / can't do** (set expectations honestly):
- **Can:** show you *activity* and let you set limits — screen-time caps, scheduling, content/search restrictions, who can interact, and DM controls.
- **Can't:** show you message *content*. Family Pairing is an activity-and-limits view, not a message-reader, and no setting can guarantee anything. Worth knowing: a **second account or the mobile browser can sidestep pairing**, which is why the device layer (Apple Screen Time / Google Family Link) sits underneath it.

**The settings worth your time** *(menus may have moved — TikTok reorganises these often, so search the setting name in-app or use the official help link below):*
- **Enable Family Pairing** — Profile → ☰ → *Settings and privacy* → **Family Pairing** → scan the QR code on your teen's matching screen.
- **Screen-time limit** — defaults to about 60 min/day for 13–17; confirm on your screen and set shorter if you like. Finer screen-time and scheduling controls arrived in 2025–26.
- **Direct Messages** — **off by default for under-16s**; confirm it's off.
- **Private account** — default for under-16s; check it's on for older teens too (Settings → Privacy).
- **Restricted Mode / content preferences** — filters more mature content.
- **Who can interact** — comments, Duet/Stitch, mentions and "suggest your account."

**Keep it current.** TikTok changes menus and defaults often — a 10-minute re-check each school term is the habit.

**One thing to talk about.** Pair this with a conversation, not just a setting → **/library/conversations**.

**If something's wrong** (this is a printout — keep these to hand):
- **Immediate danger:** call **999**.
- **Your child is upset or worried, or you're not sure:** **Childline — 0800 1111** (free, under-19s, 24/7).
- **An adult is contacting, grooming or sextorting your child:** report to **CEOP** (ceop.police.uk).
- For unwanted contact or content, see **/library/playbooks/**. Full list of who to contact: **Bearings/emergency**.

**Full guide:** /library/platforms/tiktok · **Official help:** tiktok.com/safety

*Menus move. If a path looks different, the menu name is your anchor — and the official link above always has the current route. All paths checked [DATE].*

---

## Roblox

**[BRAND] Quick-Reference Card — Roblox Parental Controls** · Updated [DATE]

*A linked, PIN-protected control panel. You set up your own account, verify your age (ID or credit card), link to your child, then manage maturity, chat, screen time and spending from your phone.*

**Age handling (re-check this one — it changed a lot for 2026):**
- A **video-selfie facial age-estimation** is now required to use chat (global rollout from Jan 2026, still being rolled out). Roblox uses it to age-group chat so it can limit adult-to-minor contact.
- New account types are rolling out from June 2026: **Roblox Kids (5-8)** and **Roblox Select (9-15)** with curated games. Parental controls now extend to age 15.
- Confirm your child's account uses their **real date of birth** — almost every protection keys off it. (This is a setting on their own account; you never need to send us a date of birth.)

**What the controls can and can't do:**
- Roblox gives you **genuine controls** — blocks, limits and approvals — not just an activity feed.
- These settings reduce exposure and spending; they are not a guarantee, and they don't read or monitor your child's messages for you.

**The high-value settings** (Settings -> Parental Controls; *menus move — search the name in-app or use Official help below*):
- **Link + verify** — set up your account, verify your age, link to your child.
- **Content maturity level** — set the ceiling (Minimal / Mild / Moderate...).
- **Chat & connections** — disable text/voice chat, review connections, and block or approve individual games.
- **Screen-time** — set daily limits.
- **Spending limits** — set a monthly Robux cap and turn on notifications (unexpected in-game spending is a common surprise for families).

**One thing to talk about:** agree together which games are approved and what a fair monthly Robux cap is — see the conversation starters at **/library/conversations**.

**If something is wrong** (this is a printout — keep these to hand):
- **Immediate danger:** call **999**.
- **An adult contacting or grooming your child** (in chat, or pressuring them onto a private app): **CEOP** — ceop.police.uk/Safety-Centre (or 101; 999 if your child is at immediate risk).
- **Your child is upset or worried, or you're not sure:** **Childline 0800 1111** (free, under-19s).
- For unwanted contact or content, see **/library/playbooks/**. Full list of who to contact: **[BRAND]/emergency**.

Full settings guide: **/library/platforms/roblox**
Official help: about.roblox.com/parental-controls · about.roblox.com/age-estimation

---

## Discord

**[BRAND]** · Updated [DATE] · Full guide: `/library/platforms/discord`

**What it is.** A chat, voice and community app built around "servers." Minimum age **13+**. Discord's **Family Centre** is the parent-facing tool — it's opt-in on *both* sides (you and your teen link via QR code; one guardian can link up to 8 teens).

**What Family Centre can — and can't — show you.**
- It can: give you a **7-day activity feed and a weekly email** — new friends added, servers joined or created (names, icons, member counts), who your teen messaged or called, and total call minutes — **names and metadata only, never message content**. It does **not** show a purchases summary.
- It cannot: show you message *content*. It is an activity view for spotting patterns and starting conversations, not a message-reader and not a monitor.

**The settings worth your 10 minutes** (menus *may have moved* — if a label differs, look for the nearest match in User Settings / Family Centre):
- **Family Centre — set up** — mobile app → User Settings → **Family Centre** → enable → scan the teen's QR code. Once linked, **only you can change the controls below** — the teen can't.
- **Sensitive-content filter** — for UK teens, choose **blur or block** (the "show" option is removed by UK rule, so this part is already handled for you).
- **Friend requests** — restrict to friends-of-friends / server members.
- **Server DMs** — choose whether server members can direct-message your teen.
- **Message requests** — filters non-friends into a separate folder. *Changing this needs an age-verified adult in the UK.*
- **Data & privacy** — turn off personalised-data and sponsored-content personalisation.

**2025–26 change to know.** UK age checks (face scan or ID) arrived **July 2025**; accounts are treated as **"teen by default" until verified as an adult.** The verification flow has been changing — worth a quick re-check in-app.

**One thing to talk about.** Friend requests and DMs from people they don't know — agree together what they'll do. Conversation starters: `/library/conversations`.

**If something's wrong.** Unwanted contact or content → `/library/playbooks/`. This card is signpost-only, not a live-incident service. **Immediate danger: call 999.** A worry about contact, content, or a distressed child: **Childline — 0800 1111** (free, 24/7). Sexual messages, pressure or sextortion from an adult: **report to CEOP** (ceop.police.uk). Full list: **[BRAND]/emergency**.

**Official help:** support.discord.com (Family Centre article · UK age-assurance article).

---

## WhatsApp

**[BRAND] Quick-Reference Card: WhatsApp** — Updated [DATE]

**What it is**
A messaging app. There is **no parental dashboard for ages 13+** — control comes from three things together: the app's own privacy settings, your device layer (Apple Screen Time / Google Family Link), and conversation. A separate parent-managed account exists for **under-13s only**.

**What controls can — and can't — do**
- WhatsApp privacy settings can limit **who can contact, add, and see** your child (groups, last seen, profile photo, location).
- They **cannot let you read chats** — even on the under-13 parent-managed account, messages are end-to-end encrypted. This app does not give parents a window into message content.

**The settings worth your time** *(menus move — if a path doesn't match your screen, search the setting name in-app or use the official help link below)*

- **Groups → My Contacts** — Settings → Privacy → Groups. Stops strangers adding your child to group chats — this single change ends most "added by a stranger" surprises and is often the highest-value one here.
- **Last seen / Online, Profile photo, About → My Contacts or Nobody** — Settings → Privacy. Limits what people outside their contacts can see.
- **Two-step verification → On** — Settings → Account. Adds a PIN that makes the account much harder for someone else to hijack.
- **Live location → Off; check disappearing messages per chat** — Settings → Privacy, then review individual chats.
- **Blocking & reporting** — show your child how to block and report unknown numbers. Messages from unknown contacts can be filtered.

**Age**
UK minimum is **13** (lowered from 16 in April 2024 — the old "16" figure is outdated). It's **self-declared with no verification**, so the device layer and conversation matter more than the birthday on the account. *Under-13 account availability is still changing through 2025–26 — re-check in-app.*

**One thing to talk about**
Pick a starter from the conversation library → /library/conversations (e.g. "who's actually in your group chats?").

**If something's wrong** (this is a printout — keep these to hand)
- Strangers messaging, or pressure/scams in chat → see /library/playbooks/* for the matching playbook.
- **Immediate danger, or your child is being threatened right now:** call **999**. This card can't help with a live incident.
- **An adult pressuring your child for images, or sexual messages/sextortion:** report to **CEOP** (ceop.police.uk).
- **Your child is upset or worried, or you're not sure:** **Childline — 0800 1111** (free, 24/7).
- Full list of who to contact: **[BRAND]/emergency**.

Full guide: **/library/platforms/whatsapp** · Official help: **faq.whatsapp.com**

---

## Fortnite / Epic Games

**[BRAND]** · Updated **[DATE]** · Settings detail: `/library/platforms/fortnite`

**What it is + age.** Fortnite runs on an Epic Games account. Under-13s get a **Cabined Account**, which blocks chat, purchases and adding friends until a parent consents by email. The cabined threshold in the UK is under-13. Epic uses age-estimation in some flows (UK method not confirmed).

**What controls can / can't do (2 bullets).**
- Epic gives you genuine **controls** — a parent PIN, chat limits, purchase approval and a mature-language filter, set and locked behind a 6-digit PIN.
- Setting up parental controls is what **lifts the cabin** on an under-13 account — so it's worth doing deliberately, not by accident. This does not detect or monitor what your child does.

**The settings worth your time** *(everything below lives under **Settings → Parental Controls** — or sign into the child's account at the Epic Account Portal; menus move, so if a name doesn't match your screen, search it in-app or use the official help link below):*
- **Set up Parental Controls** — set a **6-digit PIN**. This is the master control everything else sits behind.
- **Voice & text chat** — choose who your child can chat with.
- **Require PIN for purchases** — stops one-tap spending; review spend here too.
- **Mature-language filter** — always on for under-13s in text chat; for older children, set it here.
- **Email reports** — opt in to Epic's email report when account settings change, so you get a heads-up. (Cadence and labels vary — confirm in-app.)

**What's already fine.** For under-13s the mature-language filter is always on in text chat, and under-13 accounts start cabined — so chat and spending are locked until you choose otherwise. You're confirming and tuning, not building from zero.

**One thing to talk about.** Agree together who it's OK to play and chat with, and the rule on spending real money. More openers: `/library/conversations`.

**If something's wrong.** Unwanted contact, bullying or pressure to spend? See the relevant playbook at `/library/playbooks/*`. This card is signpost-only, not a live-incident service. **Immediate danger: call 999.** A worry about contact, content, or a distressed child: **Childline — 0800 1111** (free, 24/7). Sexual messages, pressure or sextortion from an adult: **report to CEOP** (ceop.police.uk). Full list: **[BRAND]/emergency**.

**Official help:** safety.epicgames.com/en-US/parental-controls · epicgames.com/site/en-US/cabinedaccounts

---

## YouTube / YouTube Kids

**[BRAND] Platform Settings Library · Updated [DATE]**

**What it is.** Two tiers. **YouTube Kids** is a separate app for under-13s — curated, with age profiles. Main YouTube can be run as a **supervised account**, managed through the **in-app Family Centre** or **Google Family Link**. For most UK 13+ teens on standard YouTube, the realistic control is the **device layer** (Family Link or Apple Screen Time), so set that first.

**What you can / can't expect.**
- You *can* set a content level, switch off Autoplay, pause history, cap Shorts, and add break/bedtime reminders.
- These are controls and limits — not a guarantee, and not a way to read or monitor what your child watches. The device layer is the backstop that holds even when an app's own settings are bypassed.

**The settings worth your time** *(menus move — if a path doesn't match your screen, search the setting name or use the official help link below)*

- **Content level** — on a supervised main account, choose Explore (≈9+), Explore More (≈13+) or Most of YouTube. Match it to your child's age band. *(You can also reach this from Family Link → Controls → Content filters → YouTube.)*
- **Autoplay (off)** — turn it off so videos don't roll on endlessly into less-suitable content.
- **Watch & search history** — pause or clear it to calm what gets recommended next.
- **Shorts daily limit** — added March 2026, this can be set as low as zero. One of the most useful levers for the endless-scroll problem.
- **Take-a-break / bedtime reminders** — built-in nudges for healthier stretches and sleep.
- **In YouTube Kids** — set content level, turn search on/off, set a timer, or use approved-content-only mode for younger children.

**Age.** Main account is **13+**. Under-13s should use **YouTube Kids** or a **supervised account**.

**Keep it current.** YouTube's content tiers, the Shorts limit and age checks change often — a 10-minute re-check each school term is the habit.

**One thing to talk about.** Pick one watched channel and ask your child to show you why they like it. See [BRAND] /library/conversations for openers.

**If something's wrong** (this is a printout — keep these numbers to hand):
- **Immediate danger:** call **999**.
- **Your child is upset or worried by something they've seen, or you're not sure:** **Childline — 0800 1111** (free, under-19s, 24/7).
- **An adult is contacting, grooming or sextorting your child:** report to **CEOP** (ceop.police.uk/Safety-Centre).
- For recommendations drifting or limits ignored, see **/library/playbooks**. Full list of who to contact: **[BRAND]/emergency**.

**Full guide:** /library/platforms/youtube · **Official help:** support.google.com/youtube/answer/13877231 · YouTube Kids: support.google.com/youtubekids

---
