# AI Safety Course - Founding Pilot Asset Copy

*Created 2026-06-27. Status: draft copy for founding-pilot assets attached to `74_AI_Safety_Course_Founding_Pilot_Module_Scripts.md`. This is text-ready but not design-ready. It should be checked by AI legal/safeguarding reviewers before use with paying pilot customers.*

## Asset Boundary

These assets are for parent education and household planning. They do not assess a child, judge a live situation, monitor anyone, or promise outcomes. If something is already happening, stop the asset flow and use the emergency signpost. [RTE-007, GAP-001]

Do not enter child names, school names, account handles, screenshots, messages, images, prompts, schoolwork, or incident details into any course tool or worksheet. [PRI-003, PRI-004, GAP-013]

## Asset 1 - Four Habits Card

**Claim IDs:** HAW-001, HAW-002, PRI-002, VBT-001.

### Front

# Four AI Habits For Home

1. Think before use.
2. Tool, not person.
3. Private stays private.
4. Human check before trust or action.

### Back

**Think before use**  
What are we using this tool for, and do we need it?

**Tool, not person**  
AI can generate a response. It is not a private friend, therapist, judge, or secret-keeper.

**Private stays private**  
Names, school, location, account details, private messages, images, voice, family conflict, health, schoolwork, and live-incident details do not belong in casual AI use.

**Human check before trust or action**  
Before believing, sharing, buying, submitting, or acting, check source, evidence, date, and consequence.

## Asset 2 - Private Stays Private Card

**Claim IDs:** PRI-001, PRI-002, PRI-003, PRI-004.

### Front

# Private Stays Private

AI tools are not the place for private family or child information unless a parent/carer has checked the purpose, settings, terms, and need.

### Never Enter

- Child or family names.
- School, class, teacher, or club details.
- Home area, location, routines, or travel.
- Account details, passwords, codes, or payment details.
- Private messages or screenshots.
- Private images, videos, or voice.
- Health, family conflict, or emotional disclosures.
- Schoolwork with personal details.
- Anything about something already happening.

### Ask First

- New AI tools or accounts.
- Uploading any file or image.
- Friendship problems.
- Schoolwork.
- Anything about another person's private information.

### Back

Use made-up examples for practice. Real worries go to trusted people. Live concerns use the emergency signpost or qualified route.

## Asset 3 - Tool, Not Person Script

**Claim IDs:** AIC-001, AIC-002, AIC-003, AIC-005, HAW-002.

### Parent Script

> I can see why an AI tool can feel easy to talk to. I am not angry about that. But an AI tool is not a private person and it is not responsible for you. It can generate responses, but it does not care for you or understand you like a trusted person can.

> If something feels heavy, secret, upsetting, risky, or too big to carry alone, it comes to a trusted person. That can be me, another adult we choose, school, Childline, or another qualified route.

### Household Boundaries

- AI is not a private friend.
- AI is not a therapist.
- AI is not a judge.
- AI is not a secret-keeper.
- Emotional worries move to trusted people.
- Late-night or secret use is a prompt for a calm conversation, not a diagnosis.

### Conversation Openers

These are not a way to assess or diagnose a child. Use them only to start a calm conversation.

- "Have you found yourself using it when you feel upset?"
- "Does it ever feel easier to talk there than to a person?"
- "Are you using it late at night or keeping it secret?"
- "Would you know who to go to if it said something upsetting or risky?"
- "Has the tool ever encouraged isolation, threats, harmful content, sexualised interaction, or secrecy?"

If the content suggests immediate risk or harm, stop the tool flow and use a qualified route.

## Asset 4 - Verify Before Trust Sheet

**Claim IDs:** HCM-001, HCM-004, VBT-001, VBT-002, VBT-003, SCF-001.

### Front

# Verify Before Trust

Use this before believing, sharing, buying, submitting, or acting.

1. **Who says this?**  
Is there a real source, person, organisation, or original post?

2. **What evidence is there?**  
Can we open the source and check whether it says what the AI or message claims?

3. **How current is it?**  
Is the information recent enough for this decision?

4. **What happens if it is wrong?**  
Could it affect schoolwork, money, privacy, safety, reputation, or someone else?

### Back

**For schoolwork**  
School policy comes first. Try first, ask before assessed work, check sources, and do not submit hidden AI-authored work as your own.

**For money or codes**  
Urgency is a reason to slow down. Do not send codes, logins, gift cards, or money from inside the same message thread. Check through another trusted route.

**For images, audio, screenshots, or videos**  
Seeing or hearing something is not enough. Pause before forwarding. Check source and context. If it involves threats, coercion, sexual content, or immediate danger, use a qualified route.

This sheet supports a pause. It does not decide whether something is safe.

## Asset 5 - Schoolwork Ask-First Sheet

**Claim IDs:** ORW-001, ORW-003, VBT-002, GAP-010.

### Front

# Schoolwork Ask-First

The household rule:

1. Try first.
2. Ask before assessed work.
3. Check sources.
4. Do not submit hidden AI-authored work as your own.
5. School policy comes first.

### Back

**Usually lower concern**

- Asking AI to quiz you after you have tried.
- Asking for a simple explanation of a topic.
- Asking for practice questions.
- Using AI with a parent/carer for a made-up example.

**Ask school or teacher first**

- Coursework.
- Assessed work.
- Anything submitted for marks.
- Rewriting final answers.
- Using AI-generated citations, quotes, or sources.
- Any unclear school rule.

This course cannot decide what is allowed for a specific school, subject, exam, or assignment.

## Asset 6 - Family AI Safety Agreement Starter

**Claim IDs:** PRI-002, VBT-001, AIC-005, RTE-007.

### Heading

# Our Family AI Safety Agreement

We use this as a conversation tool. It is not a contract, monitoring system, or assessment.

### Starter Clauses

1. We think before using AI.
2. Private information stays out of AI tools unless a parent/carer has checked the purpose, settings, and need.
3. AI is a tool, not a person.
4. Worries, secrets, threats, or upsetting content move to trusted people.
5. Before we believe, share, buy, submit, or act, we check source, evidence, date, and consequence.
6. School policy comes first.
7. Unknown person plus secrecy, pressure, gifts, platform switching, threats, or sexualised contact means stop and show a trusted adult.
8. If something is already happening, we stop the course/tool and use the route.

### Review Line

We will review this agreement after new tools, school-policy changes, or a Stay Current update.

### Signatures

Young person: ______________________

Parent/carer: ______________________

Review date: ______________________

## Asset 7 - Pilot Boundary Card

**Claim IDs:** PRI-003, PRI-004, VBT-004, RTE-007, GAP-013.

### Front

# What This Course Does

- Helps parents set household AI rules.
- Helps families keep private information out of AI tools.
- Helps parents teach verification habits.
- Helps families decide when to stop and use qualified routes.

### Back

# What This Course Does Not Do

- It does not assess a child.
- It does not judge real messages, images, schoolwork, or incidents.
- It does not monitor anyone.
- It does not give legal, safeguarding, clinical, or crisis advice.
- It does not process child content or live-incident details.

Please do not send names, school details, screenshots, messages, images, account handles, or incident details.

If something is happening now, use the emergency signpost.

## Pilot Asset Checklist

Before use:

- Run AI legal review.
- Run AI safeguarding review.
- Patch blocker/high findings.
- Run content lint.
- Confirm no asset asks for child PII or live-incident detail.
- Keep the Routing Card out of the pilot pack unless separately reviewed.
