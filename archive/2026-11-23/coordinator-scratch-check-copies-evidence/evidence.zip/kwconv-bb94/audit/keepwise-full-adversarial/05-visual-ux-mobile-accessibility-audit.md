# Visual, UX, Mobile And Accessibility Audit

## Visual Verdict

The design problem is not "make it prettier." The page already has enough polish. The commercial problem is that the visual hierarchy does not consistently prioritise:

1. What happens next.
2. What the parent receives.
3. Why the advice is trustworthy.
4. What is excluded for safety/privacy reasons.

## Visual/UX Findings

| Element | Issue | Conversion / Trust Consequence | Specific Design / UX Fix | Priority |
|---|---|---|---|---|
| Hero brand wordmark | `Keepwise` is larger than the value proposition across skins. | Unknown brand gets more attention than parent outcome. | Reduce brand mark scale; let H1, CTA and product preview dominate. | H |
| Hero product preview | Strong asset, but competes with long copy and brand. | Parent may not immediately understand "this is what I get." | Add caption: "Example of your Control Centre after the check." Make sample artefact clickable/expandable. | H |
| Hero CTA pair | `Get the System` and `See the tools` are less precise than the actual journey. | Parent cannot infer next step. | Primary: `Start the safety check`; secondary: `Preview plan and tools`. | H |
| Hero proof cards | Good content but too feature-like. | Trust signals blend into feature cards. | Separate trust rail visually: review, privacy, no monitoring, evidence notes. | M |
| Mobile nav | Horizontal nav hides key action and creates overflow. | First-step CTA may be invisible on mobile. | Mobile header: logo + `Start safety check`; put rest in menu. | H |
| Mega menus | Rich on desktop, absent on mobile. | Desktop menus are useful but can overwhelm; mobile loses navigation. | Keep desktop mega but shorten labels; add mobile menu or section jump drawer. | M |
| Pricing cards | Tiers are clear but do not guide choice enough. | Choice overload and uncertain value. | Add "Best starting point" label to Household or System + AI Lab; add "Choose this if..." lines. | H |
| Pricing CTA | Buttons often link internally. | Feels like no purchase path exists. | Convert to actual intake/payment/enquiry path. If demo only, label as `Prototype: start flow`. | H |
| Evidence section | Good section but looks like informational content, not conversion proof. | Parent may miss it before deciding price. | Add one evidence card above pricing and link to full evidence lower down. | H |
| Boundaries section | Strong trust asset too low on page. | Safety-conscious parent may not see key limits before pricing. | Pull mini-boundaries into hero/pricing: prevention, no monitoring, no incident handling, minimal data. | H |
| Resource cards | Useful but links loop to page sections. | "Preview guide" without actual guide can disappoint. | Link to actual sample/download or change copy to `See sample section`. | M |
| School section | Has good content but no distinct school journey. | School/ PTA buyer needs their own next step. | Add dedicated school CTA: `Request school briefing pack` with sample outline. | M |
| Product screenshots | Mockups are CSS-based and helpful; hero background asset is abstract. | Premium parents trust artefacts more than abstract device imagery. | Replace or supplement hero background with real artefact composite. | M |
| Typography | A/B/C heavy sans headings can feel startup/SaaS; D serif can feel authoritative. | Tone mismatch affects premium trust. | Hybrid: D serif for big trust headings; A sans for UI/product surfaces. | M |
| Colour | C gradient is high-energy but less serious; B blue is school-SaaS; D burgundy/green is strongest trust. | Colour can cheapen or reassure. | Use D palette as default; reserve blue/gradient for functional UI or AI Lab accents. | M |
| Footer | Footer links are internal anchors in demo. | Trust issue for privacy/terms/customer support. | Add real Terms, Privacy, Contact, Emergency Signpost, Evidence pages. | H |

## Accessibility And Mobile Notes

Observed:
- A/B/C mobile at 390px showed slight horizontal overflow.
- A/B/C mobile nav hides the key CTA due horizontal scrolling.
- H1 remains readable on mobile, but brand + copy + proof cards delay the product preview.
- Page uses semantic headings and visible focus styling in CSS.
- Cards use 8px radii and fairly clear contrast in A/D. C gradient should be checked for contrast where text overlays colour.

Needs verification before production:
- Contrast of blue/gradient buttons in Skin C.
- Tap target size for mobile nav pills.
- Keyboard access for hover/focus mega menus.
- Whether `aria-label` and alt text remain accurate if mockups become real images.
- No layout overlap across 320px, 390px, 768px, 1024px, 1440px.

## Recommended Visual System

Default:
- Product structure: Skin A.
- Authority palette and heading tone: Skin D.
- School/partner materials: Skin B.
- AI Lab accent only: restrained part of Skin C.

Do not:
- Default to C's gradient identity.
- Use abstract hero images as primary proof.
- Hide safety boundaries behind the final section.
- Rely on page anchors as "conversion" in a paid product demo.

## Mobile Default Header

Recommended mobile header:

```text
Keepwise                                      [Start safety check]
```

Secondary navigation can live behind a menu:

- How it works
- Tools
- Evidence
- Pricing
- Schools
- Emergency signpost

## First View Target

The first mobile viewport should contain:

1. Brand.
2. Clear pain/outcome headline.
3. One sentence offer definition.
4. Primary CTA.
5. Mini trust rail.

The product preview can start just below, but it should be introduced with a label: "Example output."
