# Keepwise Fix-First Backlog

## Do Now - Safe Fixes

| Change | Leak It Closes | Why It Comes First | Mechanism Improved | Owner / Type | Effort |
|---|---|---|---|---|---|
| Replace primary CTA language with `Start the safety check`; secondary with `Preview plan and tools`. | CTA ambiguity | Copy-only and high leverage. | First-step clarity | Copy / design | S |
| Add "What happens after you start" section. | Unknown fulfilment | Parents need to know intake, review, delivery and output before paying. | Purchase confidence | Copy / product / design | M |
| Add "What we ask / what we never ask" data block. | Privacy uncertainty | Makes `No child data` credible and operational. | Privacy trust | Copy / policy | M |
| Move mini-boundary rail near hero and pricing. | Safety misrouting | Active-concern parents need routing before purchase. | Safeguarding confidence | Copy / design | S |
| Fix mobile header to show only brand + primary CTA. | Mobile action hidden | Mobile is likely a key parent journey. | Conversion momentum | Code / design | M |
| Add one sample output artefact. | Product proof gap | Converts abstract bundle into tangible value. | Trust through concreteness | Content / design | M |
| Add reviewer-process block. | Human-review credibility gap | "Human-reviewed" is the paid differentiator. | Accountability | Product / copy | M |

## Do Next - Requires Content Or Policy

| Change | Leak It Closes | Required Decision | Owner / Type | Effort |
|---|---|---|---|---|
| Define delivery SLA for reviewed plan. | Fulfilment anxiety | Delivery time and support model. | Product / ops | M |
| Add refund/cancellation language. | Payment risk | Refund/cancellation policy. | Founder / legal | S |
| Add real Terms and Privacy links. | Trust/legal gap | Legal/privacy copy. | Legal / code | M |
| Add sample Evidence Note with date. | Source-backed proof gap | Real source note and review process. | Content / research | M |
| Add verified parent/school proof. | Social proof gap | Real testimonial or pilot feedback. | Content | M |
| Build school briefing pack preview. | Institutional buyer trust | Actual outline and school-safe routing language. | Product / content | M |

## Test Next - Hypotheses

| Hypothesis | Variant A | Variant B | Primary Behaviour To Watch | Why Result Matters | Required Tracking |
|---|---|---|---|---|---|
| A/D hybrid will convert better than pure A because it increases authority without losing product clarity. | Skin A default | A/D hybrid | `start_safety_check_click`, pricing scroll, evidence view | Determines default visual system. | Variant exposure, hero CTA, pricing view, check start |
| A sharper anxiety-led headline will improve relevance. | Current "practical system" headline | "Know what to check, set and say before online safety becomes a crisis." | Hero CTA click, scroll to tools, bounce | Validates whether crisis-adjacent language helps or alarms. | Variant exposure, CTA click, scroll depth |
| Data-boundary block before pricing will increase payment confidence. | Pricing without data block | Pricing with `what we ask / never ask` block | Pricing CTA click, checkout start | Tests privacy objection. | Pricing view, data block view, plan CTA |
| CTA specificity improves momentum. | `Get the System` | `Start the safety check` | CTA click, intake start | Removes ambiguity. | CTA click, intake start |
| Showing sample plan before pricing increases perceived value. | Pricing first | Sample artefact before pricing | Pricing section view, plan selection | Tests product proof. | sample_view, pricing_view, plan_select |

## Red Flags To Fix Before Paid Traffic

- No real checkout/intake path.
- No delivery timeline.
- No review-process explanation.
- No real Terms/Privacy/customer support route visible on skins.
- No sample source note.
- No refund/cancellation language.
- Mobile CTA hidden in nav.

## What Not To Do

- Do not add generic fear-driven copy.
- Do not imply the product monitors children.
- Do not claim safeguarding compliance or safety outcomes without formal support.
- Do not add fake testimonials.
- Do not make the page more visually elaborate before fixing the journey.
- Do not choose Skin C simply because the offer includes AI.
