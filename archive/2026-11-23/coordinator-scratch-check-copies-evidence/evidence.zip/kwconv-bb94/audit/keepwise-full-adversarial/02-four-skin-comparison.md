# Four Newest Skins: Full Commercial Comparison

The four newest skins share the same offer copy and page architecture. The skin decision is therefore about which visual system best carries the trust burden, product clarity and parent action.

## Scorecard

Scored qualitatively from observed rendered desktop/mobile and source CSS/content.

| Criterion | Skin A Apple Platform | Skin B AIReadySchools | Skin C Gemini | Skin D Research Institute |
|---|---|---|---|---|
| First-five-second clarity | Strong | Strong | Medium | Strong |
| Product concreteness | Strongest | Strong | Medium | Medium-strong |
| Parent trust | Strong | Medium | Weak-medium | Strongest |
| Premium seriousness | Medium-strong | Medium | Weak | Strongest |
| Warmth | Medium | Strong | Medium | Medium-low |
| AI relevance | Medium | Medium | Strong | Medium |
| Differentiation | Medium | Weak | Weakest | Strong |
| CTA prominence | Strong | Strong | Medium-strong | Strong |
| Mobile nav | Weak | Weak | Weak | Inferred weak from shared CSS |
| Risk of feeling generic | Medium | High | High | Low |
| Risk of feeling too academic | Low | Low | Low | High |
| Default suitability | Best base | Secondary/contextual | Reject default | Best trust layer |

## Skin A: Apple Platform

Verdict: **Default base.**

What works:
- Strongest "this is an actual product" signal.
- The Control Centre preview feels usable and practical.
- The neutral background and crisp cards keep cognitive load manageable.
- CTA contrast is clear.
- The dashboard/product surfaces help convert abstract safety advice into a tangible system.

Trust risks:
- Feels slightly cold and platform-generic.
- Large `Keepwise` wordmark consumes too much early attention.
- The Apple-like aesthetic can look polished but not necessarily expert or accountable.
- Without a stronger evidence/review block, it may feel like a nice SaaS wrapper around advice.

Specific changes:
- Keep A's layout and product preview.
- Reduce hero wordmark scale.
- Borrow D's muted palette and editorial evidence styling for trust sections.
- Add a visible review-process block before pricing.
- Keep CTA sharp: `Start the safety check` instead of `Get the System`.

## Skin B: AIReadySchools-Inspired

Verdict: **Useful for school/ PTA route, not default.**

What works:
- Practical, approachable, structured and not intimidating.
- Good fit for school newsletters, parent briefings and institutional contexts.
- Card system makes complex offer feel manageable.

Trust risks:
- Blue education SaaS look is familiar but not premium.
- It risks looking like a vendor template rather than a parent-trust product.
- Less distinctive; may not justify paid premium versus free school handouts.

Specific changes:
- Use B for school/ PTA landing pages or downloadable packs.
- Borrow its clarity for "what schools can offer" sections.
- Avoid making B the consumer default unless the product is intentionally school-first.

## Skin C: Gemini-Inspired

Verdict: **Reject as default; borrow only tiny AI Lab accents.**

What works:
- Immediately signals AI relevance.
- Feels lively and contemporary.
- Gradient CTA attracts attention.

Trust risks:
- Looks derivative of major AI brands.
- For child safety, "AI-looking" can reduce seriousness.
- Gradient wordmark makes Keepwise feel less ownable and less grounded.
- The AI identity competes with the safety/planning identity.

Specific changes:
- Do not use C for default or pricing.
- Borrow subtle gradient only inside AI Readiness Lab chips/cards.
- Keep main brand restrained and safety-led.

## Skin D: Research Institute

Verdict: **Best trust layer; possible premium default only after product/conversion tuning.**

What works:
- Strongest authority, seriousness and premium trust.
- Serif wordmark/heading system makes the product feel more considered.
- Burgundy/deep accent fits sensitive safety decisions better than bright AI blue.
- Better supports evidence, source notes, boundaries and claim restraint.

Trust risks:
- Can feel academic, slower and less action-oriented.
- Product surfaces can recede behind editorial gravity.
- Might make £99 founding price feel oddly low unless value/fulfilment is clarified.

Specific changes:
- Borrow D's palette and evidence tone into A's structure.
- Keep product preview large and actionable.
- Use D's style for evidence, boundaries, school trust and pricing explanation.
- Avoid making the hero feel like a report rather than a tool.

## Recommended Default

Use an **A/D hybrid**:

- A's product-led layout and Control Centre hero.
- D's muted palette, serif authority, evidence tone and serious accent.
- Mobile nav from neither: use a simplified mobile header with visible CTA.
- C only as a restrained accent for AI Lab content.
- B as the school/ PTA skin or institutional variant.

## Skin-Specific Commercial Risks

| Skin | Commercial Risk | Why It Matters | Fix |
|---|---|---|---|
| A | Feels polished but not deeply accountable | Parents need trust, not only UX clarity | Add reviewer/source/person/process signals |
| B | Feels mid-market and generic | Premium parent may not see enough value over free resources | Use on school pages, not core paid page |
| C | Feels like another AI tool | Parents are anxious about AI, not necessarily looking for more AI branding | Restrict gradient/AI identity |
| D | Feels serious but less actionable | Action friction suppresses conversion | Increase product preview and CTA clarity |

## Mobile Notes

Observed A/B/C at 390px:
- Horizontal overflow: A approx 9px, B/C approx 14px.
- Header nav becomes a sideways row of `System`, `Courses`, `Resources`; key CTA is not visible.
- Hero remains readable, but the page starts with a lot of brand and text before the product preview.

D mobile screenshot timed out in the browser, but D uses the same shared mobile nav structure, so the same nav risk should be treated as present until visually disproven.

Required fix:
- On mobile, show only `Keepwise` + `Start safety check`.
- Put other links in a menu or below fold.
- Keep hero CTA visible before proof cards.
