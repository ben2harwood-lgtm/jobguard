# Keepwise Customer Journey Map

This maps the likely cold-parent journey from first click to payment/enquiry. Leak points are inferred from the rendered/source experience only.

## Funnel Map

| Stage | Parent Question | Site Answer | Missing Reassurance | Likely Drop-Off Cause | Recommended Fix |
|---|---|---|---|---|---|
| Landing | "Is this for me?" | "UK parents of 5-18s", online safety and AI readiness, practical household system. | Sharper pain recognition: "I do not know what to check first, and I do not want to spy." | The word "system" is broad; the parent may not immediately know whether this is a course, dashboard, report, or service. | Add a one-line offer definition under hero CTA: "Answer a short parent check; receive a reviewed plan, tools and first actions." |
| First impression | "Does it feel serious?" | Clean, product-led UI; Skin D adds research authority. | Real accountability: who is behind it, why they are qualified, what review means. | Strong visual polish but no human face/organisation accountability. | Add founder/reviewer/accountability block after hero or before evidence. |
| Problem understanding | "What pain does this solve?" | Stops parent piecing together tabs, school emails, half-remembered advice. | "What situation am I in?" segmentation: first phone, teen social app risk, AI homework, privacy reset, current incident. | Parent has to map broad offer to their immediate worry. | Add "Choose your starting point" cards: first phone, privacy reset, AI homework, current concern, school/ PTA. |
| Offer understanding | "What exactly do I receive?" | Household Plan, Control Centre, Family Agreement, Control Launchpad, AI tools, courses, source notes, Stay Current. | Concrete package preview at decision point: sample plan pages, intake questions, delivery format. | Too many nouns feel impressive but not owned. | Add a "What arrives after purchase" strip with 5 artefacts and delivery timeline. |
| Trust evaluation | "Can this guide child-safety decisions?" | Human-reviewed, evidence notes, review dates, claim boundaries, no child data. | Reviewer process, source examples, policy boundaries, complaints/support route. | Parent mistrusts "source-backed" without seeing sources. | Insert sample Evidence Note and "How we review" workflow. |
| Privacy evaluation | "What do I have to tell you about my child?" | No child data, no school/screenshots; minimal data. | Exact intake fields and what is optional. | Promise feels too broad or confusing: how can plan be personalised without child details? | Add `What we ask / what we never ask` beside CTA and intake. |
| Safety/risk evaluation | "What if something is already happening?" | Emergency signpost and boundaries mention appropriate routes. | Actual emergency signpost preview and crisis boundary near top. | Parent may be in crisis and either bounce or overtrust product. | Add persistent "Current concern?" link to free signpost; state "If something is happening now, start here." |
| Value judgement | "Is £99/£129 worth it?" | Pricing tiers list many features. | Comparison with free guides, course-only, concierge; sample depth; first-year/renewal clarity. | Parent may see it as expensive checklist or too cheap to be serious. | Add "Why not just use free resources?" and "what the review adds" microcopy. |
| Plan selection | "Which tier is right?" | Household System, System + AI Lab, Concierge, AI Lab only, live cohort, school/PTA briefing. | Decision aid based on child stage/worry. | Choice overload. | Add "Most families start here" and a 3-question plan recommender. |
| Conversion | "What happens after I click?" | Buttons anchor to page sections. | Real checkout/enquiry/intake/confirmation. | No transactional confidence. | Create actual flow: `Start safety check` -> data boundaries -> intake -> plan select -> payment/enquiry -> confirmation. |
| Post-purchase | "When do I get it, and how do I use it?" | "Human-reviewed before delivery" and first actions. | SLA, email/portal delivery, revision/support, refund/cancellation terms. | Unknown effort/time. | Add confirmation-state copy and "Your first 24 hours with Keepwise." |

## Inferred Customer Experience Failure Modes

1. **The anxious parent skims, likes the idea, but does not buy because the next step is not real.**  
   Mechanism: action uncertainty.  
   Fix: make CTA begin an actual low-risk safety check.

2. **The sophisticated parent questions the evidence.**  
   Mechanism: unsupported authority.  
   Fix: show one real source note, one review-date example, and a clear claim boundary.

3. **The privacy-conscious parent is confused by personalisation without data.**  
   Mechanism: privacy credibility.  
   Fix: show exact intake field categories and data never requested.

4. **The parent with an active issue misroutes themselves.**  
   Mechanism: safety boundary.  
   Fix: put the emergency signpost and "not incident handling" language near the top and checkout.

5. **The school buyer likes the idea but cannot assess procurement/safeguarding fit.**  
   Mechanism: institutional risk.  
   Fix: add a school-specific page or pack with safeguarding routing, no-child-data model, source notes and session outline.

## Strongest Journey Assets

- The Control Centre preview makes the abstract promise concrete.
- The "Your first three actions" section correctly converts anxiety into manageable steps.
- The Family Agreement and AI rules previews show tangible outputs.
- The evidence and boundaries sections are unusually claim-conscious and should be retained.
- Pricing is visible and specific, which builds trust compared with "book a call" opacity.

## Weakest Journey Assets

- There is no visible intake form.
- There is no payment or checkout state.
- There is no confirmation or delivery timeline.
- There is no reviewer identity/process.
- The emergency signpost is named more than demonstrated.
- The hero does not segment by parent situation.
