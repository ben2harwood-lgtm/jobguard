# Copy And Conversion Rewrites

The current copy is generally clear and refreshingly bounded. The highest-value changes are not "make it punchier"; they are about making the next step, review process, data boundary and emergency boundary concrete.

Use these as safe copy directions unless a policy/legal/content decision is noted.

| Section | Current Copy | Problem | Improved Copy | Mechanism Improved |
|---|---|---|---|---|
| Hero H1 | "A practical system for setting rules, checking settings and keeping up." | Clear but generic. Does not name the parent anxiety sharply. | "Know what to check, set and say before online safety becomes a crisis." | Relevance, anxiety reduction |
| Hero H1 safer variant | Same | The stronger version may feel too crisis-led for some parents. | "A calmer way to decide what to check, set and say at home." | Clarity without alarm |
| Hero lede | "For UK parents of 5-18s: a reviewed household plan..." | Good feature list, but long and noun-heavy. | "Answer a short parent check. Get a reviewed household plan, Control Centre, family rules, device-setting guidance and AI-readiness tools matched to your child's age and situation." | Offer comprehension |
| Primary CTA | "Get the System" / "Start check" | Competing language; "System" is internal language. | "Start the safety check" | First-step clarity |
| Secondary CTA | "See the tools" | Fine, but could be more concrete. | "Preview the plan and tools" | Product proof |
| Hero trust rail | "Human-reviewed / No monitoring / No child data / Evidence notes" | Strong, but terse. | "Human-reviewed plan. No monitoring software. No child names, schools, screenshots or messages. Source notes with review dates." | Trust and privacy |
| Human review | "Human-reviewed before delivery." | Vague; triggers accountability questions. | "A trained reviewer checks your plan before delivery for age fit, obvious gaps and claim boundaries. It is planning support, not incident handling or crisis advice." | Accountability |
| Data boundary | "No child data, no school or screenshots." | Strong but needs operational clarity. | "We ask for age band, devices, platforms and household priorities. We do not ask for your child's name, school, photos, screenshots, messages or incident details." | Privacy credibility |
| Emergency signpost | "A free routing page..." | Good idea but too abstract. | "If something is happening now, start with the free emergency signpost. It routes you to school, platform, police or support options; Keepwise is prevention planning, not emergency response." | Safeguarding confidence |
| Pricing headline | "Start with the household system. Add deeper help when it matters." | Clear but not decision-guiding. | "Start with the reviewed household plan. Add AI or live help only if you need it." | Plan choice |
| Founding price note | "£99 founding" | Ambiguous. | "Founding price: £99 for the Household System and first year of Stay Current. Future renewal: £59/year for updates after year one." | Price confidence |
| Bundle CTA | "Start with bundle" | Unclear what happens next. | "Start check for System + AI Lab" | Conversion specificity |
| Concierge CTA | "Enquire" | Weak and generic. | "Ask about guided setup" | Fit clarity |
| Evidence section | "Show the sources. Show the product. Show what changed." | Strong. Keep. Needs sample. | Keep headline. Add: "Here is what a Keepwise Evidence Note looks like." | Proof specificity |
| Boundary headline | "Trusted because it does not overclaim." | Strong. Keep. | Keep, but move mini-version above pricing. | Risk reversal |
| Footer | "Prevention-focused online-safety education and planning." | Good, but could repeat emergency boundary. | "Prevention-focused planning for parents. If something is happening now, use the free emergency signpost or contact the appropriate school, platform, police or support route." | Safety clarity |

## Suggested Hero Copy Block

```text
Online safety and AI readiness for UK families.

Know what to check, set and say before online safety becomes a crisis.

Answer a short parent check. Get a reviewed household plan, Control Centre, family rules, device-setting guidance and AI-readiness tools matched to your child's age and situation.

[Start the safety check] [Preview the plan and tools]

Human-reviewed plan. No monitoring software. No child names, schools, screenshots or messages. Source notes with review dates.
```

## Suggested "What Happens Next" Block

Place this directly after hero or before pricing.

```text
What happens after you start

1. Tell us the age band, devices, platforms and worries you are planning around.
2. We create your household plan and check it before delivery.
3. You receive your Control Centre, first actions, family agreement, setting guides and relevant AI tools.
4. Stay Current keeps you updated when platform settings, AI guidance or common parent questions change.

We do not ask for child names, schools, screenshots, messages or incident details.
```

## Suggested Pricing Microcopy

```text
The Household System is the right starting point if you want a reviewed plan, setup tools and the online-safety course.

Choose System + AI Lab if AI homework, synthetic media, prompts or source-checking are already active questions in your home.

Choose Concierge only if you want guided setup and a written report across more than one child.
```

## FAQ Gaps To Add

| FAQ Question | Why It Matters | Safe Answer Direction |
|---|---|---|
| What do I have to tell you about my child? | Privacy and data trust | List exact intake categories; repeat what is never requested. |
| Who reviews the plan? | Human accountability | Explain reviewer role, training/criteria if true, and limits. |
| How long does delivery take? | Purchase confidence | State SLA or use placeholder until decided. |
| What if something is happening now? | Safeguarding risk | Route to emergency signpost and appropriate school/platform/police/support routes. |
| Is this monitoring software? | Objection handling | No; nothing installed, no messages read, no child tracking. |
| What if my school has its own AI policy? | AI homework trust | School policy comes first; Keepwise helps parents align home boundaries. |
| Can I get a refund? | Risk reversal | Add only if policy exists. |
| What happens after year one? | Pricing trust | Explain Stay Current renewal clearly. |

## Copy Claims That Need Evidence Before Use

Do not add these unless supported:

- "Expert-reviewed" unless reviewer expertise is defined.
- "Safeguarding-approved" or "compliant" unless legally reviewed.
- "Trusted by schools" unless true and permissioned.
- "Protects your child" as a guarantee.
- "Proven to reduce risk" without evidence.
- Named platform guidance claims without source review dates.
- Parent testimonials or outcomes unless real.
