# Analytics, Testing And Implementation Plan

## Minimum Useful Tracking Plan

Use these event names or equivalents.

### Core Funnel Events

- `page_view`
- `skin_variant_viewed`
- `hero_primary_cta_click`
- `hero_secondary_cta_click`
- `start_safety_check_click`
- `intake_start`
- `intake_step_complete`
- `intake_data_boundary_view`
- `plan_recommendation_view`
- `pricing_view`
- `plan_select_household`
- `plan_select_ai_lab_bundle`
- `plan_select_concierge`
- `checkout_start`
- `checkout_complete`
- `school_enquiry_start`
- `school_enquiry_submit`

### Trust Behaviour Events

- `sample_plan_view`
- `control_centre_preview_view`
- `family_agreement_preview_view`
- `source_note_view`
- `evidence_section_view`
- `boundary_section_view`
- `emergency_signpost_click`
- `privacy_link_click`
- `terms_link_click`
- `review_process_view`
- `what_we_ask_view`

### Secondary Quality Signals

- Scroll depth to tools, evidence, pricing and boundaries.
- Repeat visits before purchase.
- Plan switching between Household and AI Lab bundle.
- Abandonment after data-boundary view.
- Abandonment after pricing view.
- Enquiry vs paid plan selection split.

## Funnel Steps To Measure

1. Landing page viewed.
2. Hero CTA clicked.
3. Safety check started.
4. Data boundary accepted/continued.
5. Intake completed.
6. Plan recommended.
7. Pricing viewed.
8. Plan selected.
9. Checkout started.
10. Checkout completed.
11. Confirmation page viewed.

For schools:

1. School section viewed.
2. School pack preview viewed.
3. School enquiry started.
4. School enquiry submitted.

## Qualitative Feedback Prompts

Ask 5-8 target parents:

- What did you think Keepwise actually gives you?
- What would stop you paying £99?
- What information would you need before sharing household details?
- Did "human-reviewed" make you trust it more or raise questions?
- Did the page feel like safety support, education, software, or consultancy?
- Did anything make it feel like monitoring?
- Which skin felt most trustworthy and why?

Ask schools/PTAs:

- Would you feel comfortable sharing this with parents?
- What safeguarding or legal language would you need?
- Does "no incident handling / no child data" feel clear enough?
- Would a briefing pack be useful?

## Implementation Plan

### Phase 1 - Safe Content And Structure Fixes

| Item | Component/Page Likely Affected | Change Type | Required Content | Risk | Validation |
|---|---|---|---|---|---|
| Standardise CTA copy | All four skins / final default page | Copy | None | Low | Hero and pricing CTAs use same language |
| Add "What happens next" section | Landing page before tools or pricing | Copy/design | Delivery sequence | Medium if SLA not decided | Parent can describe journey after purchase |
| Add mini-boundary rail | Hero/pricing | Copy/design | Safety boundary wording | Low | Boundary visible before pricing |
| Add data-boundary block | Hero/pricing/intake | Copy/design | Intake field categories | Medium if operational model unclear | No contradiction with privacy policy |
| Fix mobile header | Shared CSS | Code/design | None | Low | 320/390/768px CTA visible, no overflow |

### Phase 2 - Trust Evidence Integration

| Item | Component/Page | Change Type | Required Content | Risk | Validation |
|---|---|---|---|---|---|
| Review-process block | Landing / pricing | Content/design | Reviewer role, criteria, SLA, limits | High if unsupported | Legal/founder approval |
| Sample Household Plan | Tools / pricing | Content/design | Real sample/redacted artefact | Medium | Parent understands output |
| Sample Evidence Note | Evidence | Content/design | Source, review date, boundary | Medium | Source verified and dated |
| Terms and Privacy links | Footer/checkout | Code/content | Legal docs | High if absent | Links work, claims align |
| Emergency signpost preview | Hero/footer/boundaries | Content/design | Routes and disclaimers | High | No implication of emergency service |

### Phase 3 - Design Variant Decision

Recommended:
- Default to A/D hybrid.
- Keep Skin B as school/ PTA variant.
- Retire Skin C as a full-page consumer default.
- Track `skin_variant_viewed` only if variants remain accessible for testing.

Implementation specifics:
- Use A's layout, product cards and Control Centre preview.
- Apply D's palette, serif display headings and evidence/boundary treatment.
- Reserve C-like gradient only inside AI Lab badges or cards.
- Use a single shared mobile header.

### Phase 4 - Funnel And Form Improvements

Build a real `Start safety check` path:

1. Intro screen: what it is and is not.
2. Data-boundary confirmation.
3. Age band and household context.
4. Devices/platforms used.
5. Main concern: first phone, privacy, social apps, AI homework, current concern.
6. Route active concerns to emergency signpost where needed.
7. Plan recommendation.
8. Pricing/checkout or enquiry.
9. Confirmation with delivery timeline.

Do not collect child name, school, screenshots, photos, messages or incident details if the site claims not to.

### Phase 5 - Testing And Measurement

Start with:
- A vs A/D hybrid.
- Current H1 vs anxiety-led H1.
- CTA copy test.
- Data-boundary-before-pricing test.
- Sample plan before pricing test.

Success measures:
- More safety-check starts.
- More pricing views after trust sections.
- Higher checkout starts from pricing.
- Fewer privacy-related abandonments.
- Qualitative parent trust improves without increased confusion about monitoring or crisis advice.

## QA Checklist Before Shipping

- Mobile header shows CTA.
- No horizontal overflow at 320/390/768.
- All CTAs lead to real paths or are clearly labelled as demo.
- Pricing explains founding price and renewal.
- Terms/privacy/contact exist.
- Emergency signpost route exists.
- "Human-reviewed" has process details.
- Evidence Notes have a real example.
- No unsupported safety/compliance/outcome claims.
- Copy does not imply monitoring, incident handling or crisis advice.
