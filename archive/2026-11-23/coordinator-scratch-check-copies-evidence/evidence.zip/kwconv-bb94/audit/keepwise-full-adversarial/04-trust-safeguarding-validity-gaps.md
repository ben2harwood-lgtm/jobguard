# Trust, Safeguarding And Validity Gaps

The current page is unusually careful about boundaries, which is a major strength. The gap is that several high-trust claims are asserted but not operationally shown.

## Gap Table

| Gap | Why It Damages Trust | Exact Signal To Add | Where To Place It | Confidence |
|---|---|---|---|---|
| Reviewer identity/process | "Human-reviewed" is central to value. Without process, it feels like a badge. | `How review works`: reviewer role, criteria, what is checked, what is not checked, delivery SLA. | Hero proof rail, pricing, post-CTA modal/intake. | Safe fix with real content |
| Source note example | "Source-backed" and "Evidence Notes" are premium claims, but no example source note is visible. | One sample Evidence Note card with source, reviewed date, confidence boundary and practical implication. | Evidence section and pricing trust sidebar. | Safe fix if sourced |
| Intake data model | "No child data" is strong but hard to reconcile with personalisation. | `What we ask / what we never ask`: age band, devices, platforms, household concerns; no child name, school, screenshots, messages, photos, incident details. | Before intake, hero trust rail, pricing note. | Safe fix |
| Emergency routing | Emergency signpost is mentioned but not demonstrated. | A small preview: "Current concern? Start here" with routes: school, platform, police, helpline/support. | Above fold or sticky/footer; full boundary section. | Safe fix |
| No incident handling | Good boundary appears late. | Repeat earlier: "Keepwise is prevention planning. Active concerns are routed." | Hero, schools, pricing. | Safe fix |
| Fulfilment timeline | Parent cannot tell when the plan arrives. | "Typical delivery: [timeframe]" or "during beta, delivery timing confirmed before payment." | Pricing and confirmation state. | Requires policy |
| Refund/cancellation/risk reversal | Paid safety-adjacent products need low-risk entry. | Refund/cancellation line if available; otherwise "review before payment" or "no payment until delivery terms shown." | Pricing. | Requires policy |
| Who is behind Keepwise | No founder/team/accountability signal visible in the skin pages. | About/reviewer block with name, role, approach, limitations and contact route. | After evidence or before pricing. | Requires content |
| Terms/privacy path | Footer links in demo are anchors, not actual terms/privacy pages. | Real Terms, Privacy, data minimisation and deletion links. | Footer, checkout, intake. | Safe fix |
| Child data deletion/access | Minimal data claim is good; rights/process are not visible on the skin page. | "You can request deletion/access by [route]; what we keep for legal/billing/safety reasons." | Privacy page and checkout. | Requires legal/privacy policy |
| School safeguarding expectations | Schools need bounded language and escalation clarity. | School pack: "not casework, no child data, route active concerns to DSL/platform/police/support." | School section / separate schools page. | Safe fix |
| Testimonials/social proof | No visible parent/school proof. | Real pilot quotes or anonymised before/after examples with permission. | Below hero and before pricing. | Requires real evidence |
| Product sample | Many mockups are illustrative. Parent needs downloadable or zoomable sample. | "View sample household plan" with a real redacted/sample plan PDF or page. | Hero secondary CTA and pricing. | Safe fix |
| Currentness process | Stay Current is valuable but process is vague. | Explain sources monitored, review cadence, what triggers update, and how parent receives it. | Evidence/updates section and pricing note. | Requires process |

## Safeguarding-Risk Review

Strengths:
- The page explicitly says Keepwise is not monitoring.
- It does not claim safety guarantees.
- It states active concerns are routed to school, platform, police or support routes.
- It states school sessions do not require names, screenshots, messages or case details.
- It frames AI Lab as parent-led, not child-facing.

Risks:
- "Online safety" plus "emergency signpost" may attract parents with active harm concerns. If the emergency path is only described late, the page may create ambiguity.
- "Human-reviewed plan" could be misread as professional safeguarding assessment unless bounded.
- "No child data" can sound absolute; if age, devices and platforms are collected, the page should say that clearly.
- "Source-backed" may imply clinical/legal authority if not shown with claim boundaries.

Recommended safe wording near CTA:

```text
Keepwise is prevention-focused planning, not emergency response or incident handling. If something is happening now, use the free emergency signpost or contact the appropriate school, platform, police or support route.
```

## Validity Questions The Business Must Answer

These are not copy tweaks; they are product/policy decisions.

1. Who reviews a Household Plan?
2. What training, checklist or quality rubric do reviewers use?
3. What is the delivery SLA?
4. What data is collected in the readiness check?
5. What data is stored, for how long, and where?
6. Is there a refund/cancellation policy?
7. What qualifies a parent for Concierge rather than the main system?
8. What happens when an intake response suggests an active concern?
9. Are source notes publicly accessible, member-only, or included in each plan?
10. What does "approved updates" mean, and who approves them?

## Claims To Keep

- No monitoring.
- No child names/schools/screenshots/messages/incident details, if operationally true.
- Not a safety guarantee.
- Not crisis advice.
- Parent-led AI Lab.
- Source-backed with claim boundaries, if source notes exist.
- Human-reviewed plan, if a real review process exists.

## Claims To Avoid

- "Keeps your child safe."
- "Safeguarding-compliant."
- "Expert-approved."
- "Prevents harm."
- "Fully private" or "no data" without nuance.
- "Real-time protection."
- "School-approved."
- "Current across all platforms" unless the monitoring/update process is real and bounded.
