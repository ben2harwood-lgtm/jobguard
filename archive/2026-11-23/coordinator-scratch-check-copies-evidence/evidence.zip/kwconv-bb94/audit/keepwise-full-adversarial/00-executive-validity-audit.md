# Keepwise Full Multi-Adversarial Validity Audit

Date: 2026-06-28  
Material inspected: rendered local demo at `http://127.0.0.1:8766/index.html`, the four newest demo skins, and source files in `brand-design/`.

Skins inspected:
- Skin A: `brand-design/full-offer-platform.html`
- Skin B: `brand-design/aiready-schools-inspired.html`
- Skin C: `brand-design/gemini-inspired-platform.html`
- Skin D: `brand-design/research-institute-premium.html`

The index/meta comparison copy was ignored. The underlying offer and customer experience were audited from the visitor-facing skin pages.

## A. Snapshot

Keepwise appears to be a paid parent-facing household online-safety and AI-readiness system for UK parents of children aged 5-18.  
The offer combines a human-reviewed household plan, Control Centre, family agreements, device/app setting guidance, parent courses, AI-readiness tools, a source-backed resource library, Stay Current updates, school/PTA briefings, and an optional concierge service.  
The strongest existing commercial asset is the concrete product preview: "Your first three actions", Control Centre preview, printable agreements, schoolwork ladder, source check, and pricing tiers.  
The biggest conversion/trust leak is that the page claims a serious reviewed safety product but does not show the actual intake, checkout, fulfilment timeline, reviewer/accountability model, or post-purchase experience.  
The best default direction is an A/D hybrid: Skin A's product clarity plus Skin D's serious evidence-led authority.  
Overall confidence: strong product/offer potential, medium website readiness, low checkout-readiness because the conversion flow is not visible.

## B. Validity Verdict

This is a commercially valid problem space. Parents are plausibly paying for:

- Reduced anxiety about phones, social apps, AI homework and fast-moving settings.
- A calm order of operations instead of scattered advice.
- Bounded guidance without surveillance or invasive monitoring.
- Help translating "online safety" into household rules and actual device settings.
- A source-backed way to stay current as platforms, AI tools and school expectations change.

The page does make that promise visible. It is not merely a content course or a checklist. It feels like a productised decision-support system.

The risk is that the claim "human-reviewed plan" creates a higher trust obligation than the page currently satisfies. A cautious parent will want to know who reviews it, what information they must submit, how long it takes, what the plan includes, what it excludes, how advice is sourced, and what happens when there is an active concern. These answers exist partly in the page, but they are scattered and not shown at the buying moment.

## C. Cold-Parent Journey And Likely Leak Points

| Step | Parent Decision | What The Site Gives | Likely Leak | Mechanism Affected | Severity |
|---|---|---|---|---|---|
| First arrival | "Is this for my family and is it serious?" | Clear age range, UK parent positioning, practical system promise, product preview. | Brand wordmark dominates; "system" is broad; parents may need a sharper pain statement. | Relevance and comprehension | Medium |
| Offer understanding | "What exactly do I get?" | Plan, Control Centre, agreements, courses, resources, Stay Current, evidence notes. | Too many nouns before a simple "what happens after I buy" sequence. | Cognitive load | High |
| Trust evaluation | "Can I trust this with child safety decisions?" | Human-reviewed, no monitoring, no child data, evidence notes, bounded claims. | No reviewer identity, qualifications, sourcing examples, sample report, or review workflow. | Trust and accountability | High |
| Risk evaluation | "Will this make me safer, or give false confidence?" | Boundary section says not monitoring, not guarantee, not crisis advice, minimal data. | Boundaries appear late. Emergency signpost is named but not operationally shown. | Safety confidence | High |
| Value judgement | "Is £99/£129 worth it?" | Tiers list features and year-one Stay Current. | No fulfilment timeline, sample plan depth, outcome examples, or comparison with free resources. | Perceived value | Medium |
| Pricing | "Which option should I choose?" | Household System, System + AI Lab, Concierge; add-ons. | Too many adjacent options; "founding" undefined; primary plan CTA does not buy/start. | Decision clarity | High |
| Conversion | "What happens if I click?" | CTAs anchor to page sections. | No real intake/payment/enquiry flow visible. | Momentum and confidence | Critical |
| Post-purchase expectation | "What happens next?" | Some mentions of reviewed before delivery and first actions. | No confirmation state, receipt, delivery time, data deletion path, or support route. | Risk reversal and confidence | Critical |

Most serious leaks:

1. CTA/funnel is not real enough: primary buttons mostly scroll, not convert.
2. Human-review trust is asserted, not sufficiently evidenced.
3. Safety boundaries are strong but appear too late for a high-anxiety parent.
4. Pricing and fulfilment are under-specified at the point of decision.

## D. Prioritised Findings

| Rank | Element & Location | Lens | Problem | Mechanism Affected | Why It Matters For Parent Buyers | Specific Fix | Confidence | Priority |
|---:|---|---|---|---|---|---|---|---|
| 1 | Pricing CTAs, all skins, pricing section | Conversion / customer experience | CTAs do not show a real next step: `View sample`, `Start with bundle`, and `Enquire` are anchors rather than a visible intake/payment/enquiry path. | Conversion momentum and checkout confidence | A parent buying safety guidance needs to know what they submit, pay, receive and when. | Add a visible `Start the safety check` flow: 1. choose age band, 2. answer household questions, 3. see data-minimisation note, 4. pay, 5. confirmation and delivery timeline. | Safe fix | Impact H / Effort H |
| 2 | Hero and pricing: "Human-reviewed plan before delivery" | Trust architecture | Reviewer/accountability is vague. No named role, criteria, review scope, SLA or limitations are shown. | Human accountability | "Human-reviewed" raises expectations. Without accountability it can feel like a trust badge without substance. | Add a "How review works" block near hero and pricing: who reviews, what they check, what they do not check, delivery window, escalation limits. Use placeholders if not final. | Safe fix with real content | Impact H / Effort M |
| 3 | Boundary section appears near end | Safeguarding-risk / parent confidence | Important safety limits are late: not crisis advice, not monitoring, no incident handling, minimal data. | Risk clarity | Parents with current harm concerns may misread the product as incident support. | Move a short boundary rail into hero/pricing: `Prevention planning, not emergency response`; link to free emergency signpost. Keep full boundary block later. | Safe fix | Impact H / Effort S |
| 4 | Hero H1: "A practical system..." | Clarity / positioning | Clear but generic. It does not immediately name the emotional pain: "I don't know what to do first." | Relevance and anxiety reduction | Parents pay when the site names the anxiety and makes the path feel manageable. | Test H1: "Know what to check, set and say before online safety becomes a crisis." Keep current as variant B if too sharp. | Test it | Impact M / Effort S |
| 5 | Hero brand wordmark, all skins | Visual hierarchy | `Keepwise` is larger than the value proposition, especially Skin A/B/C. | First-five-second clarity | Unknown brands should not consume more attention than the parent outcome. | Reduce product-mark size 20-35% or move brand emphasis into nav. Use that space for "what you get tonight" or sample output. | Safe fix | Impact M / Effort S |
| 6 | Evidence section | Trust / proof | Evidence process is described, but no actual source note example is visible. | Proof specificity | "Source-backed" is a premium claim. Parents need to see what a source note looks like. | Insert one sample Evidence Note card with source title, reviewed date, confidence boundary, and practical implication. Do not invent source names unless verified. | Safe fix if source exists | Impact H / Effort M |
| 7 | Data claims: "No child data, no school or screenshots" | Privacy / validity | Strong promise but may conflict with plan personalisation unless intake is explained. | Privacy trust | Parents will wonder what data is needed to create an age/app-specific plan. | Add "What we ask / what we don't ask" beside intake and pricing. Clarify age band, devices, platforms, household preferences; no names, school, messages, screenshots. | Safe fix | Impact H / Effort M |
| 8 | Pricing: "£99 founding", "£129 founding" | Pricing psychology | "Founding" is undefined; no standard price, closing date, refund/cancellation terms, or delivery timeline. | Price confidence | Ambiguity around founding pricing can feel beta or unstable. | Add: founding price includes X, available until X or first X families, standard price later if known, refund/cancellation terms if supported. | Safe fix with policy | Impact M / Effort S |
| 9 | School/PTA section | B2B trust | Good bounded language, but no school proof pack, safeguarding handoff, or sample newsletter shown. | Institutional confidence | Schools will be wary of parent-safety vendors. They need bounded roles and ready artefacts. | Add "school pack preview": briefing outline, take-home pack sample, safeguarding routing note, staff burden promise. | Safe fix | Impact M / Effort M |
| 10 | Mobile nav, all skins | UX / mobile conversion | Mobile nav scrolls horizontally and hides the primary action. Verified in A/B/C; D inferred from same CSS. | First-step action | Parents often arrive from mobile. Hiding the CTA loses momentum. | Mobile nav should show logo + `Start safety check`; collapse the rest. | Safe fix | Impact H / Effort M |
| 11 | Product preview imagery | Visual trust | `apple-system-hero.png` is abstract dashboard imagery, not a recognisable Keepwise artefact. | Concrete belief | Parents trust tangible outputs: plan, checklist, agreement, source note. | Replace abstract device image with a composite of actual artefacts: Household Plan page, Control Centre, Family Agreement, Source Note. | Safe fix / visual content | Impact M / Effort M |
| 12 | No testimonials/outcome evidence | Social proof / validity | No parent quotes, pilot outcomes, school feedback, or "used by" evidence visible. | Social trust | For safety products, other-parent proof reduces fear of choosing wrong. | Add only verified proof: pilot parent quote, school/ PTA feedback, or anonymised "what changed after setup" stories. Use placeholders until real. | Requires evidence | Impact H / Effort M |

## E. Expert Verdict

Is the site currently strong enough for a paid parent buyer?

It is strong enough to generate interest and probably collect waitlist/enquiry intent. It is not yet strong enough to confidently take payment for a safety-adjacent, human-reviewed product without a clearer intake, fulfilment and accountability experience.

What is suppressing conversion most?

Not the design skin. The biggest suppressor is that the customer journey stops at page anchors. Parents cannot see the actual buying path, the data they provide, the review process, the delivery timeline, or the post-purchase state.

Fastest route to make it commercially effective:

1. Convert the hero/pricing CTA into a visible safety-check/intake flow.
2. Add review-process accountability and a sample output.
3. Move short safety/data boundaries above the first pricing decision.
4. Use Skin A/D hybrid for default visual system.

What should not be changed yet:

- Do not add stronger safety or efficacy claims.
- Do not imply monitoring, crisis response, or safeguarding intervention.
- Do not invent source authority, legal compliance, testimonials or school partnerships.
- Do not optimise minor colour/style details before fixing the funnel.
