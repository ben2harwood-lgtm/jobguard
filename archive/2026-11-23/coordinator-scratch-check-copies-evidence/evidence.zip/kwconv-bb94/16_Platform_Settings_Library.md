# Platform Settings Library

**The "do this, here's where" reference parents told us they want most (83% want settings help). Ten guides, device layer first.** Each is parent-ready: the controls that matter, where to find them, what they do, and what changed in 2025–26.

**Honest caveat to keep on every guide:** *Menus move. App makers rename and relocate settings often — if a path below doesn't match your screen, search the setting name in the app, or use the official help link. All paths checked June 2026.* Confidence: `[V]` verified to official source · `[PV]` partly verified · `[NV]` re-check before relying.

**Two things to understand before you start:**

- **Monitor vs control.** Snapchat, Instagram and Discord "family centres" mostly show you *activity* (who, not what) and let you change *some* settings — they are **not** message-readers. Apple, Google, Roblox and Epic give you genuine *controls* (blocks, limits, approvals). Don't over-trust the social dashboards.
- **Age accuracy is the linchpin.** Almost every protection keys off the birthday on the account. The single most valuable thing you can do on any social app is make sure your child's **real date of birth** is set — Meta and Roblox now actively re-check with AI/face scans. `[V]`

**Do this first, in this order** (highest leverage first): **1) the device layer (Apple Screen Time or Google Family Link)** — it governs every app, install and website at once → then the apps your teen actually uses, roughly **Snapchat → Instagram → TikTok → Roblox → Discord → WhatsApp → Fortnite → YouTube.**

> **Heads-up for 2026–27:** UK rules are tightening. Online Safety Act child-protection duties have been live since 25 July 2025, and under-16 social-media restrictions are expected around Spring 2027. Expect more face-scan / ID age checks across these apps over the next year. `[V]`

---

## 1. Apple Screen Time (iPhone / iPad) — set this first

**What it is:** device-level control via Family Sharing. For a child under 18, Communication Safety and web-content limits are **on by default**. `[V]`

**Set up:** Settings → your name → **Family Sharing** → add your child's Apple Account → then Settings → **Screen Time** → your child's name.

**Check these (Settings → Screen Time):**
- **Lock Screen Time with a passcode** your child doesn't know — *do this first*, or everything else can be switched off. `[V]`
- **Downtime** — hours when only allowed apps/calls work (e.g. overnight, homework). `[V]`
- **App Limits** — daily limits by category (e.g. Social) or single app. `[V]`
- **Communication Limits** — who they can contact during allowed time and downtime. `[V]`
- **Communication Safety** — on-device blurring of nude images in Messages/AirDrop with guidance; Apple can't see the photos. On by default under 18. `[V]`
- **Content & Privacy Restrictions** — block age-inappropriate web/apps/music, and **lock "Share My Location"** so it can't be changed. `[V]`
- **Ask to Buy** — your approval required for purchases/downloads. `[V]`

**Age:** a Child Apple Account is parent-created for under-13s; 13–17s can have their own account you manage via Screen Time. `[V]`
**New 2025–26:** article current to May 2026; child can request more time and you approve from your phone; iOS 26 added age-range/age-assurance APIs (`[NV]` UK specifics). 
**Official:** support.apple.com/en-us/108806

---

## 2. Google Family Link (Android / Chromebook) — set this first

**What it is:** device-level control app for a child's supervised Google Account — screen time, app approval, content filters, location, contacts. `[V]`

**Check these (Family Link app):**
- **Daily limits & schedules** — *Screen time* tab → time limits / weekly schedule. `[V]`
- **Downtime / bedtime** and **School time** hours. `[V]`
- **App management** — *Controls* → approve/block apps, per-app limits, mark educational apps unlimited. `[V]`
- **Content filters** — *Controls* → SafeSearch, Chrome, Google Play maturity ratings, YouTube. `[V]`
- **Approved contacts (Android)** — approve who they can call/text. `[V]`
- **Purchase approval** for the Play Store. `[V]`

**Age:** parent creates a supervised account for under-13s (credit-card consent check). At 13 the teen can take the account over; you can keep supervision until they remove it (you're notified + device briefly locks). `[V]`
**New 2025–26:** redesigned app with separate Screen Time and Controls tabs; School Time on phones/tablets; call/text contact approval. `[PV]`
**Official:** support.google.com/families/answer/7101025

---

## 3. Snapchat

**What it is — Family Centre.** Both of you need accounts and must opt in. You can see their friends list and *who* they've messaged/called in the last 7 days (**not** the content), set content restrictions, disable the My AI chatbot, and share location as a family. `[V]`

**Check these:**
- **Set up Family Centre** — Profile → ⚙️ Settings → *Privacy Controls* → **Family Centre** → select child → send invite. `[V]`
- **Contact Me** → set to **Friends** (not "Friends and Contacts") so strangers can't message. `[V]`
- **Snap Map → Ghost Mode** — Map → ⚙️ → **Ghost Mode** (hides live location; recommended on for under-18s). `[V]`
- **View My Story** → **My Friends** or Custom. `[V]`
- **My AI** — Settings → clear My AI data / disable (full removal needs Snapchat+). `[V]`
- **Two-factor authentication** — Settings → Two-Factor Authentication. `[V]`

**Age:** 13+, self-declared, **no verification**; 13–17 get stricter defaults. `[PV]`
**New 2025–26:** Jan 2026 Family Centre update added daily time-spent (by feature), "trust signals" on new friends, and an embedded safety course. `[PV]`
**Official:** parents.snapchat.com (UK: /en-GB/parental-controls)

---

## 4. Instagram (Meta)

**What it is — Teen Accounts + supervision.** Under-18s are auto-placed into **Teen Accounts** with protective defaults on; under-16s need your permission (via supervision) to loosen any of them. `[V]`

**Check these:**
- **Set up supervision** — Settings → **Family Centre** → invite/accept. Lets you see who they messaged in 7 days (not content), set time limits, and schedule "off" periods. `[V]`
- **Verify the real birthday** — most protections key off age; changing to 18+ triggers an ID/face age check. `[V]`
- Confirm the Teen-Account defaults are on: **private account**, **strictest messaging** (only people they follow), **most-restrictive sensitive-content** and **Hidden Words**, **time-limit nudge at 60 min**, **Sleep Mode mutes notifications 10pm–7am**. `[V]`
- **Under-16s can't go Live** or turn off DM nudity-blur without your permission. `[V]`
- Consider the stricter **Limited Content** setting (removes comments, filters more mature material). `[V]`

**Age:** 13+. Meta uses **AI age-assurance** (live UK) and from May 2026 **AI visual age estimation** to move suspected-teen accounts into protections even with an adult birthday listed. `[V]`
**Official:** help.instagram.com/995996839195964 · familycenter.meta.com

---

## 5. TikTok

**What it is — Family Pairing.** Links your account to your teen's to manage screen time, content, search, DMs and privacy. `[V]`

**Check these:**
- **Enable Family Pairing** — Profile → ☰ → *Settings and privacy* → **Family Pairing** → scan QR on the teen's matching screen. `[V]`
- **Screen-time limit** (default 60 min/day for 13–17; can set shorter). `[PV]`
- **Direct Messages** — **off for under-16s by default**; confirm. `[V]`
- **Private account** — default for under-16s; check on for older teens (Settings → Privacy). `[V]`
- **Restricted Mode / content preferences.** `[PV]`
- **Who can interact** — comments, Duet/Stitch, mentions, "suggest your account." `[PV]`

**Age:** 13+, self-declared; suspected under-16 accounts forced private. `[V]`
**New 2025–26:** finer screen-time/scheduling controls; under-16 default-private + no-DMs are the key protections. **TikTok reorganises menus often — verify paths in-app.** A second account or the mobile browser can bypass pairing. `[V]`
**Official:** tiktok.com/safety/en/guardians-guide

---

## 6. Roblox — re-check this one, it changed a lot in 2026

**What it is — Parental Controls (linked, PIN-protected).** You create an account, verify your age with ID/credit card, link to your child, then manage maturity, chat, screen time and spending from your phone. `[V]`

**Check these (Settings → Parental Controls):**
- **Link + verify** your age, then link to the child. `[V]`
- **Content maturity level** — set the ceiling (Minimal / Mild / Moderate…). `[V]`
- **Chat & connections** — disable text/voice chat, review connections, **block or approve individual games**. `[V]`
- **Screen-time** daily limits. `[V]`
- **Spending limits** — monthly Robux cap + notifications (in-game spend is a top complaint). `[V]`

**Age — major 2026 overhaul:** facial **age-estimation (video selfie) now required to use chat** (global rollout from Jan 2026), which then age-groups chat to limit adult↔minor contact. New account types rolling out from June 2026: **Roblox Kids (5–8)** and **Roblox Select (9–15)** with curated games; parental controls now extend to age 15. `[V]`
**Official:** about.roblox.com/parental-controls · about.roblox.com/age-estimation

---

## 7. Discord

**What it is — Family Centre.** Opt-in both sides (up to 8 teens per guardian). You get a 7-day activity feed + weekly email: new friends added, servers joined/created (names, icons, member counts), who they messaged/called, and total call minutes — **names and metadata only, never message content**; no purchases data. `[V]` *(verified vs Discord help, Jun 2026)*

**Check these:**
- **Set up** — mobile app → User Settings → **Family Centre** → enable → scan the teen's QR. `[V]`
- **Sensitive-content filter** — for UK teens only **blur or block** is available ("show" is removed by UK rule). `[V]`
- **Friend requests** — restrict to friends-of-friends / server members. `[V]`
- **Server DMs** — toggle whether server members can DM them. `[V]`
- **Message requests** — filters non-friends into a separate folder (changing this needs an **age-verified adult** in the UK). `[V]`
- **Data & privacy** — turn off personalised-data and sponsored-content personalisation. `[V]`
- Once linked, **the teen can't change these themselves** — only you, in Family Centre. `[V]`

**Age:** 13+. UK age checks (face scan or ID) introduced July 2025; accounts treated as "teen by default" until verified adult. The verification vendor/flow has been in flux — `[PV]`, re-check.
**Official:** support.discord.com (Family Centre article) · UK age-assurance help article.

---

## 8. WhatsApp

**What it is:** **no parental dashboard for 13+** — control is via privacy settings + the device layer + conversation. (A parent-managed account exists for **under-13s** only, and even then parents can't read chats — it's end-to-end encrypted.) `[PV]`

**Check these (Settings → Privacy):**
- **Groups → My Contacts** so strangers can't add your child to group chats. `[V]`
- **Last seen / Online**, **Profile photo**, **About** → My Contacts / Nobody. `[PV]`
- **Two-step verification** (Settings → Account) → on. `[V]`
- Turn **live location** off; review disappearing-message settings per chat. `[PV]`
- Teach blocking/reporting unknown numbers (messages from unknown contacts can be filtered). `[PV]`

**Age:** UK minimum **13** (lowered from 16 in April 2024 — the old "16" is outdated). Self-declared, no verification. `[V]`
**Official:** faq.whatsapp.com

---

## 9. Fortnite / Epic Games

**What it is — Cabined Accounts + parental controls.** Under-13s get **Cabined Accounts** that block chat, purchases and adding friends until a parent consents by email; setting up parental controls lifts the cabin. `[V]`

**Check these:**
- **Set up Parental Controls** — sign into the child's account at the Epic Account Portal (or in-game Settings → Parental Controls) → set a **6-digit PIN**. `[V]`
- **Voice & text chat** — set who they can chat with. `[V]`
- **Require PIN for purchases**; review spend. `[V]`
- **Mature-language filter** — on by default for under-13s in text chat (and for all players in Game Channels); 13+ can switch it on. `[V]` *(verified vs Epic, Jun 2026)*
- **Daily email reports** when settings change — opt in. `[V]`

**Age:** Cabined threshold is under-13 in the UK. `[V]` Epic uses age-estimation in some flows (`[NV]` UK method).
**Official:** safety.epicgames.com/en-US/parental-controls · epicgames.com/site/en-US/cabinedaccounts

---

## 10. YouTube / YouTube Kids

**What it is — two tiers:** **YouTube Kids** (separate app for under-13s, curated, age profiles) and **supervised accounts** on main YouTube (managed via in-app Family Centre or Google Family Link). For most UK 13+ teens on standard YouTube, the realistic control is the **device layer (Family Link / Screen Time)**. `[V]`

**Check these (supervised main YouTube):**
- **Content level** — Explore (≈9+) / Explore More (≈13+) / Most of YouTube. `[V]`
- **Disable Autoplay**; **pause/clear watch & search history**. `[V]`
- **Shorts daily limit** — from March 2026 can be set to **zero**. `[V]`
- **Take-a-break / bedtime reminders.** `[V]`
- In **YouTube Kids**: content level, search on/off, timer, approved-content-only mode. `[V]`

**Age:** main account 13+; under-13s should use YouTube Kids or a supervised account. `[V]`
**Official:** support.google.com/youtube/answer/13877231 · YouTube Kids: support.google.com/youtubekids

---

## Cross-cutting notes (put these in the parent's plan)

- **Set the device layer first.** It's the backstop that works even when an app's own controls are bypassed.
- **Bypass routes to know about:** second/"finsta" accounts, using the mobile *browser* instead of the app (defeats TikTok pairing), and shared-device confusion. Device-level controls catch most of this. `[V]`
- **The dashboards show "who," not "what."** They're for noticing patterns and starting conversations — not surveillance, and not a guarantee.
- **Re-check after updates.** Apps change settings constantly; a 10-minute re-check each school term is the habit (this is exactly what the *Stay Current* membership automates).

*Items most likely to have moved since June 2026 and worth re-verifying in-app: TikTok menu labels, Snapchat iOS-vs-Android labels, Discord's UK age-verification flow, WhatsApp's under-13 account availability, and the AI age-estimation rollouts on Instagram/YouTube/Roblox.* `[PV]`/`[NV]`
