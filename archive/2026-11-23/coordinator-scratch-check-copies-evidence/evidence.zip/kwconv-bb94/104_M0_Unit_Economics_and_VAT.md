# 104 — M0 Unit-Economics Checkpoint & VAT Note

**Status:** M0 pre-work deliverable. *"Written down before the first sale, revisited after the pilot cohort"* (plan `100_Automated_Build_Plan.md` §1 M0, line 41; M0-done condition, line 241).
**Product:** automated Keepwise — £49 one-off VAT-inclusive pilot price + £29/yr "Stay Current" renewal; no founding pricing, no Concierge, no per-customer human labour (`99_Automated_Offering_Design.md` §4.2; `100` §1).
**Every number below is pre-registration-of-a-forecast, not a promise.** All modelling assumptions are tagged `[ASSUMPTION]` and are the things the pilot cohort exists to falsify.
**British English throughout. Currency £. VAT-inclusive prices unless stated.**

---

## 0. One-screen summary

| Line | Figure | Basis |
|---|---|---|
| **Gross price (one-off)** | £49.00 | VAT-inclusive, pre-registration (`99` §4.2) |
| Stripe fee | −£0.94 | 1.5% + 20p UK standard card (verified 2026) |
| Refund/chargeback budget | −£2.94 | 6% of gross (`100` §5 B0; break-glass `99` §7.2) |
| Support (bounded est.) | −£1.67 | 4 min/cust @ £25/hr `[ASSUMPTION]` |
| **Net contribution / one-off sale** | **≈ £43.46** | after all four deductions |
| *(memo: net excl. support)* | *£45.13* | *reconciles to `99` §4.3's £45.20* |
| **Net contribution / £29 renewal** | **≈ £24.96** | 4 min support; £26.62 excl. support |
| **Break-even sales/yr** (recurring fixed only) | **≈ 460–710** | editorial £20–30k ÷ £43.46 |
| **VAT threshold crossing** | **≈ 1,837 sales** | £90,000 gross ÷ £49 |
| **VAT revisit trigger** | trailing-12-mo gross **£75,000** | ≈ 1,531 sales — decision *logged, not decided* |
| **Net if £49 held post-registration** | **£40.83** | £49 × 5⁄6 (ex-VAT), matches `100` line 241 |
| **CAC ceiling (one-off net)** | **≈ £43** | was £45–52 in `99` §4.3 — see §6, adjusted down for support |
| **THE RENEWAL WRINKLE** | **≈ 751–1,127 renewals/yr** to self-fund the currency layer at £29 | vs **≈ 368–552** at the old £59 — **~2× the renewals** (§3) |

**The one thing to carry out of this document:** the maths of the one-off is comfortable; **the £29 renewal, not the £49 sale, is the number that decides whether the editorial-currency promise survives.** At £29 the currency layer needs roughly **twice** the renewals it needed at £59, and at realistic year-1 cohort sizes that is a **watch-item, not a solved problem** (§3, cross-ref `99` §7.2 break-glass condition 3).

---

## 1. Verified external facts (July 2026)

| Fact | Value | Verified |
|---|---|---|
| UK VAT registration threshold | **£90,000** rolling-12-month taxable turnover | Unchanged since 1 Apr 2024; confirmed still £90k for 2026/27 (HMRC / FreeAgent / Commons Library — §7) |
| UK VAT de-registration threshold | £88,000 | same sources |
| UK VAT standard rate | **20%** | unchanged |
| Stripe UK standard card fee | **1.5% + £0.20** per domestic UK card | stripe.com/gb/pricing, corroborated 2026 (§7) |

Two riders on Stripe, both `[ASSUMPTION]`-adjacent facts to confirm at B0:
- **EU/EEA cards cost 2.5% + 20p; non-UK/EEA cards 3.25% + 20p.** The model below assumes ~100% UK-issued cards. A meaningful overseas mix would raise the effective fee — re-check the actual card-country split after the pilot. `[ASSUMPTION]`
- **Once VAT-registered, Stripe charges 20% VAT *on its own fee*.** Recoverable as input VAT once registered, so it is *not* a permanent cost — but it is a cash-flow line to note (§4). Pre-registration it is not charged to a non-registered UK business at the standard domestic rate in the way that affects contribution here; treated as immaterial pre-threshold. `[ASSUMPTION]` — confirm with accountant at B0.

---

## 2. Per-sale waterfall

### 2.1 One-off at £49 (VAT-inclusive, pre-registration)

| Step | £ | Note |
|---|---|---|
| Gross | **49.00** | VAT-inclusive; no output VAT payable while below threshold |
| − Stripe fee | −0.94 | 1.5% × 49 = 0.735; + 0.20 = 0.935 → **£0.94** |
| − Refund/chargeback budget @ 6% | −2.94 | 6% of gross. This is a *budgeted reserve* across the cohort, not a per-sale certainty; expressed per-sale for the waterfall. Chargebacks also carry Stripe's £20 dispute fee if contested — a further reason to refund fast rather than fight (`[ASSUMPTION]`: contest rate low). |
| − Support (bounded) | −1.67 | see §2.3 |
| **= Net contribution / sale** | **≈ 43.46** | |

*Memo:* excluding support, £45.13 — which reconciles to the **£45.20** headline in `99` §4.3 (line 134) and the "~£45 net" used throughout `99`. The difference is that `99`'s table deducts Stripe + refund but not support; this checkpoint adds a support line because **an automated product still generates human email** (see §2.3). Both figures are correct for their stated scope.

### 2.2 Renewal at £29 (VAT-inclusive)

| Step | £ | Note |
|---|---|---|
| Gross | **29.00** | |
| − Stripe fee | −0.64 | 1.5% × 29 = 0.435; + 0.20 = 0.635 |
| − Refund/chargeback @ 6% | −1.74 | same budget basis; renewals likely refund *less* than cold one-offs `[ASSUMPTION]` — 6% is conservative here |
| − Support (bounded) | −1.67 | assume same minutes/renewal `[ASSUMPTION]`; probably lower for a warm customer |
| **= Net contribution / renewal** | **≈ 24.96** | £26.62 excluding support (matches `99` §4.3 line 136's ~£26.60) |

### 2.3 The support estimate — bounded process, not a guess

The product is automated (block-assembly, no runtime LLM, no per-customer human labour — `99` §1; `100` §7.5). **But humans email anyway**: "my plan didn't arrive", "how do I delete my data", "the wizard link is broken", "can I get a refund". The support cost is real even at zero *designed* labour.

Bounded estimate:
- **Minutes per customer** `[ASSUMPTION]`: **4 min** blended average across the whole cohort. Rationale: most customers (est. 80–90%) generate *zero* contact; a minority generate a 10–20 min exchange (refund, deletion request, delivery failure). 4 min blended is the midpoint of a 3–6 min range.
- **£/hr basis** `[ASSUMPTION]`: **£25/hr** — founder-equivalent / part-time VA rate. (A VA is ~£12–18/hr; founder opportunity cost is higher; £25 is a deliberately un-generous midpoint so the net isn't flattered.)
- **Cost = 4/60 × £25 = £1.67/customer.**

Sensitivity (this line is the softest in the model):

| Minutes | @ £20/hr | @ £25/hr | @ £30/hr |
|---|---|---|---|
| 3 min | £1.00 | £1.25 | £1.50 |
| **4 min** | £1.33 | **£1.67** | £2.00 |
| 6 min | £2.00 | £2.50 | £3.00 |

Even the worst cell (£3.00) only moves the one-off net from £43.46 to ~£42.13 — support is a real line but **not** where the model lives or dies. **Revisit after the pilot with actual ticket volume × actual handle time.** If deletion requests or delivery failures run hot, this line and the refund line both move together — watch them as a pair.

---

## 3. Break-even, and THE RENEWAL WRINKLE

### 3.1 One-off break-even (recurring fixed costs only)

Recurring fixed cost = editorial currency £20–30k/yr (`99` §4.5; `100` §1) + hosting/email ≈ £0–840/yr (§4). Net contribution £43.46/sale.

| Editorial | + hosting hi | Break-even sales/yr |
|---|---|---|
| £20,000 | £20,840 | **≈ 460–480** |
| £25,000 | £25,840 | ≈ 575–595 |
| £30,000 | £30,840 | **≈ 690–710** |

So **the one-off business covers its recurring fixed costs at roughly 460–710 sales/year** — inside the "Base" year-2/3 volumes of `99` §4.5 (400/1,200/2,800 new customers) and above the Conservative case. This is comfortable and unsurprising.

### 3.2 The renewal wrinkle — stated prominently

**The editorial-currency layer (£20–30k/yr) is the cost of the *kept-current* promise — the Digest, the six-month platform review, the twelve-month concern review (`100` §1.6). That promise is what the £29/yr renewal is sold to fund (`99` §4.2, line 128).** So the honest question is not "does the £49 cover editorial?" (at scale, yes) — it is **"can the £29 renewal stream self-fund the currency layer?"**

At £29, net contribution/renewal ≈ **£26.62** (excl. support; the figure `99` uses). The old model priced renewal at **£59** (≈ £54.38 net). Because the renewal net roughly halved, **the number of renewals needed to self-fund the same editorial cost roughly doubled:**

| Editorial to self-fund | Renewals needed @ **£29** (£26.62 net) | Renewals needed @ old **£59** (£54.38 net) |
|---|---|---|
| £20,000 | **≈ 751** | ≈ 368 |
| £25,000 | **≈ 939** | ≈ 460 |
| £30,000 | **≈ 1,127** | ≈ 552 |

**Ratio ≈ 2.04× — halving the renewal price doubles the renewals the currency layer needs to pay for itself.** (The brief's stated ~690–1,035 vs ~430 range is the same finding at slightly tighter editorial assumptions; on a strict £20–30k band with 6%-refund nets the figures are ~751–1,127 vs ~368–552. Same conclusion, sharper numbers.) *If support is deducted from renewal net too (£24.96), the £29 requirement rises further to ~801–1,202 — so 751–1,127 is the optimistic edge of the range.*

### 3.3 What renewal *conversion rate* that implies — the watch-item

Renewals only exist from customers acquired in prior years. Mapping the "renewals needed" onto the year-1 cohort sizes in `99` §4.5 (Conservative/Base/Strong Y1 = 150 / 400 / 800 new customers) shows the trap:

| Editorial | Renewals needed | ÷ Consv Y1 (150) | ÷ Base Y1 (400) | ÷ Strong Y1 (800) | ÷ Base cum. Y2 pool (~1,600) | ÷ Strong cum. Y2 pool (~3,800) |
|---|---|---|---|---|---|---|
| £20k | ~751 | 501% ✗ | 188% ✗ | 94% ✗ | **47%** | **20%** |
| £25k | ~939 | 626% ✗ | 235% ✗ | 117% ✗ | 59% | 25% |
| £30k | ~1,127 | 751% ✗ | 282% ✗ | 141% ✗ | 70% | 30% |

**Reading this table:** against the *first-year* cohort alone, self-funding the currency layer from £29 renewals demands conversion rates of 94% → 750% — i.e. **impossible in years 1–2.** It only becomes achievable once a *cumulative* renewal pool has built up (Base ~47–70%, Strong ~20–30% of the pool renewing). And note the break-glass line: `99` §7.2 condition 3 fires if **renewal opt-in falls below ~15% once the first digests go out** — below which "the editorial fixed cost sinks the model at every volume below ~5,000" (`99` line 215).

**Therefore, for the pilot and the first two trading years, the editorial currency is founder-sweat / cross-subsidised by one-off contribution — exactly as `99` §4.5 line 160 states ("year 1 founder-sweat; editorial covered from Y2 in the Base case").** The £29 renewal does **not** carry the currency layer early; the £49 one-off does (§3.1 shows 460–710 one-offs cover it).

### 3.4 Watch-item logged for the pilot

- **Measure:** renewal opt-in % once the first digests ship (`99` §7.2 condition 3 threshold = 15%).
- **Break-glass cross-ref:** `99` §7.2 — any *two* of five conditions firing within six months ⇒ drop to £29 one-off; renewal-below-15% is condition 3.
- **The specific danger of the £29 decision:** it is defensible *because* the one-off funds editorial early — but it permanently moves the renewal-driven self-funding point out to a much larger cumulative base. **If growth stalls before the cumulative pool reaches ~1,500–3,800 renewing accounts, the currency promise is structurally founder-subsidised, not self-funding.** That is an accepted, eyes-open cost of the £29 choice — logged here so a future cut is data, not fear.

---

## 4. Fixed-cost amortisation

**Recurring, annual:**
- **Editorial currency: £20,000–£30,000/yr** equivalent (`99` §4.5; `100` §1). Year-1 largely founder-sweat.
- **Hosting/email: ≈ £0–£70/month → £0–£840/yr** (`100` §7 line 69: Vercel + Supabase + Resend + Stripe ≈ £0–70/mo to low-thousands of customers; no runtime LLM). `[ASSUMPTION — confirm current tiers before commit; per 100 line 69 [INF]]`

**One-off, year-1 only (external gate reviews — cash, not hours; `100` line 225):**
- **Safeguarding / block-library review (Gate A):** **£1,500–£4,000** `[ASSUMPTION — estimate to confirm]`
- **Solicitor Gate B0 (privacy/terms/checkout/data-model launch review):** **£1,000–£3,000** `[ASSUMPTION — estimate to confirm]`
- Combined one-off: **£2,500–£7,000**, incurred once before first sale, not recurring.

### Amortisation table

Recurring fixed (editorial + hosting) and the year-1 one-off review loading, spread across customers-in-a-year:

| Customers/yr | Recurring per-cust (lo → hi) | Yr-1 one-off review loading (lo → hi) | As % of £43.46 net (recurring lo → hi) |
|---|---|---|---|
| **100** | £200.00 → £308.40 | £25.00 → £70.00 | 460% → 710% — **deeply loss-making** |
| **300** | £66.67 → £102.80 | £8.33 → £23.33 | 153% → 237% — still under water |
| **1,000** | £20.00 → £30.84 | £2.50 → £7.00 | 46% → 71% — **profitable** |
| **5,000** | £4.00 → £6.17 | £0.50 → £1.40 | 9% → 14% — fixed cost near-irrelevant (matches `99` §4.5 "Fully funded, <10% of net") |

**Reading it:** below ~460 customers/yr the recurring fixed cost exceeds net contribution and the business is loss-making on fixed cost alone (this is the §3.1 break-even restated per-customer). The one-off review loading is only material at pilot scale (£25–70/customer at n=100) and vanishes by n=1,000 — **do not let the one-off gate costs deter the pilot; they amortise away fast.**

---

## 5. VAT

### 5.1 Threshold crossing table

At £49 VAT-inclusive, each sale is £49 of taxable turnover pre-registration.

| Rolling-12-month gross | Sales at £49 | Status |
|---|---|---|
| £75,000 | **≈ 1,531** | **Revisit trigger** — begin VAT decision work (headroom to threshold ≈ 306 sales) |
| £88,000 | ≈ 1,796 | De-registration threshold (reference) |
| **£90,000** | **≈ 1,837** | **Must register** — output VAT now due on sales |

The 1,837-sale figure and the £40.83 held-price net below are the same numbers already logged in `100` line 241; this document is their working.

### 5.2 The three post-threshold options

Once registered, 20% output VAT is due. On a £49 VAT-inclusive price, the VAT element is £49 × 1⁄6 = **£8.17**, leaving **£40.83** ex-VAT.

| Option | Customer pays | Business keeps (ex-VAT) | Effect |
|---|---|---|---|
| **A — Hold £49 inclusive** | £49 (unchanged) | **£40.83** | Absorb the VAT: net/sale drops £45.13 → ~£40.83 (before Stripe/refund/support), i.e. **~£8 margin hit per sale**. Honest and frictionless for the customer. |
| **B — Raise to £59 inclusive** | £59 | £49.17 | Restores ~£49 ex-VAT. **Collides with Qustodio Complete £75.95/yr and re-anchors the retail brand** (`99` §4.2 line 126 warns £49 is the ceiling; £59 pushes it). A price *rise*. |
| **C — £49 + VAT (£58.80)** | £58.80 | £49.00 | Keeps full £49 ex-VAT; presents as "£49 plus VAT". Effectively a rise to the customer, same collision as B, and B2B-flavoured framing for a consumer product. |

**CPR / honesty rider:** any price change at the threshold **must be honest** — no "was £49, now £59" implying a discount lapsed, no burying VAT. Under the Consumer Protection from Unfair Trading Regs (and the claims regime in `100` §1.6/§1.9), the change must be presented as what it is: a VAT-registration price adjustment. The claims-lint and honesty rule apply to price copy as they do to product copy.

### 5.3 Decision: LOGGED, NOT DECIDED

- **This is not decided here** (matches `100` line 241: "decision point logged").
- **Revisit trigger:** trailing-12-month gross reaches **£75,000** (≈ 1,531 sales) — ~£15k / ~306 sales of headroom before the £90k line, enough to make the choice deliberately rather than in a panic.
- **Default lean (not a decision):** Option A (hold £49, absorb to £40.83) preserves the impulse price and the funnel-width thesis the whole pivot rests on (`99` §4.4); the ~£8/sale hit is survivable at the volumes that get you to the threshold. But the choice is the founder's, made at the trigger, on the actual margin and channel data then.
- Cross-ref `100` §5 B0 line 197: the VAT position note is part of the Gate B0 launch pack.

---

## 6. CAC ceilings recomputed at the £49 net

`99` §4.3 (line 138) set **break-even CAC ≈ £45 on the one-off alone; ≈ £52 with modest renewal LTV** (25% renew once). Those figures used the £45.20 net (no support line).

Recomputing on this checkpoint's **£43.46** net (support included):

| Basis | `99` §4.3 figure | This checkpoint | Why it moved |
|---|---|---|---|
| One-off net alone | £45 | **≈ £43.46** | support line (−£1.67) added |
| + modest renewal LTV (25% renew once @ £24.96 net) `[ASSUMPTION]` | £52 | **≈ £49.70** | £43.46 + 0.25 × £24.96 = £49.70; slightly lower because both the base net and the renewal net now carry support |

**So the honest CAC ceiling is ~£43 (one-off) to ~£50 (with renewal LTV)** — about **£1.50–£2.30 lower** than `99`'s £45–£52 headline, entirely because of the support line. **This does not change any conclusion in `99` §4.4:** UK Meta CPC ~£1.11 median still implies ~39 affordable clicks/sale at a £43 ceiling (needing ≥~2.6% cold-click-to-purchase vs the ~2.5% in `99`), and the break-glass CAC trip-wire of **~£45 not falling** (`99` §7.2 condition 4) is unchanged. Paid social remains *reachable, not a fountain* — the £2 shift is inside the noise of the CPC assumption. If VAT registration later forces Option A (net → ~£40.83 pre-Stripe/support ⇒ ~£38–39 all-in), the CAC ceiling tightens to ~£38–40 and paid social gets *materially* harder — **a second reason the VAT decision (§5) and the acquisition model are linked, and both are pilot watch-items.**

---

## 7. Sources

**External (verified July 2026):**
- UK VAT registration threshold £90,000 / standard rate 20% (unchanged since Apr 2024):
  - [House of Commons Library — VAT Registration briefing](https://commonslibrary.parliament.uk/research-briefings/sn00963/)
  - [FreeAgent — UK VAT rates and thresholds 2026/27](https://www.freeagent.com/rates/vat/)
  - [Xero UK — VAT registration thresholds](https://www.xero.com/uk/guides/vat-registration-thresholds/)
- Stripe UK standard card fee 1.5% + £0.20:
  - [Stripe — Pricing & Fees](https://stripe.com/pricing) (GB: stripe.com/gb/pricing)
  - [We Are Founders — Stripe Fees UK 2026 (1.5% + 20p)](https://www.wearefounders.uk/stripe-fees-uk-2026/)

**Internal (repo facts cited by file/line):**
- `99_Automated_Offering_Design.md` — §4.2 pricing (line 118, 124, 126); §4.3 unit economics table (lines 130–138); §4.4 CAC/channels (lines 144–147); §4.5 three-year scenarios & cohort sizes (lines 149–163); §7.2 break-glass conditions (lines 209–219); hosting/email cost (line 69 cross-ref via 100).
- `100_Automated_Build_Plan.md` — §1 M0 unit-economics checkpoint mandate (line 41); §1.6 kept-current bounded claim (line 20); §1.9 enumerated data promise + sibling-count minimisation (line 24); running costs £0–70/mo (line 69); Gate B0 VAT position note in launch pack (line 197); external gate costs are cash not hours (line 225); M0-done VAT/pricing note "£49 VAT-inclusive; ~1,837-sale threshold; ~£40.83 net if held; decision point logged" + unit-economics checkpoint (line 241).
- `101_Tool_Build_Specs.md` — tool build specs (referenced for scope; no economics figures drawn from it).

---

*This checkpoint is a M0 pre-sale artefact. Every `[ASSUMPTION]` above — support minutes and rate, refund/chargeback realism, card-country mix, editorial cost point within the £20–30k band, external review quotes, hosting tier, renewal-LTV persistence — is a variable the pilot cohort exists to replace with a measured number. Revisit this whole document after the pilot cohort before scaling spend.*
