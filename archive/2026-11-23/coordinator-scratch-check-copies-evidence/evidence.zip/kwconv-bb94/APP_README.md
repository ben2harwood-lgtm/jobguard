# Keepwise — application

The coded product that delivers the content package in this repo. Built to
`21_MASTER_BUILD_SPEC.md`; content files `00`–`20` are the copy source of truth.

> **Status: Fable audit-ready preview.** The public app journey, readiness quiz,
> safety-check flow, pricing, checkout handoff pages, locked library shell,
> emergency signpost, concierge/schools forms, and guardrail tests are wired. The
> backend commerce/auth/delivery layers still depend on external account setup and
> later milestone work.

## Stack (spec §4)

Next.js (App Router) + TypeScript · Tailwind (preflight off; the canonical visual
system is `app/brand.css`) ·
Supabase/Postgres · Plausible (cookieless) + an `events` table · Vitest.
Stripe webhooks / Resend arrive in later milestones. Stripe Payment Link handoff
routes are wired now: set `STRIPE_PAYMENT_LINK_SYSTEM`,
`STRIPE_PAYMENT_LINK_SYSTEM_FOUNDING`, and `STRIPE_PAYMENT_LINK_STAY_CURRENT` to
make the checkout buttons leave the preview fallback and open Stripe.

## Run it

```bash
npm install
npm run dev          # http://localhost:3000
```

No secrets are needed for M1. Without `SUPABASE_*` the event/quiz API no-ops
gracefully; without `NEXT_PUBLIC_PLAUSIBLE_DOMAIN` the Plausible script is omitted.
Copy `.env.example` → `.env.local` to switch any layer on. See `supabase/schema.sql`
for the database (run it once Supabase is provisioned).

## Verify (what CI runs)

```bash
npm run content-lint   # negation-aware efficacy/fear/coaching lint (spec §10.3)
npm run typecheck
npm test               # guardrail + unit suite (Vitest)
npm run build          # prebuild re-runs the content lint, so the build fails on a violation
```

CI (`.github/workflows/ci.yml`) runs all four on every push/PR. It is green only
when every guardrail passes legitimately.

## Routes

`/` · `/how-it-works` · `/pricing` · `/sample` · `/for-schools` · `/concierge` ·
`/checkout/system` · `/checkout/stay-current` · `/privacy` · `/terms` ·
`/emergency` (ungated) · `/quiz`. API: `/api/events`, `/api/quiz`,
`/api/schools`, `/api/concierge`.

Paid-library tools include `/library/first-phone`, a locally saved first-phone
setup, agreement and three-day check-in walkthrough.

## Guardrails enforced as hard build constraints (spec §2)

- **Content lint** — `lib/content-lint.mjs` (shared by CI + tests). Sentence-level
  negation-aware; allow-list in `content-lint.allow.json`. Fails the build on any
  non-negated, non-allow-listed efficacy / fear / "coaching" phrase.
- **No child-identifiable data** — `lib/pii.ts`; every API route rejects payloads
  with child-PII keys. Age is a band only.
- **No user-to-user features / no child accounts** — enforced by
  `tests/guardrails-structure.test.ts` (no forum/chat/messages/comments/community/
  profile/child/kids routes).
- **Emergency = signpost only** — `/emergency` is ungated, has no upsell, uses a
  minimal header/footer, and links only to official UK authorities. Linked in the
  global footer site-wide.
- **Plan-safety** — a static test asserts no non-admin code marks a plan
  `delivered` (becomes load-bearing in M3).
- **Concierge is not self-serve** — a test asserts no `STRIPE_PRICE_CONCIERGE` env
  is referenced.

## Configurable tokens (the three open founder decisions — spec §14)

These are placeholders so the decisions drop in later without touching logic:

- **Brand / domain** — `lib/brand.ts`, overridable via `NEXT_PUBLIC_BRAND_*` env.
  Working brand is "Keepwise".
- **Price** — `lib/pricing.ts`, overridable via `NEXT_PUBLIC_PRICE_*` env. Display
  only; Stripe is authoritative in M2.
- **Solicitor sign-off** — `/terms` is a plain-English summary + a clearly-labelled
  solicitor-review placeholder. A launch gate, not a code blocker.

## Latest local verification

Checked 2026-07-02:

- `npm run content-lint` passed across 92 files.
- `npm run typecheck` passed.
- `npm test` passed: 7 files, 286 tests.
- `npm run build` passed and generated 24 routes.
