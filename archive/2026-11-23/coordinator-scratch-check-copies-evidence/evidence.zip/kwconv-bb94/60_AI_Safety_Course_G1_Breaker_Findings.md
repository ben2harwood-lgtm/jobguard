# AI Safety Course - G1 Breaker Findings

*Created 2026-06-27. Cross-model adversarial review of the Phase 1 evidence layer (`57_AI_Safety_Course_Claim_Register.md`, `58_AI_Safety_Course_Gap_Register.md`) against the G1 Breaker Brief. This is an adversarial evidence review to prepare for human gates. It is not legal, safeguarding, or clinical advice, and it does not design the course or write downstream content.*

## What Claude Verified During This Pass

**Verified and cleared:**

- KCSIE is the 2025 edition, in force from 1 September 2025. The register's "Annual update" flag on KCSIE rows is correct. Note a September 2026 edition is likely, and new RSHE guidance covering deepfakes and online harms comes into force 1 September 2026.
- The CEOP reporting route is live and operates as part of the National Crime Agency. The cited route resolves.
- The Online Safety Act is in force and Ofcom is the regulator. CSEA reporting duties for in-scope providers commenced 7 April 2026. The "platform responsibility, not a guarantee" framing is current.
- The DfE generative-AI guidance documents exist, with the exact current title and URL still requiring pre-launch re-check.

**Verified and found defective:** the adult scope of the Data (Use and Access) Act purported-intimate-image provisions, the Action Fraud / Report Fraud service name, and the need for tighter child-image preservation wording.

## Findings

| Severity | Claim ID / Gap ID | Problem | Why it matters | Recommended action |
|---|---|---|---|---|
| **Blocker** | GRM-004; also HCM-003, RTE-007, SMI-006 | "Preserve what you safely can" and "save only what is safe" are not carved out from suspected nude or sexual images of under-18s. | Retaining, screenshotting, copying, downloading or forwarding an indecent image of a child may itself be legally serious. A downstream builder could turn this into unsafe "screenshot it for the police" copy. | Patch all incident rows so suspected nude or sexual images of under-18s are never saved, screenshotted, copied, downloaded or forwarded. Restrict "preserve" language to non-image contexts and route immediately. |
| **Major** | SMI-002, SMI-003, S16 | The Data (Use and Access) Act 2025 purported-intimate-image provisions are adult-scoped and cannot alone ground under-18 image claims. | A child-image claim could be supported by the wrong legal source. | Add child-image-specific legal sources, keep legal wording cautious, and send to human legal review. |
| **Major** | S14; SCF-001, SCF-002, SCF-003, SCF-004, RTE-005, HAW-003 | Fraud routing uses "Action Fraud / Report Fraud". Claude reported that Action Fraud has been replaced by Report Fraud, with jurisdiction nuance. | Routing accuracy and currency. | Lead with Report Fraud, keep "formerly Action Fraud" only as context, and add Scotland 101 caveat. |
| **Major** | S02 and rows citing it | Claude flagged a possible title/URL defect for the DfE product-safety source and noted it should not be treated as binding consumer law. | S02 is heavily cited, so broken traceability would affect many rows. | Re-check exact title and URL before launch. Mark as non-binding product guidance/expectations, not a legal duty or guarantee. |
| **Major** | SMI-001, PRI-001, PRI-002, PRI-005, VBT-003, HAW-003, HAW-004, SCF-001, SCF-002, SCF-003 | Several rows route to safeguarding/legal services or make data-protection claims but had Review flag = `none`. | Builders could read an unflagged row as already cleared. | Add [SAFEGUARDING REVIEW] for routing rows and [LEGAL REVIEW] for data-protection/legal-substance rows. |
| **Major** | RTE-003; also SMI-002 routing, S09, S10 | Report Remove, IWF reporting, and CEOP are different routes with different functions and eligibility. | A parent could be sent to the wrong route. | Map each service to its function and age eligibility; avoid using IWF, Report Remove, and CEOP interchangeably. |
| **Major** | VBT-001, HCM-004, GAP-007 | Checklist rows could be built as scam, grooming or deepfake identification tools. | That creates the false-reassurance failure mode the brief excludes. | Add an explicit "supports a pause and routing decision, never a verdict" constraint. |
| **Major** | AIC-003, ORW-004, GAP-004 | Watchpoint lists could become a scored or diagnostic quiz. | This would breach the no-clinical-assessment line. | Keep watchpoints as conversation prompts only, never a scored profile or diagnosis. |
| **Major** | PRI-003, PRI-004 | Data-minimisation wording could become a compliance claim about the course. | "GDPR compliant" or similar would be a legal conclusion. | Add [LEGAL REVIEW] and phrase as design intent, not compliance determination. |
| **Minor** | SMI-005, AIC-004, GRM-003, PRI-005 | Age bands may be read as evidence-derived thresholds. | S17 is developmental/social-media evidence, not AI-specific UK age-band proof. | State that bands are practical design conventions, not measured cutoffs. |
| **Minor** | SMI-004 and "prevention" naming | "Prevention module" could be read as outcome efficacy. | GAP-001 bars efficacy claims. | Treat "prevention" as topic framing, not a promised outcome. |
| **Minor** | GRM-001 | "AI can amplify contact risk" may imply a measured increase. | The source supports mechanism more than prevalence. | Reword to "can make impersonation or contact attempts more convincing." |
| **Minor** | Whole register | "Threat area" values 1-9 can visually collide with Tier values. | A careless reader or script could confuse threat area with source tier. | Consider renaming threat-area values TA1-TA9 in a later clean-up. |
| **Minor** | RTE-002 and CEOP rows | CEOP scope limits are not explicit. | CEOP is for grooming and online sexual abuse, not every online harm. | Add scope language wherever CEOP is routed. |

## G1 Verdict

**Fail as written, narrowly.** One Blocker was open when Claude reviewed the files: the lack of a child-image carve-out around "preserve" or "save" language. With that fixed, the layer moves toward **Pass with required patches**, but it still needs human legal and safeguarding review before it becomes canonical.

## Claims To Move Or Add To Gap Register

- Any claim that a parent should preserve or save evidence in suspected under-18 nude or sexual-image incidents.
- Any under-18 legal-basis element that relies only on the adult-scoped Data (Use and Access) Act purported-intimate-image provisions.
- Any assumption that routing service names and eligibility will stay stable without a living-update process.

## Claims Needing Human Legal Review

SMI-002, SMI-003, RTE-003, the new child-image preservation carve-out, PRI-003, PRI-004, HCM-002, and RTE-008.

## Claims Needing Human Safeguarding Review

All rows already flagged, plus SMI-001, PRI-001, PRI-002, PRI-005, VBT-003, HAW-003, HAW-004, SCF-001, SCF-002, SCF-003, SMI-006, GRM-004, HCM-003, RTE-007, AIC-003, and ORW-004.

## Fast-Moving Claims Needing Pre-Launch Re-Check

- Report Fraud service details: name, URL, phone, jurisdiction.
- Data (Use and Access) Act 2025 purported-intimate-image provisions, including adult scope and commencement.
- Ofcom Online Safety Act child-protection duties and codes.
- CEOP, IWF, and Report Remove URLs and eligibility.
- NSPCC and Childline helpline hours.
- KCSIE edition and new RSHE guidance timing.
- JCQ AI-in-assessments guidance.
- Platform and product behaviour, which should remain outside static content unless maintained through the living update stream.
