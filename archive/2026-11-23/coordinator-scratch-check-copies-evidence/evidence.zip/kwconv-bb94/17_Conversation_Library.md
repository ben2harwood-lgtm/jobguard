# Conversation Library

**The paid differentiator. Free sites tell parents to "have the conversation"; this gives them the actual words — warm, specific, non-cringe, and tuned to a child's age.** Built on CEOP/Thinkuknow, NSPCC, Internet Matters and adolescent-development research. Confidence: `[V]` verified to a named source · `[PV]` partly verified · principle-based scripts are crafted from verified principles.

---

## The one idea behind all of it

What a parent actually *knows* about their child's online life depends far more on the child **choosing to tell them** than on any monitoring or control (Kerr & Stattin's landmark finding on parental knowledge). `[V]` So every script below is, underneath, a way to make your child more likely to come to you. Warmth beats surveillance — not as a nicety, but because it works.

---

## Ten principles (the evidence-based do's and don'ts)

1. **Little and often, not one "big talk."** CEOP's literal slogan is "talk little, talk often." Weave it into everyday life. `[V]`
2. **The cornerstone line: "come to me, and you won't be in trouble."** This single message defeats the threat that keeps kids silent (shame / fear of punishment). Lead with it everywhere. `[V — CEOP]`
3. **Stay calm and non-judgemental — never anger or panic.** Validate the feeling first. `[V — NSPCC]`
4. **Be curious, don't lecture. Ask, don't tell.** Take genuine interest in their games, apps and creators the way you would their offline life. `[V — Internet Matters]`
5. **Open questions beat "why."** Ask **"what happened?"** not **"why did you do that?"** — the second shuts them down. `[V — NSPCC]`
6. **No fear, shame or victim-blaming language** — even about people on TV/in the news. They're listening for how you'd react if it were them. `[V — NSPCC]`
7. **Enter sideways.** Use a TV storyline or news item as a low-stakes way in: "that thing on the show got me thinking…". `[V]`
8. **Pick a calm moment, not a flashpoint.** Not mid-argument, not when emotions are high. A car journey (no eye contact) is ideal. `[V — NSPCC]`
9. **Frame rules as safety, not control.** Say so out loud. `[V — Internet Matters]`
10. **Play and co-use builds the channel.** Knowing a bit about their world makes it far easier for them to raise a problem with you later. `[V — Internet Matters]`

---

## The "what NOT to say" card (keep this visible)

These phrases reliably shut a teenager down. Swap them:

| Don't say | Say instead |
|---|---|
| "Why did you send that / do that?" | "What happened? Talk me through it." |
| "They were so stupid to share it." (about anyone) | "That could happen to anyone — it's really common." |
| "It shouldn't have been sent in the first place." | "Let's just sort out what happens now." |
| "If anything happens I'll take your phone away." | "If anything happens, telling me won't cost you your phone." |
| "They're just attention-seeking." | "Sounds like they were really struggling." |
| "How could you be so naive?" | "These scams are designed to fool adults too." |
| "We need to talk." (ominous, scheduled) | *(raise it sideways, mid-activity, low-key)* |

The reasoning: anything that signals judgement, punishment, or blame teaches your child to handle the next problem alone. `[V — NSPCC]`

---

## How the conversation changes by age (the posture slide)

The same topic is a different conversation at 11 and at 17, because the child is developmentally different (reward-seeking peaks in mid-adolescence while self-control is still maturing; peers amplify risk most around 13–14). `[V]` The parent's posture should slide:

- **11–12 — Co-use.** Hands-on, alongside them, structured. You set things up *together* and a lot is visible.
- **13–14 — Co-set.** The threshold year. Move from "here are the limits" to "we need limits, let's agree them." Start the awkward topics in earnest. *(Flagship band — sextortion peak, peak peer-influence.)*
- **15–16 — Coach.** Supervision *with* conversation; hand over day-to-day control with a backstop; weekly check-ins.
- **17–18 — Consult.** Near-adult. Few imposed rules; you're a sounding board on footprint, scams and adult reporting routes.

---

## The conversation starters

Each gives a core opener plus how to age-tune it. Use your own words — these are scaffolding, not a script to read out.

### 1. The cornerstone — "you can always come to me" (ALL ages, use first and often)
> "If anything online ever feels weird, scary, or out of control — even if you'd broken a rule to get there — I want you to come straight to me, and you will not be in trouble. Helping you matters to me way more than any rule."

*11–12:* keep it concrete ("come and find me, even if it's embarrassing"). *17–18:* peer-to-peer ("you're nearly an adult, but that offer never expires"). `[V — CEOP]`

### 2. Show me your world (ALL — builds the channel)
> "Show me something you actually like on here — what's the funniest or best thing you've seen this week?"

`[principle — Internet Matters / Common Sense]`

### 3. New app check (11–14)
> "What app do you want to use, and what do people mainly do on it? Let's set it up together."

`[V — Common Sense opener]`

### 4. Sextortion / "the scam that targets teenagers" (13–18, especially boys)
> "There's a scam going round aimed at people your age. Someone pretends to be a teenager, gets flirty fast, gets a person to send a nude — then threatens to share it unless they pay. If that ever happens to you or a mate: **stop, don't pay, don't delete the messages, block them, and come to me.** It's never the victim's fault, and it can be fixed."

*13–14:* this is the priority conversation — have it early. *17–18:* add the adult route (they age out of Report Remove; mention StopNCII). `[V — CEOP/NCA]`

### 5. Nudes — what's okay (13–16)
> "Can I ask you something a bit awkward — what kind of photos do you reckon are okay to send or post, and what isn't? I just want to know what you already think."

`[V — NSPCC opener]`

### 6. Nudes — the pressure angle (13–18)
> "If someone ever pressured you for a picture — even someone you liked — what do you think you'd do? You can always blame me: 'my mum checks my phone' is a totally fine excuse to use."

`[principle — NSPCC]`

### 7. AI chatbots & companions (12–18)
> "Have you used any of the AI chatbot apps? Which are actually useful? One thing worth knowing — they can feel like a friend because they remember stuff, but they can't actually care about you, and they get things confidently wrong. Great for ideas; not the place to go for anything that's really worrying you. That's what people are for."

*Use it side-by-side while using one:* "Does that sound right to you? How could we check?" `[V — NSPCC / Internet Matters]`

### 8. Strangers / grooming (11–14)
> "Online, people aren't always who they say they are — someone can seem 14 and not be. Has anyone you don't know in real life ever added or messaged you? What did you do?"

Name the key red flag: *anyone who wants to move the chat to a private or disappearing app.* `[V — NSPCC / Internet Matters]`

### 9. Scams & money (12–18)
> "There are some really convincing scams aimed at people your age now — free V-Bucks, crypto 'flips', fake job DMs, 'your account's locked' messages. If something promises money or freebies for a click or a code, what's your gut say? Show me one if you get one — some are genuinely clever."

Add for 15–18: "and never let anyone use your bank account for a fee — that's money-muling, it's a crime, and it's your name on it." `[principle — Internet Matters / Action Fraud]`

### 10. Screen-time — collaborative (13–18)
> "I don't want to be the screen-time police, so let's set the limits together. What do you think is fair, and what would actually help you put it down at night?"

`[V — Internet Matters]`

### 11. Phones at night / sleep (11–16)
> "Can we find a charging spot for phones that isn't your bed? Not a punishment — there's solid evidence screens in bed wreck sleep, and I'll do it too."

`[V — sleep evidence]`

### 12. How online makes you feel (13–18)
> "Do you ever notice certain accounts or apps leave you feeling rubbish about yourself? What do you do when that happens?"

`[V — Common Sense]`

### 13. Mistakes & repair (ALL)
> "Everyone messes up online — posts something, sends something, clicks something. If it happens to you, my job isn't to lecture you, it's to help you sort it. Deal?"

`[principle — NSPCC / CEOP]`

### 14. Pornography / unrealistic sex (14–18, via a hook)
> "That storyline got me thinking — a lot of what's online about sex and bodies is pretty unrealistic. Do you and your mates ever talk about how fake some of that stuff is?"

`[V — NSPCC / Internet Matters]`

### 15. Bullying & group-chat drama (11–16)
> "Group chats can get brutal. If one ever turns on you — or someone you know — you can show me, and I won't go storming in or take your phone. We'll figure out the smart move together."

Reinforces the no-confiscation pact that keeps kids talking. `[principle — NSPCC / Ofcom]`

---

## How to use this in the product

- **Lead every age-band pack with starter #1 (the cornerstone).** It's the highest-impact line and shouldn't be buried.
- **Pair each script with its platform setting and its family-agreement clause** — conversation + setting + agreement is the "do it this weekend" bundle parents pay for.
- **Make 13–14 the most-resourced band** (threshold year).
- **Ship the "what not to say" card as a standalone one-pager** — parents value the don'ts as much as the do's, and it's instantly shareable.

*Build note: where these scripts lean on a named source's wording (CEOP #AskTheAwkward, NSPCC, Internet Matters), we visibly credit it — citing trusted authorities is part of how a paid product earns trust against free ones.*
