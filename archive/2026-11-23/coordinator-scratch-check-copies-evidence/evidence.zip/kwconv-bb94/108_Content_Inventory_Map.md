# 108 — Content Inventory and Coverage Map

**Reconciled 31 October 2026 · KW-003 · branch `feat/milestone-2` · HEAD `f91b58b6ab8d7dc05e1c2b9a0517747c5ff60867` plus the preserved working tree.**

This is the existing build-plan 100 §2 M1 / §9 traceability map, refreshed from source: `library item ↔ source MDX ↔ derived block IDs ↔ plan slots ↔ review metadata`. It is an inventory and a bounded handoff for the queued work, not a new content audit, a publication decision or a replacement ledger. The authoritative execution state remains in `docs/chat-build/KEEPWISE_QUEUE.json`.

## 1. Current counts and what they mean

| Source measure | Count / finding |
|---|---|
| Library MDX under `content/` | **51**: 19 platform guides, 25 files under `content/playbooks/` (18 playbooks and seven modules), five age-band packs, one conversation library, one currency page |
| Assembly MDX under `blocks/` | **74**: **10 marked published**, **64 draft**, zero withdrawn |
| Classes represented | All ten editable block classes; `signpost` is intentionally a locked runtime constant, not an eleventh MDX class to author |
| Block provenance | 51 blocks name an existing source MDX; 23 have `sourceFile: null` |
| Versions | 73 blocks at version 1; `fixed.footer.all` at version 2 |
| Content dates | 32 source MDX files say `updatedAt: 2026-06-20`; 19 say `2026-06-21`. These are source metadata, not evidence of an October fact-check or device test |
| Review identifiers on published blocks | Seven say `editorial` / `editorial`; three say `editorial` / `editorial-safeguarding`. All 64 drafts have null publisher/checker |
| Competent external clearance | **Not established by these metadata or this inventory.** Keep the named approval, scope, version and conditions separate from a published flag |

The previous 45-block / 12-published / 33-draft figures are superseded. Its “concern class absent” and “iMessage block absent” statements are also superseded. Existing source already contains ten concern digests and an iMessage/SMS thin block. Previous approximate 215–225/full-pool and 170–180/to-author counts are historical planning estimates, **not current quotas**. The test is missing useful coverage, after reuse and review.

`P` below means the file is marked published; `D` means draft. Neither means a feature has passed launch acceptance. `reviewBy` is the stored re-review deadline, not an independent reviewer verdict. `lib/blocks/schema.ts` and `registry.ts` enforce structural fields, dates and reviewer identifiers; a role string does not establish a person's qualifications or a Gate A approval.

### Totals by class

| Class | Files | P | D | Existing output / smallest next concern |
|---|---:|---:|---:|---|
| `open` | 4 | 1 | 3 | Summary: four openings already exist; three await review/activation. |
| `map` | 6 | 1 | 5 | Exposure notes: all six domains have a higher-band fragment; five await review/activation. The scored six-domain table exists independently. |
| `action` | 7 | 1 | 6 | Top actions: seven authored; six drafts. One published conditional action cannot supply three distinct first actions. |
| `platform` | 28 | 2 | 26 | 19 source guides plus thin/fallback blocks; only Snapchat and the generic fallback carry P flags. |
| `concern` | 10 | 0 | 10 | Ten authored digests for next-month; none activated. Reuse the 25 source playbooks/modules before adapting any additional family. |
| `band` | 5 | 1 | 4 | All five source packs and five agreement fragments exist; four fragments remain draft. |
| `conversation` | 11 | 1 | 10 | 11 assembled scripts already exist; ten drafts. The larger source conversation library also exists. |
| `calm` | 1 | 1 | 0 | One evergreen proportion block; check any additional required de-escalation pairing against actual scenario coverage. |
| `task` | 1 | 1 | 0 | One find-this-out task; use the questionnaire/scoring unknowns to identify only missing useful actions. |
| `fixed` | 1 | 1 | 0 | Footer already exists; settings checklist is derived by the renderer and emergency text is a constant. |
| **Total** | **74** | **10** | **64** | Reuse existing material before new authoring. |

## 2. Exact block register

All file links below are present in the inspected working snapshot. Trigger summaries are the predicates stored on each block; predicates are ANDed. Declared `ageBands` are metadata and do not themselves prove runtime age filtering (see §4). Slots and source provenance are recorded here without relabelling drafts as delivered coverage.

### `open`

| Block file / version | State | Slot | Source MDX | Stored predicates | reviewBy |
|---|---|---|---|---|---|
| [open.behind.all](blocks/open/open.behind.all.mdx) v1 | D | `summary` | `content/playbooks/is-this-normal.mdx` | `settings_setup` equals No one / not sure | 2027-07-06 |
| [open.on-top.all](blocks/open/open.on-top.all.mdx) v1 | D | `summary` | `content/playbooks/is-this-normal.mdx` | `knows_core_rule` equals Yes | 2027-07-06 |
| [open.reassuring.all](blocks/open/open.reassuring.all.mdx) v1 | P | `summary` | `content/playbooks/is-this-normal.mdx` | `would_tell_you` oneOf Very, Fairly | 2027-07-05 |
| [open.worried.all](blocks/open/open.worried.all.mdx) v1 | D | `summary` | `content/playbooks/is-this-normal.mdx` | `would_tell_you` oneOf Unsure, Not very | 2027-07-06 |

### `map`

| Block file / version | State | Slot | Source MDX | Stored predicates | reviewBy |
|---|---|---|---|---|---|
| [map.ai-exposure.higher](blocks/map/map.ai-exposure.higher.mdx) v1 | D | `exposure-map` | No sourceFile (fresh/thin/furniture) | `ai_tools` includes AI "companion"/character chat apps | 2027-07-06 |
| [map.contact-platform.higher](blocks/map/map.contact-platform.higher.mdx) v1 | D | `exposure-map` | No sourceFile (fresh/thin/furniture) | `accounts_private` equals No | 2027-07-06 |
| [map.device-settings.higher](blocks/map/map.device-settings.higher.mdx) v1 | D | `exposure-map` | No sourceFile (fresh/thin/furniture) | `settings_setup` equals No one / not sure | 2027-07-06 |
| [map.family-readiness.higher](blocks/map/map.family-readiness.higher.mdx) v1 | D | `exposure-map` | No sourceFile (fresh/thin/furniture) | `family_rules` equals None | 2027-07-06 |
| [map.image-location.higher](blocks/map/map.image-location.higher.mdx) v1 | D | `exposure-map` | No sourceFile (fresh/thin/furniture) | `location_sharing` equals Yes | 2027-07-06 |
| [map.threat-awareness.higher](blocks/map/map.threat-awareness.higher.mdx) v1 | P | `exposure-map` | No sourceFile (fresh/thin/furniture) | `knows_core_rule` oneOf Partly, No/Don't know | 2027-07-05 |

### `action`

| Block file / version | State | Slot | Source MDX | Stored predicates | reviewBy |
|---|---|---|---|---|---|
| [action.bedroom-overnight.all](blocks/action/action.bedroom-overnight.all.mdx) v1 | D | `top3` | No sourceFile (fresh/thin/furniture) | `device_location` equals Anywhere incl. bedroom overnight | 2027-07-06 |
| [action.core-rule.all](blocks/action/action.core-rule.all.mdx) v1 | P | `top3` | `content/playbooks/sextortion.mdx` | `knows_core_rule` oneOf Partly, No/Don't know | 2027-07-05 |
| [action.device-setup.all](blocks/action/action.device-setup.all.mdx) v1 | D | `top3` | No sourceFile (fresh/thin/furniture) | `settings_setup` oneOf No one / not sure, Came as default | 2027-07-06 |
| [action.family-agreement.all](blocks/action/action.family-agreement.all.mdx) v1 | D | `top3` | No sourceFile (fresh/thin/furniture) | `family_rules` oneOf None, Informal | 2027-07-06 |
| [action.location-off.all](blocks/action/action.location-off.all.mdx) v1 | D | `top3` | No sourceFile (fresh/thin/furniture) | `location_sharing` equals Yes | 2027-07-06 |
| [action.private-accounts.all](blocks/action/action.private-accounts.all.mdx) v1 | D | `top3` | No sourceFile (fresh/thin/furniture) | `accounts_private` oneOf No, Think so, not checked | 2027-07-06 |
| [action.who-can-message.all](blocks/action/action.who-can-message.all.mdx) v1 | D | `top3` | No sourceFile (fresh/thin/furniture) | `online_only_contacts` oneOf Regularly, Sometimes | 2027-07-06 |

### `platform`

| Block file / version | State | Slot | Source MDX | Stored predicates | reviewBy |
|---|---|---|---|---|---|
| [platform.ai-chatbots.11-18](blocks/platform/platform.ai-chatbots.11-18.mdx) v1 | D | `platform-notes` | `content/platforms/ai-chatbots.mdx` | `ai_tools` answered | 2027-01-06 |
| [platform.apple-screen-time.5-16](blocks/platform/platform.apple-screen-time.5-16.mdx) v1 | D | `platform-notes` | `content/platforms/apple-screen-time.mdx` | `devices_used` answered | 2027-01-06 |
| [platform.broadband-router.5-18](blocks/platform/platform.broadband-router.5-18.mdx) v1 | D | `platform-notes` | `content/platforms/broadband-router.mdx` | No predicates | 2027-01-06 |
| [platform.discord.13-18](blocks/platform/platform.discord.13-18.mdx) v1 | D | `platform-notes` | `content/platforms/discord.mdx` | `social_platforms` includes Discord | 2027-01-06 |
| [platform.fallback-generic.all](blocks/platform/platform.fallback-generic.all.mdx) v1 | P | `platform-notes` | No sourceFile (fresh/thin/furniture) | No predicates | 2027-01-05 |
| [platform.fortnite.5-18](blocks/platform/platform.fortnite.5-18.mdx) v1 | D | `platform-notes` | `content/platforms/fortnite.mdx` | `gaming_platforms` includes Fortnite | 2027-01-06 |
| [platform.game-consoles.5-18](blocks/platform/platform.game-consoles.5-18.mdx) v1 | D | `platform-notes` | `content/platforms/game-consoles.mdx` | `gaming_platforms` includes Console online (PS/Xbox) | 2027-01-06 |
| [platform.google-family-link.5-16](blocks/platform/platform.google-family-link.5-16.mdx) v1 | D | `platform-notes` | `content/platforms/google-family-link.mdx` | `devices_used` answered | 2027-01-06 |
| [platform.imessage-thin.all](blocks/platform/platform.imessage-thin.all.mdx) v1 | D | `platform-notes` | No sourceFile (fresh/thin/furniture) | `messaging_apps` includes iMessage/SMS | 2027-01-06 |
| [platform.instagram.13-18](blocks/platform/platform.instagram.13-18.mdx) v1 | D | `platform-notes` | `content/platforms/instagram.mdx` | `social_platforms` includes Instagram | 2027-01-06 |
| [platform.minecraft.5-16](blocks/platform/platform.minecraft.5-16.mdx) v1 | D | `platform-notes` | `content/platforms/minecraft.mdx` | `gaming_platforms` includes Minecraft | 2027-01-06 |
| [platform.mobile-games-thin.all](blocks/platform/platform.mobile-games-thin.all.mdx) v1 | D | `platform-notes` | No sourceFile (fresh/thin/furniture) | `gaming_platforms` includes Mobile games with chat | 2027-01-06 |
| [platform.pinterest-bereal.13-18](blocks/platform/platform.pinterest-bereal.13-18.mdx) v1 | D | `platform-notes` | `content/platforms/pinterest-bereal.mdx` | `social_platforms` includes Pinterest, BeReal | 2027-01-06 |
| [platform.reddit.13-18](blocks/platform/platform.reddit.13-18.mdx) v1 | D | `platform-notes` | `content/platforms/reddit.mdx` | `social_platforms` includes Reddit | 2027-01-06 |
| [platform.roblox.5-16](blocks/platform/platform.roblox.5-16.mdx) v1 | D | `platform-notes` | `content/platforms/roblox.mdx` | `gaming_platforms` includes Roblox | 2027-01-06 |
| [platform.school-devices.5-18](blocks/platform/platform.school-devices.5-18.mdx) v1 | D | `platform-notes` | `content/platforms/school-devices.mdx` | `devices_used` includes Own laptop/PC | 2027-01-06 |
| [platform.signal-thin.13-18](blocks/platform/platform.signal-thin.13-18.mdx) v1 | D | `platform-notes` | No sourceFile (fresh/thin/furniture) | `messaging_apps` includes Signal | 2027-01-06 |
| [platform.smart-tv-thin.all](blocks/platform/platform.smart-tv-thin.all.mdx) v1 | D | `platform-notes` | No sourceFile (fresh/thin/furniture) | `devices_used` includes Smart TV/streaming | 2027-01-06 |
| [platform.smartwatch-thin.all](blocks/platform/platform.smartwatch-thin.all.mdx) v1 | D | `platform-notes` | No sourceFile (fresh/thin/furniture) | `devices_used` includes Smartwatch | 2027-01-06 |
| [platform.snapchat.11-18](blocks/platform/platform.snapchat.11-18.mdx) v1 | P | `platform-notes` | `content/platforms/snapchat.mdx` | `social_platforms` includes Snapchat | 2027-01-05 |
| [platform.steam.13-18](blocks/platform/platform.steam.13-18.mdx) v1 | D | `platform-notes` | `content/platforms/steam.mdx` | `gaming_platforms` includes PC/Steam | 2027-01-06 |
| [platform.telegram-thin.13-18](blocks/platform/platform.telegram-thin.13-18.mdx) v1 | D | `platform-notes` | No sourceFile (fresh/thin/furniture) | `messaging_apps` includes Telegram | 2027-01-06 |
| [platform.tiktok.13-18](blocks/platform/platform.tiktok.13-18.mdx) v1 | D | `platform-notes` | `content/platforms/tiktok.mdx` | `social_platforms` includes TikTok | 2027-01-06 |
| [platform.twitch.13-18](blocks/platform/platform.twitch.13-18.mdx) v1 | D | `platform-notes` | `content/platforms/twitch.mdx` | `social_platforms` includes Twitch | 2027-01-06 |
| [platform.vr-thin.all](blocks/platform/platform.vr-thin.all.mdx) v1 | D | `platform-notes` | No sourceFile (fresh/thin/furniture) | `devices_used` includes VR headset | 2027-01-06 |
| [platform.whatsapp.11-18](blocks/platform/platform.whatsapp.11-18.mdx) v1 | D | `platform-notes` | `content/platforms/whatsapp.mdx` | `messaging_apps` includes WhatsApp | 2027-01-06 |
| [platform.x-thin.13-18](blocks/platform/platform.x-thin.13-18.mdx) v1 | D | `platform-notes` | No sourceFile (fresh/thin/furniture) | `social_platforms` includes X | 2027-01-06 |
| [platform.youtube.5-18](blocks/platform/platform.youtube.5-18.mdx) v1 | D | `platform-notes` | `content/platforms/youtube.mdx` | `social_platforms` includes YouTube | 2027-01-06 |

### `concern`

| Block file / version | State | Slot | Source MDX | Stored predicates | reviewBy |
|---|---|---|---|---|---|
| [concern.crypto-finance.15-18](blocks/concern/concern.crypto-finance.15-18.mdx) v1 | D | `next-month` | `content/playbooks/crypto-finance.mdx` | `age_band` oneOf 15–16, 17–18 | 2027-07-11 |
| [concern.cyberbullying.11-16](blocks/concern/concern.cyberbullying.11-16.mdx) v1 | D | `next-month` | `content/playbooks/cyberbullying.mdx` | `age_band` oneOf 11–12, 13–14, 15–16 | 2027-07-11 |
| [concern.fake-images.13-16](blocks/concern/concern.fake-images.13-16.mdx) v1 | D | `next-month` | `content/playbooks/ai-nudify.mdx` | `talked_fake_images` oneOf Not yet, Briefly | 2027-07-11 |
| [concern.gambling.11-18](blocks/concern/concern.gambling.11-18.mdx) v1 | D | `next-month` | `content/playbooks/gambling-loot-boxes.mdx` | `gaming_platforms` includes Roblox, Fortnite, Console online (PS/Xbox), PC/Steam, Mobile games with chat | 2027-07-11 |
| [concern.grooming.11-16](blocks/concern/concern.grooming.11-16.mdx) v1 | D | `next-month` | `content/playbooks/grooming.mdx` | `talked_grooming` oneOf Not yet, Briefly | 2027-07-11 |
| [concern.online-challenges.11-16](blocks/concern/concern.online-challenges.11-16.mdx) v1 | D | `next-month` | `content/playbooks/online-challenges.mdx` | `social_platforms` includes TikTok, YouTube, Snapchat | 2027-07-11 |
| [concern.privacy.all](blocks/concern/concern.privacy.all.mdx) v1 | D | `next-month` | `content/playbooks/privacy-footprint.mdx` | `accounts_private` oneOf No, Think so, not checked | 2027-07-11 |
| [concern.scams.12-18](blocks/concern/concern.scams.12-18.mdx) v1 | D | `next-month` | `content/playbooks/scams-money-muling.mdx` | `talked_scams` oneOf Not yet, Briefly | 2027-07-11 |
| [concern.screen-time.11-16](blocks/concern/concern.screen-time.11-16.mdx) v1 | D | `next-month` | `content/playbooks/screen-time-sleep.mdx` | `device_location` oneOf Anywhere incl. bedroom overnight, Bedroom but not overnight | 2027-07-11 |
| [concern.sextortion.13-18](blocks/concern/concern.sextortion.13-18.mdx) v1 | D | `next-month` | `content/playbooks/sextortion.mdx` | `talked_sextortion` oneOf Not yet, Briefly | 2027-07-11 |

### `band`

| Block file / version | State | Slot | Source MDX | Stored predicates | reviewBy |
|---|---|---|---|---|---|
| [band.11-12.11-12](blocks/band/band.11-12.11-12.mdx) v1 | D | `family-agreement` | `content/agebands/11-12.mdx` | `age_band` equals 11–12 | 2027-07-06 |
| [band.13-14.13-14](blocks/band/band.13-14.13-14.mdx) v1 | P | `family-agreement` | `content/agebands/13-14.mdx` | `age_band` equals 13–14 | 2027-07-05 |
| [band.15-16.15-16](blocks/band/band.15-16.15-16.mdx) v1 | D | `family-agreement` | `content/agebands/15-16.mdx` | `age_band` equals 15–16 | 2027-07-06 |
| [band.17-18.17-18](blocks/band/band.17-18.17-18.mdx) v1 | D | `family-agreement` | `content/agebands/17-18.mdx` | `age_band` equals 17–18 | 2027-07-06 |
| [band.5-10.5-10](blocks/band/band.5-10.5-10.mdx) v1 | D | `family-agreement` | `content/agebands/5-10.mdx` | `age_band` equals 5–10 | 2027-07-06 |

### `conversation`

| Block file / version | State | Slot | Source MDX | Stored predicates | reviewBy |
|---|---|---|---|---|---|
| [conversation.ai-companions.12-18](blocks/conversation/conversation.ai-companions.12-18.mdx) v1 | D | `this-week-conversation` | `content/conversations.mdx` | `talked_ai_companions` oneOf Not yet, Briefly | 2027-07-06 |
| [conversation.cornerstone.all](blocks/conversation/conversation.cornerstone.all.mdx) v1 | D | `this-week-conversation` | `content/conversations.mdx` | No predicates | 2027-07-06 |
| [conversation.cyberbullying.11-16](blocks/conversation/conversation.cyberbullying.11-16.mdx) v1 | D | `this-week-conversation` | `content/conversations.mdx` | `messaging_apps` includes WhatsApp | 2027-07-06 |
| [conversation.fake-images.13-16](blocks/conversation/conversation.fake-images.13-16.mdx) v1 | D | `this-week-conversation` | `content/conversations.mdx` | `talked_fake_images` oneOf Not yet, Briefly | 2027-07-06 |
| [conversation.first-phone.11-12](blocks/conversation/conversation.first-phone.11-12.mdx) v1 | D | `this-week-conversation` | `content/conversations.mdx` | `devices_used` includes Own smartphone | 2027-07-06 |
| [conversation.gaming-strangers.11-14](blocks/conversation/conversation.gaming-strangers.11-14.mdx) v1 | D | `this-week-conversation` | `content/conversations.mdx` | `online_only_contacts` oneOf Regularly, Sometimes | 2027-07-06 |
| [conversation.grooming.11-16](blocks/conversation/conversation.grooming.11-16.mdx) v1 | D | `this-week-conversation` | `content/conversations.mdx` | `talked_grooming` oneOf Not yet, Briefly | 2027-07-06 |
| [conversation.location.11-16](blocks/conversation/conversation.location.11-16.mdx) v1 | D | `this-week-conversation` | `content/conversations.mdx` | `location_sharing` equals Yes | 2027-07-06 |
| [conversation.scams.12-18](blocks/conversation/conversation.scams.12-18.mdx) v1 | D | `this-week-conversation` | `content/conversations.mdx` | `talked_scams` oneOf Not yet, Briefly | 2027-07-06 |
| [conversation.screen-time.11-16](blocks/conversation/conversation.screen-time.11-16.mdx) v1 | D | `this-week-conversation` | `content/conversations.mdx` | `device_location` equals Anywhere incl. bedroom overnight | 2027-07-06 |
| [conversation.sextortion.13-18](blocks/conversation/conversation.sextortion.13-18.mdx) v1 | P | `this-week-conversation` | `content/conversations.mdx` | `talked_sextortion` equals Not yet | 2027-07-05 |

### `calm`

| Block file / version | State | Slot | Source MDX | Stored predicates | reviewBy |
|---|---|---|---|---|---|
| [calm.is-this-normal.all](blocks/calm/calm.is-this-normal.all.mdx) v1 | P | `dont-panic` | `content/playbooks/is-this-normal.mdx` | No predicates | 2027-07-05 |

### `task`

| Block file / version | State | Slot | Source MDX | Stored predicates | reviewBy |
|---|---|---|---|---|---|
| [task.private-accounts.all](blocks/task/task.private-accounts.all.mdx) v1 | P | `next-month` | No sourceFile (fresh/thin/furniture) | `accounts_private` dontKnow | 2027-07-05 |

### `fixed`

| Block file / version | State | Slot | Source MDX | Stored predicates | reviewBy |
|---|---|---|---|---|---|
| [fixed.footer.all](blocks/fixed/fixed.footer.all.mdx) v2 | P | `footer` | No sourceFile (fresh/thin/furniture) | No predicates | 2027-07-05 |

The emergency slot is provided by `lib/signpost.ts` through `emergencySlotContent()` and its hash verification. It must not become an editable signpost block. `lib/blocks/render.ts` already derives the settings checklist from selected non-fallback platform blocks and renders the exposure table; empty body sections are omitted. `deliverPlan()` already adds the pause guard. Those mechanisms are reuse, not new authoring tasks.

## 3. Library-to-block source map (all 51 MDX files)

“None” below means no block declares this exact `sourceFile`; the source itself exists and may still be directly available in the library or referenced by other guidance. It is **not** a reason to recreate it. Library MDX has `updatedAt` and sources but no block-style publication/reviewer fields; do not inherit a block's review state onto its whole source document or vice versa.

| Library source | Declared derived blocks (P/D as in §2) |
|---|---|
| [content/agebands/11-12.mdx](content/agebands/11-12.mdx) | `band.11-12.11-12` (D) |
| [content/agebands/13-14.mdx](content/agebands/13-14.mdx) | `band.13-14.13-14` (P) |
| [content/agebands/15-16.mdx](content/agebands/15-16.mdx) | `band.15-16.15-16` (D) |
| [content/agebands/17-18.mdx](content/agebands/17-18.mdx) | `band.17-18.17-18` (D) |
| [content/agebands/5-10.mdx](content/agebands/5-10.mdx) | `band.5-10.5-10` (D) |
| [content/conversations.mdx](content/conversations.mdx) | `conversation.ai-companions.12-18` (D), `conversation.cornerstone.all` (D), `conversation.cyberbullying.11-16` (D), `conversation.fake-images.13-16` (D), `conversation.first-phone.11-12` (D), `conversation.gaming-strangers.11-14` (D), `conversation.grooming.11-16` (D), `conversation.location.11-16` (D), `conversation.scams.12-18` (D), `conversation.screen-time.11-16` (D), `conversation.sextortion.13-18` (P) |
| [content/currency/whats-changing.mdx](content/currency/whats-changing.mdx) | None declared; reusable source exists |
| [content/platforms/ai-chatbots.mdx](content/platforms/ai-chatbots.mdx) | `platform.ai-chatbots.11-18` (D) |
| [content/platforms/apple-screen-time.mdx](content/platforms/apple-screen-time.mdx) | `platform.apple-screen-time.5-16` (D) |
| [content/platforms/broadband-router.mdx](content/platforms/broadband-router.mdx) | `platform.broadband-router.5-18` (D) |
| [content/platforms/discord.mdx](content/platforms/discord.mdx) | `platform.discord.13-18` (D) |
| [content/platforms/fortnite.mdx](content/platforms/fortnite.mdx) | `platform.fortnite.5-18` (D) |
| [content/platforms/game-consoles.mdx](content/platforms/game-consoles.mdx) | `platform.game-consoles.5-18` (D) |
| [content/platforms/google-family-link.mdx](content/platforms/google-family-link.mdx) | `platform.google-family-link.5-16` (D) |
| [content/platforms/instagram.mdx](content/platforms/instagram.mdx) | `platform.instagram.13-18` (D) |
| [content/platforms/minecraft.mdx](content/platforms/minecraft.mdx) | `platform.minecraft.5-16` (D) |
| [content/platforms/pinterest-bereal.mdx](content/platforms/pinterest-bereal.mdx) | `platform.pinterest-bereal.13-18` (D) |
| [content/platforms/reddit.mdx](content/platforms/reddit.mdx) | `platform.reddit.13-18` (D) |
| [content/platforms/roblox.mdx](content/platforms/roblox.mdx) | `platform.roblox.5-16` (D) |
| [content/platforms/school-devices.mdx](content/platforms/school-devices.mdx) | `platform.school-devices.5-18` (D) |
| [content/platforms/snapchat.mdx](content/platforms/snapchat.mdx) | `platform.snapchat.11-18` (P) |
| [content/platforms/steam.mdx](content/platforms/steam.mdx) | `platform.steam.13-18` (D) |
| [content/platforms/tiktok.mdx](content/platforms/tiktok.mdx) | `platform.tiktok.13-18` (D) |
| [content/platforms/twitch.mdx](content/platforms/twitch.mdx) | `platform.twitch.13-18` (D) |
| [content/platforms/whatsapp.mdx](content/platforms/whatsapp.mdx) | `platform.whatsapp.11-18` (D) |
| [content/platforms/youtube.mdx](content/platforms/youtube.mdx) | `platform.youtube.5-18` (D) |
| [content/playbooks/age-up-cards.mdx](content/playbooks/age-up-cards.mdx) | None declared; reusable source exists |
| [content/playbooks/ai-companions.mdx](content/playbooks/ai-companions.mdx) | None declared; reusable source exists |
| [content/playbooks/ai-nudify.mdx](content/playbooks/ai-nudify.mdx) | `concern.fake-images.13-16` (D) |
| [content/playbooks/ai-schoolwork.mdx](content/playbooks/ai-schoolwork.mdx) | None declared; reusable source exists |
| [content/playbooks/critical-thinking.mdx](content/playbooks/critical-thinking.mdx) | None declared; reusable source exists |
| [content/playbooks/crypto-finance.mdx](content/playbooks/crypto-finance.mdx) | `concern.crypto-finance.15-18` (D) |
| [content/playbooks/cyberbullying.mdx](content/playbooks/cyberbullying.mdx) | `concern.cyberbullying.11-16` (D) |
| [content/playbooks/dark-patterns.mdx](content/playbooks/dark-patterns.mdx) | None declared; reusable source exists |
| [content/playbooks/disclosure-scripts.mdx](content/playbooks/disclosure-scripts.mdx) | None declared; reusable source exists |
| [content/playbooks/doxxing-swatting.mdx](content/playbooks/doxxing-swatting.mdx) | None declared; reusable source exists |
| [content/playbooks/gambling-loot-boxes.mdx](content/playbooks/gambling-loot-boxes.mdx) | `concern.gambling.11-18` (D) |
| [content/playbooks/grooming.mdx](content/playbooks/grooming.mdx) | `concern.grooming.11-16` (D) |
| [content/playbooks/is-this-normal.mdx](content/playbooks/is-this-normal.mdx) | `calm.is-this-normal.all` (P), `open.behind.all` (D), `open.on-top.all` (D), `open.reassuring.all` (P), `open.worried.all` (D) |
| [content/playbooks/livestreaming.mdx](content/playbooks/livestreaming.mdx) | None declared; reusable source exists |
| [content/playbooks/online-challenges.mdx](content/playbooks/online-challenges.mdx) | `concern.online-challenges.11-16` (D) |
| [content/playbooks/parasocial.mdx](content/playbooks/parasocial.mdx) | None declared; reusable source exists |
| [content/playbooks/pornography.mdx](content/playbooks/pornography.mdx) | None declared; reusable source exists |
| [content/playbooks/privacy-footprint.mdx](content/playbooks/privacy-footprint.mdx) | `concern.privacy.all` (D) |
| [content/playbooks/radicalisation.mdx](content/playbooks/radicalisation.mdx) | None declared; reusable source exists |
| [content/playbooks/room-by-room.mdx](content/playbooks/room-by-room.mdx) | None declared; reusable source exists |
| [content/playbooks/scams-money-muling.mdx](content/playbooks/scams-money-muling.mdx) | `concern.scams.12-18` (D) |
| [content/playbooks/screen-time-sleep.mdx](content/playbooks/screen-time-sleep.mdx) | `concern.screen-time.11-16` (D) |
| [content/playbooks/self-harm.mdx](content/playbooks/self-harm.mdx) | None declared; reusable source exists |
| [content/playbooks/sexting-nudes.mdx](content/playbooks/sexting-nudes.mdx) | None declared; reusable source exists |
| [content/playbooks/sextortion.mdx](content/playbooks/sextortion.mdx) | `action.core-rule.all` (P), `concern.sextortion.13-18` (D) |

## 4. Questionnaire, age-band and output coverage

This section records the smallest remaining differences in the current code and content. It distinguishes **authored**, **selected by the existing engine**, and **cleared for delivery**. Code evidence is `lib/questionnaire-data.ts`, `lib/blocks/assemble.ts`, `registry.ts`, `schema.ts` and `render.ts`. No new content or engine change is made by KW-003.

### KW-007 supersession — tested engine 1b.1 checkpoint

The tables and findings below retain the **KW-003 inspection baseline**. The subsequent KW-007 implementation supersedes these specific software gaps: age metadata and age predicates now apply to the same selected band; per-block interpolation names only its applicable bands; messaging-only Snapchat/Discord/Instagram DMs resolve to the equivalent guide without inventing social answers in the receipt; `Other` receives an explicit eligible app fallback; ordering and deduplication are deterministic; and each service selects the guide set needed across mixed bands, using one adequate all-band guide when sufficient. Missing service/band coverage, unsupported hardware and selections omitted by the five-note limit are now recorded explicitly, and the customer build adapter rejects insufficient coverage. The five-note limit and absence of a suitable hardware guide have **not** been removed by those reporting changes.

Coordinator evidence for this checkpoint: **482 tests passed across 17 files, including 27 diagnostic tests; TypeScript check passed** on the canonical project. KW-015/016 should reuse these tested mechanisms rather than rebuild them. Existing content bodies, 10 published flags / 64 drafts, competent-review gates, actual hardware guidance and live customer/provider acceptance remain separate unfinished work. The MDX corpus digest in §7 is unchanged; synthetic fixture passes do not publish or approve guidance.

### App and device options

| Input family / option | Reusable coverage | Current limitation / next bounded action |
|---|---|---|
| Social: Snapchat | Source guide and P block | Specific block fires from the social answer; competent-review evidence and age applicability still need the ordinary gates. |
| Social: TikTok, Instagram, YouTube, Discord, Reddit, Twitch, Pinterest, BeReal | Existing source guides and D blocks (Pinterest/BeReal share one) | The current published pool uses generic fallback for selected apps until appropriate blocks are cleared. Reuse the drafts. |
| Social: X | Thin D block already exists | Generic fallback is available. Full-guide expansion depends on actual coverage need, not an assumed quota. |
| Messaging: WhatsApp, iMessage/SMS, Telegram, Signal | Existing D blocks; WhatsApp has a full source guide | All can receive generic app fallback now. The old “iMessage hard gap / no fallback” claim is obsolete. |
| Messaging-only: Snapchat / Discord | Specific source guides and blocks exist | Their block predicates require the social answer. A messaging-only choice therefore gets fallback. Fix selection/alias equivalence after checking actual answer contracts; do not rewrite the guides. |
| Messaging: Instagram DMs | Instagram source and D block exist | `APP_SLUGS_BY_LABEL` lacks this exact label, and the block requires social Instagram. It gets generic fallback; adding social Instagram does not make the DM label itself canonical. |
| Messaging: In-game chat | Mobile-game, console and game guidance already exists | No label-specific app slug; generic fallback is explicit. Use a bounded follow-up or honest general guidance rather than guessing the game. |
| Gaming: Roblox, Fortnite, Minecraft, console online, PC/Steam, mobile games with chat | Five full source guides plus a mobile-game thin D block | Current P pool uses app fallback. Published-plan platform notes are capped at five; later selected services can be omitted and need explicit coverage handling. |
| AI: schoolwork assistants / embedded AI | AI-chatbots source guide and D block | Both labels map to the AI-chatbots slug. They currently receive fallback while the block is draft. |
| AI: image generators / companion or character chat | AI source playbooks and conversation material already exist | These two exact app labels lack a slug and receive generic fallback. Do not claim all four AI labels get a specific chatbot guide. Distinct guidance must be justified from existing sources. |
| None / Don't know / Other app selections | Existing scoring confidence handling and generic text | `tickedPlatforms()` skips None, Don't know and Other. No dedicated app note is produced for those labels; ensure the eventual journey names this bounded uncertainty instead of claiming exact coverage. |
| Own smartphone / shared phone or tablet | Apple Screen Time and Google Family Link sources and D blocks | Device labels map to both controls, but devices never receive the app fallback. No selected hardware notes appear while their guides remain draft. Shared-device instructions should reuse the existing room-by-room source. |
| Games console / smart TV / VR / smartwatch | Console source plus thin D blocks | Mapped device candidates exist; they wait for publish/review and have no device-specific fallback today. There is no need to invent missing thin blocks. |
| Own laptop/PC | School-devices source and D block; room-by-room source | No `DEVICE_SLUGS_BY_LABEL` entry for this choice. The existing school-managed device guide is not proof of home-PC coverage. Choose the appropriate existing source and clarify managed versus home device before adaptation. |
| Home broadband/router | Full source and D block exist | No questionnaire device label maps to this guide; record an explicit applicability rule if it belongs in the first-week plan. |

The generic fallback is taken from the eligible pool and used per ticked **app**, across social/messaging/gaming/AI. It is not tied only to `social_platforms`, contrary to the old map. Hardware intentionally gets no “app we do not cover yet” text. In the current code, the cap of five is also a coverage limit, not evidence that later selections were served.

### Age bands

| Band | Existing source / fragment | Current remaining difference |
|---|---|---|
| 5–10 | Source pack + D band fragment | Activate the existing scoped fragment only after its review; no new pack is needed. |
| 11–12 | Source pack + D band fragment | Reuse the first-phone material and existing fragment; review/activation pending. |
| 13–14 | Source pack + P band fragment | A P flag alone does not establish Gate A; retain source/version evidence. |
| 15–16 | Source pack + D band fragment | Existing fragment is caught by the code's high-risk text rule; distinct reviewer needed before publication. |
| 17–18 | Source pack + D band fragment | Apple/Google source guides include this age band, while their block metadata stops at 15–16; inspect the actual useful older-teen pathway before adding or changing material. |

**Applicability finding for KW-007/KW-015/KW-016:** `blockFires()` evaluates stored predicates, but `assemblePlan()` does not filter the pool by each block's `ageBands`. The band fragments themselves use age predicates; most platform blocks do not. Therefore the old assertion that under-11 social/messaging blocks cannot fire is unsupported. Resolve actual age applicability with synthetic boundary cases before customer acceptance; do not infer it from a filename or metadata range. Similarly, one source pack may support several useful fragments without demanding three fragments per age band by quota.

### Plan outputs and unresolved coverage families

| Required output | Already implemented or authored | Smallest remaining coverage / acceptance work |
|---|---|---|
| Summary and exposure map | Four openings; six higher-band map notes; scored table for all six domains | Review the existing drafts and verify the selected narrative agrees with the table. Add another fragment only for a demonstrated uncovered state. |
| First three actions | Seven action blocks, six draft; sorting and per-domain cap already implemented | Clear appropriate existing actions; establish useful output for contrasting households. Current P pool provides at most one action and sometimes none. Check the technical-action expectation when device-settings is elevated. |
| This-week conversation | 11 blocks plus the larger conversation source library | Activate reviewed existing branches and a suitable cornerstone/default; the sole P sextortion branch is conditional, so the slot can otherwise be empty. |
| Settings checklist / setup | Renderer derives a checklist from specific platform blocks | Generic fallback contributes no settings. Resolve guide selection/review and connect existing setup rather than create a second task system. |
| Agreement starting points | Five source packs and five band fragments | Review/activate the four drafts and preserve adult-controlled rules; later versioned agreement is KW-012. |
| Don't-panic and next-month | Evergreen proportion block; one find-this-out task; ten D concerns; later-action mechanism | Verify actual high-risk/action pairing and missing unknown-answer tasks; do not recreate the concern class or automatically author the old numerical deficit. |
| Emergency / footer / render | Locked emergency constant, hashed source, version-2 footer, renderer, pause guard | Keep current verification and review evidence; do not add a second signpost source. |
| Full concern library / age transitions | 25 source playbook/module files, 5 band packs, conversation and transition material | Only derive additional blocks where a required questionnaire/output family has no suitable existing fragment or honest fallback. Competent scope review remains separate. |

Remaining-family cursor for KW-015: **(1)** existing draft review/activation and plan-slot defaults; **(2)** app label/trigger equivalence and five-note overflow; **(3)** hardware/home-PC/router applicability and explicit unavailable guidance; **(4)** age applicability and source/block age-span differences; **(5)** unknown-answer tasks and high-risk/action pairing; **(6)** any demonstrably missing offer-level concern/conversation/transition derivative after source reuse. These are bounded families, not six newly invented content packages. Record the specific item and remaining list during each later checkpoint.

## 5. Review state and gate applicability

### Published flags are not approval evidence

The ten P blocks are identifiable in §2. Seven use identical publisher/checker labels; three — `action.core-rule.all`, `conversation.sextortion.13-18`, `platform.snapchat.11-18` — use `editorial` / `editorial-safeguarding`. That satisfies the existing structural distinction for those high-risk files, but the inventory does not establish an external identity, competence, signed scope or Gate A verdict. Preserve the exact review artefact when recovered; do not convert these role names into an endorsement.

Applying the existing `isHighRisk()` rule to the exact id/concerns/body finds **14** flagged blocks: three P and **11 D**. This is the code rule, not a professional risk determination. The 11 draft IDs are:

- `band.15-16.15-16`
- `concern.fake-images.13-16`
- `concern.grooming.11-16`
- `concern.sextortion.13-18`
- `conversation.fake-images.13-16`
- `conversation.gaming-strangers.11-14`
- `conversation.grooming.11-16`
- `platform.signal-thin.13-18`
- `platform.telegram-thin.13-18`
- `platform.vr-thin.all`
- `platform.x-thin.13-18`

The other 53 drafts are not caught by that marker rule; they are not automatically cleared. For example, a source about AI companions can still need safeguarding review even if the string matcher does not flag its particular derivative. KW-017 tracks actual required review, and KW-016 must preserve eligibility checks across delivery paths.

| Gate / review scope | What this inventory establishes | What remains held |
|---|---|---|
| A0 | `105_Gate_A0_Submission_Pack.md` is a ready-to-send architecture pre-read; its Part 6 permits limited verbatim slice work while awaiting a verdict | Bulk adaptation/fresh authoring waits for actual scoped verdict. This applies to later equivalent work, not only KW-015. No signed result was supplied with this snapshot. |
| A + B0 | `100_Automated_Build_Plan.md` §5 and the queue retain both before first sale | Published flags, successful tests and this map do not establish clearance. Changed sharing/search/school/activity scope must be included in the appropriate review. |
| B1 | Existing profile/digest/first-phone requirements are recorded | Actual digest/sequence activation and calendar promises wait for approval and functioning delivery machinery. |
| B2 | DNS remains a separate conditional feature | No DNS flag-on is authorised by this inventory. |
| AI practice / Lab / child access | `lib/ai-safety-scenarios.ts` explicitly holds the eight authored scenarios for review; course pack is Draft 1.0 | Customer routes, supervised activity activation and actual learning-content completion need their scoped safeguarding/legal/access clearances. Generic isolated software fixtures may proceed. |
| Derivatives | Source versions, scripts and destinations can be inventoried now | A translation/recording inherits neither the source's published flag nor its approval. Review the actual derivative/version before activation. |

`reviewBy` dates on the ten P blocks are later than 31 October 2026; that date check is structural only. The source's `updatedAt` and script claims are not a substitute for rechecking a real device/version or an official factual source when preparing customer publication.

## 6. Reuse beyond assembly blocks

| Promised output | Existing material to reuse | Remaining connection / limit |
|---|---|---|
| Written platform guidance and troubleshooting | 19 platform MDX files; ten named walkthrough scripts in `28_Platform_Video_Scripts.md` | U05 requires actual tested device/app versions, dates, mismatch/unavailable/region/account-type branches and real captioned recordings. Scripts alone are not recordings or testing evidence. |
| Age-band learning / Foundations material | Five MDX packs, `19_Age_Band_Packs.md`, `29_Masterclass_Scripts.md` | The masterclass file covers all five age families but has duplicate/alternate 15–16 and 17–18 headings. Select the intended reviewed version; do not count seven separate courses. Course delivery is KW-036/037. |
| Conversations and incident-routing cards | `content/conversations.mdx`, `17_Conversation_Library.md`, `34_Threat_Playbook_Cards.md`, 25 playbook/module MDX sources | Reuse actual text and routes; new/adapted consequential scripts require the applicable review. Avoid collecting free-text disclosures. |
| AI Readiness Lab | `55_AI_Readiness_Lab_Complete_Course_Pack.md` contains four modules, facilitator/lesson notes, ten workbook worksheets, project and schoolwork material, a school/PTA taster, newsletter and email drafts. Separate reusable curriculum, lesson and workbook sources are `51_AI_Readiness_Lab_Curriculum_Spec.md`, `52_AI_Readiness_Lab_Lesson_Plans.md` and `53_AI_Readiness_Lab_Parent_Workbook.md`; `75_AI_Safety_Course_Founding_Pilot_Asset_Copy.md` supplies later asset drafts | Draft material, not a cleared customer course. The recording plan is conditional. `88_AI_Safety_Course_First_Sale_Decision_Log.md` records the later decision: Lab folds into the £49 system once built, with no separate course SKU. Reconcile retired add-on/concierge/founding claims before reuse. |
| Scenario trainer | Eight authored objects in `lib/ai-safety-scenarios.ts`; supporting routing/self-check/update-stream data already exists | Reuse isolated fixtures in KW-034. Actual production routing/content acceptance stays held in KW-035; do not bypass import guards. |
| School/PTA session and conversion kit | `13_School_PTA_Outreach_Pack.md` provides one-pager/outreach/offer outline; course pack §§20–22 provide a 60-minute taster agenda, handout outline, school-boundary wording and newsletter draft | KW-042 must make one session deliverable, align the offer and data/procurement sheet, demonstrate activation and explain school visibility. These drafts are useful inputs but not evidence of a recording, named presenter or working licence. |
| Agreement and plan output | `lib/blocks/render.ts`; `components/FamilyAgreementBuilder.tsx` and its gated `app/library/family-agreement/page.tsx` | The existing builder lets adults select age-band clauses, add a local custom rule and print/PDF. It stores/sends nothing. Preserve it; synced structured rules/versioning are later jobs, while unrestricted custom wording stays local/print-only. |
| First-phone transition / setup | `components/FirstPhoneWalkthrough.tsx`, `app/library/first-phone/page.tsx`, linked from the library hub and documented in `APP_README.md` | Existing 18-task journey per device variant: today, agreement and a three-day check-in; localStorage progress, device choice, next unfinished task and next-review date. Reuse in KW-009/011/020/021. This is local progress, not verified cross-device household sync. |
| Printable packs | `27_Platform_QuickRef_Cards_print.html`, `33_Printable_AgeBand_Cards.html`, `34_Threat_Playbook_Cards_print.html`, `32_AgeBand_Cards_and_Weekend_Checklists.md`, `81_AI_Safety_Course_Founding_Pilot_Printable_Pack.html` | Real authored HTML/Markdown assets exist. Reconcile retired branding/offer wording, source versions and signpost before delivery; existence is not a rendered print-quality or professional-review pass. |

### Media and languages: bounded discovery, not an absence claim

The coordinator checked the canonical device on 31 October 2026, with these explicit bounds:

| Checked location / reference scope | Observed result |
|---|---|
| Project source, excluding dependencies/build output | No common audio/video/caption files and no locale directories found. Text scripts exist as listed above. |
| ZIP central directories of `brand-worlds.zip` (90 entries), `keepwise-skins-site.zip` (29), `brand-test-site.zip` (58), `brand-review.zip` (89), `Bearings-brand-mockups-pack.zip` (33) | No matching media/locale entries in these five project archives. Contents were inventoried by name, not treated as reviewed media. |
| Immediate `/Users/benharwood/Downloads` names matching Keepwise / AI safety / readiness | Only `Keepwise_Corrected_Feature_Gap_Audit_2026-10-30.md` was found; no matching asset directory. This was not a recursive Downloads or whole-home search. |
| Scanned project text references | No named external Drive/Dropbox/SharePoint/OneDrive asset location or media-file path/URL was discovered. General source/help links are not evidence of owned recordings. |
| Connected external stores and unreferenced folders | **Not inspected. Global asset availability remains unverified**, rather than declared nonexistent. No external asset location is currently identified for a targeted follow-up. |

No recording or translation is counted as completed from a script, an English content file or an uninspected external account. KW-045 still needs the actual first useful language set and competent review; KW-046 needs identified usable media, exact source versions and review. If a concrete location becomes available, inspect it before creating replacements. Keep both sets bounded by demand, available authorised assets and review capacity; no default quota of 20 is adopted.

`67_AI_Safety_Course_Human_Review_Pack.md` is a handoff/review-work pack, explicitly not clearance or sellability. `88_AI_Safety_Course_First_Sale_Decision_Log.md` retains unresolved first-sale owner details as well as its later automated-offer decision. Neither fills a missing signed review, recording or approved translation.

## 7. Checkpoint provenance and next use

The counts/registers above were recomputed from the current source snapshot, not copied from the prior 45-block table. The 125 MDX paths are unique; every non-null block `sourceFile` resolves to one of the actual library MDX files. The corpus digest covers relative path plus file SHA-256, sorted by path, and retains source versions for subsequent checking:

```text
MDX corpus SHA-256: 28e544a0991d1016c8856aa604430c78af7efcce36c30d26b027d434c90a8f7b
algorithm: sha256(concat(relativePath + NUL + sha256(fileBytes) + LF))
paths: every .mdx under blocks/ and content/, sorted by relative POSIX path
```

No code, content body, publication flag, reviewer identity, source date or asset was changed by this inventory refresh. Independent review must identify the final inventory hash and source corpus digest. Acceptance of KW-003 completes this map only; U05/U10/U12/N08/N09 still require their later software, real content, review and operational evidence.

Use this map as the same shared inventory in KW-015/017/029/033/035/037/042/045/046. Update affected rows when an exact source/version or asset changes; retain unknowns as unknowns. The queue owns job acceptance, gates and the next checkpoint.

## 8. KW-018 — observed versions and correction flags (6 November 2026)

This appendix applies to the existing §2 block rows and §6 reuse rows; it adds no asset ledger. `observeContentVersions(asOf)` in `lib/content-versions.ts` returns exact repository paths, **current** whole-file SHA-256, MDX body hashes, declared `updatedAt` (date only), block versions and existing health/log eligibility. Inventory paths in §6 are reused directly. No asset is regenerated. Each invocation reads current bytes; it is not a frozen historical provenance record.

For every existing block, `sourceFile` is the direct source identity where present; its **derivation-time pin remains null**. Blocks without it retain unknown historical source identity. Their body hash identifies the block, not the source used when deriving it. Missing genuine publication log currently leaves all ten marked-published blocks ineligible; review role strings do not establish competence. Exact source and derivative reviews remain separate from observed identity.

Three §6 printable origins are evidenced in the assets themselves: `27_Platform_QuickRef_Cards_print.html` names `27_Platform_QuickRef_Cards.md` in its generation comment; `33_Printable_AgeBand_Cards.html` names `32_AgeBand_Cards_and_Weekend_Checklists.md` in its render comment; `34_Threat_Playbook_Cards_print.html` names `34_Threat_Playbook_Cards.md` in its generation comment. These links establish direct dependencies, **not** the historical version/hash used. Current asset bytes and current source bytes are observed separately; all historical pins remain unknown.

For §6's scripts (`28`, `29`), Markdown checklists (`32`), printable pilot pack (`81`) and curriculum/lesson/workbook/course sources (`51`/`52`/`53`/`55`), retain exact asset path/current hash and unknown historical provenance/currentness unless an explicit origin is evidenced. General library links and similar topic names do not pin a derivation. Translation and recording availability remains **unverified**, as bounded in §6. No notice asset or replacement URL is invented; the internal review-held update stream remains unwired.

Repository workflow: obtain an observation with an explicit date, then call `affectedAssets(assets, sources, changedSourceIds)` with exact changed/withdrawn/missing source paths. Only direct dependents are returned, sorted by exact asset identity; repeated inputs return the same flags. `assetCurrentness` reports `held` for missing/withdrawn/rejected evidence, `stale` for known pin mismatch, `unknown` for absent historical provenance, and `current` only for exact source pins plus explicit exact-byte source AND derivative review/publication eligibility. A current observed hash cannot fill a missing historical pin. These identity flags establish neither suitability nor publication permission. Unknown provenance needs recovery or a newly reviewed replacement, not a backfilled assertion about the old asset.

`replacementFlag` assesses an explicitly supplied candidate against the same direct sources and its own pins/review/publication evidence; no candidate means unknown. Invalid or duplicate identities reject the operation rather than select an arbitrary winner. These pure functions do not mutate files, send notices or change live views. Downloaded copies cannot be remotely retracted: flags return a replacement advisory for authorised later handling. KW-019/020 owns household matching, preferences, deduplication and approved notices; KW-045/046 retains actual language/media review and delivery gates. Independent mechanism review and coordinator acceptance remain required.
