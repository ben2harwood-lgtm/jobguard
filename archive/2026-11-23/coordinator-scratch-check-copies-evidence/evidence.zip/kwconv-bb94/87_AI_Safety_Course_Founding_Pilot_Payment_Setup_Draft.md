# AI Safety Course - Founding Pilot Payment Setup Draft

*Created 2026-06-27. Status: operational draft for setting up a tiny manual paid pilot. Do not create or share a live payment link until the decisions in `85_AI_Safety_Course_First_Sale_Legal_Admin_Pack.md` and copy in `86_AI_Safety_Course_Founding_Pilot_Terms_Privacy_Drafts.md` are completed.*

## Setup Principle

Use the simplest flow that still puts the buyer notice, terms, privacy notice, refund/cancellation wording, emergency signpost, and required acknowledgements before payment.

Do not publish a broad checkout page. Use a private/warm-link flow for a maximum of 5 pilot households.

## Current Best Setup

1. Send warm parent outreach from `77_AI_Safety_Course_Founding_Pilot_Outreach_Copy.md`.
2. If a parent is interested, send the private pre-payment page draft in `89_AI_Safety_Course_Private_PrePayment_Page_Draft.md` after every placeholder is filled.
3. Collect required confirmations before or during payment.
4. Send payment link only after the buyer has seen the required information.
5. Deliver manually, not instantly.

## Payment Provider Configuration

Product:

- Name: Bearings AI Safety Course - Founding Parent Pilot
- Price: GBP 49
- Quantity: 1
- Delivery: manual digital delivery

Required buyer data:

- email address;
- parent/carer 18+ acknowledgement;
- terms/privacy/refund acknowledgement;
- digital-content acknowledgement if using early delivery;
- optional marketing consent, separate from purchase.

If Stripe Payment Links in the account can collect all required acknowledgements, use those fields. If not, collect the acknowledgements in a pre-payment form or confirmation email before sending the Stripe link.

Do not collect:

- child name;
- child school;
- child date of birth;
- account handles;
- screenshots;
- messages;
- images;
- attachments;
- prompts;
- schoolwork;
- incident details.

## Payment Button Copy

Use clear payment wording:

> Join the founding pilot - pay GBP 49

Do not use vague wording such as:

- "Continue";
- "Reserve";
- "Request access";
- "Join" without making payment clear.

## Required Confirmation Text

Use the checkbox wording in `86_AI_Safety_Course_Founding_Pilot_Terms_Privacy_Drafts.md`.

Minimum required confirmations:

1. 18+ parent/carer.
2. Has read pilot notice, terms, privacy, refund/cancellation.
3. Will not send child details, screenshots, messages, images, attachments, or live-incident details.
4. Digital-content early-access acknowledgement if materials are sent before the 14-day cancellation period ends.

Optional marketing consent must be separate and unticked by default.

## Success Message

Use after payment:

> Thank you. Your founding pilot materials will be sent manually to your email address within [TIMEFRAME].
>
> Please do not send child names, school details, account handles, screenshots, messages, images, attachments, schoolwork, prompts, or incident details.
>
> If something is happening now, use the emergency signpost: [EMERGENCY LINK].

## Manual Fulfilment Checklist

When payment arrives:

- [ ] Confirm buyer email.
- [ ] Confirm 18+ parent/carer acknowledgement.
- [ ] Confirm terms/privacy/refund acknowledgement.
- [ ] Confirm digital-content acknowledgement if early delivery is used.
- [ ] Record buyer in `80_AI_Safety_Course_Founding_Pilot_Tracker.md`.
- [ ] Send Email 1 from `79_AI_Safety_Course_Founding_Pilot_Email_Templates.md`, including the purchase summary from `86`.
- [ ] Send Email 2 with material links.
- [ ] Set feedback reminder for 5-7 days.

## Stop Conditions Before Sending Payment Link

Do not send the link if:

- any placeholder remains in buyer-facing terms/privacy/refund copy;
- the emergency signpost link is missing or unverified;
- the payment flow cannot collect or record required acknowledgements;
- the product page implies legal review, safeguarding review, expert approval, compliance, or outcome promises;
- school/PTA circulation is the source of the lead;
- buyer asks about a live concern or tries to send incident detail.

## Records To Keep

Keep minimal records:

- buyer ID;
- lead ID;
- payment date;
- amount;
- acknowledgement status;
- materials sent status;
- feedback requested/received status;
- refund status;
- boundary issue type only, if any.

Do not retain child-identifying detail in records.

## Next Human Decision Point

This setup cannot become live until Ben decides:

- trading/contact details;
- address/contact-address approach;
- refund/cancellation option;
- digital delivery timing;
- payment-provider acknowledgement flow;
- ICO fee/exemption outcome.
