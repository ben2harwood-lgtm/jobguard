# Platform Setup — Video Scripts (record these)

**Updated 20 Jun 2026 — corrected against review `31` and re-aligned by content. Read aloud while screen-recording the taps. Tooling/batch order: `26` §5.**

---

## Apple Screen Time (iPhone/iPad) — video script

**Run time:** approx. 3–4 minutes · Founder voiceover, screen recording of an iPhone/iPad

**Goal:** Walk a parent through the handful of Apple Screen Time settings that matter most, in order, on a child's iPhone or iPad — calmly, with no panic and no overclaiming.

**You will need:**
- The child's iPhone or iPad (or your own, signed into your Family Sharing)
- Family Sharing already set up with your child's Apple Account added (Settings → your name → Family Sharing)
- A Screen Time passcode in mind that your child doesn't know

> **On-screen caption to keep visible throughout:** *Apple menus move. If a path doesn't match your screen, search the setting name in Settings, or use support.apple.com/en-us/108806*

---

| # | What to say (voiceover) | What to tap (on screen) |
|---|---|---|
| 1 | "This is the one device setting worth doing first. Apple Screen Time works at the device level, so it covers every app, install and website at once — before you touch any individual app. And the good news: if your child is under 18, Communication Safety and web-content limits are already on by default. We're just confirming and tightening." | Open **Settings**. [caption: *Screen Time is the device layer — set it first*] |
| 2 | "First, make sure Family Sharing has your child's account added. If you've already done this, skip ahead." | Tap **your name → Family Sharing**. Show the child's Apple Account listed. |
| 3 | "Now into Screen Time, and select your child." | Back to **Settings → Screen Time → your child's name**. |
| 4 | "Do this one first, because nothing else holds without it. Lock Screen Time with a passcode your child doesn't know — otherwise every setting we're about to make can simply be switched off." | Tap **Lock Screen Time with a passcode**. Set a code. [caption: *Set this first — or the rest can be turned off*] |
| 5 | "Downtime sets the hours when only allowed apps and calls work — overnight, or homework time. Pick what fits your household." | Tap **Downtime**. Set a schedule. |
| 6 | "App Limits let you cap time by category — like Social — or for a single app, per day." | Tap **App Limits**. Add a limit (e.g. Social). |
| 7 | "Content and Privacy Restrictions is where you block age-inappropriate web, apps and music. And while you're here, lock 'Share My Location' so it can't be changed." | Tap **Content & Privacy Restrictions**. Show content filters, then lock **Share My Location**. |
| 8 | "Communication Limits is where you decide who they can contact — during allowed time, and during downtime. It's how you keep contact to the people you're comfortable with." | Tap **Communication Limits**. Show the during-allowed-time and during-downtime options. |
| 9 | "Communication Safety blurs nude images on-device in Messages and AirDrop, with guidance. Apple can't see the photos — this isn't monitoring. That's how it works today; if you want to be sure, the official help link in the description has the current behaviour. It's on by default under 18; just confirm it's on." | Show **Communication Safety** toggled on. [caption: *On-device. Apple can't see the photos.*] |
| 10 | "Last one: Ask to Buy means purchases and downloads need your approval from your phone." | Show **Ask to Buy** enabled. |
| 11 | "A note on ages: under-13s use a parent-created Child Apple Account; 13 to 17-year-olds can have their own account that you manage here through Screen Time." | Stay on the Screen Time screen. |

---

**Settings-move note (say near the close):** "Apple does rename and move these from time to time, including in recent iOS updates. If a path doesn't match your screen, search the setting name, or use the official help link in the description: support.apple.com/en-us/108806."

**New for 2025–26 (optional line):** "One newer touch: when your child asks for more time, you can now approve it straight from your own phone."

**Calm close:** "That's it. A passcode, downtime, app limits, content restrictions, who they can contact, and purchase approval — the right few things, set once. This won't catch everything, and it's not a substitute for talking. There's a conversation guide at /library/conversations. And if something ever does go wrong — in immediate danger it's always 999, and for a worry about images or contact, /emergency has the right people, including Childline on 0800 1111. The full written version of this is at /library/platforms/apple-screen-time."

---

## Google Family Link (Android/Chromebook) — video script

**Video Script — Setting up Google Family Link (Android / Chromebook)**
*Run time: ~3 minutes · Founder reads voiceover aloud while screen-recording the Family Link app*

**Goal:** Show a parent the handful of Family Link settings that matter most, calmly, so they leave knowing what to change and what's already fine.

**You will need:** Your phone with the Family Link app installed, your child's supervised Google Account already linked, and a quiet minute. *(If you haven't created the supervised account or linked the device yet, do that first — the official help link at the end walks you through it.)* [on-screen caption: *Menus move — if your screen looks different, search the setting name or use the help link at the end.*]

| # | What to say (calm, first-person voiceover) | What to tap (on-screen action) |
|---|---|---|
| 1 | "This is Google Family Link. It's a device-level control, which is why we start here — it governs every app, install and website at once, so it's the highest-leverage thing you'll set up." | Open the Family Link app; show the child's profile. |
| 2 | "Quick honest note before we start: Family Link gives you real controls — limits, blocks, approvals. It does not read your child's messages, and that's by design. No tool can guarantee safety; this just gives you sensible defaults." | Stay on the home screen. [on-screen caption: *Controls, not message-reading*] |
| 3 | "First, screen time. Open the Screen time tab. Here you can set a daily limit and a weekly schedule. There's no 'right' number — pick something you can both live with." | Tap **Screen time** → show time limits / weekly schedule. |
| 4 | "In the same tab you'll find Downtime, or bedtime, and School time. School time should now work on phones and tablets too, not just Chromebooks — if you don't see it on your device, check the official help link. Set the quiet hours that fit your week." | Show Downtime / bedtime and **School time** hours. |
| 5 | "Now the Controls tab. App management lets you approve or block apps and set per-app limits. A nice touch: you can mark educational apps as unlimited so homework isn't penalised." | Tap **Controls** → **App management**; show approve/block and per-app limits. |
| 6 | "Still in Controls, open content filters. Check SafeSearch, Chrome, your Google Play maturity rating and YouTube. This is where you set the ceiling for what shows up." | Show **content filters**: SafeSearch, Chrome, Google Play, YouTube. |
| 7 | "Two more quick ones. On Android you can approve who your child can call or text — that's the approved-contacts setting. And turn on purchase approval so the Play Store needs your OK. One thing to know: because this is the same supervised account, these controls carry across to your child's Chromebook too." | Show **Approved contacts** (Android) and **Purchase approval**. [on-screen caption: *Same account = same controls on a Chromebook*] |
| 8 | "A word on age, because it matters. For under-13s you create this account, and a credit-card check just confirms you're the adult. At 13 your teen can take the account over — you can keep supervision until they remove it, and if they do, you're notified and the device briefly locks." | Show the account/age screen. [settings move note: *exact wording varies by app version*] |
| 9 | "That's it — the settings worth your time, not every toggle in the app. Before you finish, have a short chat about the screen-time schedule rather than springing it on them. We've got openers in the conversation library." | Return to home screen. [on-screen caption: */library/conversations*] |
| 10 | "If you're ever worried about contact from strangers or something they've seen, our playbooks walk you through it. And if a child might be at immediate risk, this isn't the place for that — go straight to our emergency page, or call 999. Take it one setting at a time. You've got this." | [on-screen caption: *Full guide: /library/platforms/google-family-link · Playbooks: /library/playbooks · Emergency: /emergency · Official help: support.google.com/families/answer/7101025*] |

*Settings-move note to read or caption: "Google has been redesigning Family Link through 2025–26 — you should see separate Screen Time and Controls tabs, and School time should appear on phones and tablets as well as Chromebooks. If your layout differs, or you don't see School time at all on your device, search the setting name in the app or use the official help link."*

**Calm close (voiceover):** "Prevention, not panic — a few of the right settings, set once, and a conversation to go with them."

---

## Snapchat — video script

| **Snapchat — Family Centre Walkthrough** (approx. 3 minutes) |
| --- |

**Goal:** Show a parent how to set up Snapchat's Family Centre and check six settings that matter — calmly, with no panic.

**You will need:** Your own Snapchat account and your child's account (both opted in), the app open and updated, screen recording on. Have the official help page ready: parents.snapchat.com (UK: /en-GB/parental-controls).

---

| # | What to say (voiceover) | What to tap (on-screen) |
| --- | --- | --- |
| 1 | "This is Snapchat. Snapchat's parent tool is called Family Centre. Two quick things to know up front: the minimum age is 13, it's self-declared and not verified — so the single most useful thing is making sure the real birthday is on the account. And Family Centre shows you *who* your child talks to, not *what* they say. It's not a message-reader, and it doesn't monitor anything for you." | Hold on the camera / home screen. *[on-screen caption: "Family Centre = who, not what"]* |
| 2 | "Let's set it up. You and your child both need accounts, and you both have to opt in. From your profile, tap the settings cog, then Privacy Controls, then Family Centre. Choose your child and send the invite. Once they accept, you'll see their friends list and who they've messaged or called in the last 7 days. One thing to note: the next six settings live in your child's own Settings on their phone, not in your Family Centre dashboard — so it's easiest to do them together on their device." | Profile → ⚙️ Settings → *Privacy Controls* → **Family Centre** → select child → send invite. *[caption: "Both must opt in · Next six settings are on the child's device"]* |
| 3 | "Now six settings, quickest wins first. The first is Contact Me. In Settings, set this to Friends — not 'Friends and Contacts' — so people who aren't friends can't message them. If yours already says Friends, that part's done." | Settings → **Contact Me** → choose **Friends**. *[caption: "Friends, not Friends and Contacts"]* |
| 4 | "Next, location. Open the Map, tap the settings cog, and turn on Ghost Mode. That hides their live location — a reasonable default for under-18s. This isn't about secrecy, it's just not broadcasting where they are." | Map → ⚙️ → **Ghost Mode** (on). *[caption: "Ghost Mode hides live location"]* |
| 5 | "Then, who can see their Story. In Settings, set View My Story to My Friends, or use Custom if you want to narrow it further." | Settings → **View My Story** → **My Friends** / Custom. |
| 6 | "Snapchat has a built-in chatbot called My AI. In Settings you can clear its data and disable it. Full removal needs Snapchat+, but disabling and clearing is enough for most families." | Settings → **My AI** → clear data / disable. *[caption: "Full removal needs Snapchat+"]* |
| 7 | "Last one — turn on Two-Factor Authentication in Settings. It protects the account login itself." | Settings → **Two-Factor Authentication** (on). |
| 8 | "A couple of newer things from the January 2026 update — and these are still rolling out, so if your app's updated you may now see them: daily time spent, broken down by feature; 'trust signals' flagged on new friends; and a short built-in safety course worth a look together. If they're not there yet, don't worry — they're arriving for accounts in waves." | Show the Family Centre dashboard / time-spent view. *[caption: "New Jan 2026 (rolling out): time-spent, trust signals, safety course"]* |
| 9 | **Settings-move note:** "If any of these don't match your screen, app makers move things around — just search the setting name in the app, or use the official help page: parents dot snapchat dot com." | Show parents.snapchat.com (UK: /en-GB/parental-controls). *[caption: "Menus move — search the setting name. Paths checked June 2026. parents.snapchat.com (UK: /en-GB/parental-controls)"]* |
| 10 | "That's it. You've set the things that matter without changing everything. The full written version of this is at slash library, platforms, Snapchat. The next step that pays off most isn't a setting — it's one short conversation about why 'Friends only' and Ghost Mode are reasonable. There's a starter for that in the conversation library. And if something ever does go wrong, don't troubleshoot it in the app — in immediate danger it's always 999. If a nude image of an under-18 has been shared or threatened, Childline's Report Remove on 0800 1111 can help get it taken down; and for sexual pressure or contact from an adult, you can report to CEOP. Our emergency page has the full list." | Calm close. *[caption: "Guide: /library/platforms/snapchat · Talk: /library/conversations · Playbooks: /library/playbooks · 999 · Childline Report Remove 0800 1111 · CEOP · Full list: /emergency"]* |

---

## Instagram (Meta) — video script

**Instagram (Meta) — Settings Walkthrough** · Screen-Recording Video Script (approx. 3–4 minutes)

**Goal:** Confirm a teen's Instagram Teen Account protections and set up supervision — calm, in plain English, in one sitting.

**You will need:** Your phone, your teen's Instagram open (or your own logged in), and about 5 minutes together with your teen. (The video runs 3–4 minutes; the hands-on check takes about five.)

**A note before you record:** Instagram's menus move. Wherever a path looks different on screen, say so and point to the menu name as the anchor and the official help link in the description.

| # | What to say (voiceover) | What to tap (on screen) |
|---|---|---|
| 1 | "Let's take five minutes with Instagram. Good news first: if your teen is under 18, Instagram already puts them in a Teen Account with protections switched on by default. So a lot of this is confirming, not fixing." | Open Instagram. Show the profile screen. *[on-screen caption: Under-18s = Teen Account, defaults ON]* |
| 2 | "First, let's set up supervision. Head to Settings, then Family Centre. If you don't see it by that name, look for 'Supervision' — Instagram moves these around." | Tap the menu, go to **Settings → Family Centre**. *[caption: Settings -> Family Centre (may have moved)]* |
| 3 | "From here you invite or accept the link between your accounts. Once it's connected, you can see who they've messaged in the last seven days — that's who, not what — set time limits, and schedule off periods. It's an activity view, not a way to read messages." | Show the invite/accept screen and the activity overview. *[caption: Shows WHO, not message content]* |
| 4 | "Next, check the birthday is correct, because most protections key off age. One thing to know: if an account is set to 18 or over, Instagram triggers an ID or face age check." | Navigate to the account's date-of-birth setting. *[caption: Real birthday = right protections]* |
| 5 | "Now let's confirm the Teen-Account defaults are on. You're looking for: private account; messaging set to the strictest option, so only people they follow can message; the most-restrictive sensitive-content setting and Hidden Words; a time-limit nudge at sixty minutes; and Sleep Mode, which mutes notifications from 10pm to 7am." | Scroll through privacy and content settings, pausing on each. *[caption: Private · Strictest DMs · Sensitive content · Sleep Mode]* |
| 6 | "If your teen is under 16, a couple of these are locked on by default: they can't go Live, and they can't turn off the nudity-blur on DMs without your permission. Nothing to change here — just useful to know." | Show the relevant toggles as greyed/locked if visible. *[caption: Under-16: some controls locked on]* |
| 7 | "If you'd like to go a step stricter, there's a Limited Content setting that removes comments and filters more mature material. Optional — set it if it suits your household." | Show the Limited Content option. *[caption: Optional: Limited Content]* |
| 8 | "One more thing to know for the year ahead: Meta uses AI age-assurance, live in the UK, and from May 2026, AI visual age estimation — so suspected-teen accounts get moved into protections even if an adult birthday is listed." | Hold on the supervision/home screen. *[caption: 2026 — AI age estimation rolling out]* |
| 9 **Settings-move note** | "Remember, these menus shift over time. If a path doesn't match, the menu name is your anchor, and the official Instagram help link in the description always has the current route." | Show the Family Centre home once more. *[caption: help.instagram.com/995996839195964 · familycenter.meta.com]* |
| 10 **Close** | "That's it. The strongest approach isn't a single toggle — it's this plus an open conversation. We've got starters in the conversation library, and our playbooks walk you through anything that goes wrong. If something ever does, don't troubleshoot it in the app — in immediate danger it's always 999. If a nude image of an under-18 has been shared or threatened, Childline's Report Remove on 0800 1111 can help get it taken down; and for sexual pressure or contact from an adult, you can report to CEOP. Our emergency page has the full list." | End card. *[caption: Talk: /library/conversations · Playbooks: /library/playbooks · 999 · Childline Report Remove 0800 1111 · CEOP · Full list: /emergency]* |

**Calm close (read over the end card):** "Full written guide is at slash library, platforms, Instagram. Take what's useful, leave the rest — you've now got the right things in place."

---

## TikTok — video script

**TikTok — Family Pairing Walkthrough** · Screen-Recording Video Script (approx. 3 minutes)

**Goal:** Set up TikTok's Family Pairing and confirm the handful of settings that matter — calmly, in one sitting, with no panic and no overclaiming.

**You will need:** Your own TikTok account and your teen's account, both apps open and updated, your teen's phone to hand (you'll scan a QR code), and a few quiet minutes together. Have the official help page ready: tiktok.com/safety.

**A note before you record:** TikTok reorganises its menus often. Wherever a path looks different on screen, say so, point to the menu name as the anchor, and send people to the official help link.

| # | What to say (calm, first-person voiceover) | What to tap (on-screen) |
|---|---|---|
| 1 | "Let's take a few minutes with TikTok. The parent tool here is called Family Pairing — you link your account to your teen's and manage things from your own phone. Two quick honest things first: the minimum age is 13 and it's self-declared, so the most useful thing is making sure the real birthday is on the account. And Family Pairing shows you activity and lets you set limits — it does not let you read their messages. It's not a monitor." | Open TikTok. Hold on the home screen. *[on-screen caption: Family Pairing = limits + activity, not message-reading]* |
| 2 | "Let's set it up. On your phone, go to your Profile, tap the menu, then Settings and privacy, then Family Pairing. You'll get a QR code — scan it on your teen's matching screen to link the two accounts. It's easiest to do this together on their device." | Profile → ☰ → *Settings and privacy* → **Family Pairing** → scan the QR on the teen's screen. *[caption: Link via QR — do it together]* |
| 3 | "Now the settings, quickest wins first. Screen time. TikTok defaults to about sixty minutes a day for 13 to 17s — confirm what yours shows, and set it shorter if you'd like. The scheduling controls got finer in 2025–26, so you can shape when, not just how long." | Open **Screen-time** limit; set a daily limit / schedule. *[caption: ~60 min default for 13–17 — confirm on your screen]* |
| 4 | "Next, direct messages. For under-16s, DMs are off by default — so this part may already be handled. Just confirm they're off. For older teens, set this to what you're comfortable with." | Open **Direct messages**; confirm off for under-16s. *[caption: Under-16 DMs — off by default]* |
| 5 | "Then privacy. A private account is the default for under-16s — and TikTok now forces suspected under-16 accounts to private even if an older age is listed. For older teens, check the account is set to private yourself, under Settings then Privacy." | Settings → **Privacy** → confirm **Private account** on. *[caption: Private = default under-16; check it for older teens]* |
| 6 | "Two more. Restricted Mode filters more mature content — switch it on if it suits your household. And under 'who can interact,' you can decide who comments, who can Duet or Stitch their videos, who can mention them, and whether their account gets suggested to others." | Show **Restricted Mode**, then the **who-can-interact** controls (comments, Duet/Stitch, mentions, suggest-your-account). *[caption: Restricted Mode + who can interact]* |
| 7 | "One thing worth knowing: a second account, or just using TikTok in the phone's browser, can sidestep pairing. That's not a reason to worry — it's the reason your device-level controls, Apple Screen Time or Google Family Link, sit underneath all of this as a backstop." | Hold on the Family Pairing overview. *[caption: A 2nd account or the browser can bypass pairing — device layer is the backstop]* |
| 8 **Settings-move note** | "If any of these don't match your screen, that's normal — TikTok reorganises its menus more than most. Search the setting name in the app, or use the official help page: tiktok dot com slash safety. And because the menus and defaults change so often, a quick re-check each school term is the habit worth keeping." | Show tiktok.com/safety. *[caption: Menus move — search the setting name · re-check each school term · tiktok.com/safety]* |
| 9 **Close** | "That's it — paired, screen time set, DMs and privacy confirmed, and the interaction controls tuned. The strongest step now isn't another toggle — it's one short conversation. We've got starters in the conversation library, and our playbooks walk you through anything that goes wrong. If something ever does, don't troubleshoot it in the app — in immediate danger it's always 999. For an adult contacting, grooming or sextorting your child, you can report to CEOP; and for a worried or upset child, Childline is free on 0800 1111. Our emergency page has the full list." | Calm close. *[caption: Full guide: /library/platforms/tiktok · Talk: /library/conversations · Playbooks: /library/playbooks · 999 · Childline 0800 1111 · CEOP ceop.police.uk · Full list: Bearings/emergency]* |

**Calm close (read over the end card):** "Full written version is at slash library, platforms, TikTok. The right few things, set once — calm, not complicated — and a conversation to go with them."

---

## Roblox — video script

**Video Script — Roblox Parental Controls (approx. 3-4 minutes)**

**Goal:** Walk a parent calmly through Roblox's linked parental controls — maturity, chat, screen time and spending — and explain the 2026 age changes, without panic.

**You will need:** your own phone with the Roblox app, a way to verify your age (ID or credit card), and your child's Roblox account details to link to.

*Founder note before recording: keep the tone calm and plain. Name what's already fine as clearly as what to change. Show the menu, not just the tap.*

| # | What to say (calm, first-person voiceover) | What to tap (on-screen action) |
|---|---|---|
| 1 | "Roblox is one to re-check, because it changed a lot for 2026. The good news: it gives you genuine controls — blocks, limits and approvals — all from your own phone. Let's set them up together." | Open the Roblox app on your phone. [on-screen caption: Roblox — Parental Controls] |
| 2 | "First, the foundation. You set up your own account, verify your age with ID or a credit card, then link it to your child's account. Everything is PIN-protected, so your child can't quietly switch it off." | Tap **Settings**, then **Parental Controls**. Set up your account, verify your age, then link to your child's account. [on-screen caption: Settings -> Parental Controls] |
| 3 | "While we're here — one quick thing about age. From January 2026 Roblox asks for a short video-selfie age check to use chat, and it uses that to keep adult and minor chat groups apart. It's still rolling out, so it may look a little different on your screen. Make sure your child's account shows their real date of birth, because nearly every protection keys off it." | Check the account's date of birth is correct. [on-screen caption: Age check — real DOB matters] |
| 3b | "And there's a bigger change for younger children: from June 2026 Roblox is rolling out new account types — Roblox Kids for 5- to 8-year-olds and Roblox Select for 9- to 15-year-olds, both with curated games — and parental controls now reach up to age 15. This one's still rolling out too, so check what your child's account offers." | Show the account-type / age-group screen if present. [on-screen caption: New 2026 — Roblox Kids (5-8), Roblox Select (9-15)] |
| 4 | "Now the setting most parents want first: maturity. This sets the ceiling on the kind of content they can reach — Minimal, Mild, Moderate, and so on. Pick the level that fits your child, not the maximum." | Tap **Content maturity level** and choose your ceiling. |
| 5 | "Next, chat and connections. Here you can turn off text and voice chat, review who they're connected to, and block or approve individual games one by one. If chat is already off and that suits you — that's fine, you can leave it." | Tap **Chat & connections**. Adjust chat, review connections, block or approve games. |
| 6 | "Screen time. A simple daily limit, set here. You don't need to be strict to be sensible — pick something you can both live with." | Tap **Screen-time** and set a daily limit. |
| 7 | "And spending — this is the one that catches families out. Set a monthly Robux cap and switch on notifications, so there are no surprise charges. Unexpected in-game spending is a common surprise, and this is the setting that helps." | Tap **Spending limits**. Set a monthly Robux cap and turn on notifications. |
| 8 | "That's the core done — maturity, chat, screen time and spending, all PIN-protected." | [on-screen caption: settings move — if a path doesn't match, search the setting name in-app] |
| 9 | "One last thing. These controls reduce exposure and surprises — they're not a guarantee, and they won't read messages for you. The real protection is the conversation alongside them. We've got starters at the conversations library, and if something ever feels wrong, our playbooks walk you through it. If something ever does go wrong, don't troubleshoot it in the app — in immediate danger it's always 999. If an adult is contacting, grooming or pressuring your child, you can report to CEOP; and for a worried or upset child, Childline is free on 0800 1111. Our emergency page has the full list." | [on-screen captions: /library/conversations · /library/playbooks · 999 · CEOP ceop.police.uk · Childline 0800 1111 · Full list: /emergency] |
| 10 | "If a menu has moved since we filmed this, the official Roblox help pages are linked below — and you'll find the full written guide on our settings page." | [on-screen captions: about.roblox.com/parental-controls · about.roblox.com/age-estimation · /library/platforms/roblox] |

*Settings-move note to read at the close: "Roblox renames and relocates settings fairly often. If anything on your screen doesn't match, search the setting name inside the app or use the official link below — and re-check the 2026 age and account changes, as they're still rolling out."*

**Calm close:** "That's Roblox sorted for now. Calm, not complicated — the right few settings, and a conversation to go with them."

---

## Discord — video script

**Length:** ~3 minutes · Companion to the guide at `/library/platforms/discord`

**Goal:** Walk a parent calmly through linking Discord's Family Centre and setting the handful of controls that matter — and being clear about what's already taken care of.

**You will need:** your phone with the Discord app, your teen's phone (to scan the QR code), and about ten minutes. This is a both-sides setup, so do it together. (The video runs about three minutes; the hands-on setup is the ten.)

---

| # | What to say (calm voiceover) | What to tap (on-screen) |
|---|---|---|
| 1 | "Discord is for ages 13 and up. The parent tool is called Family Centre, and it's opt-in on both sides — so you and your teen link your accounts once, together. One guardian can link up to eight teens, if you've more than one." | Open the Discord app. `[caption: Discord — Family Centre]` |
| 2 | "First, let's set expectations on what this shows. Family Centre gives you a 7-day activity feed and a weekly email — new friends added, servers they've joined or created, who they messaged or called, and total call minutes. That's names and metadata only — never message content, and there's no purchases summary. It's for noticing patterns and starting conversations, not reading their chats." | Hold on the home screen. `[caption: patterns, not chats]` |
| 3 | "To set it up: go to User Settings, then Family Centre, and enable it. Then scan the QR code on your teen's phone to link." | Tap User Settings → **Family Centre** → enable → scan teen's QR. `[caption: link via QR]` |
| 4 | "Good news on content: for UK teens, the sensitive-content filter only offers blur or block — the 'show' option is removed by UK rule. So pick blur or block; that part's largely handled for you." | Open **Sensitive-content filter** → choose blur or block. |
| 5 | "Now friend requests. Restrict these to friends-of-friends or server members, so it's not wide open to strangers." | Set **Friend requests** → friends-of-friends / server members. |
| 6 | "Server DMs — this decides whether people in a shared server can message your teen directly. Set it to what you're comfortable with." | Toggle **Server DMs**. |
| 7 | "Message requests filters people who aren't friends into a separate folder. One note: in the UK, changing this needs an age-verified adult — so it may ask you to verify." | Review **Message requests**. `[caption: may need age-verified adult]` |
| 8 | "Last one — Data and privacy. Turn off personalised-data and sponsored-content personalisation." | Open **Data & privacy** → turn both off. |
| 9 | "Once you're linked, only you can change these — your teen can't undo them from their side." | Return to Family Centre overview. |
| 10 | "[settings move note] Discord changes its menus often, and there's a 2025–26 change: UK age checks — a face scan or ID — arrived in July 2025, and accounts are treated as teen-by-default until verified as adult. That flow has been shifting, so if a label looks different, the official Family Centre article at support.discord.com has the current path." | `[caption: support.discord.com]` |
| 11 | "That's it — a few minutes, the right settings. The real follow-up is a conversation about who they accept and message. We've got starters in the conversation library. And if something ever feels wrong, the playbooks point the way — and in an emergency, go straight to our emergency page or 999." | `[caption: /library/conversations · /library/playbooks · /emergency]` |

**Calm close:** "You've set the things that matter and you know what this view can and can't tell you. Re-check it once a term — that's the habit."

---

## WhatsApp — video script

**[BRAND] Screen-Recording Script: WhatsApp Privacy Settings**
*Approx. 3 minutes · first-person voiceover, calm and unhurried*

**Goal:** Walk a parent through the handful of WhatsApp privacy settings that matter, and be honest about what the app can and can't do.

**You will need:** A phone with WhatsApp installed and signed in, screen recording on. Decide beforehand whether you're filming on the child's phone alongside them or demoing on your own.

**Opening note (no tapping yet):** *"Two quick honest things before we start. WhatsApp has no parental dashboard for ages 13 and up — so we're not installing monitoring, we're just tightening a few privacy settings. There is a separate parent-managed account for under-13s, but that's still changing through 2025–26, so check in-app for what's available. And either way it won't let you read chats; messages are end-to-end encrypted. What we can do is control who reaches your child. That's plenty."*

| # | What to say (voiceover) | What to tap (on-screen) |
|---|---|---|
| 1 | "Open WhatsApp and go to Settings, then Privacy. That's our home base for today." | Open WhatsApp → **Settings → Privacy** |
| 2 | "First, Groups. Set this to My Contacts. This is the big one — it stops strangers adding your child straight into group chats." `[on-screen caption: Groups → My Contacts]` | Tap **Groups** → select **My Contacts** |
| 3 | "Back in Privacy: Last seen and Online, Profile photo, and About. Set each to My Contacts, or Nobody if you'd rather. This limits what people outside their contacts can see." `[on-screen caption: Last seen · Profile photo · About]` | Tap each in turn → choose **My Contacts** / **Nobody** |
| 4 | "Now turn off Live location, and while you're here, glance at disappearing messages — that's set per chat, so it's worth a quick look." | **Live location → Off**; open a chat to show **disappearing messages** |
| 5 | "Next, two-step verification. This one's under Settings, then Account. Turn it on and set a PIN — it makes the account itself much harder for someone else to hijack." `[on-screen caption: Settings → Account → Two-step verification → On]` | Back to **Settings → Account → Two-step verification → On** |
| 6 | "Last, the human skill: show your child how to block and report an unknown number. WhatsApp can also filter messages from people not in their contacts." | Open a chat from an unknown number → show **Block / Report** |

**Settings-move note (say near the end):** *"If any of those didn't sit exactly where I showed you, don't worry — menus get renamed and moved. Search the setting name inside the app, or use the official help page, faq dot whatsapp dot com. We keep the live version on our site at /library/platforms/whatsapp."* `[on-screen caption: Menus move — official help: faq.whatsapp.com · Full guide: /library/platforms/whatsapp]`

**On age (brief):** *"One thing to know: the UK minimum age is 13 — that dropped from 16 back in April 2024, so the old 16 figure you might remember is out of date. It's self-declared with no verification, which is exactly why your device-level controls and a good conversation matter more than the birthday on the account."*

**Calm close:** *"That's it — a few minutes, the right settings, done. For a conversation starter to go with this, see our conversation library at /library/conversations. And if you're ever dealing with something happening right now, this video isn't the place. In immediate danger it's always 999. If an adult is pressuring your child for images or sextorting them, you can report to CEOP. And for a worried or upset child, Childline is free on 0800 1111. The full list of who to contact is on our emergency page."* `[on-screen caption: 999 · CEOP ceop.police.uk · Childline 0800 1111 · Full list: /emergency · Talk: /library/conversations]`

---

## Fortnite / Epic Games — video script

**Goal:** Calmly set up Epic parental controls behind one PIN, and confirm the chat, purchase and language settings — without panic, in a few minutes.

**You will need:** The child's Epic Games account signed in (in-game, or at the Epic Account Portal), and a 6-digit PIN you'll choose and remember.

**A note before we start — settings move.** Epic renames and relocates things. If a screen doesn't match mine, search the setting name in-app or use the official help links at the end. Everything here uses only what Epic documents.

| # | What to say (calm voiceover) | What to tap (on-screen) |
|---|------------------------------|--------------------------|
| 1 | "First, the big picture. Fortnite runs on an Epic account. If your child is under 13 in the UK, they get what Epic calls a Cabined Account — chat, purchases and adding friends are blocked until you consent by email. Setting up parental controls is what lifts that cabin, so let's do it on purpose. Epic also estimates age in some sign-up flows — the exact UK method isn't confirmed, so the birthday on the account still matters." | [on-screen caption: *Under-13 = Cabined Account*] Show the account/age screen |
| 2 | "We'll put everything behind one parent PIN. Sign into your child's account at the Epic Account Portal, or in-game go to Settings, then Parental Controls." | Open **Settings → Parental Controls** |
| 3 | "Set a six-digit PIN now. This is the lock for every control we're about to touch — pick something your child won't guess, and that you'll remember." | Enter and confirm the **6-digit PIN** [on-screen caption: *One PIN locks the rest*] |
| 4 | "Now chat. Under Voice and text chat, choose who they can talk to. There's no single right answer — pick what fits your child and your agreement at home." | Tap **Voice & text chat**, set the option |
| 5 | "Next, spending. Turn on Require PIN for purchases so nothing gets bought in one tap. You can also review spend on this screen." | Toggle **Require PIN for purchases**; glance at spend |
| 6 | "Good news on language — for under-13s the mature-language filter is always on in text chat. For older children, set it here. Either way, confirm where it stands rather than assume." | Check the **Mature-language filter** setting [on-screen caption: *Always on under 13 — confirm for older kids*] |
| 7 | "Last one. Opt in to Epic's email report, which lets you know when account settings change — a quiet heads-up, not surveillance. The labels and timing can vary, so confirm what's on offer on your screen." | Enable **Email reports** |
| 8 | "That's the setup. Notice how much was already sensible — cabined by default under 13, and the language filter always on in text chat for under-13s. We confirmed those and tuned chat and spending. The best next step isn't another setting — it's a chat about who it's OK to play with and the rule on real money. There are openers in our conversation library." | [on-screen caption: */library/conversations*] |

**Settings-move note (read at end):** "If any screen looked different, that's normal — search the setting name in-app, or check Epic's parental-controls page, linked on screen." [on-screen caption: *safety.epicgames.com/en-US/parental-controls · epicgames.com/site/en-US/cabinedaccounts*]

**Calm close:** "This isn't about locking everything down or worrying every night — it's the right few settings, set once, behind a PIN you control. If something ever goes wrong, our playbooks point you to the next step. For immediate danger, call 999. For a worry about contact, content or a distressed child, there's Childline on 0800 1111, free and round the clock; and for an adult pressuring a child, you can report to CEOP — the full list is on our emergency page. That's it — you're set." [on-screen caption: *999 · Childline 0800 1111 · CEOP · full list: [BRAND]/emergency*]

---

## YouTube / YouTube Kids — video script

**Run time: ~3 minutes** · For [BRAND] Platform Settings Library · Updated [DATE]

**Goal:** Walk a parent calmly through the handful of YouTube settings that actually matter, on a supervised main account and in YouTube Kids — what to change, and what's already fine.

**You will need:** Your child's device or your linked Family Link / supervising account, signed in. A few quiet minutes.

**A note before we start (read once):** Menus move — YouTube renames and relocates settings often. If something on your screen doesn't match mine, search the setting name in the app, or use the official help link at the end. And remember: these are sensible controls, not a guarantee or a way to monitor — the goal is fewer rough edges, not surveillance.

| # | What to say (calm, first-person) | What to tap (on-screen action) |
|---|---|---|
| 1 | "First, the big picture. There are two tiers here. YouTube Kids is a separate, curated app for under-13s. Main YouTube can be run as a supervised account — you manage that through the in-app Family Centre or Google Family Link. And for most teens on standard YouTube, your real backstop is the device layer — Family Link or Screen Time. So if you've set that up already, you're further along than you think." | Show the YouTube app icon and the YouTube Kids app icon side by side. [on-screen caption: Two tiers — Kids app + supervised main account] |
| 2 | "Let's start on a supervised main account. The first setting is the content level. You've got three: Explore, which is roughly 9-plus; Explore More, around 13-plus; and Most of YouTube. Pick the one that matches your child's age band — no need to overthink it. If you can't find it in the YouTube app, you can also reach it from Family Link: open Controls, then Content filters, then YouTube." | Tap into the supervised account's settings and show the content-level options. [on-screen caption: Content level — pick to match the age band · also via Family Link → Controls → Content filters → YouTube] |
| 3 | "Next, Autoplay. This is the one that quietly turns ten minutes into an hour. Switch it off so one video doesn't roll straight into the next." | Toggle Autoplay off. [on-screen caption: Autoplay — off] |
| 4 | "Now watch and search history. You can pause it, or clear it. That's worth doing because it calms down what gets recommended next — the feed stops chasing one rabbit hole." | Show the pause-history and clear-history options. [on-screen caption: History — pause or clear] |
| 5 | "Added in March 2026, the Shorts daily limit can be set right down — as low as zero. If the endless short-video scroll is your main worry, this is one of the most useful levers you have." | Open the Shorts daily limit and show it set to zero. [on-screen caption: Shorts limit (added March 2026) — can be set as low as zero] |
| 6 | "And finally on main YouTube — take-a-break and bedtime reminders. Gentle built-in nudges for healthier stretches and for sleep. Turn them on and let the app do the reminding for you." | Enable take-a-break and bedtime reminders. [on-screen caption: Take-a-break + bedtime reminders] |
| 7 | "If your child is under 13, you'll be in YouTube Kids instead. Same idea, four things to check: the content level, whether search is on or off, a timer, and approved-content-only mode if you want a tightly curated set for a younger child." | Switch to YouTube Kids; show content level, search on/off, timer, approved-content-only mode. [on-screen caption: YouTube Kids — content level · search · timer · approved-only] |
| 8 | "Quick word on age. Main YouTube is for 13 and up. Under-13s should be on YouTube Kids or a supervised account — almost everything keys off getting the age band right, so it's worth checking." | Show where the account's age band / supervision status is set. [on-screen caption: Main account = 13+] |

**Settings-move note (say at the end):** "If any of those weren't where I showed them, that's normal — search the setting name in the app, or tap the official help links on screen now: the main YouTube help page, and the separate YouTube Kids one. We keep the full written guide current at [BRAND] /library/platforms/youtube. And because these tiers, the Shorts limit and the age checks change often, a quick re-check each school term is the habit." [on-screen caption: Official help: support.google.com/youtube/answer/13877231 · YouTube Kids: support.google.com/youtubekids · Full guide: [BRAND] /library/platforms/youtube]

**Calm close:** "That's it — content level, Autoplay off, history paused, Shorts capped, reminders on. The next step isn't another setting, it's a two-minute chat — ask them to show you one channel they love. We've got openers at /library/conversations. If recommendations keep drifting or limits get ignored, head to /library/playbooks. And if anything ever feels live or frightening, don't troubleshoot — go straight to /emergency. You've done the right things today." [on-screen caption: /library/platforms/youtube · /library/conversations · /library/playbooks · /emergency · Official help: support.google.com/youtube/answer/13877231 · YouTube Kids: support.google.com/youtubekids]

---
