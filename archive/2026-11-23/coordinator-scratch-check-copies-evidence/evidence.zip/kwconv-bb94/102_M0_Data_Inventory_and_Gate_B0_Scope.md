# 102 — M0 Data Inventory and Gate B0 Scope

*Created 2026-07-05. Status: M0 deliverable per build plan `100_Automated_Build_Plan.md` §2 M0 ("Gate B0 scoping + data inventory") and §5 Gate B0. This document is the founder-side briefing pack for the solicitor engagement; it is not legal advice and nothing in it is a settled legal position. Lawful bases are CANDIDATES for the solicitor to confirm or replace.*

**Product context (fixed facts this document is consistent with):** the automated Keepwise offering (blueprint `99`, build plan `100` v1.1, tool specs `101`). **£49 one-off, VAT-inclusive** pilot price; **£29/yr Stay Current renewal** (first year included); no founding pricing; Concierge retired; no per-customer human labour; plans assembled deterministically from editor-published content blocks (no runtime LLM; locked crisis signpost in `lib/signpost.ts`). The optional child-first-name field was **deleted 2026-07-04** — the product now collects no child name anywhere (`lib/questionnaire-data.ts:87-89`; `supabase/schema.sql:54-57`).

**Sources read for this document:** `supabase/schema.sql`; `app/api/{quiz,events,schools,concierge}/route.ts`; `components/{Quiz,StartSafetyCheck,ConciergeEnquiryForm,SchoolEnquiryForm,Analytics}.tsx`; `lib/{events,questionnaire-data,pii,pricing,checkout}.ts`; plan `100` §1.9, §4.2, §5; drafts `86`; templates `79`; audit register `94` items F24/F25/F71; decision log `88`.

---

## Part 1 — The data inventory

### 1.1 How the app stores and protects data (current architecture)

- All persistence is Supabase Postgres. The app talks to the database **only through the service-role key** (`lib/db.ts`); there is no client-side database access.
- **RLS is enabled on all ten tables with no policies** (`supabase/schema.sql:133-142`), so the anon and authenticated keys can read and write nothing. This is a deliberate hardening posture (audit F4 / plan 93 R2): if client-side access is ever added, explicit policies must be written; RLS is never disabled (`supabase/schema.sql:126-132`).
- Every API route that accepts a payload runs `checkNoChildPii()` first and rejects (HTTP 422) any payload whose **field names** match child-PII patterns (child name, full name, DOB, school, screenshot, photo, image/message upload) — `lib/pii.ts:12-22, 51-57`. This is a key-name guard, not a free-text content scanner; free-text fields rely on visible notices plus review/redaction before storage (`lib/pii.ts:46-49`).
- Analytics is **cookieless**: Plausible script plus a first-party `events` table. The anonymous session id lives in `sessionStorage`, not a cookie (`components/Analytics.tsx:7-13, 20-28`).
- **No deletion tooling exists yet.** The privacy page promises deletion on request and a 30-day purge of plan answers (`app/privacy/page.tsx:103`), but there is no deletion route, no retention cron, and no tested erasure path (audit F25 notes the cron is deferred). Plan `100` §2 M3 makes a tested deletion request a launch condition. Every "deletion path" cell below is honest about this.

**Repo hygiene notes surfaced by this inventory (wiring fixes, pre-B0):**

1. `app/privacy/page.tsx:103` still says answers "and the optional first name" are deleted within 30 days — the first-name field no longer exists. Stale copy; must be corrected when the F24 privacy rewrite lands.
2. `supabase/schema.sql:33` still labels Stay Current "£59/yr" in a comment, and `schema.sql:24` still allows `tier = 'concierge'` in `purchases`. Comment/data-model residue from the retired ladder; tidy at M2 so the schema matches the £49/£29 world.
3. The `StartSafetyCheck` component stores no form record, but it **does emit its selections as event props** (see `events` row below). "Click-only, nothing stored" is not quite the whole story and the privacy notice should not say it is.

### 1.2 Field-by-field inventory

Legend: **PD?** = personal data under UK GDPR (in context — a field that is anonymous alone becomes personal data when linked to an email or account). **Child?** = relates to a child (none of it identifies a child; that is the design invariant). Lawful bases are **candidates only — solicitor confirms** (Part 3a item 1).

#### Table `users` (`supabase/schema.sql:12-18`) — created at M2 with checkout; not written by any current route

| Field | Where stored | Collected via | PD? | Child? | Candidate lawful basis | Retention (proposed) | Deletion path | Minimisation note |
|---|---|---|---|---|---|---|---|---|
| `email` | `users.email` | Stripe checkout → account creation (M2) | Yes | No | Contract | Life of entitlement + 6 yrs for tax/dispute records (solicitor to confirm split) | Planned (M3 launch condition: tested deletion request) | Only identifier we hold for a purchaser; no name field, no address, no phone |
| `marketing_consent` | `users.marketing_consent` | Separate opt-in (PECR) | Yes (consent record) | No | Consent (the flag is also evidence of consent) | Keep while consent stands + suppression record after withdrawal | Planned | Defaults false (`schema.sql:15`); never bundled with purchase |
| `is_admin` | `users.is_admin` | Internal | Yes | No | Legitimate interests (admin/security) | Life of account | Planned | Admin surface governed by the §4.1 security baseline in plan `100` |

#### Table `purchases` (`schema.sql:21-31`) — M2

| Field | Where stored | Collected via | PD? | Child? | Candidate lawful basis | Retention (proposed) | Deletion path | Minimisation note |
|---|---|---|---|---|---|---|---|---|
| `stripe_session_id`, `stripe_payment_intent`, `amount_pence`, `status`, `purchased_at`, `updates_until` | `purchases` | Stripe webhook (M2) | Yes (linked to `user_id`) | No | Contract; legal obligation for the accounting subset | 6 yrs from end of financial year (HMRC records duty) — this subset survives an erasure request | Planned; erasure carve-out to be documented | Store references, not card data — Keepwise never sees card details (drafts `86` §4). Metadata minimisation: see Part 2.5 |

#### Table `subscriptions` (`schema.sql:34-40`) — M2+; Stay Current renewal £29/yr

| Field | Where stored | Collected via | PD? | Child? | Candidate lawful basis | Retention (proposed) | Deletion path | Minimisation note |
|---|---|---|---|---|---|---|---|---|
| `stripe_subscription_id`, `status`, `current_period_end` | `subscriptions` | Stripe (renewal) | Yes | No | Contract | As `purchases` | Planned | **Open design fork:** `lib/checkout.ts:34-45` treats Stay Current as a separate payment link (customer-initiated re-purchase) while this table implies a Stripe auto-renewing subscription. Whichever wins changes the renewal terms and the reminder/cancellation mechanics (F71 item 2) — solicitor decision list item 3/9 |

#### Table `quiz_responses` (`schema.sql:44-52`) — LIVE; written by `app/api/quiz/route.ts:48-54`

| Field | Where stored | Collected via | PD? | Child? | Candidate lawful basis | Retention (proposed) | Deletion path | Minimisation note |
|---|---|---|---|---|---|---|---|---|
| `email` (optional) | `quiz_responses.email` | Quiz email form, only if the parent asks for their snapshot by email (`components/Quiz.tsx:100-108, 149-190`) | Yes | No | Legitimate interests for sending the one requested snapshot email; **consent for anything beyond it** | Non-consented: delete/anonymise 30 days after the snapshot email. Consented: until unsubscribe | None today — needs the retention job | Email is optional; quiz result shows on screen regardless. Copy already promises "We'll only email you about this" (`Quiz.tsx:187`) |
| `marketing_consent` | same row | Separate unticked checkbox (`Quiz.tsx:173-182`) | Yes (consent record) | No | Consent (PECR — see Part 3a item 10) | With the email | None today | Explicitly separate from the snapshot request; PECR-clean pattern, solicitor to confirm wording |
| `score`, `band` | same row | Click-only quiz answers | Only when an email is on the row | Indirectly (household readiness, no identifiers) | Legitimate interests (product/funnel measurement) | 12 months, then aggregate | None today | `answers_jsonb` is written as `{}` — **individual quiz answers are never stored**, only the total and band (`app/api/quiz/route.ts:52`) |

#### Table `questionnaires` (`schema.sql:58-66`) — the paid diagnostic; no route yet (M2); shape fixed by `lib/questionnaire-data.ts`

| Field | Where stored | Collected via | PD? | Child? | Candidate lawful basis | Retention (proposed) | Deletion path | Minimisation note |
|---|---|---|---|---|---|---|---|---|
| `user_id` | `questionnaires.user_id` | Purchaser account | Yes | No | Contract | With the account | Planned (M3 tested) | Links every row below to an identifiable purchaser — which is why the whole record is personal data even though no field identifies a child |
| `child_age_band` | `questionnaires.child_age_band` | Q1, band picker only — `5-10 / 11-12 / 13-14 / 15-16 / 17-18` (`lib/questionnaire-data.ts:58-64, 73-79`) | Yes (via account link) | Yes — about a child, identifies none | Contract (needed to assemble the plan) | While entitlement is active; deletion on request | Planned | Band, never DOB (`schema.sql:2-3, 55-57`). M0 flag decision: Q1 becomes multi-band for multi-child households (plan `100` §7 flag 2) — still bands only |
| `answers_jsonb` — answer **option ids** for Q2–Q24 | `questionnaires.answers_jsonb` | Structured single/multi choices: devices, device location, settings setup, social/messaging/gaming platforms, AI tools, and the talked-about-it concern questions (`lib/questionnaire-data.ts:71-322`) | Yes (via account link) | Yes — household facts about a child's online life, no identifiers | Contract | While entitlement is active; deletion on request. `/privacy` currently promises answer deletion within 30 days of delivery (`app/privacy/page.tsx:103`) — **that promise conflicts with re-check and multi-year entitlement features; solicitor + founder must reconcile (Part 3a item 2)** | Planned | Every answer is an enumerated option id — no free text anywhere in Q1–Q24. "Don't know" is always offered so parents are never pushed to disclose |
| `household_children` (sibling count) | inside `answers_jsonb` | Q2, single choice **banded: "1", "2", "3+"** (`lib/questionnaire-data.ts:81-86`) | Yes (via account link) | Yes (household composition) | Contract | As `answers_jsonb` | Planned | **Kept, with justification — see §1.3** |
| `free_text` (Q25 `priority_note`, the parent worry box) | `questionnaires.free_text` | Optional final text box, flagged `pii: true`, with the visible notice "Please don't include names, your child's school, or details of any live incident…" (`lib/questionnaire-data.ts:323-331`) | Yes — and could contain anything a parent types | Potentially, despite the notice | Contract for the priority request itself; the field is treated as high-risk regardless | **`purge_after` = submitted_at + 30 days** (`schema.sql:63-65`); purge job must exist before first sale | Planned — the +30d purge is a B0 launch condition, not an aspiration | Never parsed by the assembly engine and never rendered into a plan (plan `100` §3.4 rule: "`priority_note` is never parsed — PII, rendered nowhere"). Redaction path: reviewed/redacted before storage per `schema.sql:63` — the concrete mechanism (redact-on-ingest vs review-then-store) is an M2 spec item the solicitor should see |
| `submitted_at`, `purge_after` | same table | System | Yes (metadata of a personal record) | No | Contract | With the record | Planned | `purge_after` is the enforcement column for the worry-box promise |

#### Table `plans` (`schema.sql:70-78`) — the assembled output; M2

| Field | Where stored | Collected via | PD? | Child? | Candidate lawful basis | Retention (proposed) | Deletion path | Minimisation note |
|---|---|---|---|---|---|---|---|---|
| `content_mdx`, `pdf_url`, `status`, `delivered_at` | `plans` | Derived — assembled from published blocks + the questionnaire | Yes (derived personal data, linked to `user_id`) | Yes (a plan about a household's children, no identifiers in it) | Contract | Life of entitlement (it is the product); deletion on request deletes the plan too | Planned | Interpolated values inside the plan are whitelist-only: age-band label(s), ticked platform names, sibling count (plan `100` §3.4 step 5). Schema comment "assisted, human-in-the-loop" (`schema.sql:68`) is stale under the automated model — `status` transitions become engine-driven; tidy at M2 |

#### Table `briefings` (`schema.sql:81-87`) — M4

Content only (`month`, `subject`, `body_mdx`, `sent_at`). **No personal data.** Recipient targeting at M4 will use `users`/`purchases`, reviewed at Gate B1, not B0.

#### Table `events` (`schema.sql:91-98`) — LIVE; written by `app/api/events/route.ts:41-48`

| Field | Where stored | Collected via | PD? | Child? | Candidate lawful basis | Retention (proposed) | Deletion path | Minimisation note |
|---|---|---|---|---|---|---|---|---|
| `type` | `events.type` | 32-name closed enum (`lib/events.ts:8-42`); unknown types rejected (`app/api/events/route.ts:37-39`) | No (alone) | No | Legitimate interests (cookieless funnel analytics) | 13 months, then delete or aggregate (proposed) | None today — needs the retention job | Closed vocabulary; nothing free-form in the type |
| `session_id` | `events.session_id` | Random UUID from `sessionStorage` ("bsid"), generated client-side; **currently attached only to the once-per-session `visit` event** (`components/Analytics.tsx:20-28`) — all other `track()` call sites omit it | Borderline — an online identifier; treat as personal data for safety (ICO's cautious view of online identifiers) | No | Legitimate interests | As `events` | None today | Not a cookie, dies with the tab session, never joined to `user_id` today (`events.user_id` is never set by the route — `app/api/events/route.ts:43-47`). **If session ids are ever joined to accounts, the analytics story changes — flag to solicitor** |
| `props_jsonb` | `events.props_jsonb` | Per-event props: quiz `band`, `marketing_consent` boolean on `email_capture` (`components/Quiz.tsx:99`), and — material — the `/start` checker's selections `{ageBand, startingPoint, selectedTools}` on `plan_recommendation_view` (`components/StartSafetyCheck.tsx:70-79`) | No as stored today (no identifier on those events) | Weakly (an age band with no session id and no account) | Legitimate interests | As `events` | None today | The `/start` checker (`components/StartSafetyCheck.tsx`) stores **no form record** — its four steps are click-state only and the final screen says "nothing child-identifiable has been collected" (`StartSafetyCheck.tsx:298-301`), which is true; but the selections do reach `events.props_jsonb` as unlinked analytics and the privacy notice must say so. Child-PII keys are rejected at the route (`app/api/events/route.ts:23-29`) |
| `user_id` (nullable) | `events.user_id` | Not populated by any current code | — | — | — | — | — | If M2+ ever sets it, those events become account-linked personal data; requires a privacy-notice update first |

#### Table `enquiries` (`schema.sql:103-113`) — school kind LIVE; concierge kind DORMANT

| Field | Where stored | Collected via | PD? | Child? | Candidate lawful basis | Retention (proposed) | Deletion path | Minimisation note |
|---|---|---|---|---|---|---|---|---|
| `kind`, `contact_name`, `email`, `organisation`, `role` | `enquiries` | **School form (live):** `components/SchoolEnquiryForm.tsx` on `/for-schools` (`app/for-schools/page.tsx:172`) → `app/api/schools/route.ts:50-58`. Adult staff/PTA contact; `organisation` is the institution, never a child's school (`app/api/schools/route.ts:10-12`) | Yes | No | Legitimate interests (responding to a B2B enquiry) | 12 months from last contact, then delete (proposed) | None today | Form copy promises "We'll only use these details to reply to your enquiry. No child data, ever" (`SchoolEnquiryForm.tsx:71-74`) |
| `message` (free text) | `enquiries.message` | School form optional textarea (`SchoolEnquiryForm.tsx:67-70`) | Yes — free text could contain anything | Potentially | Legitimate interests | As above | None today | Audit F72 (Held): this textarea lacks the in-field "no pupil names/incident detail" notice the concierge form has — **fix before B0 submission**; the key-name PII guard cannot inspect content (`lib/pii.ts:46-49`) |
| Concierge enquiry fields (`age_bands`, `household_scope`, `preferred_contact`, `parent_carer_confirmed` in `props_jsonb`) | `enquiries` rows with `kind='concierge'` | **Dormant.** `components/ConciergeEnquiryForm.tsx` and `app/api/concierge/route.ts` exist but are referenced by no page — `/concierge` is a form-less honest notice (`app/concierge/page.tsx:13-19`) | Would be, if re-lit | Bands only | n/a while dormant | No new rows can be created; delete any legacy rows | n/a | Documented so the solicitor sees the dormant socket exists. If Concierge is ever re-lit, that is a new processing activity requiring a notice update first |

#### Table `feedback` (`schema.sql:116-124`) — M3+

| Field | Where stored | Collected via | PD? | Child? | Candidate lawful basis | Retention (proposed) | Deletion path | Minimisation note |
|---|---|---|---|---|---|---|---|---|
| `usefulness`, `took_action`, `calmer`, `recommend` | `feedback` | Post-delivery feedback form (M3+) | Yes via `plan_id` → `user_id` chain | No | Legitimate interests (product improvement) | Detach from `plan_id` (anonymise) after 12 months; keep scores aggregate-only | Planned | Structured scores, no identifiers of their own |
| `notes` (free text) | `feedback.notes` | Same form | Yes | Potentially | Legitimate interests | Keep only no-child-detail product notes; redact before storage (pattern from `86` §6) | Planned | Same visible-notice + review treatment as every other free-text field |

#### Client-side and third-party (no database row)

| Item | Where | PD? | Note for the privacy notice |
|---|---|---|---|
| `bsid` session id | Browser `sessionStorage` only (`components/Analytics.tsx:20-28`) | Treat as online identifier | Not a cookie; expires when the tab session ends; used only to stitch funnel steps. **No cookie banner is needed for analytics because no cookies or equivalent persistent storage are used — solicitor to confirm the PECR "strictly necessary/anonymous" analysis for sessionStorage** |
| Plausible analytics | External script `plausible.io/js/script.js`, loaded only when `NEXT_PUBLIC_PLAUSIBLE_DOMAIN` is set (`components/Analytics.tsx:35-44`) | Aggregate; Plausible is cookieless by design | Plausible must appear on the processor list; disclosure wording in Part 2.4 |
| Stripe checkout | Stripe-hosted payment page (payment links — `lib/checkout.ts`) | Yes — Stripe collects email + card as processor/controller per its terms | Keepwise never sees or stores card details (`86` §4). Metadata rule in Part 2.5 |

#### FUTURE: the `plan_assemblies` log (plan `100` §4.2 — will be stored from sale #1)

This does not exist in `supabase/schema.sql` yet; it is a normative M2 requirement and belongs in the B0 pack **now** because it is captured from the first sale.

| Field group (plan `100` §4.2) | PD? | Child? | Candidate lawful basis | Retention (proposed) | Deletion path | Minimisation note |
|---|---|---|---|---|---|---|
| Block id/version/content-hash; source file + hash; author; checker; publish timestamp; `reviewBy`; withdrawal timestamp; render engine version; code Git SHA; signpost version/hash; PDF/template version; offer-page version at purchase | Editorial/system metadata — not customer personal data (author/checker are staff records) | No | Legitimate interests (ASA/CAP 3.7 authorship and substantiation record) | Life of product + limitation period | Not deleted on customer request (contains no customer data) | The immutable publish log half of the record |
| **Assembly id; pseudonymous household id; answer option ids; interpolation values (age-band labels, platform names, sibling count)** | **Yes. State this plainly: the pseudonymous household id resolves to an identifiable purchaser account, so the assembly log ties a set of answers about a household's children to an identifiable person. It is personal data and Gate B0 treats it as such** (plan `100` §1.9, §4 rules) | Yes (band-level, no identifiers) | Legitimate interests (defending the accuracy/traceability of advice given; consumer-dispute and regulatory substantiation) — solicitor to confirm this basis and the balancing test | **Solicitor decision (Part 3a item 6).** Founder proposal: retain 6 years from delivery (limitation period), with the personal half **de-linked** (household id destroyed or re-hashed) on account erasure while the editorial half survives | Erasure request de-links; does not destroy the editorial record | The log stores **option ids**, not prose; `free_text` is never copied into it; the audit render must be byte-identical from these fields alone (plan `100` §4.2), which is why deletion is a de-link, not a row delete |

### 1.3 The sibling-count justification (data-minimisation record required by plan `100` §1.9 and §2 M0)

**What is collected:** Q2, "How many children in the household use connected devices?" — enumerated options **"1", "2", "3+"** only (`lib/questionnaire-data.ts:81-86`).

**Why it is needed:** the product is a **whole-household plan**. Sibling count is on the interpolation whitelist (plan `100` §3.4 step 5) because plan copy must read correctly for one child versus several ("your child" vs "your children"; whether splice connectors and per-band sections render for multi-child households — plan `100` §7 flag 2). Without it, multi-child plans either overclaim (pretending per-child coverage) or read wrongly (singular copy for a three-child household).

**Why it is minimised enough:**
- It is stored **band-level only** ("3+" caps it) — the proposal recorded here is that band-level storage is the permanent rule; no exact count above 3 is ever collected.
- It contains **no identifiers**: no names, ages (beyond the separately-collected age band(s)), sexes, or any per-child attribute. It is a household attribute of the parent's account, comparable to "number of devices".
- The alternative — not collecting it — was considered and rejected because the interpolation need is real and the field is the least-identifying possible form of the information.

**Solicitor asks:** confirm the necessity/proportionality analysis above holds for the contract basis, and that band-level storage is an adequate minimisation position (Part 3a item 1).

### 1.4 Why the assembly log paragraph matters (restated for the solicitor)

The public data promise (Part 2, and plan `100` §1.9) enumerates what is never collected. It must sit honestly beside the fact that Keepwise **does** keep, per sale: a pseudonymous household id, the answer option ids, and the interpolation values, indefinitely-by-default, to make every plan auditable. The privacy notice must disclose this log in plain English (proposed line: *"We keep a technical record of which guidance blocks your plan was built from and which answer options selected them, so we can show exactly what advice you were given and why. This record is linked to your account."*). B0 cannot pass while the notice is silent on it.

---

## Part 2 — The B0 pack scope, mapped to existing assets

Gate B0 (plan `100` §5) blocks the first sale and covers: privacy notice, terms of sale, refund/cancellation wording with the digital-content acknowledgement, support mailbox + bounded support process, Stripe metadata minimisation, the enumerated data promise, the assembly-log classification, and the VAT position note. Plan `100` §5 states the pack "lifts from existing repo assets… wiring plus solicitor sign-off, not fresh invention." This section is that wiring map.

### 2.1 Adapting `86_AI_Safety_Course_Founding_Pilot_Terms_Privacy_Drafts.md`

The `86` scaffolds were written for a five-buyer manual course pilot. The structure survives; the substance changes as follows.

| `86` section | Reuse? | What must change for the automated £49 product |
|---|---|---|
| Pre-Payment Summary Block (`86` lines 11–39) | Yes — becomes the checkout pre-contract information block (CCR item, §2.3) | Product: "founding pilot place in the… Course" → **the Keepwise system** (name per decision log `88` 2026-07-05; Bearings naming retired — mockup reconciliation is the separate M0 naming item). Price: "GBP 49" → **"£49 one-off, VAT-inclusive"** plus **"optional renewal £29/yr after your included first year"**. What you get: four modules → **instant personalised plan, the guidance library (51 items incl. the AI guides), conversation scripts, Family Agreement builder, printables, first year of updates** — the honesty rule (plan `100` §1.4/§1.6): nothing unshipped, no course promise, no digest calendar promise. Delivery: "manual… within [TIMEFRAME]" → **"instant — your plan is assembled and delivered within minutes of payment"** (engine target p95 < 2 min, plan `100` §4). The boundary paragraph ("do not send child names…") survives verbatim. Add the **enumerated data promise** (plan `100` §1.9) verbatim: *"No child names, no dates of birth, no school names, no message uploads, no photos, no contact lists, no monitoring, and no free-text disclosures about your child. Keepwise uses minimal parent-provided household setup information to assemble your plan."* (Note: the questionnaire's optional worry box must be reconciled with "no free-text disclosures about your child" — either the box carries the promise as its notice and the purge/never-rendered mechanics make it true, or the promise wording adjusts. Solicitor item 12.) |
| Payment Checkbox Copy (`86` lines 41–63) | Yes | Keep: 18+/parent-carer; read-terms; boundary confirmation; separate optional marketing consent. **Change:** the conditional digital-content acknowledgement becomes **required for every sale** because delivery is instant (see cancellation row). Wording stays: *"I want access… before the 14-day cancellation period ends, and I understand that once the digital materials are supplied I may lose my right to cancel for that digital content."* |
| Terms §1 Who provides (`86` §1) | Yes | Placeholders [TRADING NAME]/[EMAIL]/[ADDRESS] are Ben decisions (Part 3b) — still blank in decision log `88` |
| Terms §2 What you are buying (`86` §2) | Rewrite the includes; keep the excludes | Includes list → system contents (as above). Excludes list survives and **gains one line**: no human review of your answers — add an **automated-assembly disclosure**: *"Your plan is assembled automatically from guidance blocks that our editors have written, reviewed and dated. No person reads your answers, and no AI generates the words in your plan."* (Matches the true-claims set, plan `100` §1.6.) |
| Terms §3 Eligibility | Verbatim | 18+, parent/carer. F71 item 3: this representation must also appear in the binding terms, not only checkout copy |
| Terms §4 Price (`86` §4) | Adapt | £49 one-off VAT-inclusive. **Add the renewal terms:** first year of Stay Current included; thereafter **£29/yr**; state **how renewal is taken** — the open fork (customer-initiated re-purchase via a renewal link, per `lib/checkout.ts:34-45`, versus Stripe auto-renewing subscription, per `subscriptions` table) is solicitor decision item 3/9; if auto-renewal, the reminder-before-charge and easy-cancel mechanics must be specified (F71 item 2). Keep "Payment is handled by Stripe. Keepwise does not see or store card details." |
| Terms §5 Delivery (`86` §5) | Rewrite | Manual delivery → instant automated delivery. Delete the "Do not automate instant access until…" instruction — this B0 review **is** that review |
| Terms §6 Cancellation and refunds, Options A/B (`86` §6) | Keep both options for the solicitor; recommend B | **Option A (withhold delivery for 14 days) is incompatible with the product** — instant delivery is the pitch. **Option B (early digital delivery with express consent + acknowledgement that the statutory cancellation right is lost once supply starts)** is the recommended route; solicitor confirms wording and mechanics (decision items 3–5). The separate goodwill promise — *"14-day no-quibble refund"* (current `/terms` summary; F71 item 1) — must be drafted as a **contractual refund promise sitting on top of** the waived statutory right, so the waiver and the promise don't contradict. Refund window [NUMBER] → 14 days, aligned |
| Terms §7 Boundaries (`86` §7) | Near-verbatim | "Pilot" → the service. The do-not-send list, the boundary-reply rule, and the suspected-CSAM stop rule (do not open/review/copy/forward) all survive — they are the support process (§2.2) |
| Terms §8 Emergency signpost (`86` §8) | Verbatim mechanism | Use the verified live URL (per `84`); the signpost content is the hash-pinned constant (`lib/signpost.ts:20-28`) — terms link and constant must agree |
| Terms §9 Changes during the pilot | Adapt | Becomes the content-updates clause using the **bounded "kept current" definition** (plan `100` §1.6): review dates on blocks, urgent withdrawal path, update notices — never implying platform monitoring |
| Terms §10 Feedback | Adapt lightly | Same no-child-detail rule; feeds the `feedback` table rows in §1.2 |
| Terms §11 Professional review status (`86` §11) | Replace at launch | Pre-B0 the honest draft-status line stays (F25). Once Gates A and B0 pass, replace with an accurate statement of what was reviewed — solicitor decides the final wording (decision item 8); never "certified/approved" (claims lint) |
| Privacy Notice §§1–7 (`86` lines 166–240) | Structure yes; contents replaced by Part 1 | §2 What we collect → the Part 1 inventory in plain English, **including**: quiz email + consent flag; enquiry data; cookieless events + session id; Plausible; questionnaire answers (option ids + bands + sibling count); the worry box and its 30-day purge; **the assembly log disclosure** (§1.4); Stripe references. This closes **F24**. §4 Lawful bases → Part 1 candidates, solicitor confirms. §5 Processors → Stripe, Supabase, hosting (Vercel or equivalent — confirm), Plausible, [EMAIL PROVIDER]. §6 Retention → the Part 1 schedule, signed off. §7 Rights → keep, incl. ICO complaint line; the rights contact must be the real support inbox (Ben decision; audit F27/F28 — placeholder `hello@example.com` must be impossible in production) |
| Confirmation Email Add-On (`86` lines 242–262) | Yes | Becomes the **durable-medium confirmation** (§2.3): sent at purchase, restating product/price/provider/terms/privacy/refund-cancellation **including the recorded digital-content acknowledgement and the delivery-start statement**. Wire into template `79` Email 1 |
| Publication Gate (`86` lines 264–274) | Superseded | Replaced by the B0 PASS checklist (Part 3) |

### 2.2 Adapting `79_AI_Safety_Course_Founding_Pilot_Email_Templates.md` — the bounded support process

Zero-per-customer-labour does not mean zero support; it means support is **bounded and templated**. The `79` set maps as:

| `79` template | Fate in the automated product |
|---|---|
| Email 1 (purchase confirmation) | Survives as the transactional purchase/durable-medium email, merged with the `86` confirmation add-on. Automated. Purchase summary updated: Keepwise system, £49 VAT-inclusive, instant delivery line, £29/yr renewal note |
| Email 2 (materials delivery) | Merges into Email 1 — delivery is instant, so confirmation and delivery are one email linking to the plan hub. The boundary reminder paragraph survives |
| Email 3 (gentle nudge) | Optional activation nudge ("your plan is waiting") — a service email, PECR position to confirm (item 10). Not launch-blocking |
| **Email 4 (boundary reply for live concerns)** | **Kept near-verbatim. This is the core of the bounded support process:** cannot advise on live situations; emergency signpost link; 999 line; do-not-send list; the already-sent rule ("I will not open, review, copy, forward…"). Sent manually from the support inbox using the template — templated human response, not per-customer product labour |
| Email 5 (feedback request) | Survives for the M3+ feedback loop; no-child-detail rule intact |
| Email 6 (refund confirmation) | Survives as the refund template — aligns with the final refund wording from §2.1 |
| Email 7 (thank you/close) | Optional; keep |
| **Send Rules (`79` lines 149–159)** | **Become the written support-process policy for B0:** boundary reply for any live concern; no follow-up questions on live situations; never open/handle unsolicited material; the suspected-CSAM stop rule (halt channel, qualified route, legal/safeguarding advice); log boundary **issue type only**, identifying details removed; no outcome promises; signpost link in purchase and boundary emails. Add the two support categories the automated product answers: **boundary reply** and **non-urgent product questions** (access, refunds, deletion requests) — everything else is signposted |

The support inbox address itself is a Ben decision (Part 3b) and a production build gate (audit F27: the build should fail if `NEXT_PUBLIC_SUPPORT_EMAIL` is unset — the deletion-rights promise depends on it).

### 2.3 Consumer Contracts Regulations 2013 — checkout checklist (distance sale of digital content)

For the solicitor to verify against the implemented checkout, item by item:

1. **Pre-contract information** shown before payment: trader identity, contact address, support email (Ben decisions); main characteristics of the system (the honest includes list); **total price £49 including VAT**; the renewal (£29/yr after the included first year) and how it is taken; delivery method and timing ("instant, within minutes"); complaint handling; the existence — and conditional loss — of the 14-day cancellation right; digital-content **functionality and compatibility** information (web app, modern browser, PDF downloads).
2. **Express request for immediate supply + acknowledgement of losing the cancellation right** captured **before** delivery starts (the required checkbox, §2.1), and **recorded** (timestamped with the purchase).
3. **Durable-medium confirmation** — the confirmation email (§2.1 last row) sent within a reasonable time and in any event before supply completes, restating the pre-contract information **and the recorded acknowledgement**.
4. **Delivery-start acknowledgement** — the confirmation states that supply began at purchase with the buyer's express consent.
5. **Cancellation communications** — a stated route to cancel/refund (support inbox; no forms or hoops), the model-cancellation-form question (solicitor: is it required where the right is waived at supply?), and refund-processing commitments consistent with Email 6.
6. **Renewal comms** (if auto-renewal chosen): pre-renewal reminder and an easy cancellation mechanic (F71 item 2).

### 2.4 Cookieless-analytics disclosure

Wording for the privacy notice (solicitor to approve): *"We use Plausible, a cookieless analytics service, to count visits and page views in aggregate. We also record which steps of our own pages were used, against a random session id that lives only in your browser tab's session storage — it is not a cookie, it is not shared with anyone, and it is never joined to your account. Because we set no cookies or similar persistent identifiers for analytics, there is no cookie banner."* Facts per `components/Analytics.tsx:7-13, 20-28` and §1.2 `events` rows — including that the `/start` checker's selections (age band, starting point, areas) are recorded as unlinked analytics events (`components/StartSafetyCheck.tsx:70-79`).

### 2.5 Stripe metadata minimisation note

Rule for M2 implementation, for the solicitor to bless as a processing-minimisation commitment: Stripe checkout sessions and payment links carry **only** — internal user/purchase ids (pseudonymous), the tier (`system` / `stay-current`), and the amount. **Never** in Stripe metadata, product descriptions or statement descriptors: questionnaire answers, age bands, platform selections, sibling count, worry-box text, or anything from the diagnostic. The Stripe product name is the generic "Keepwise Household System". Keepwise stores only Stripe references (`purchases` row, §1.2), never card data.

### 2.6 Audit register items closed by this pack

- **F24 (HIGH, `app/privacy/page.tsx`):** privacy page describes only the questionnaire; silent on quiz email, enquiries, events/session id, Plausible; no retention statements. Closed by the §2.1 privacy-notice rewrite carrying the full Part 1 inventory + retention schedule.
- **F25 (HIGH, `app/privacy/page.tsx`):** no draft-status disclosure on /privacy (unlike /terms) while making a hard 30-day promise with no purge job. Interim fix: add the honest draft line now. Closed properly when the solicitor-approved notice ships **and the purge/deletion jobs exist**. Solicitor decides final disclosure wording (item 8).
- **F71 (MED, `app/terms/page.tsx`):** the three named terms gaps — refund-vs-cooling-off-waiver interaction, renewal mechanics, 18+/parental-status representation — are solicitor items 4, 5 and 9 and are resolved in the §2.1 terms adaptation.

---

## Part 3 — Decision lists

### 3(a) For the solicitor (numbered; the engagement checklist)

1. **Lawful bases** — confirm or replace every candidate basis in the Part 1 tables (contract for account/purchase/questionnaire/plan; legitimate interests for analytics, enquiries, feedback, assembly-log substantiation; consent for marketing), including the legitimate-interests balancing assessments and the sibling-count necessity analysis (§1.3).
2. **Retention schedule sign-off** — every "Retention (proposed)" cell in Part 1, including: the 30-day worry-box purge as a binding promise; reconciling the current public "answers deleted within 30 days of delivery" promise (`app/privacy/page.tsx:103`) with multi-year entitlement and re-check features; the 6-year accounting carve-out surviving erasure.
3. **Cancellation Option A vs B** (`86` §6) for instant digital delivery — confirm Option B (express request + acknowledgement, loss of statutory right at supply) and its exact wording; confirm Option A is properly rejected for this product.
4. **Refund wording vs CCR** — the goodwill "14-day no-quibble refund" drafted as a contractual promise layered over the waived statutory right (F71 item 1) without creating contradiction or reviving the statutory framework by accident.
5. **The no-quibble refund ↔ cooling-off waiver interaction** stated plainly in consumer-facing copy: buyers waive the statutory right at delivery but hold a stronger contractual one — is the proposed plain-English line acceptable?
6. **Assembly-log retention period** — the personal half of the `plan_assemblies` record (§1.2 last table): confirm the substantiation basis, set the retention period (founder proposal: 6 years from delivery), and approve the de-link-on-erasure mechanic (editorial record survives; household id destroyed).
7. **Privacy-notice completeness vs F24** — confirm the rewritten notice covers every processing activity in Part 1 (quiz email, enquiries, events + session id, Plausible, questionnaire, worry box, assembly log, Stripe) and nothing the code does is undisclosed.
8. **Draft-status disclosures vs F25** — approve the interim "being finalised with a solicitor" line and the final post-review replacement wording for both /privacy and /terms (and terms §11's replacement — never "approved/certified").
9. **F71 terms items** — (i) refund/cooling-off (items 4–5 above); (ii) **renewal mechanics**: bless whichever renewal design is chosen (customer-initiated £29 re-purchase vs auto-renewing subscription) and, if auto-renewal, specify reminder and cancellation requirements; (iii) the 18+/parent-carer representation moved into the binding terms.
10. **PECR positions** — (i) quiz snapshot email: solicited one-off email vs marketing; (ii) the separate marketing-consent checkbox wording (`components/Quiz.tsx:173-182`); (iii) future service emails (delivery, renewal reminder, activation nudge, urgent content-withdrawal notices) as non-marketing service messages — noting Gate B1 will separately cover the digest/first-phone sequence; (iv) the sessionStorage session id under PECR's storage-and-access rules (no banner position, §2.4).
11. **ICO registration/fee position** — route and tier of the data-protection fee for the trading entity (carried over from `86` Publication Gate and decision log `88`); record paid/exempt with date.
12. **The enumerated data promise as a binding public statement** (plan `100` §1.9) — approve it as marketing copy that is also a compliance commitment; specifically reconcile "no free-text disclosures about your child" with the existence of the optional worry box (never parsed, never rendered, purged +30d) — adjust either the promise wording or the field's presentation so both are strictly true.

### 3(b) For Ben (still open from decision log `88` — blank "Owner answer" cells)

1. **Trading name / legal identity** ("Ben Harwood trading as […]" or other lawful setup) — feeds every [TRADING NAME] placeholder and the data-controller identity.
2. **Business/contact address** for distance-selling disclosure — decide what can lawfully and comfortably appear.
3. **Support inbox address** — a real, monitored mailbox; production build should fail while it is a placeholder (audit F27/F28).
4. **Data-controller identity** on the privacy notice — must match the trading setup (decision 1).
5. **Delivery-timing statement** — confirm the public wording for instant delivery (proposed: "your plan is delivered within minutes of payment"; engine target p95 < 2 min) and the fallback wording if assembly is delayed.

(The product name — Keepwise — was recorded 2026-07-05 in `88`; the remaining naming work is reconciling the Bearings-branded mockups, an M0 item outside this pack. The VAT note is recorded per plan `100` §2 M0: £49 VAT-inclusive; registration threshold £90,000 — **verify the current threshold at engagement** — ≈1,837 sales; ≈£40.83 net per sale at 20% standard rate if registered and the price is held.)

### What B0 PASS means (the checklist)

Gate B0 is passed when all of the following are true:

- [ ] Solicitor has confirmed/replaced every lawful basis (3a-1) and signed off the retention schedule (3a-2).
- [ ] Privacy notice published covering the **complete** Part 1 inventory — including the assembly-log disclosure, quiz email, enquiries, cookieless analytics, and the worry-box purge — closing F24; stale "optional first name" line removed.
- [ ] Draft-status lines resolved per 3a-8, closing F25.
- [ ] Terms of sale final: automated-assembly disclosure; £49 VAT-inclusive; £29/yr renewal terms with chosen mechanics; 18+ representation; boundaries; signpost — closing F71.
- [ ] Cancellation Option B (or the solicitor's alternative) implemented in checkout: express request + acknowledgement captured and recorded; durable-medium confirmation email live; the full §2.3 CCR checklist verified against the built flow.
- [ ] Refund wording final and consistent across terms, checkout, and Email 6.
- [ ] Deletion request path **built and tested end-to-end** (plan `100` §2 M3), the worry-box +30d purge job running, and the quiz-email/enquiry retention jobs scheduled.
- [ ] Assembly-log classification recorded (personal data), retention period set, de-link-on-erasure mechanic specified for M2.
- [ ] PECR positions confirmed (3a-10); marketing consent flows verified against them.
- [ ] ICO fee position recorded (paid/exempt + date).
- [ ] Processor list final (Stripe, Supabase, hosting, Plausible, email provider) and matching the notice.
- [ ] Stripe metadata minimisation rule (§2.5) adopted as an M2 implementation constraint.
- [ ] Support inbox live and monitored; bounded support process (§2.2) adopted in writing.
- [ ] The enumerated data promise approved as a binding statement (3a-12) and published verbatim wherever the offer page cites it.
- [ ] All five Ben decisions (3b) recorded in decision log `88`.

### Estimated solicitor scope

**Small.** This is a review engagement, not drafting from scratch: the terms and privacy scaffolds exist (`86`), the support templates exist (`79`), the checkout checklist and data inventory are in this document, and the required changes are enumerated in §2.1. The solicitor reviews roughly a dozen pages of adapted drafts against this inventory, answers the twelve numbered questions in 3(a), and signs off a retention schedule that is already proposed line-by-line. Assume the plan `100` §5 turnaround (1–2 weeks); book the engagement at Gate A/B0 submission (M3 code-complete) and use the same engagement to scope Gate B1, which is a later, separate checkpoint.
