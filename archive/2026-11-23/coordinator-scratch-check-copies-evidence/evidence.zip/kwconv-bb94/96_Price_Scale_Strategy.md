# 96 — Price vs Scale: Strategy Memo

**For:** Ben · **Date:** 4 July 2026 · **Status:** Decision memo — answers the founder's question directly
**Question asked:** *"Are we more likely to get 100,000 customers at £49 or 50,000 at £99? What is the sweet spot between price and scalability? What do we need to add to the offering, or how do we need to frame it, to capture the premium market?"*
**Inputs:** File 95 (pricing & willingness-to-pay assessment) plus four fresh research legs — unit economics & elasticity, UK market size & channels, premium-market capture, and review-operations scaling. Every external figure below is sourced in the legs (links at the end); everything derived or assumed is flagged **[INF]** = inference.
**Stance:** Adversarial, no flattery. Where the evidence is thin, it says so.

---

## 1. The direct answer

**Neither scenario is real, and the question hides its own answer.** 100,000 × £49 = £4.90M and 50,000 × £99 = £4.95M — the two scenarios are **revenue-identical**. Since revenue can't split them, the tie is broken by four things the question doesn't mention: cost to acquire each customer, cost to serve each customer, the margin left to fund growth, and whether the number is reachable at all. On all four, £99 wins — and on two of them, £49 doesn't merely lose, it breaks the business.

| | 100,000 @ £49 | 50,000 @ £99 |
|---|---|---|
| Gross revenue | £4.90M | £4.95M |
| Contribution after fees, refunds and delivery, before marketing | ~£2.6–3.4M | **~£3.6–4.2M** [INF — see §2] |
| Human-review labour (at the spec's 20 min/plan, loaded to 20–30 min) | ~33,300 hours ≈ **20 person-years**; a 25–32 person review organisation | ~16,700 hours ≈ 10 person-years; 12–15 people |
| Maximum affordable acquisition cost per customer (CAC) | **£26–£54** | **£72–£106** |
| Cheapest realistic *paid* CAC (UK Meta ads, base assumptions) | £67+ — **loses money on every sale** | £60 (optimised) – £114 (base) — **can work at the margin** |
| Penetration of the ~6.5M UK families with a 5–18-year-old required | 1.5% | 0.8% |
| Verdict | **Self-contradictory**: promises 20 person-years of hand labour at the price least able to pay for it, via channels that can't deliver the volume | **Merely very hard**: needs a funded team and a working paid channel over 3–5+ years |

**So: 50,000 @ £99 is strictly more likely** — same revenue, roughly £0.7–1.0M more contribution, half the review labour, and it is the only scenario in which paid acquisition can ever be net-positive. But the honest answer is that **both are one to two orders of magnitude beyond what a solo, non-technical founder with no channel and no customers can reach in years 1–3.** For calibration:

- The global category leader, Qustodio, had **~1M paying customers worldwide** after 13 years and venture funding — 100k UK customers would be ~10% of that, in one country, in a harder-to-sell category (paid advice vs software).
- **All paid Substack subscriptions in the UK combined total ~500k.** 100k customers would be a fifth of the entire UK paid-newsletter market, in one niche product.
- Free is the incumbent: Internet Matters (3M+ visitors, ~31% parent brand awareness, a free personalised toolkit) is what "at scale" looks like in this category — and it's charity-funded.

**What *is* reachable** [INF, grounded in channel ceilings in §2]: **Year 1 ≈ 100–300 customers** (pilot → school-gate/PTA talks → word of mouth, all warm), **Year 2 ≈ 500–1,500** (PTA network + compounding content + first retargeting spend), **Year 3 great outcome ≈ 1,500–5,000 cumulative**. At £99–£149 that is a £150k–£700k business with ~70% contribution margin. That's the real game. Section 7 puts numbers on three scenarios.

---

## 2. Why the economics choose "premium-fewer" — the constraint is not demand

Two costs decide this business, and neither one cares what you charge.

### 2.1 Cost to serve is flat per customer, forever

The product's core promise — a human reviews every plan — costs the same 20–30 minutes whether the customer paid £49 or £249. Modelled at a safeguarding-literate reviewer rate of £30–£45/hr [INF, anchored between CIEP editing rates £31.92–£42.66/hr and safeguarding consultancy £70/hr], plus support contact and tooling, cost-to-serve is **~£13–£22 per customer at every scale from 100 to 100,000**. There are no economies of scale in human review — only small economies of organisation, offset by QA and management overhead.

What the review eats, by price:

| Price | Net after 6% refunds/chargebacks + Stripe (1.5% + 20p) | Minus £13–22 review & serve | Review as % of price |
|---|---|---|---|
| £49 | £45.12 | £23–32 left | **31–51%** |
| £99 | £91.37 | £69–78 left | 15–25% |
| £149 | £137.62 | £116–125 left | 10–17% |

At £49 the human layer consumes a third to half the price before you've spent a penny on acquisition, content upkeep or your own time. And the 20-minute figure is a **spec target, not a measured fact** — zero customer plans have been reviewed yet. If pilot plans take 45 minutes (plausible early), review costs ~£34/plan: **£49 is dead on arrival at 45 minutes; £99 is still fine.** The pilot must time this.

### 2.2 Cost to acquire kills the cheap price twice

Break-even CAC (what a sale can afford to pay for its own acquisition) vs what channels actually cost:

| Price | Break-even CAC (+3-yr renewal LTV) | Meta ads UK (base) | Google Search UK | School/PTA talks | SEO/content |
|---|---|---|---|---|---|
| £29 | £14 (£30) | £53–67 ✗ | £150+ ✗ | ✓ | ✓ (slow) |
| £49 | **£32 (£54)** | **£67 ✗** | £150+ ✗ | ✓ | ✓ (slow) |
| £99 | **£78 (£106)** | **£114 base / ~£60 optimised — marginal ✓** | £150–250 ✗ | ✓ | ✓ (slow) |
| £149 | £125 (£157) | £178 base / conditionally ✓ | marginal | ✓ | ✓ (slow) |

(CPC basis: UK Meta median £1.10, modelled £0.80 blend; UK Google education-category CPC ~£4.67–£8.41; cold purchase conversion 0.7–1.5% by band [INF, elasticity ≈ −0.8]. Sources in the legs.)

Readings:

1. **£49 forecloses the only channel with a five-figure ceiling.** At realistic cold-traffic CAC, £49 is under water before fulfilment. The cheap price doesn't buy scale — it removes the one channel that scales, leaving only warm/free channels whose combined ceiling is a few hundred to low thousands of customers. *The £49 price is the anti-scale price.*
2. **£99 is the minimum price at which paid acquisition can ever be net-positive**, and only after the conversion fixes in §5 (guarantee, visible human, testimonials). £129–£149 is where it becomes comfortably fundable.
3. At *base* assumptions cold paid traffic loses money at every price — consistent with file 95's core risk (worry is universal; paying for advice is not yet a UK category). Paid ads are a year-2+ tool, unlocked by proof, not a launch channel.
4. The modelled profit curve at constant marketing spend **peaks at £99–£149** — roughly double where the revenue curve peaks (£79). Cheap prices buy volume that costs £13–22 each to serve and £53–67 each to acquire.
5. The £13–22 fixed cost-to-serve plus a ~£60 minimum realistic paid CAC sets a **hard price floor around £79** for any paid growth. Below that, growth can only ever be hand-to-hand.

### 2.3 The one cost that does amortise — and what pays for it

The kept-current library is the mirror image: **~£20–30k/yr fixed** [INF: ~550 hr/yr of refresh, regulatory watch and briefings at editing rates] regardless of customer count. At 100 customers/yr that's £200–300 per customer — more than the price at every tier; at 1,000 it's £20–30; at 10,000, £2–3. Two consequences:

- **Below ~500 customers/yr it is the library, not the review, that breaks the model** — at pilot scale, "kept current" is founder sweat or it doesn't happen. (And "kept current" is itself an objective advertising claim needing substantiation — see §5.3.)
- **~430 Stay Current renewals at £59 fully fund the currency layer.** The renewal base, not the one-off price, is what pays for "kept current". Protect renewal economics fiercely, and tie the renewal to something a subscriber can see (§5).

**The structural conclusion, plainly:** the cost that never amortises (human review) is priced per customer, so price must clear it with room to fund growth; the cost that does amortise (the library) rewards whatever volume you can genuinely reach. Both point the same way — **charge more, serve fewer, and let the renewal engine carry the fixed cost.** The economics themselves choose premium-fewer. This is not a positioning preference; it's arithmetic.

---

## 3. The sweet spot

**£99 headline now (with £79 founding pricing through the pilot), £129–£149 as the tested growth target once proof exists. The defensible range is £79–£149. £29–£49 is structurally unprofitable to acquire and to serve.**

Three qualifications:

- £99 is only honest **after the value-visibility fixes land** (file 95: what ships today reads £49–79 because the human review is invisible at checkout). The fixes are nearly free — see §5.
- The sweet spot is **not a single compromise price but a short ladder** (§4): productised-service evidence shows specialists using good–better–best capture up to 2.8× vs single-price generalists, and you already own a £650 top anchor doing nothing.
- Price is what *funds* scalability here, not what obstructs it. Every £1 of price above the floor is £1 of CAC headroom, reviewer wages, or guarantee reserve. At £49 the margin left cannot pay for any of the three things scale requires.

---

## 4. Recommended tier architecture (resolves register finding F21)

One ladder, three visible rungs, one post-purchase engine. All claims listed are ones you can substantiate today.

| Rung | Name | Price | What it includes | What it honestly claims |
|---|---|---|---|---|
| **GOOD** | **Keepwise Plan** | **£99** standard · **£79 founding** (pilot only, time-limited, then retired) | Personalised household plan **reviewed by a named person** with a written reviewer's note on *your* plan; ~51-item kept-current library; conversation scripts; Family Agreement builder; printables; sibling/whole-household coverage; stated delivery SLA; 14-day money-back guarantee; first year of Stay Current | "Your plan is checked and published by [name], [honest credential] — a real person, not a chatbot." Never "written by hand", never "professionally endorsed" (until §5's endorsement is real) |
| **BETTER** | **Keepwise Plan + Setup Call** | **£149** | Everything in Good **+ a 20-minute live setup call** + printed pack posted home. **Slot-limited per month** (true scarcity — your diary) | "Done-with-you setup, limited slots" |
| **BEST** | **Concierge** (existing, unchanged) | **from £650**, ~4 slots/month | Done-with-you full setup | Unchanged. Its job on the pricing page is to make £149 look modest — keep it prominent even at zero sales |
| **Engine** | **Stay Current renewal** | **£59/yr** (existing) | Updates **+ an annual human re-review as the child ages up**, plus a *visible public changelog* of what changed | Sold after purchase, never as an entry rung. This is the recurring-revenue engine and the only credible fix for education-vertical churn (highest voluntary churn of any Recurly vertical) |

### What NOT to launch

1. **No £49 rung inside the review ladder.** A visible cheap tier re-anchors the whole ladder downward (£99 becomes "2× the cheap one" instead of "half a coaching hour"), cannibalises willing £99 buyers rather than converting free-tool users, and — if it includes human review — is negative-to-thin margin per §2.1. It also selects file 95's death-knell customer: the one who praises you for being "cheaper than the free stuff".
2. **AI-Lab (£49 course) becomes a satellite SKU, not a rung.** If launched, it lives on its own page as a separate self-serve product with **no human review and no review claim**, feeding the ladder — never displayed beside the £99 plan. The £129 bundle survives only as a post-purchase up-sell, never a checkout down-anchor. *This is the recommended resolution of F21; record it in the decision log (file 88).*
3. **No review-free "basic plan" tier.** An automated plan may honestly claim only "generated from our editor-maintained library" — which is a £29–39 content product competing head-on with Internet Matters' free personalised toolkit. File 95 already ruled: free wins that fight.
4. **No bulk-publish path that bypasses the per-plan review log.** The log is your advertising substantiation (§5.3) and the audit trail for the entire premium claim.

---

## 5. Capturing the premium: what to add, how to frame it

### 5.1 What actually licenses a premium (evidence, not theory)

Across every adjacent category studied — UK baby-sleep consultants (£125 call → £425 package), educational-psychology assessments (£600–£1,900 vs free NHS), premium tutoring (£15/hr → £60–150/hr), US admissions consulting (~$6,500 average), productised services (2.8× specialist premium) — the premium was licensed by the same short list: **a named credentialed human; a bespoke written deliverable with standing; outcome proof; genuine scarcity; high-touch access for a defined period; a named methodology; a money-back guarantee.**

**What is never on the list: more content.** No premium in any category studied was bought with volume of information. Keepwise's most visible asset (the 51-item library) is precisely the thing that cannot command the premium; the invisible asset (the human review) is precisely the thing that can. Every pound of effort spent enlarging the library instead of surfacing the human is spent on the wrong side of that line.

### 5.2 The additions, ranked by pricing power per unit of cost

| Priority | Addition | Pricing power | Cost to build/run | Call |
|---|---|---|---|---|
| **Do before any price rise** (these alone justify £99) | Named reviewer + honest credential + photo at checkout | Very high | ~Nil (it's you) | The universal premium lever; nothing else works without it |
| | **Visible reviewer's note on the customer's own plan** ("I changed X because your 14-year-old…") | Very high | Minutes per plan, inside the 20 | **The 20 minutes must produce a visible artefact. Invisible review is priced at £0 by the buyer.** |
| | 14-day money-back guarantee at checkout | Very high | Refund exposure (~budget 6% refunds+chargebacks all-in) | ≈ +21% conversion in file 95's cited test; also what pulls Meta CAC toward viable |
| | Stated delivery SLA ("reviewed plan within N working days") | High | Discipline; caps throughput | The cap is *also* honest scarcity |
| | Monthly review-slot cadence ("X review slots this month") | High | Nil — it's true | Free, honest scarcity; paces your workload |
| | Visible Stay Current changelog | Medium | Low | Makes "kept current" provable, supports the renewal |
| **Do next** (cheap writing/pilot exercises) | 3–5 testimonials that name the review | Very high | The pilot itself | Watch content: you need "the review caught something", not "cheaper than free" |
| | Published methodology page ("The Keepwise Review Method") | High | One-off writing | Reframes "buy a guide" → "buy a proven system" |
| | Sibling/whole-household coverage stated explicitly | Medium | ~Nil | Cheap perceived-value multiplier |
| **Price separately, never bundle into base** (recurring labour) | 20-min setup call | High | Real ongoing time | The £149 tier |
| | Printed pack posted home | Medium | Per-unit fulfilment | £149-tier inclusion or gift add-on |
| | Annual human re-review | High | Recurring labour | Inside the £59 renewal — the renewal thesis |
| **Defer** | School / DSL endorsement (B2B2C) | Highest | Highest — relationships, procurement, and guardrail-gated | Enormous trust transfer, but you cannot claim professional approval until it is literally true. A year-2–3 play |

### 5.3 The one framing shift

**Move the product from the £0–25 "guide" shelf to the £50–500 "expert time" shelf with a single headline:**

> **"Expert help with your family's online life — a personalised plan, reviewed by a real person (not a chatbot)."**

Why this one: it puts the uncopyable feature (human review) in the headline; it answers the free-competitor objection inside the frame itself ("not a chatbot" is a sharp, *true* wedge against Internet Matters' free-but-algorithmic toolkit); and it sits on the coaching/consultancy shelf (£45–180/hr parent coaching, £70/hr safeguarding consultancy) — the only shelf where £99 reads as cheap. Price against the human shelf, never against content: *"a safeguarding-literate person reads your household's plan — that is why it isn't free."*

Guardrail and compliance notes (all binding):

- **"Safer", never "safe"; "help", never "protection".** No safety guarantees.
- **Answer an existing worry; never manufacture one.** Calm competence, not fear.
- **Quarantine the word "safeguarding" in headlines** until a school/DSL relationship makes it literally true — it is a term of art owned by professionals. "Safety review", not "safeguarding review".
- **CAP Code rule 3.7:** "every plan is reviewed by [a person/name]" is an objective claim — you must **hold documentary evidence before the ad runs** (who reviewed, credential, per-plan review record). The admin publish-log is exactly this substantiation; keep it, and never ship around it. The ASA judges by what consumers understand: "human-checked" means individual attention, not sample QA.
- **The founder-personal claim has a ceiling.** "Reviewed personally by Ben" is comfortably true to ~1,000–2,000 plans/yr and false beyond it. The current design (AI-drafted, named accountable human checks and publishes every plan) scales honestly to **~2,900 plans/yr per named reviewer** — which covers every scale you can actually reach for years. Plan the wording migration (named individual → named review team with published credentials) *before* it's needed, not after.

### 5.4 The warning signal, restated

If pilot buyers praise Keepwise as *"better value than the free stuff"*, the premium has failed and you are holding a £39 convenience product. The praise you need is *"the review caught something I'd missed."* Treat the content of the praise as a formal pilot metric.

---

## 6. What this means for the 5-buyer pilot — now

This memo **sharpens, not changes**, file 95's pilot plan:

1. **Pilot at £79 founding (honest for what ships today), with the §5 "do-first" fixes shipped *before* the first pilot invitation.** Testing price without the visible human review just re-tests the broken frame. The pilot should test the £99 *proposition* at a £79 founding price.
2. **Do not test £49.** There is no decision it could inform: §2 shows £49 fails on serve-cost and acquisition regardless of what five buyers say. A cheap test price would only contaminate your first five testimonials and anchors.
3. **Time every review, honestly.** The whole model rests on the unvalidated 20-minute spec target. Log actual minutes per plan including queue admin and library-checking. Under 30 minutes: model holds. Around 45: £99 still works, and you know your real floor.
4. **Capture the praise verbatim** and score it against §5.4. Also ask file 95's before-questions (what they'd expect to pay; what they compared it to) — the "what shelf is this on?" answer is worth more than the conversion rate at n=5.
5. **Ask about the renewal in-pilot:** would an annual human re-review as your child ages up be worth £59? The renewal engine (§2.3) is load-bearing and completely untested.
6. **Success criterion unchanged from file 95:** the pilot's real job is to answer the one question no desk research can — whether UK parents will pay for advice at all. Everything in this memo is conditional on that answer.

---

## 7. Three-year realistic scenarios [INF — directional, grounded in §2 channel ceilings; no UK conversion data exists for this category]

Assumptions: average realised price rises as founding pricing retires and the £149 tier takes 15–25% of sales; renewals at £59 with 25% year-1 renewal, 60% persistence; review loaded at 25 min/plan; content currency £20–30k/yr from year 2 (year 1 is founder sweat).

| | **Conservative** (pilot lukewarm; warm-only; category question answers "weakly") | **Base** (pilot proves; PTA channel works; visibility fixes lift conversion) | **Strong** (base + paid social works post-proof at CAC < £50) |
|---|---|---|---|
| Year 1 customers | 60 | 150 | 300 |
| Year 2 customers | 180 | 500 | 1,200 |
| Year 3 customers | 350 | 1,200 | 3,000 |
| Cumulative customers | ~590 | ~1,850 | ~4,500 |
| Avg realised price | ~£85 | ~£105 | ~£110 |
| Year 3 revenue (incl. renewals) | ~£33k | ~£135k | ~£350k |
| Cumulative 3-yr revenue | ~£55k | ~£200k | ~£500k+ |
| Review load, year 3 | ~145 h/yr — founder, comfortably | ~500 h/yr — founder at ~10 h/wk **or** first contract reviewer (~£12–18k/yr) | ~1,250 h/yr — **one named full-time reviewer (~£44k loaded)**; founder claim migrates to named review team |
| Content currency | Not covered — founder sweat or the "kept current" claim quietly dies | Covered from year 2 (~250 sales/yr at £99 covers it; renewals take over) | Fully funded by renewals; ~70% contribution before CAC |
| What it is | A side project, honestly | **A real solo business** | A small company — first hire, paid channel, ~£350k/yr run-rate |

Notes: (i) Conservative is not failure-by-execution — it's what the numbers look like if the concern-to-payment gap is real. Decide in advance what year-1 number triggers a pivot rather than a grind. (ii) Strong-case year 3 (3,000 @ ~£110) delivers ~70% contribution with review at 15% of revenue and content at 8% — *that is a business*; the same 3,000 customers at £49 would have the same £69k of human-layer cost consuming 47% of half the revenue — *that is a job with liability*. (iii) Nothing above requires — or survives contact with — a £49 headline price.

---

## 8. Uncertainty register — what this memo cannot know

| Assumption | Status |
|---|---|
| UK parents will pay for online-safety *advice* at any scale | **The load-bearing unknown.** No published UK study exists. Only the pilot answers it. |
| 20 min/plan review time | Spec target; zero real plans reviewed. Pilot must measure it. |
| Price-banded conversion curve (elasticity ≈ −0.8), £0.80 Meta CPC blend, school-talk conversion 5–15% | All [INF], anchored to published benchmarks but unvalidated for this category |
| Actual UK CPC for parenting-safety keywords | **No published data.** Check Google Keyword Planner before any spend. |
| Renewal rates by price band; renewal persistence 60%/yr | [INF]; education subscriptions carry the highest voluntary churn of Recurly's verticals — the renewal engine is a thesis, not a fact |
| 6% refunds+chargebacks with a visible guarantee | [INF], mid-range of published course-business figures |
| Professional indemnity insurance cost beyond founder scale | Not researched — flag for follow-up before first hire |

---

## 9. Bottom line

1. **50k @ £99 beats 100k @ £49 on everything except the revenue line, where they tie** — ~£0.7–1.0M more contribution, half the fulfilment labour, and the only CAC headroom that can ever fund paid growth. But both are fantasy for this founder in this decade's first half; the real target is **1,500–5,000 well-served customers over three years at £99–£149**.
2. **The sweet spot is £99 now (£79 founding through the pilot), £129–£149 once proven — because price is the fuel for scale here, not the brake.** £49 is the anti-scale price: it forecloses paid acquisition, starves the review layer, and anchors the brand against free.
3. **The premium is captured by a person, a proof and a promise — never by more content.** Named reviewer, visible reviewer's note, guarantee, SLA, honest scarcity: nearly free to build, worth more to the price than the entire library. Frame as *"reviewed by a real person, not a chatbot"* on the coaching shelf.
4. **Ship the visibility fixes, then run the pilot at £79 founding, time the reviews, and score the praise.** The pilot decides whether any of this has a market. Everything else in this memo is ready for either answer.

---

## 10. Addendum (4 July) — the founder's reframe: "cheap-volume or dear-few, given near-zero overheads?"

**The premise is half-true, and the false half decides the question.** "Very little overheads once built" is true of the library (fixed cost, amortises with every sale) but false of the review (£13–22 *per plan, forever* — §2.1). This product has software's fixed costs and a service's unit costs. The only way to make the premise fully true is to remove the human review — at which point it is a £29–39 content product competing with Internet Matters' free personalised toolkit, a fight file 95 already showed free wins. **The zero-overhead version of this business is a different and worse business, not a cheaper version of this one.**

**Even granting the premise fully — zero marginal cost — cheap still loses.** With no unit costs, profit = price × buyers − acquisition, so a lower price wins only if it recruits buyers *more than proportionally*. The break-even multiples:

| Price | Net per sale (after fees/refunds + review) | Buyers needed to match £99's profit | With ~£40 CAC |
|---|---|---|---|
| £49 | ~£27 | **2.7×** | net −£13 → **can never match** |
| £79 | ~£55 | 1.34× | need 2.2× |
| **£99** | **~£73** | 1× | 1× |
| £149 | ~£120 | **0.61×** — can lose 39% of buyers and still win | 0.42× |

The category's demand is price-*inelastic* within the band (modelled ≈ −0.8): the real objection is "why pay at all when the NSPCC is free?", and that objection is identical at £49 and £99. A 50% price cut plausibly adds ~40% more buyers — nowhere near the 170% needed to tie. Price cuts here don't convert free-users; they collect less from people who would have paid anyway.

**"Sell the most" and "earn the most" point the same way, which is the surprise.** Units are maximised at £0. But among *prices*, volume is bought with margin: £99+ funds acquisition (ads, guarantees, a reviewer), £49 cannot (§2.2) — so over three years the higher price yields **more customers, not fewer**. "Cheap-high-volume vs dear-low-volume" is a false dichotomy in a no-channel business; the real options are **dear-with-a-growth-engine vs cheap-with-none**.

**Where the volume instinct is right:** the amortising library does reward volume — reached through renewals (~430 × £59 funds the whole currency layer), later school/PTA bulk licensing (wholesale volume without re-anchoring retail), and the £49 AI-Lab as a separate satellite SKU. Volume through *channels and renewals*, never through the core sticker price.

## 11. Addendum (4 July) — pricing the AI course (resolves the F61 consolidation)

The course is ONE product ("AI Readiness Lab") in three delivery modes, priced by the same rule that governs the whole portfolio — **you charge for the human in the room** (97's Huckleberry gap: human ≈ 1.7× algorithmic):

| Mode | Price | Rationale |
|---|---|---|
| **Founding pilot** (manual delivery, founder-supported, feedback part of the bargain) | **£49 founding — keep as drafted** in 76/88 | Honest for founder-touched delivery at pilot stage; sits on the course shelf so it does not undercut the £99 System |
| **Recorded / self-serve** (no human — 97's future "automated satellite") | **£49** with the full tool pack visible (workbook, AI agreement, prompt card, schoolwork ladder, source check, project canvas); **£39 if ever stripped** | 90's call stands: NSPCC £30 / Parent Zone £6.99 anchor the bare-course shelf; the tools are what license £49. Do not bury at £29 |
| **Live cohort** (4 × 60–75 min sessions) | **£99–129 beta → £149–199 proven** | Human-time shelf; cheap vs £45–180/hr coaching |
| **School/PTA session** (B2B) | **£300–750** (unchanged, enquiry-gated behind review) | The real course margin line — no CAC, institutional trust |

Rules carried from §4: satellite SKU on its own page, never beside the £99 System at checkout; no review claims in course copy (findings 73/83); the £129 System+Lab bundle exists only as a post-purchase up-sell and only once standard £99 pricing is live (£79 founding + £49 = £128 makes a £129 "bundle" a worse deal — broken maths during the founding era). The full ladder now reads coherently: £0 free resources · £49 self-serve tools · £99 a person reviews your household · £149 they call you · £650 they do it with you.

## Sources

**Internal:** `95_Pricing_WTP_Assessment.md` (pricing bands, free-competitor anchors, +21% guarantee test, concern-to-payment gap) · `21_MASTER_BUILD_SPEC.md` line 196 (<20 min/plan target) · `20_Currency_Layer.md` (refresh cadence) · Findings register F21 (ladder decision — resolved by §4).

**External (as cited in the research legs):**
[ONS Families & Households 2024](https://www.ons.gov.uk/peoplepopulationandcommunity/birthsdeathsandmarriages/families/bulletins/familiesandhouseholds/2024) · [Child Benefit statistics Aug 2025](https://www.gov.uk/government/statistics/child-benefit-statistics-annual-release-august-2025/child-benefit-statistics-with-small-area-statistics-2025) · [ICO 2026 parental concern](https://ico.org.uk/about-the-ico/media-centre/news-and-blogs/2026/04/one-click-too-many-75-of-parents-fear-their-kids-arent-making-safe-choices-online/) · [Ofcom children & parents 2025](https://www.ofcom.org.uk/media-use-and-attitudes/media-habits-children/children-and-parents-media-use-and-attitudes-report-2025) · [Unbounce Conversion Benchmark Report](https://unbounce.com/conversion-benchmark-report/) · [SuperAds UK Facebook CPC](https://www.superads.ai/facebook-ads-costs/cpc-cost-per-click/united-kingdom) · [PPC Chief education CPC](https://ppcchief.com/google-ads-cost/education) · [LocaliQ search benchmarks](https://localiq.com/blog/search-advertising-benchmarks/) · [Stripe UK pricing](https://stripe.com/gb/pricing) · [Recurly churn benchmarks](https://recurly.com/research/churn-rate-benchmarks/) · [Monetizely price–churn](https://www.getmonetizely.com/articles/the-price-churn-relationship-finding-the-sweet-spot) · [GetLatka — Qustodio](https://getlatka.com/companies/qustodio) · [Internet Matters impact](https://www.internetmatters.org/about-us/) · [Press Gazette — UK Substack](https://pressgazette.co.uk/newsletters/substack-reveals-newsletters-with-most-paying-subscribers-in-uk/) · [Parentkind](https://www.parentkind.org.uk/) · [Tiny Sleepers sleep-consultant costs](https://tinysleepers.co.uk/blog/sleep-consultant-cost-uk) · [Gemma Coe packages](https://childsleepspecialist.co.uk/sleep-consultant-packages/) · [EdPsychs fees](https://www.edpsychs.com/home/educational-psychology-services/our-fees/) · [The Profs tutor costs](https://www.theprofs.co.uk/student-resources/uncategorized/how-much-does-a-tutor-cost-per-hour-in-the-uk/) · [Private Prep admissions-consultant costs 2025](https://privateprep.com/cost-of-college-admissions-consultants-2025-report/) · [Growbo productised-service pricing (HubSpot 2.8×)](https://www.growbo.com/how-to-price-your-productized-service/) · [CIEP suggested minimum rates](https://www.ciep.uk/knowledge-hub/suggested-minimum-rates.html) · [The Safeguarding Consultant pricing](https://www.thesafeguardingconsultant.co.uk/pricing/) · [ASA — misleading advertising & substantiation](https://www.asa.org.uk/advice-online/substantiation.html) · [gov.uk employer NI 2026/27](https://www.gov.uk/guidance/rates-and-thresholds-for-employers-2026-to-2027) · [SEO.com — how long SEO takes](https://www.seo.com/blog/how-long-does-seo-take/)
