# Branding Deep Dive - Premium Direction

**Date:** 20 June 2026  
**Project:** AI Safety Build / household digital-safety product  
**Purpose:** Replace the current "clean AI-generated template" feel with a premium, specific, trust-building brand and design system.

---

## Executive Take

The MVP has the right strategic ingredients: prevention not panic, no monitoring, personalisation, human review, UK sourcing, current guidance, and a richer paid "System" rather than a cheap report.

The problem is that the brand execution does not yet make those ingredients feel expensive or distinctive. It looks like a competent information page: system font, generic teal, equal-weight cards, narrow column, default FAQ treatment, and copy that over-explains instead of composing a strong category.

The brand should move from:

> helpful online-safety information page

to:

> premium household advisory system: editorial rigour, practical artefacts, clear judgement, current sources, no surveillance

The recommended direction is **modern editorial advisory**, not app, charity, school, therapy, cyber-security, or child-safety charity.

---

## Recommendation In One Line

Use **Bearings** as the working brand, with a premium editorial/service identity:

> **Bearings**  
> Get your bearings on family life online.

Then name the offer plainly:

- **The Household System** - core GBP 99 product
- **Setup Session** - GBP 179 tier
- **Stay Current** - GBP 59/year renewal layer
- **Readiness Check** - free quiz

This keeps the brand warm and ownable, while the product language stays concrete.

---

## What Premium Must Signal Here

Premium is not more decoration. It is evidence of judgement.

For this product, premium is communicated by five things:

1. **Orientation**
   - The parent feels, "These people know what matters and what can wait."
   - Design implication: strong hierarchy, fewer equal cards, visible prioritisation.

2. **Currency**
   - The parent sees that the material is current, dated, maintained and sourced.
   - Design implication: date stamps, source rails, "last updated" labels, monthly briefing previews.

3. **Human review**
   - The plan is not a generic AI result.
   - Design implication: show the workflow: diagnostic -> draft -> human review -> plan.

4. **Privacy restraint**
   - No spyware, no child account, no child-identifiable data.
   - Design implication: put the "what we do not collect" promise high up, in plain language.

5. **Finish**
   - The product is a finished system, not another reading list.
   - Design implication: show product artefacts: sample plan page, top-three actions, library index, monthly briefing.

NN/g's trustworthiness guidance maps cleanly to this: design quality, upfront disclosure, comprehensive/current content, and connection to the wider web all drive credibility. Source: https://www.nngroup.com/articles/trustworthy-design/

---

## Current MVP Diagnosis

Files reviewed:

- `23_Landing_Page_v2.html`
- `10_Free_Readiness_Quiz.html`
- `04_Landing_Page_v1.html`
- `08_Email_Templates.md`
- `14_Positioning_Pricing_and_Model.md`
- `15_Offering_Architecture_and_Blueprint.md`
- `21_MASTER_BUILD_SPEC.md`
- `06_Threat_and_Naming_Reference.md`

### What Is Working

- The strategic repositioning from GBP 39 report to GBP 99 System is right.
- The "not surveillance" stance is strong.
- The no-panic tone is valuable and legally safer.
- The product components are rich enough to justify a premium price.
- "Kept current" is a real USP, not empty positioning.
- Human review is a strong anti-AI-template trust signal.

### What Feels Off

- The visual system is too generic: system font, teal buttons, rounded white cards.
- The page reads like a clean scaffold rather than a brand with taste.
- The hero has no product artefact, so the premium claim is not visually proven.
- Everything is weighted similarly: tiles, tiers, sections and FAQs compete instead of leading the eye.
- The phrase "The System" feels underbranded when used alone.
- The current palette is calm but one-note: grey/teal/white.
- The type scale is too small for a premium landing page.
- The equal card grid makes rich content feel like a feature checklist.
- The FAQ/details UI feels browser-native and cheap.
- Copy repeats "No spyware. No panic." well, but needs a more proprietary rhythm around orientation, currency and judgement.

---

## Brand Positioning

### Category

Use:

> **Household online-safety system**

and:

> **Family digital-readiness system**

Use the first for consumer/parent marketing. Use "digital readiness" more often for schools/PTAs.

Avoid:

- parental control app
- monitoring software
- online safety course
- child protection service
- AI safety app
- family safety app
- coaching
- safeguarding assessment

### Positioning Statement

> Bearings helps UK parents understand what matters in their household online - and what to do first - with a human-reviewed plan, a kept-current library, and no monitoring of children.

### USP Stack

Lead with these, in this order:

1. **Personalised to your household**  
   Age band, platforms, devices, AI exposure, conversation gaps.

2. **Human-reviewed before delivery**  
   This is the strongest "not default AI" signal.

3. **Kept current**  
   Apps, risks and law change. The product stays dated and maintained.

4. **No monitoring or child data**  
   Distinguishes from Bark/Qustodio/Life360-style tools.

5. **UK-sourced, parent-readable, practical**  
   Ofcom, NSPCC, CEOP/NCA, IWF, etc.

### Brand Promise

> You will know what matters first, what can wait, and where to go next.

This is safer and more premium than promising safety or peace of mind.

---

## Naming

### Recommended Brand: Bearings

Why it works:

- Implies orientation, judgement and direction.
- Does not imply surveillance, protection guarantees, therapy or crisis help.
- Can stretch to schools and advisory products.
- Feels more premium than "Household Ready".
- Less generic-startup than "Outset" in this specific category.

Suggested lockups:

- **Bearings**
- **Bearings for Families**
- **Bearings Household System**
- **Bearings Readiness Check**
- **Bearings Stay Current**

Tagline:

> Get your bearings on family life online.

More formal alternative:

> Clearer judgement for family life online.

### Product Names

Current names are close, but should be tightened:

| Current | Recommended | Reason |
|---|---|---|
| Free readiness quiz | Readiness Check | More premium and less quizzy |
| The System | The Household System | More specific and ownable |
| The Concierge | The Household Concierge | Premium, done-with-you; signals scarcity/service |
| Stay Current | Stay Current | Keep - strong and accurate |
| Personalised plan | Household Plan | Shorter and more branded |
| Library | Guidance Library | Less generic |
| Family-agreement builder | Family Agreement | Drop "builder" in marketing copy |

---

## Copy Direction

### Voice

Calm, specific, literate, proportionate. Think:

- expert older sibling
- editorial briefing
- private-school quality without private-school smugness
- practical parent-to-parent restraint
- no panic, no chumminess

### Copy Rules

Use:

- "what matters first"
- "current to [month year]"
- "human-reviewed"
- "for your household"
- "no monitoring"
- "no child accounts"
- "no child-identifiable data"
- "apps, ages and risks"
- "the guidance that applies now"
- "what can wait"

Avoid:

- "protect your child"
- "keep your child safe"
- "peace of mind"
- "powered by AI"
- "AI safety" in consumer-facing copy
- "dashboard"
- "coaching"
- "child-safe"
- "never worry again"
- "risk-free"
- "guaranteed"
- "monitor"
- "track"
- "watch"
- "shield"

### Hero Copy Direction

The current headline:

> The online risks moved on. We keep up so you don't have to.

This is good, but slightly newsletter-like and not premium enough. Better:

#### Recommended Hero A

> Know what matters online before it becomes urgent.

Subcopy:

> Bearings builds a human-reviewed online-safety plan for your household, then keeps the guidance current as apps, risks and rules change. Built for UK parents of 11-18s. No monitoring. No child accounts. No panic.

CTA:

> Start the Readiness Check

Secondary:

> See the Household System

Trust rail:

- Human-reviewed plan
- Current UK sources
- No child-identifiable data
- First year of updates included

#### Hero B

> A household plan for family life online.

Subcopy:

> Answer a short diagnostic. Get a prioritised plan, age-band guidance, platform settings, threat playbooks and the words to use - reviewed by a human and kept current for a year.

#### Hero C

> The internet changes. Your family's plan should not go stale.

Subcopy:

> Bearings gives parents a clear, current and privacy-safe way to understand the online risks that apply to their household - and the few actions worth taking first.

### Premium Copy Pattern

Instead of:

> What's inside the System

Use:

> What you get back

Then show artefacts:

- A household plan
- The top three actions
- A current guidance library
- The conversation to have this week
- A monthly "what changed" briefing

Instead of:

> You're not short of information. You're short of time, proportion and currency.

Use:

> Most parents do not need more tabs open. They need a point of view.

Then:

> Bearings turns current UK guidance into a practical plan for your child's age, apps and household habits - so you can act without becoming an expert in every platform.

---

## Visual Direction

### Target Feel

Keywords:

- editorial
- considered
- current
- calm
- grounded
- exact
- private advisory
- productised service
- parent-literate

Not:

- cyber-security
- SaaS dashboard
- school worksheet
- charity campaign
- therapy brand
- childcare brand
- AI startup
- generic template

### What To Show Visually

Do not rely on stock family photos as the primary signal. They will cheapen the product and pull it toward generic parenting advice.

Use product artefacts instead:

- A sample "Household Plan" page.
- A "Top three actions" excerpt.
- A dated source note: "Current to June 2026".
- A library index showing age bands/platforms/playbooks.
- A monthly briefing sample.
- A family agreement excerpt.
- A privacy promise card: "We do not collect your child's name, school, photos or messages."

This makes the value concrete and premium.

---

## Typography

### Commercial Premium Stack

Use if budget allows:

```css
--font-display: "Tiempos Headline", "Source Serif 4", Georgia, serif;
--font-serif: "Tiempos Text", "Source Serif 4", Georgia, serif;
--font-sans: "Söhne", "IBM Plex Sans", ui-sans-serif, system-ui, sans-serif;
--font-mono: "Söhne Mono", "IBM Plex Mono", ui-monospace, SFMono-Regular, Menlo, monospace;
```

Why:

- **Tiempos** gives editorial authority and warmth. Klim describes it as modern, robust, clear and built for editorial typography. Source: https://klim.co.nz/fonts/tiempos-text/
- **Söhne** gives modern utility without the sterile default-app feel. Klim frames it through Akzidenz-Grotesk/Helvetica and wayfinding. Source: https://klim.co.nz/collections/soehne/

Use Tiempos for:

- H1
- major section headings
- pull statements
- PDF/report body text
- sample plan excerpts

Use Söhne for:

- navigation
- buttons
- form fields
- labels
- body copy on marketing pages
- metadata and source rails

### Open-Source MVP Stack

Use if licensing needs to wait:

```css
--font-display: "Source Serif 4", Georgia, serif;
--font-serif: "Source Serif 4", Georgia, serif;
--font-sans: "IBM Plex Sans", ui-sans-serif, system-ui, sans-serif;
--font-mono: "IBM Plex Mono", ui-monospace, SFMono-Regular, Menlo, monospace;
```

Why:

- Source Serif 4 is a transitional serif designed to complement Source Sans. Source: https://fonts.google.com/specimen/Source+Serif+4
- IBM Plex is versatile, global and distinctive, with Sans/Serif/Mono variants. Source: https://www.ibm.com/plex/

### Type Scale

Use fixed breakpoint sizes. Do not use viewport-based type scaling.

| Token | Desktop | Tablet | Mobile | Font | Use |
|---|---:|---:|---:|---|---|
| Display | 64 / 70 | 52 / 58 | 40 / 46 | Tiempos Headline 500 | Landing H1 |
| H1 app/page | 48 / 56 | 42 / 50 | 34 / 40 | Tiempos Headline 500 | Internal page title |
| H2 | 38 / 46 | 34 / 42 | 28 / 36 | Tiempos Headline 500 | Major sections |
| H3 | 24 / 32 | 22 / 30 | 21 / 29 | Söhne 600 | Module/card titles |
| Lead | 22 / 34 | 21 / 32 | 19 / 30 | Söhne 400 | Hero lede |
| Body | 18 / 29 | 18 / 29 | 17 / 27 | Söhne 400 | Marketing body |
| Longform | 19 / 31 | 18 / 30 | 17 / 28 | Tiempos Text 400 | Plans, reports |
| Small | 15 / 22 | 15 / 22 | 15 / 22 | Söhne 400 | Metadata |
| Label | 13 / 18 | 13 / 18 | 13 / 18 | Söhne 600 | Source/date labels |

Letter spacing: **0 throughout**. Do not use negative tracking. Use font size, line height and weight for hierarchy.

### Reading Width

- Longform body width: 620-680px.
- Marketing lead width: 720-780px.
- Avoid paragraphs wider than about 80 characters. WCAG visual presentation guidance references a max line width of 80 characters and text spacing requirements. Source: https://www.w3.org/TR/WCAG21/#visual-presentation and https://www.w3.org/TR/WCAG21/#text-spacing

---

## Spacing And Layout

Use an 8px spacing system:

```css
--space-1: 4px;
--space-2: 8px;
--space-3: 12px;
--space-4: 16px;
--space-5: 24px;
--space-6: 32px;
--space-7: 48px;
--space-8: 64px;
--space-9: 80px;
--space-10: 96px;
--space-11: 128px;
```

GOV.UK's design system is a useful reference for tested type scales, responsive behaviour and vertical rhythm. Source: https://design-system.service.gov.uk/styles/type-scale/

### Page Grid

Desktop:

- Max page width: 1184px.
- Outer margin: 48px minimum.
- Grid: 12 columns.
- Gutter: 24px.
- Section padding: 96px top and bottom.

Tablet:

- Outer margin: 32px.
- Grid: 8 columns.
- Section padding: 80px top and bottom.

Mobile:

- Outer margin: 20px.
- Grid: 4 columns.
- Section padding: 56px top and bottom.

### Component Spacing

- Header height: 80px desktop, 64px mobile.
- Hero top padding: 72px desktop, 48px mobile.
- Hero bottom padding: 96px desktop, 64px mobile.
- Space between eyebrow and H1: 16px.
- Space between H1 and lead: 24px.
- Space between lead and CTA row: 32px.
- Space between CTA row and trust rail: 24px.
- Section heading to body: 24px.
- Section heading to content grid: 40px.
- Card internal padding: 24px desktop, 20px mobile.
- Card gap: 16px or 24px depending on density.

---

## Colour System

The current teal/grey palette is calm but too generic. Keep the calm, add editorial depth and a warmer human accent.

### Recommended Palette

```css
--canvas: #F6F7F5;
--surface: #FFFFFF;
--ink: #17201D;
--text: #34403B;
--muted: #6A746F;
--line: #DDE3DF;

--cedar: #2F5D50;
--cedar-dark: #21453B;
--lichen: #E7EFEA;

--copper: #A8644B;
--copper-soft: #F0E4DE;

--source-blue: #2F5F8F;
--source-blue-soft: #E6EEF6;

--warning: #A85A4A;
--emergency: #8F3434;
```

Usage:

- Canvas: main background.
- Surface: product artefacts/cards.
- Ink: headings.
- Cedar: primary action and brand accent.
- Copper: human warmth, not CTA.
- Source blue: citations, official source chips.
- Emergency red: emergency page only.

Avoid:

- purple/blue gradient hero
- childlike primary colours
- cyber black/neon green
- pale teal everywhere
- alarm red in normal pages
- beige-dominated lifestyle palette

### Contrast

Meet WCAG contrast:

- Normal text: 4.5:1 minimum.
- Large text: 3:1 minimum.
- UI component boundaries: 3:1 where the boundary is required for understanding.

---

## Shape, Borders, Shadows

Premium here should feel crisp, not pillowy.

- Card radius: 8px max.
- Button radius: 6px.
- Input radius: 6px.
- Tag/source chip radius: 999px allowed only for small metadata chips.
- Border: 1px solid `--line`.
- Shadows: use sparingly; prefer hairlines and layered surfaces.

Shadow token, if needed:

```css
--shadow-soft: 0 18px 50px rgba(23, 32, 29, 0.08);
```

Do not use glow, glassmorphism, floating blobs, bokeh, or gradient orbs.

---

## Homepage Structure

The homepage should stop being a long stacked text page and become a premium proof sequence.

### First Viewport

Layout:

- Left: editorial hero copy.
- Right: realistic product artefact preview.
- Bottom: trust/source rail with date and privacy promises.

Hero artefact should show:

- "Household Plan"
- "Current to June 2026"
- "Top three actions"
- one example action
- "Human reviewed"
- source chips: Ofcom / NSPCC / CEOP / IWF

Do not put the hero in a card. The artefact can be a framed product object.

### Suggested Order

1. Hero: promise + artefact + CTA.
2. Trust rail: current sources, no child data, human review, refund.
3. "What you get back": show artefacts, not feature tiles.
4. "Why this is different": not free advice, not monitoring, not panic.
5. "How the plan is built": diagnostic -> review -> plan -> library.
6. "Inside the Household System": library architecture with age/platform/playbook modules.
7. Pricing.
8. Sample excerpt / source-backed credibility.
9. FAQ.
10. Footer with emergency/privacy/source links.

### Replace Equal Card Grid

Current:

- 8 equal tiles under "What's inside".

Recommended:

- One large sample plan artefact.
- Three supporting columns:
  - Plan
  - Library
  - Stay Current
- Then a structured index table for the details.

Equal cards make everything feel equally important. Premium judgement means showing what matters most.

---

## Product Artefact Design

Create a consistent document/product look across sample plan, library pages and briefing.

### Household Plan Excerpt

Header:

- Bearings Household Plan
- Household: age band 13-14
- Current to: June 2026
- Reviewed: [date]

Top module:

- Top three actions
- Time estimate
- Why this matters
- Link into guide/playbook

Source rail:

- Based on current guidance from Ofcom, NSPCC, CEOP/NCA and IWF

Visual:

- White surface.
- 8px radius.
- Fine border.
- Tiempos heading.
- Söhne metadata.
- Small source chips.

### Library Page

Navigation spine:

- Your age band
- Platform settings
- Threat playbooks
- Conversations
- Family agreement
- What's changing

Premium signal:

- Every guide gets "Last checked [month year]".
- Every threat guide has "Source notes".
- Each page states "What changed since last check" if relevant.

### Monthly Briefing

It should look like a private memo, not a newsletter.

Title:

> Stay Current Briefing - June 2026

Sections:

- What changed
- What it means for parents
- What to check this month
- Source notes

---

## Component Specifications

### Button

Primary:

```css
height: 48px;
padding: 0 22px;
border-radius: 6px;
font: 600 15px/20px var(--font-sans);
background: var(--cedar);
color: white;
```

Hover:

```css
background: var(--cedar-dark);
```

Secondary:

```css
height: 48px;
padding: 0 22px;
border-radius: 6px;
border: 1px solid var(--line);
background: var(--surface);
color: var(--ink);
```

### Cards

```css
border-radius: 8px;
border: 1px solid var(--line);
background: var(--surface);
padding: 24px;
```

Use cards for real repeated items only:

- pricing tiers
- guide cards
- source notes
- plan action cards

Do not put page sections inside cards.

### Metadata Chips

```css
border-radius: 999px;
padding: 6px 10px;
font: 600 13px/18px var(--font-sans);
background: var(--source-blue-soft);
color: var(--source-blue);
```

Use for:

- "Current to June 2026"
- "Human reviewed"
- "No child data"
- "Ofcom"
- "NSPCC"

### FAQ

Do not use browser-default `details` styling unmodified. It reads unfinished.

Use:

- 1px top border rows.
- Plus/minus icon.
- 18px body.
- 24px vertical padding.
- No card boxes around each question.

---

## Page Copy Blueprint

### Header

Left:

> Bearings

Right:

- How it works
- What is inside
- Pricing
- Emergency signpost
- Start check

### Hero

Eyebrow:

> For UK parents of 11-18s

H1:

> Know what matters online before it becomes urgent.

Lead:

> Bearings builds a human-reviewed online-safety plan for your household, then keeps the guidance current as apps, risks and rules change. No monitoring. No child accounts. No panic.

CTA:

> Start the Readiness Check

Secondary:

> See what is inside

Trust rail:

> Human-reviewed plan / Current UK sources / No child-identifiable data / First year of updates included

### Differentiator Section

Heading:

> Not another article list. Not another monitoring app.

Body:

> Free resources are useful, but they leave parents to work out what applies, what is current and what to do first. Monitoring apps show activity, but they do not help you build judgement. Bearings sits in the gap: a household plan, practical guides and a monthly current layer.

### "What You Get Back"

Use this section to show artefacts.

Heading:

> What you get back

Items:

- A Household Plan with your top three actions.
- Your age-band guidance.
- Platform setting guides for the apps you actually use.
- Threat playbooks for the risks that matter now.
- The words to use in the conversation this week.
- A monthly briefing while your update year is active.

### Pricing Copy

Use:

> The Household System

Not:

> The System

Core tier:

> Your plan, guidance library and first year of updates.

Setup tier:

> The same system, with a guided setup session.

Stay Current:

> Keep the guidance current after your included year.

---

## Competitor And Reference Learnings

### Internet Matters

Source: https://www.internetmatters.org/

What it proves:

- Parents expect advice by age, issue, activity, apps and platforms.
- It owns breadth and public-service trust.
- It is free and broad, which leaves room for a paid product to own personalisation, prioritisation and finish.

Do borrow:

- Clear IA by age/platform/issue.
- Current/trending topic structure.
- Practical parent language.

Do not borrow:

- Colourful charity-resource feel.
- Overloaded navigation.
- Broad "everything for everyone" positioning.

### Safer Online Parents Portal

Source: https://saferonline.co.uk/parents-portal/

What it proves:

- UK parent price points around GBP 79, GBP 129 and GBP 249/year exist in the category.
- Personalised age guidance, technical setup and consultations are paid-value cues.

Do borrow:

- Tier anchoring.
- Setup/consultation as premium proof.

Do not borrow:

- Course/LMS framing.
- Generic "protect your children" claims.
- Price page as feature stack only.

### Aura

Source: https://www.aura.com/

What it proves:

- Family digital safety can be positioned as a broad, paid, premium subscription.
- "All-in-one" and protection language is common in the security-app category.

Do borrow:

- Confidence of category claim.
- Strong trust/guarantee rail placement.

Do not borrow:

- AI-powered promise.
- Identity-theft/security aesthetic.
- Broad protection framing.

### Qustodio / Bark / Life360

Sources:

- https://www.qustodio.com/en/premium/
- https://www.bark.us/
- https://www.life360.com/

What they prove:

- Monitoring/control apps own "alerts, tracking, blocking, reports".
- They compete on features, devices and safety claims.

Do borrow:

- Pricing clarity.
- Feature comparison discipline.

Do not borrow:

- Monitoring vocabulary.
- Peace-of-mind claims.
- Child tracking visuals.
- Feature grid overload.

### Stripe / Linear / Watershed

Sources:

- https://stripe.com/
- https://linear.app/
- https://watershed.com/

What they prove:

- Premium digital products often signal quality through typography, confident hierarchy, product artefacts and exact language.
- Watershed is a useful reference for "rigorous data, real outcomes" style: serious without becoming governmental.

Do borrow:

- Strong product artefact previews.
- Confident, short headings.
- System language.
- Evidence/detail after the headline.

Do not borrow:

- AI-agent hype.
- Dark, ultra-SaaS aesthetic.
- Developer-tool density.

### GOV.UK Design System

Source: https://design-system.service.gov.uk/styles/type-scale/

What it proves:

- Readability and accessibility can coexist with strong hierarchy.
- Type scale and vertical rhythm should be deliberate.

Do borrow:

- Tested legibility.
- Clear responsive type scale logic.

Do not borrow:

- Full government visual identity.
- Institutional heaviness.

---

## Moodboard Directions

### Direction 1 - The Private Briefing

Best for: Bearings.

Feel:

- editorial
- quiet confidence
- source-backed
- current

Visual cues:

- serif display type
- white document artefacts on cool canvas
- fine rules
- date/source chips
- minimal photography

Hero:

> Know what matters online before it becomes urgent.

Use if:

- We want premium and distinctive.
- We want to avoid SaaS and charity.

### Direction 2 - The Household Operating Manual

Best for: Household Ready.

Feel:

- practical
- structured
- accessible
- slightly more mainstream

Visual cues:

- sans-led typography
- structured checklists
- plan modules
- more direct iconography

Hero:

> A practical online-safety plan for your household.

Use if:

- We want maximum clarity over elegance.
- We are selling through schools/PTAs.

### Direction 3 - The Calm Technology Service

Best for: Outset.

Feel:

- modern
- productised
- slightly more SaaS

Visual cues:

- sans-led
- product screens
- clean grids
- fewer editorial flourishes

Hero:

> Start family life online on the front foot.

Use if:

- We want a scalable product feel.
- We accept slightly less warmth.

### Recommendation

Use **Direction 1: The Private Briefing**.

Reason: it most clearly signals premium, human judgement and current guidance. It is also the furthest from default AI and monitoring-app conventions.

---

## Implementation Checklist

### Brand Decisions

- Pick working name: Bearings.
- Replace `Bearings` across public files.
- Rename the offer to "The Household System".
- Rename quiz to "Readiness Check".
- Keep "Stay Current".

### Design System

- Add font stack tokens.
- Decide commercial vs open-source MVP fonts.
- Replace current palette with the expanded palette above.
- Move from 14-16px radii to 6-8px.
- Replace equal card grids with artefact-led layout.
- Add source/date metadata components.
- Add a product artefact preview to hero.

### Copy

- Rewrite hero around "what matters first".
- Move "No monitoring / no child data" into high-trust rail.
- Replace repeated "No spyware. No panic." with a fuller privacy/current/human-review promise.
- Remove old "report" language from quiz and school files where it conflicts with the premium System.
- Add "Current to [month year]" wherever guidance appears.

### Proof

- Build a sample Household Plan excerpt.
- Build one monthly briefing sample.
- Build one source-note panel.
- Add a "what we do not collect" privacy card.
- Add a named "review before delivery" step.

---

## Concrete CSS Starter

```css
:root {
  --font-display: "Tiempos Headline", "Source Serif 4", Georgia, serif;
  --font-serif: "Tiempos Text", "Source Serif 4", Georgia, serif;
  --font-sans: "Söhne", "IBM Plex Sans", ui-sans-serif, system-ui, sans-serif;
  --font-mono: "Söhne Mono", "IBM Plex Mono", ui-monospace, SFMono-Regular, Menlo, monospace;

  --canvas: #F6F7F5;
  --surface: #FFFFFF;
  --ink: #17201D;
  --text: #34403B;
  --muted: #6A746F;
  --line: #DDE3DF;
  --cedar: #2F5D50;
  --cedar-dark: #21453B;
  --lichen: #E7EFEA;
  --copper: #A8644B;
  --copper-soft: #F0E4DE;
  --source-blue: #2F5F8F;
  --source-blue-soft: #E6EEF6;
  --warning: #A85A4A;
  --emergency: #8F3434;

  --radius-card: 8px;
  --radius-control: 6px;
  --shadow-soft: 0 18px 50px rgba(23, 32, 29, 0.08);
}

body {
  margin: 0;
  background: var(--canvas);
  color: var(--text);
  font-family: var(--font-sans);
  font-size: 18px;
  line-height: 1.6;
  letter-spacing: 0;
  -webkit-font-smoothing: antialiased;
  text-rendering: optimizeLegibility;
}

.container {
  width: min(100% - 96px, 1184px);
  margin-inline: auto;
}

.hero-title {
  max-width: 760px;
  margin: 0;
  color: var(--ink);
  font-family: var(--font-display);
  font-size: 64px;
  line-height: 70px;
  font-weight: 500;
  letter-spacing: 0;
}

.hero-lede {
  max-width: 720px;
  margin: 24px 0 0;
  font-size: 22px;
  line-height: 34px;
  color: var(--text);
  letter-spacing: 0;
}

.button-primary {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  height: 48px;
  padding: 0 22px;
  border-radius: var(--radius-control);
  background: var(--cedar);
  color: #fff;
  font: 600 15px/20px var(--font-sans);
  letter-spacing: 0;
  text-decoration: none;
}

.card {
  border: 1px solid var(--line);
  border-radius: var(--radius-card);
  background: var(--surface);
  padding: 24px;
}
```

Mobile adjustments:

```css
@media (max-width: 720px) {
  .container {
    width: min(100% - 40px, 1184px);
  }

  .hero-title {
    font-size: 40px;
    line-height: 46px;
  }

  .hero-lede {
    font-size: 19px;
    line-height: 30px;
  }
}
```

---

## Priority Next Step

Do not start by restyling every page.

Start with one high-fidelity homepage direction:

1. Replace the brand with Bearings.
2. Build the artefact-led hero.
3. Add the new typography and palette.
4. Rewrite the hero and first three sections.
5. Create a sample Household Plan visual.
6. Test the screenshot at desktop and mobile.

If that first viewport does not feel premium, nothing lower down the page will save it.

