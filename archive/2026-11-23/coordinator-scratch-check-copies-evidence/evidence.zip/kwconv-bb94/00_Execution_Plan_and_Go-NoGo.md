# V1 Execution Plan — UK Parent-Facing Online-Safety Product

**Compiled 20 June 2026. For the founder, to act on this week.**

Confidence tags on regulatory/threat claims: `[confirmed]` public guidance · `[inference]` reasoned from public guidance · `[solicitor]` needs solicitor sign-off · `[verify]` needs verification. `ASSUMPTION` marks a planning assumption you can correct.

---

## Two flags before you start (the only dissent this doc raises)

1. **Naming the retention layer "coach" is a trap.** Your own prior notes name it: "coach/coaching" language quietly reintroduces a founder-as-service-business you've rejected, and it reads to a regulator as bespoke advice (higher liability). Throughout V1, the retention layer is the **AI Safety Planner** / **Family Safety Plan** — automated, content-and-template-driven, not a person coaching anyone. The master prompt's "coach subscription" is treated purely as an internal functional label, never customer-facing copy.

2. **Don't tell parents the under-16 social-media restriction is live — it isn't.** It's law-in-principle (Children's Wellbeing and Schools Act 2026) but not in force; protections are expected ~Spring 2027 `[confirmed]`. Several threat facts also rest on the Crime and Policing Act 2026 (Royal Assent 29 Apr 2026), whose provisions commence on staggered dates `[verify]` — so check commencement before any "it is now illegal to…" claim ships.

---

## 0. Regulatory go / no-go

**Verdict: GO, as scoped.** On the locked V1 design — an adult-only paid report plus an automated prevention subscription, no user-to-user features, no child users, no child-identifiable data, emergencies signpost-only — no UK regulation reviewed prohibits a solo founder operating this without specialist licensing. The two regulations most people expect to catch it, the Online Safety Act and the ICO Children's Code, most likely **do not bind it**, for structural reasons. The real obligations are mundane: ICO data-protection fee, honest non-fear-based marketing, and careful advice with a proper disclaimer. This is not a clean legal verdict — three items need a solicitor or DPO eye before launch, listed below.

| # | Question | Answer | Confidence |
|---|---|---|---|
| 1 | Obvious public-guidance blocker? | None found. | `[inference]` |
| 2 | In Online Safety Act scope? | No — it is neither a user-to-user nor a search service; it sells the provider's own content to adults. Stays out **only while** there is no parent-to-parent messaging, forum, or child account. | `[inference]` / `[solicitor]` for written confirmation |
| 3 | ICO Children's Code applies? | Very likely not — adult-facing, children not "likely" users (more-probable-than-not test), plausibly within the "preventive/counselling" carve-out. Conditional on actually keeping children out. | `[confirmed]` test / `[inference]` application |
| 4 | Needs ICO registration? | Yes — expect to register and pay the data-protection fee, **Tier 1 = £52/yr** for a micro sole trader. | `[confirmed]` |
| 5 | Avoid child-identifiable data in V1? | Yes — design out child names, DOBs, schools, screenshots, message uploads. Keeps you clear of special-category (Art 9) data and reinforces #3. | `[confirmed]` |
| 6 | Avoid incident-specific uploads / screenshots? | Yes — exclude from V1 entirely. Not needed for the report and they pull in your highest-risk data. | `[confirmed]` |
| 7 | Subscription framed as education/parent support, not safeguarding advice? | Yes — frame as prevention education + planning tools + signposting. Do **not** frame as safeguarding determinations, crisis intervention, legal/clinical advice. | `[inference]` |

**Must-not-do list to stay on the right side of the line**

- No user-to-user messaging, community forum, or child accounts (the line that moves you into OSA scope) `[confirmed]`.
- No collection of child-identifiable or special-category data; no screenshots, no message/incident uploads `[confirmed]`.
- No outcome or safety guarantees in any copy ("keeps your child safe", "prevents grooming", "protects your teen") — unsubstantiable efficacy claims `[confirmed]`.
- No cure/treat claims (a child's anxiety, addiction, mental-health condition) — banned under DMCC Sch 20 `[confirmed]`.
- No fear-based selling ("your child is in danger unless you buy") — banned practice; the standard is stricter because anxious parents are a "vulnerable consumer" audience `[confirmed]`.
- No live crisis intervention — signpost only.

**Before launch, get sign-off on (not blockers, just close them out):**

- **Marketing copy** — DMCC vulnerable-consumer + ASA substantiation exposure `[solicitor]`.
- **Disclaimer + Terms of Service** — negligent-misstatement limitation within the UCTA 1977 / Consumer Rights Act 2015 limits (you cannot exclude liability for death/personal injury from negligence) `[solicitor]`.
- **Written "Children's Code does-not-apply" assessment** + privacy notice, retention schedule, legitimate-interests assessment, lightweight DPIA-style risk note `[confirmed]` these are required/best-practice; wording `[verify]`.

**Sources:** OSA explainer (gov.uk); OSA scope checker & Schedule 1 exemptions (ofcom.org.uk, legislation.gov.uk); ICO Children's Code scope & data-protection fee (ico.org.uk); ASA substantiation (asa.org.uk); DMCC unfair practices CMA207 (gov.uk). Full list in `06_Threat_and_Naming_Reference.md`.

---

## 1. V1 build scope — cheapest and most reversible first

Rule: build cheap, useful, sellable, easy-to-change layers before anything expensive, automated, legally risky, or hard to unwind. The rehearsal engine is **out**. Automation behind the report comes **after** the report and Planner have sold.

| Order | Component | Effort | Reversibility | Legal/safeguarding sensitivity | Manual at launch? | "Done" = thin sellable version |
|---|---|---|---|---|---|---|
| 1 | Regulatory source pack + **emergency signpost screen** | Low | High | Low (signpost only) | Yes | One verified screen, scenario→route, live on the site |
| 2 | **Minimal privacy & data model** + notice | Low | High | Medium | Yes | Privacy notice live; questionnaire collects no child-identifiable data; ICO fee paid |
| 3 | **Parent questionnaire** | Low | High | Low–Med | Yes | ~25 structured questions in a free form tool (Tally/Typeform), no child PII |
| 4 | **Report template** | Low | High | Low | Yes | Section-by-section template that maps answers → prioritised actions |
| 5 | **Lightly-manual report production** | Low | High | Low | **Yes** | AI-assisted draft + founder review + PDF/email; <20 min/report |
| 6 | **Landing page** | Low | High | Med (claims) | Yes | One page, priced, email capture, buy button |
| 7 | **Payment link** | Low | High | Low | Yes | Stripe Payment Link or Payment Element; no custom checkout |
| 8 | **Delivery email** | Low | High | Low | Yes | Templated email delivering the PDF + Planner invite |
| 9 | **AI Safety Planner description + price** | Low | High | Med (framing) | Yes | Clear page: what it is/isn't, automated, monthly |
| 10 | **Planner month-1 content** | Med | High | Med | Yes | Welcome + first monthly briefing + 2 action plans + 1 conversation script |
| 11 | **Usage & conversion tracking** | Low | High | Low | Yes | Plausible/GA + a spreadsheet funnel; no heavy analytics stack |
| 12 | **Feedback form** | Low | High | Low | Yes | 4-question post-report form |
| 13 | **School/PTA outreach pack** | Med | High | Low | Yes | One-pager + email; only if a warm school lead appears |

**Do not, in V1:** build an app, a login system, an automated scoring engine, a user dashboard, or any child-facing workflow. Manual report production is proven with paying users *before* any automation spend.

What's already built in this folder: items 1, 2, 3, 4, 6 (drafts), and the Planner description (9) — see file list at the end. Items 5, 7, 8, 11, 12 are setup tasks in the this-week checklist.

---

## 3. First paid offer and the path to the Planner

**Offer name (working):** *Household Online-Safety Report* (consumer category label; brand name TBD — shortlist in `06`).

**Headline promise:** Know exactly where your teen is exposed online — and the three things to do first — without the panic.

**Recommended launch price: £39** one-off. `ASSUMPTION` — anchored to a considered, human-reviewed personalised report (not a free checklist) and a parent audience with willingness to pay; test against the band below.

| Price test | Use when |
|---|---|
| £29 | If £39 converts below ~2% of visitors and price is the named objection |
| £39 | Default launch price |
| £49 | If early buyers convert easily and report feedback is strong |
| £19 intro / first 25 buyers | Founding-customer cohort to seed testimonials, then retire |

**What's included:** the personalised report (10 sections, see `01`), the emergency signpost reference, and a 14-day window to ask one clarifying follow-up by email. **Excluded:** monitoring, live intervention, legal/clinical advice, anything child-facing, any guarantee of safety.

**Fulfilment:** lightly manual — parent completes questionnaire → AI-assisted draft against the template → founder review/edit → PDF delivered by email. **Delivery timeline:** within 48 hours (under-promise; you'll often do it same day) `ASSUMPTION`.

**Refund policy:** no-quibble refund within 14 days if unhappy. A low-friction refund is cheaper than a chargeback or an ASA/CMA complaint and supports the trust frame `[inference]`.

**Immediately after purchase:** confirmation + questionnaire link. **After delivery:** the report's final section invites them into the Planner with a specific, non-cold reason tied to their own non-urgent gaps ("your report flagged 4 medium-priority actions — the Plan walks you through one a fortnight").

**The ladder**

| Rung | Product | Price | Role |
|---|---|---|---|
| 0 | Free 2-minute readiness quiz | £0 | Email capture, top-of-funnel |
| 1 | **Household Online-Safety Report** | **£39** | Paid wedge |
| 2 | **AI Safety Planner (Family Safety Plan)** | **£7/mo or £70/yr** | Retention `ASSUMPTION` price |
| 3 | Deep-dive household session (later) | £149 | Optional, post-traction only |
| 4 | School/PTA briefing (later) | £500–£1,500 | B2B stretch, post-traction |

**Be candid: report→subscription is a hard motion.** The report can *resolve* the anxiety that drove the purchase, killing subscription intent. Counter it by (a) designing the report to surface more medium-priority gaps than a parent can act on at once, so the Plan is the obvious way to work through them; (b) making month-1 Planner content concrete and immediately useful, not a newsletter; (c) pricing the Plan low enough to be an easy yes. If report→Plan conversion is weak, **fix the Plan's value proposition before building any more product** — do not build the rehearsal engine.

**Renewal logic — the Plan earns its keep through:** a monthly threat briefing (what changed, what to do), fortnightly prioritised action plans, conversation scripts, family-agreement updates, new-platform risk notes, and an annual report refresh. **It must not provide:** crisis intervention, safeguarding determinations, legal advice, therapy, bespoke active-incident advice, AI-companion features, or any minor-facing chat.

---

## 6. 90-day launch-and-learn plan

This runs **after** V1 ships. The product is live and priced — this is instrumentation, not a free beta.

**Founder reach** `ASSUMPTION` (correct this): a small warm network — school-gate parents, a couple of education/PTA contacts, London parent WhatsApp/Facebook groups, LinkedIn, and personal network. Plan is built so it survives a small list.

**First-customer profile**

- Parent of an 11–16-year-old, typically the mother, digitally capable but not confident about the newest risks (AI, sextortion, Snapchat).
- Anxiety trigger: a news story, a school letter, a friend's child's incident, or their teen getting a first phone/new app.
- Arrives via: a shared post, a school/PTA mention, or word of mouth.
- Pays now because: it's concrete, bounded, and cheaper than the worry. Won't pay if: it reads as generic free advice, alarmist, or like spyware. Trust signal needed: visible sourcing (NSPCC/CEOP/IWF), calm tone, a named real person behind it, clear "what we don't do".

**Week-by-week**

| Phase | Focus |
|---|---|
| Pre-launch | Pay ICO fee; publish privacy notice + disclaimer (solicitor-reviewed); set up Stripe link, form, delivery email, signpost screen, landing page; produce 3 sample reports for friends to pressure-test; line up 5–10 warm parents |
| Launch week | Soft launch to warm list + 1–2 parent groups; goal: **first 5 paid reports**; hand-deliver quality; collect a testimonial and a "what nearly stopped you buying" |
| Week 1 | Deliver every report <48h; send feedback form; make the Planner invite live; watch checkout abandonment |
| Weeks 2–4 | One organic channel push (a school/PTA intro or a parent-group post); target **15–25 total reports**; first Planner sign-ups; ship month-1 Planner content |
| Month 2 | Test the £49 price or the founding-cohort retirement; first **month-1 Planner renewals**; ask every satisfied buyer for one referral; first school/PTA conversation if a lead exists |
| Month 3 | Measure month-3 retention; total **40–60 reports** as a healthy-but-modest signal `ASSUMPTION`; decide against the gates in §7 |

**Metrics to instrument (define each in the tracking sheet):** visitors; email-capture rate; visitor→paid-report conversion; checkout abandonment; questionnaire completion rate; report delivery time; refund rate; report satisfaction; **report→Planner conversion**; Planner activation; month-1/2/3 renewal; briefing open rate; action-plan completion; referrals; school/PTA enquiries; CAC and payback (only if you spend on ads).

**What counts as real value (behaviour, not applause):** pays without a discount; completes the questionnaire; opens the report and takes ≥1 action; starts a conversation with their teen; subscribes to the Plan; renews past month 1; refers another parent; asks for a school/PTA version.

**Vanity metrics / false positives to discount:** social likes; "this is so important" with no purchase; free-quiz downloads with no conversion; one-off panic buys that never renew; school *interest* with no booked meeting; high report satisfaction with zero Planner conversion; clicks from fear-tinged copy that don't convert; praise from friends; your own enthusiasm.

---

## 7. Decision gates — with real numbers

Modest, solo-founder, low-cost-consumer thresholds — **not** venture benchmarks. Set now, before you're emotionally invested. Measured at the **end of the 90 days** unless stated.

| Metric | Kill (stop/narrow) | Iterate | Keep as wedge | Spin-out candidate (later) |
|---|---|---|---|---|
| Visitor → email | <3% | 3–8% | 8–15% | >15% |
| Visitor → paid report | <0.5% | 0.5–1.5% | 1.5–3% | >3% sustained |
| Report completion | <50% | 50–70% | 70–85% | >85% |
| Report satisfaction (top-2 box) | <60% | 60–75% | 75–90% | >90% |
| Refund rate | >15% | 8–15% | 3–8% | <3% |
| **Report → Planner** | **<5%** | **5–12%** | **12–20%** | **>20%** |
| Month-3 Planner retention | <40% | 40–55% | 55–70% | >70% |
| Referral rate (buyers referring ≥1) | <5% | 5–15% | 15–25% | >25% |
| CAC vs price (if paying for traffic) | CAC > report price | breakeven on report | report covers CAC + some LTV | LTV ≫ CAC, repeatable |
| School/PTA signal | none after outreach | 1 warm conversation | 1 booked/paid session | repeatable pipeline |
| Regulatory/safeguarding risk | uncontrollable issue | manageable with fixes | controlled | controlled |

**Headline thresholds to commit to now**

- **Minimum viable paid signal:** ≥20 paid reports in 90 days at ≥1% visitor→paid conversion, refunds <15% `ASSUMPTION`.
- **Acceptable early refund rate:** ≤8%.
- **Acceptable report→Planner conversion:** ≥10% to justify continuing the Plan; <5% means fix the Plan before building anything.
- **Acceptable month-3 retention:** ≥50%.
- **Referral threshold:** ≥10% of buyers refer at least one parent.
- **School/PTA threshold:** ≥1 paid or firmly-booked session before any B2B build.
- **CAC payback:** the report alone must cover paid-acquisition cost before you scale spend; don't scale on projected Plan LTV.
- **Spin-out threshold:** all of — strong trust, ≥1.5% paid conversion, ≥55% month-3 retention, ≥15% referrals, and one repeatable acquisition channel.

**Strategic logic:** paid conversion but weak 90-day retention → keep as a wedge/acquisition product, don't spin out. Strong usage but weak payment → reposition or bundle. Strong trust + conversion + month-3 retention + referrals + a repeatable channel → it may earn a standalone brand. Uncontrollable regulatory/safeguarding/trust risk → stop or narrow. Sells only on founder trust → useful but not scalable. Buyers don't convert to Plan → revise the Plan before more product. Weak Plan renewals → do not build the rehearsal engine. CAC > supportable LTV → don't scale paid acquisition.

---

## 9. Risk register

| Risk | Severity | Likelihood | Mitigation | Decision trigger |
|---|---|---|---|---|
| Regulatory blocker emerges | High | Low | Stay out of OSA scope (no U2U/child accounts); solicitor sign-off on copy + disclaimer; ICO fee paid | Any credible regulator contact → pause sales, get advice |
| Safeguarding incident via the product | High | Low | Signpost-only; prominent emergency screen; no live-incident handling | Any incident where product was relied on in a crisis → review scope immediately |
| Over-collection of child data | High | Med | Questionnaire designed to exclude child PII/screenshots; data-min review before launch | Any child-identifiable field requested → remove before launch |
| Emergency advice drifts into intervention | High | Med | Hard rule: emergencies = route to authority only; no bespoke steps; reviewed copy | Any "what should I do right now" feature request → reject for V1 |
| Plan read as safeguarding advice | Med | Med | "Education + planning + signposting" framing; explicit "what this isn't"; no "coach" language | Copy implies determination/advice → rewrite |
| Parent distrust of AI | Med | High | Human review on every report; lead with sources; "AI-assisted, human-checked" | Distrust named in feedback → emphasise human check |
| Fear-based one-off purchase, no renewal | Med | High | Calm copy; Plan value concrete; surface more gaps than fit one sitting | Renewal <40% → fix Plan, not acquisition |
| Report resolves anxiety → kills subscription | Med | High | Report deliberately surfaces medium-priority backlog; Plan = the way to clear it | Report→Plan <5% → redesign report ending + Plan offer |
| Free resources undercut willingness to pay | Med | Med | Sell the *personalisation + prioritisation*, not facts anyone can google | Price objection dominates → sharpen "why paid" |
| Monitoring apps own the category | Med | Med | Differentiate: household-level, prevention, not spyware; own the calm/premium whitespace | Buyers expect monitoring → re-message positioning |
| Weak acquisition channel | High | Med | Test one organic channel hard before paid; school/PTA as a second leg | No channel >1% by day 90 → reposition or pause |
| School/PTA cycle too slow | Med | High | Treat B2B as a later leg, not a V1 dependency | B2B not converting → keep consumer focus |
| Becomes generic advice content | Med | Med | Every output is prioritised + household-specific | Feedback says "could've googled this" → deepen personalisation |
| Brand sounds alarmist/exploitative | Med | Low | Calm/premium tone guardrails; banned-words list | Any fear copy ships → pull and rewrite |
| Rehearsal engine built too early | Med | Med | Locked out of V1; gated behind Plan renewal proof | Anyone scoping it pre-traction → defer |
| Overbuilt infra before demand proof | Med | Med | Manual fulfilment until volume hurts | Building automation before ~50 paid reports → stop |
| Founder network = misleading traction | Med | High | Separate warm-network sales from cold conversion in the funnel sheet | Sales only from friends → discount as signal |

---

## 10. What must be verified before launch

1. Solicitor sign-off on marketing copy, disclaimer, and Terms of Service `[solicitor]`.
2. ICO data-protection fee self-assessment completed and paid (expect £52) `[confirmed]`.
3. Written "Children's Code does-not-apply" assessment on file `[confirmed]`.
4. Privacy notice, retention schedule, legitimate-interests assessment, lightweight DPIA-style note `[confirmed]`.
5. Crime and Policing Act 2026 **commencement dates** for the AI-CSAM/nudify/chatbot offences, before any "it is now illegal to…" claim `[verify]`.
6. Every emergency signpost number/URL re-checked live on launch day `[confirmed]` as of 20 Jun 2026, but re-verify.
7. HMRC Self Assessment registration; consider professional-indemnity/public-liability insurance `[confirmed]`/prudent.
8. The two `[PV]` threat stats ("~1 in 4 teens use AI chatbots for support"; "90%+ young people experienced scams") sourced to primary reports before they appear in marketing.

---

## 11. What you can build immediately, no more research

Everything in this folder (`01`–`13`) — report system, sample report, signpost screen, landing page, privacy notice, threat/naming reference, the report-generation prompt, email templates, the Planner's month-1 content, the free quiz, feedback form, the decision-gate tracker, and the school/PTA pack. What's left is account setup, not content: put the questionnaire into Tally, create the Stripe £39 link, wire the email templates into your sending tool, and host the two HTML pages. None of this needs further research; it needs doing.

---

## 12. This-week checklist (one page)

**Monday — legal/admin foundation**
- [ ] Complete ICO data-protection fee self-assessment; pay £52.
- [ ] Register for HMRC Self Assessment if not already.
- [ ] Brief a solicitor for a fixed-fee review of copy + disclaimer + ToS (send them the landing page + privacy notice drafts).

**Tuesday — the wedge**
- [ ] Put the questionnaire (`01`) into Tally/Typeform; confirm it collects **no** child name/DOB/school/screenshots.
- [ ] Finalise the report template (`01`); produce one real report for a friendly family using the sample (`02`) as the model.

**Wednesday — the sell layer**
- [ ] Stand up the landing page (`04_Landing_Page_v1.html`) on a cheap host/Carrd; wire the email capture.
- [ ] Create a Stripe Payment Link at £39; test a live £39 purchase and refund yourself.
- [ ] Publish the emergency signpost screen (`03`) as its own page; link it in the footer and the report.

**Thursday — Planner + delivery**
- [ ] Publish the AI Safety Planner description + £7/mo (or £70/yr) link.
- [ ] Write the delivery-email template (PDF attached + Planner invite).
- [ ] Draft month-1 Planner content (welcome + first briefing + 2 action plans + 1 script).

**Friday — instrument + soft launch**
- [ ] Add analytics + a one-tab funnel spreadsheet (visitor→email→paid→Plan).
- [ ] Re-verify every signpost number/URL.
- [ ] Soft-launch to 5–10 warm parents; aim for the **first 5 paid reports**; ask each what nearly stopped them buying.

---

*Files in this build:*
*`00` this plan · `01` readiness report system · `02` sample worked report · `03` emergency signpost screen (.md + .html) · `04` landing page (HTML) · `05` privacy & data notice · `06` threat & naming reference*
*`07` report-generation prompt (fulfilment engine) · `08` email lifecycle templates · `09` AI Safety Planner month-1 content · `10` free readiness quiz (HTML) · `11` feedback form · `12` funnel & decision-gate tracker (XLSX) · `13` school/PTA outreach pack*
