# Full Offering Site Assimilation Plan

*Created 2026-06-28. Purpose: turn the expanded Bearings offer into a coherent site and prototype direction. This plan uses `21_MASTER_BUILD_SPEC.md` as the build reference, `26_Pricing_Library_and_Content_v3.md` for the original pricing ladder, `39_Offer_Value_Expansion.md` for the Control Centre/value stack, and `90_Full_Offer_Value_and_Pricing_Research.md` for the updated pricing and full-offer recommendation.*

## Goal

Make the public site feel like a trusted, valuable household system rather than a thin course page or a pile of articles.

The site should make this clear within the first two scrolls:

1. Bearings is a personalised household online-safety system.
2. It includes practical tools parents can customise and print.
3. It now includes AI readiness/safety for homework, privacy, synthetic media, companion-style tools, and source-checking.
4. It is evidence-grounded, current, and cautious about claims.
5. It is not monitoring software, crisis advice, child-facing content, or a safety guarantee.

## Product Architecture To Show

### Core Paid Offer

**The Household System**  
Personalised plan, age-band pack, current guidance library, Control Centre, Family Agreement, platform guides, scripts, playbooks, printables, and first year of Stay Current.

### AI Add-On / Bundle

**AI Readiness Lab for Families**  
Parent-led course plus workbook and tools: Family AI Agreement, prompt card, schoolwork ladder, source-check sheet, synthetic-media rules, small project canvas, project review checklist, and reset habit.

### Ongoing Layer

**Stay Current**  
Monthly approved updates, platform guide refreshes, AI update slot, changelog, annual household re-run, and age-band reissue. This is a human-reviewed update layer, not automated monitoring.

### Premium Layer

**The Concierge**  
Done-with-you setup and audit, all-children written report, follow-up, priority guidance boundaries, optional AI rules module.

### Public Trust Layer

**Resources, Field Notes, Evidence Notes, What Changed**  
Free tasters and trust-building content. This layer should support conversion but not become the paid product.

### School/PTA Layer

Warm-introduction second channel: parent briefing, workbook sample, school newsletter copy, optional community readiness offer.

## Recommended Public Information Architecture

Keep the main nav short enough to scan:

- How it works
- Tools
- AI Lab
- Resources
- Pricing
- Start check

Footer/secondary links:

- Evidence
- For schools
- Emergency signpost
- Privacy
- Terms

Reason: "Evidence" matters, but putting every trust signal in the top nav can make the product feel institutional before the parent understands the value. It should be visible on the home page and footer, with its own page available.

## Page Roles

| Page | Role | Key updates |
|---|---|---|
| `/` | Main conversion story | Reframe hero around full system + AI readiness. Add product architecture, tools, evidence/resources, pricing preview, and boundaries. |
| `/how-it-works` | Process confidence | Add Control Centre, AI Lab, tools, and human-reviewed update layer to the process. |
| `/pricing` | Value and choice clarity | Show three family choices: System, System + AI Lab, Concierge. Explain Stay Current as included year one then renewal. |
| `/tools` | Tangible value page | Preview Control Centre, Family Agreement, AI Agreement, prompt card, schoolwork ladder, source-check sheet, project canvas, reset tools. |
| `/ai-readiness` | Course page | Parent-led course page using `54` and `76`, with careful boundaries and review-status language. |
| `/resources` | Free trust layer | Field Notes, free tasters, first-phone mini-guide, AI homework one-pager, sample agreement, emergency signpost. |
| `/evidence` | Trust proof | Parent-facing source notes, last-reviewed dates, claim boundaries, and how updates are reviewed. |
| `/for-schools` | Second-channel offer | Add AI parent briefing and workbook sample to the existing school/PTA page. |
| `/library` | Paid hub | Add AI toolkit category and stronger "what to do next" navigation. |
| `/library/family-agreement` | Paid tool | Keep current builder; consider separate AI Agreement once review gates clear. |
| `/library/whats-changing` | Maintenance proof | Align with `65_AI_Safety_Course_Stay_Current_Update_Stream_Spec.md`. |

## Pricing To Reflect

> **Price-source note:** `26_Pricing_Library_and_Content_v3.md` remains the single authoritative price canon (System £99, founding £79). This plan reads as layout/architecture direction, **not** the price source of truth. The ladder shown below is `90`'s recommended re-pricing — **PENDING founder decision** (`93` decision Q3 / risk R4). It conflicts with the current price canon `26` and the live app tokens in `lib/pricing.ts`; **do not build or publish pricing from this table until one ladder is chosen.** Once the ladder is decided, sweep `26`, `lib/pricing.ts`, `90`, and `91` to the one chosen ladder in the same change (updating `26` if the `90` ladder is adopted).

The public pricing should avoid overwhelming families with every possible price.

Recommended family pricing display:

| Offer | Public display |
|---|---|
| Household System | GBP 99 founding / one-off |
| System + AI Lab | GBP 129 founding bundle |
| Concierge | from GBP 650 |
| Stay Current | included year one, then GBP 59/year |

Secondary or FAQ:

- AI Readiness Lab recorded standalone: GBP 49.
- Live AI parent cohort: beta GBP 99-129, later GBP 149-199.
- School/PTA parent briefing: GBP 350-750.

## Messaging Hierarchy

### Above The Fold

Use one clear line:

> A personalised household system for online safety and AI judgement.

Support:

> Your plan, tools, family rules, AI readiness course, and current guidance in one calm place. No monitoring, no child account, no screenshots, and no safety promises.

### What Makes It Valuable

- Personalised plan.
- Human review.
- Customisable tools.
- Practical printables.
- AI readiness.
- Source-backed guidance.
- Kept current.

### What Makes It Trusted

- Least-data design.
- No child-identifiable data.
- No monitoring.
- Signpost-only emergencies.
- Evidence notes.
- Dated updates.
- Human review gates for sensitive claims.

## Two New Mock-Up Directions

### Mock-Up A: Full-Offer Platform

Style: Apple/Oura/Stripe-level product clarity.

Purpose: make the full product architecture instantly understandable and valuable.

Must show:

- Hero as full system, not just a plan.
- Offer stack: System, Tools, AI Lab, Stay Current, Concierge.
- Tool grid with Control Centre and AI tools.
- Pricing bundle signal: System + AI Lab.
- Trust rail: no monitoring, no child data, human-reviewed, evidence-grounded.

### Mock-Up B: Evidence-Led Premium

Style: luxury editorial plus institutional trust.

Purpose: make Bearings feel serious, calm, sourced, and worth paying for without becoming cold or bureaucratic.

Must show:

- Strong source/evidence layer.
- Public resources and Field Notes.
- "What Changed" update proof.
- Tangible household artefacts.
- Same pricing bundle but presented with restraint.
- Clear boundaries.

## Implementation Phases

### Phase 1: Prototype The Story

- Create two new static mock-ups in `brand-design/`.
- Add them to `brand-design/index.html`.
- Verify desktop/mobile, no overflow, no broken assets, no banned claims.

### Phase 2: Assimilate Into The Next Build

- Add pricing tokens for AI Lab and System + AI Lab bundle in `lib/pricing.ts`.
- Update `SiteHeader` and footer link strategy.
- Update `/` to include full offer architecture, tools, AI Lab, resources/evidence, and bundle pricing.
- Update `/pricing` to show System, System + AI Lab, Concierge, and Stay Current note.
- Update `/how-it-works` so "what's inside" includes tools and AI readiness.
- Add `/tools`, `/ai-readiness`, `/resources`, and `/evidence` routes.
- Update `/for-schools` to include AI parent briefing.
- Update `/library` to include AI toolkit navigation.

### Phase 3: Proof And Trust

- Add sample tool previews.
- Add parent-facing evidence notes from `57` and `58`.
- Add a sample "What Changed" briefing from approved/static examples only.
- Add clear "not monitoring / not crisis / not child-facing / no child data" boundaries across high-risk pages.

### Phase 4: QA

- Run content lint.
- Run structure/guardrail tests.
- Browser-check desktop and mobile layouts.
- Check no public page implies safety outcomes, compliance, diagnosis, monitoring, or live-incident support.
- Check all new claims use cautious wording and source/review context.

## Guardrails

- No "keeps children safe", "prevents harm", "fully compliant", "safe by design", or similar outcome/compliance promises.
- No child-facing flow.
- No child accounts.
- No child names, schools, dates of birth, screenshots, messages, images, account handles, schoolwork, prompts, or incident details.
- No AI judging real content.
- No parent community/forum/comments.
- Emergency/routing stays ungated and non-monetised.
- Evidence and updates must be dated and review-gated where sensitive.

## Immediate Next Build Step

Create the two mock-ups first, because they will settle the visual and narrative hierarchy before the actual Next app is changed.

