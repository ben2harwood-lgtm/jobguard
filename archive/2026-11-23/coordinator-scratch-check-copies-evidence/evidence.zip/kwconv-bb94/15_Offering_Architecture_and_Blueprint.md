# The Offering — Architecture & Content Blueprint

**The structure of the rich product: what's in it, how it fits together, and the build sequence.** This is the canon the library is built against. It keeps the offering coherent (not just "more stuff") and disciplined (rich *content*, lean *delivery* — no expensive infrastructure).

---

## The product in one picture

A household answers a short diagnostic → receives a **personalised plan** → that plan unlocks a **deep, kept-current resource library**, organised so a parent only ever sees the bit that applies to their child, right now.

```
                    ┌─────────────────────────────────────────┐
   Free quiz  ──▶   │  THE SYSTEM (£99 / founding £79)          │
   (snapshot)       │                                           │
                    │  1. Personalised readiness plan            │  ◀── the diagnostic
                    │  2. Age-band pack (5-10 … 17-18, 5 bands)│  ◀── the differentiator
                    │  3. Platform settings library (10 guides)  │  ◀── the spine (revealed demand)
                    │  4. Threat & scenario playbooks (12)        │  ◀── the depth
                    │  5. Foundations modules (3)                 │
                    │  6. Conversation library + scripts          │  ◀── the differentiator
                    │  7. Family-agreement builder                │
                    │  8. Emergency signpost                      │  ◀── carried from V1
                    │  9. "What the law now requires" explainer   │  ◀── credibility/recency
                    └─────────────────────────────────────────┘
                                      │
              ┌───────────────────────┼────────────────────────┐
              ▼                                                ▼
   The Concierge (from £650)                     Stay Current (£59/yr, yr1 bundled)
   live done-WITH-you setup/audit                monthly briefing · setting-change alerts
   bespoke all-children report · capped slots    refreshed playbooks/videos · the renewal hook
```

**Delivery stays lean:** PDF/web library + email, lightly-manual personalisation (the `07` report-generation prompt, expanded). **No app, no login system, no scoring engine, no rehearsal engine in V1.** Richness is in the *content*, which is cheap and reversible; we do not build expensive infrastructure before sales prove it.

---

## The content inventory (what gets built)

> **V3 update (20 Jun 2026, see `26`):** the System now also includes **setup how-to videos** (per platform), a **recorded masterclass** per stage, and **printable quick-reference cards** — the value-density layer that makes £99 unmissable and gives Stay Current its renewal hook (re-recorded videos when platform UIs change).

### A. Age-band packs — the spine the parent navigates by
Posture slides across the bands: **co-use → co-set → coach → consult** (developmentally grounded; the closing "dual-systems" gap and falling peer-risk amplification). Each band = platforms/behaviours typical at that age, the risks most salient, the parenting posture, the 5 conversations that matter most, the settings to prioritise, and an age-tuned family-agreement clause menu.

| Band | Theme | Notes |
|---|---|---|
| 5–10 | First tablet / foundations | Co-use; controls front-loaded; tablet · YouTube Kids · Roblox Kids · spend PINs |
| 11–12 | Transition / first device | Hands-on, structured; controls front-loaded |
| **13–14** | **The threshold year** | **Flagship** — legal social-media onboarding, sextortion peak, peak peer-influence; most-resourced |
| 15–16 | Autonomy / GCSE years | Coaching, supervision-with-conversation |
| 17–18 | Launch / near-adult | Footprint, scams, adult reporting routes; consultant posture |

### B. Platform settings library — the spine of revealed demand (10 guides)
Device layer **first** (governs everything), then by teen priority. Each guide: the parental feature + what it can/can't see, the 4–8 highest-value settings with menu paths ("may move"), minimum age & how age is handled, 2025–26 changes, official help URL.

Order: **1. Apple Screen Time · 2. Google Family Link · 3. Snapchat · 4. Instagram · 5. TikTok · 6. Roblox · 7. Discord · 8. WhatsApp · 9. Fortnite/Epic · 10. YouTube.**

### C. Threat & scenario playbooks (12) — the depth
Each playbook: plain-English explanation · current UK picture (2025–26) · warning signs · prevention actions · **"what to do if it's already happening"** (calm steps + signpost only).

**Core five (refresh from `06`):** sextortion · AI deepfake/nudify · grooming & coerced app migration · scams/fraud/money-muling · AI-companion/chatbot harms.
**Seven new:** cyberbullying & peer-on-peer abuse · self-harm, suicide & eating-disorder content · pornography exposure · gambling, loot boxes & in-game spending · sexting & peer image-sharing ("nudes") · radicalisation & extremist content · screen-time, sleep & digital wellbeing.

### D. Foundations modules (3) — comprehensive cover, lighter touch
Privacy, data & digital footprint (absorbs location-sharing/physical safety) · critical thinking & misinformation/conspiracy · livestreaming safety (cross-referenced from grooming/nudes/screen-time).

### E. Conversation library — the paid differentiator
Conversation principles (do's/don'ts, evidence-based) · a **"what not to say" card** (verbatim-citable anti-patterns) · ~15 conversation starters across 9 topics, each with age variants · the cornerstone "come to me, you won't be in trouble" script leading every band.

### F. Family-agreement builder
Age-banded clause menus parents pick from; collaborative framing ("safety not control"); a living, revisitable document.

### G. Currency layer — the renewal engine
A "What the law now requires / what's changing" evergreen explainer (OSA child duties live since 25 Jul 2025; under-16 social-media restrictions expected ~Spring 2027 — the **transition-period** hook) · a monthly threat-briefing template/system · setting-change alerts.

### H. The personalised plan + emergency signpost
The diagnostic output that ties A–G to *this* household (expanded from the `01`/`02` report) and the `03` signpost embedded throughout.

---

## How the inventory maps to the tiers

| Component | Free quiz | System £99 | Concierge £650+ | Stay Current £59/yr |
|---|---|---|---|---|
| Readiness snapshot | ✓ | — | — | — |
| Personalised plan | — | ✓ | ✓ (all children, deeper) | — |
| Age-band pack | — | ✓ (their band) | ✓ (all bands) | — |
| Platform library | — | ✓ | ✓ + live walkthrough | updates |
| **Setup how-to videos** | — | ✓ | ✓ + walked through live | re-recorded on UI change |
| Threat playbooks + modules | — | ✓ | ✓ | refreshed |
| Conversation library | — | ✓ | ✓ | new scripts |
| **Recorded masterclass** | — | their stage | all | new ones |
| **Quick-reference cards** | — | ✓ | ✓ | new cards |
| Family-agreement builder | — | ✓ | ✓ (facilitated) | — |
| Monthly briefing + alerts | — | (yr 1 bundled) | (yr 1 bundled) | ✓ |
| Live setup/audit + follow-up | — | — | ✓ | — |

---

## Build sequence (highest value first)

1. **Platform settings library** — revealed #1 demand; concrete; immediately useful. *(building now — file `16`)*
2. **Conversation library** — the differentiator. *(building now — file `17`)*
3. **Threat & scenario playbooks + modules** — the depth. *(building now — file `18`)*
4. **Age-band packs** — assemble from 1–3 with the posture slide + the 5 key conversations per band. *(next — file `19`)*
5. **Currency layer** — "what's changing" explainer + first 3 monthly briefings. *(next — file `20`)*
6. **Premium personalised plan** — redesign the `01`/`02` report into the richer System plan that routes into the library. *(next — file `21`)*
7. **Repackage the sell layer** — update landing page + offer to the premium positioning and tiers. *(after content — revise `04`)*

**Discipline check:** every item above is content (writing), reusable and reversible. The only "infrastructure" is hosting PDFs/pages and the existing manual fulfilment. We are deliberately *not* building an app, login, dashboard, scoring engine, or the rehearsal engine until sales earn them.

---

## Sourcing & guardrails (unchanged, applied throughout)
Prevention not panic · signpost-only emergencies · no child data · no efficacy/safety guarantees · confidence-tag regulatory/threat claims · cite UK authorities (Ofcom, NSPCC, CEOP/NCA, IWF, Gambling Commission, Samaritans, Beat, gov.uk) · recency is a premium signal, so date everything and keep the currency layer honest.
