# User-Testing Pack — names & design directions

You have two ready-to-test packages. **Test one variable at a time** — don't show all eight versions at once or you can't tell whether the name or the look drove the preference.

## The two studies
1. **Design directions** (look & feel) — folder `brand-design/`. Four aesthetics, **same name + copy**, so only the design varies. *Question for testers:* which feels most like calm, premium, trustworthy help you'd actually pay for?
2. **Name + selling angle** — folder `brand-variants/`. Four names, each with a different way of describing the product, current look. *Question:* which name — and which way of putting it — makes you most likely to click "start"?

**Recommended sequence:** run the **design** test first, lock the look, then run the **name** test inside the winning look. (Or run both but to *different* people.)

## Get them in front of parents (this week)
1. **Host each free on Netlify Drop** (app.netlify.com/drop): drag the `brand-design` folder onto it → you get a public URL; drag `brand-variants` → a second URL. Each folder's `index.html` is the chooser that links the four. ~2 minutes each, no account needed for a quick share.
2. **Make a 3-question feedback form** (Tally or Google Forms, free):
   - "Which version did you prefer? (1 / 2 / 3 / 4)"
   - "In one line — why?"
   - "Would you trust this enough to pay £99? (yes / maybe / no)"
   Paste the form's link into each chooser where it says `[FEEDBACK FORM]` (the "Share your view" button).
3. **Share** the chooser URL + form to 5–10 warm parents and one parent group/WhatsApp. **8–12 responses is plenty** of signal at this stage.

## What to watch for (beyond the vote)
- Don't say which you like before they've clicked through.
- Note which one they **remember an hour later** — memorability beats first impression.
- Listen for the *reason*: "feels expensive / trustworthy / calm" = good; "looks like an app / a bit cold / too fancy / too sparse" = flags.
- For names, watch for mis-hearing or mis-spelling — that's a word-of-mouth leak.

## How to read the results
- **Design:** go with a clear preference; if it's split, default to **C (Warm-Editorial)** — lowest risk — and apply the universal type/whitespace upgrades either way (see `37`).
- **Name:** remember Levelhead / First Thing First / Keep Pace each have clearance problems — if one of those *angles* wins, keep the angle and pair it with a **cleared** name (Steadwise, or a fresh screened pick). See `36`.
- Either way, apply the two copy fixes: soften the H1 **"crisis" → "problem"**, and **substantiate the trust chips** (link them).

## The packages (and local previews)
- `brand-design/` — A Quiet Luxury · B Clinical-Trust · C Warm-Editorial · D Dark Concierge. Local: `http://localhost:8767`. Detail: `37`.
- `brand-variants/` — Bearings · Levelhead · First Thing First · Keep Pace. Local: `http://localhost:8766`. Detail: `36`.

*(Local URLs are for you only — they can't be shared with parents. Use Netlify Drop for that.)*
