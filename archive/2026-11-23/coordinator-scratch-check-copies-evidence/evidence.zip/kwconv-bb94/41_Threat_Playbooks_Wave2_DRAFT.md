# Threat Playbooks — Wave 2 (DRAFTS)

> These are unreviewed first drafts produced 2026-06-21. Every setting path, figure and link is marked for fact-check before publishing.


---

## AI in schoolwork — cheating, fake citations and classmate deepfakes

**DRAFT — fact-check every setting path, figure and link against the live source before publishing.**

Last drafted: 2026-06

A calm playbook for the everyday reality that generative AI has landed in homework. This isn't a moral panic — it's a new set of skills to teach and a new conversation to have. Most of it is ordinary parenting: curiosity over confrontation, habits over surveillance. One strand is more serious — deepfaked or AI-altered images of real classmates — and that strand is signpost-only. Confidence markers follow the rest of the library: `[V]` verified to a named UK source · `[PV]` partly verified · `[verify]` re-check before publishing.

This playbook sits alongside the existing AI entries in the Core Five (AI deepfake/nudify; AI companions/chatbots) and Module I (critical thinking & misinformation). It covers three connected things a parent meets in a single school year: homework shortcuts, fabricated sources, and AI images of other children.

---

## What it is

Three overlapping situations, not one:

- **AI homework shortcuts.** A child uses a chatbot to write an essay, solve a problem set, or summarise a book they didn't read — handing in the AI's work as their own. The harm isn't only "cheating"; it's the learning that doesn't happen, and a habit of outsourcing thinking.
- **Fabricated sources ("hallucinations").** Chatbots routinely invent confident-sounding facts, quotes and references — including citations to books, papers and web pages that **do not exist**. A child who trusts the output can hand in work built on made-up evidence without realising.
- **Deepfaked or AI-altered images of classmates.** "Nudify" apps and face-swap tools let someone create a fake nude or a humiliating fake image of a real, identifiable child. This is the serious strand: it is bullying, it can be a sexual offence, and it is handled as a safeguarding matter — *signpost-only* in this playbook.

These belong together because the same tools sit behind all three, and the same calm conversation opens all three.

---

## The UK picture, 2025-26

- **AI use among children is now mainstream.** Ofcom's media-literacy research finds the large majority of teens have used a generative-AI tool, with ChatGPT and similar among the most-used. `[verify exact figure and survey year against the latest Ofcom "Children and parents: media use and attitudes" / "Children's Media Lives" report]`
- **Schools are setting their own rules.** There is no single national ban or rulebook for pupils' AI use; the Department for Education has published guidance on generative AI in education, but day-to-day rules on what's allowed in homework are **set school by school** — which is why the school angle below matters. `[verify current DfE generative-AI-in-education position at gov.uk]`
- **Fabricated citations are a known, documented failure mode**, not a rare glitch — chatbots generate plausible references that don't exist. This is well-established and worth teaching as a feature of how the tools work, not a child's mistake. `[V — widely documented; cite a reputable explainer such as Internet Matters or Ofcom Making Sense of Media]`
- **Deepfake abuse of children is a live and growing harm.** Creating a sexual or nude image of someone under 18 — including an AI-generated or AI-altered one — is illegal, and the IWF has reported sharp growth in AI-generated child sexual abuse material. Report Remove (run by the IWF and Childline) handles AI-generated and AI-altered nude imagery of under-18s, not only "real" photos. `[V — IWF; Report Remove]` `[verify the latest IWF AI-CSAM figure before quoting any number]`
- **The law is tightening.** Online Safety Act child-protection duties have been live since 25 July 2025. Creating a sexually explicit deepfake without consent is now a specific offence under the **Data (Use and Access) Act 2025 (s.138)**, in force 6 February 2026 — creation alone is enough, and sharing such an image was already an offence under earlier law.

---

## Warning signs

Most AI use is invisible by design, so this rests on conversation more than detection. Possible flags:

- Homework finished suspiciously fast, or in a polished register that doesn't sound like them — then an inability to explain what they wrote.
- Confident "facts," quotes or sources in their work that don't check out, or references to books and articles you can't find anywhere.
- A teacher's comment about work that "isn't in their own words."
- Sudden distress, withdrawal or panic around the phone after something circulated in a year-group chat (a possible sign of a deepfake or fake image involving them or a friend) — handled below as a safeguarding matter, not a homework one.
- A child laughing about or sharing an "AI photo" of a classmate. Treat this as seriously as any other image-based bullying.

---

## Prevention — the everyday conversation

This is where most of the work is, and it's calm work.

**Frame AI as a tool with a job, not a forbidden thing.** A child who feels they have to hide it will hide it. The honest line is: AI is genuinely useful for some things (explaining a tricky concept, suggesting how to structure an essay, quizzing yourself before a test) and useless-to-harmful for others (writing the thing you're meant to write; being trusted as a source of facts).

**Teach the "explain it back" test.** The simplest integrity check a child can apply to their own work: *could I explain every sentence of this to a teacher right now?* If not, it isn't theirs yet. This is the human-in-the-loop principle in miniature — the child stays the author and the AI stays a tool.

**Teach that chatbots make things up.** Children are often shocked that a confident answer can be invented. Show them once: ask a chatbot for sources on a niche topic, then try to find those sources. When they can't, the lesson lands better than any lecture. The rule that follows: **never cite anything you haven't seen with your own eyes.** Click through to the real book or page; if it isn't there, it isn't a source.

**Separate "help me understand" from "do it for me."** A useful family rule of thumb: it's fine to ask AI to *explain*, *check* or *coach*; it's not fine to ask it to *produce the work you'll hand in*. Where the line sits in any given subject is the school's call — which is the next section.

**Model it yourself.** If you use AI for anything, say so, and say where you double-checked it. "The chatbot suggested this but I looked it up because it sometimes gets things wrong" teaches more than a rule ever will.

---

## The school angle

Because the rules are set locally, the most useful prevention step is to **find out what your child's school actually permits** — and to make sure your child knows it too.

- **Ask for the school's position on AI in homework.** Many schools have added this to their homework, ICT-use or academic-integrity policy. If you can't find it, a short email to the form tutor or head of year is reasonable: *"What's the school's expectation on pupils using AI tools like ChatGPT for homework?"*
- **Get the rule in your child's words.** "Allowed to help me revise, not allowed to write my essay" is a clearer guide than a policy document they'll never read.
- **If a teacher raises a concern about AI use**, treat it as a conversation, not a verdict. AI-detection tools are unreliable and can wrongly flag genuine work `[verify with a reputable source — this is well-documented but cite Ofcom Making Sense of Media or an academic-integrity body]`, so the productive move is to ask the child to explain and reproduce their thinking, not to accuse.
- **If the concern is a deepfake or fake image of a pupil**, that is no longer a homework matter — it goes to the school's designated safeguarding lead (DSL) and the routes below.

---

## If it's already happening — homework and fake sources

Calm, ordinary, no crisis:

1. **Open with curiosity, not accusation.** "Walk me through how you did this" surfaces the truth without a fight.
2. **Use the explain-it-back test together.** If they can't explain it, the gap *is* the lesson — and the fix is redoing it with AI as a coach, not an author.
3. **Check the sources together.** Look for each reference. When one turns out not to exist, you've taught hallucination first-hand.
4. **Loop in the school honestly if work was handed in that breached the rules.** Most schools treat a first, owned-up mistake as a teaching moment. Getting ahead of it with the tutor is usually better than waiting.
5. **Reset the habit, not just the homework.** Agree where AI helps and where it doesn't, in this child's subjects. This is a wellbeing-and-integrity issue, not an emergency — there's no helpline for it, and there shouldn't be.

---

## If an image of a real child is involved — signpost only

*This strand is serious and signpost-only. We do not give bespoke incident-handling steps; the routes below are run by the right authorities, and they exist for you and for the child.*

A deepfaked, "nudified" or AI-altered nude or sexual image of someone under 18 is treated as child sexual abuse material in law, **even if it's fake and even if a classmate made it as a "joke."** It is also image-based bullying and may be a criminal offence. The calm facts:

- **Don't make or forward it, and don't ask the child to send it to you.** Sharing it on — even to show an adult — can itself be an offence.
- **Don't save, share or forward the image — you don't need to gather evidence yourself; the official routes below handle it.**
- **The image can be reported and taken down.** **Report Remove** (childline.org.uk/remove), run by the IWF and Childline, handles AI-generated and AI-altered nude images of under-18s, and an under-18 can report an image of themselves. `[verify URL and current AI-image scope]`
- **Report it to the platform** it appeared on.
- **Tell the school's designated safeguarding lead** if classmates are involved — schools must act on this even when it happens off-site.

Then route to the people whose job this is:

- **Immediate danger to a child → 999.**
- **Online child sexual abuse, including AI-generated/altered imagery, blackmail or an adult involved → CEOP** (ceop.police.uk/ceop-reporting); **101/999** as appropriate.
- **Remove a nude or sexual image of an under-18 → Report Remove** via Childline (childline.org.uk/remove).
- **Worried about a child generally → NSPCC 0808 800 5000.**
- **Support for the child → Childline 0800 1111.**

Reassure the child: if an image of them has been faked or shared, **it is not their fault and they are not in trouble.** Fear of an adult's reaction is exactly what keeps children silent.

---

## Signpost quick-reference

| Situation | Route |
|---|---|
| Immediate danger to a child | **999** |
| AI-generated/altered nude or sexual image of an under-18; blackmail; adult involved | **CEOP** (ceop.police.uk/ceop-reporting) |
| Remove a nude/sexual image of an under-18 (incl. AI-generated/altered) | **Report Remove** via Childline (childline.org.uk/remove) |
| Image-based bullying involving classmates | **School DSL** + the routes above |
| Worried about a child generally | **NSPCC 0808 800 5000** · child: **Childline 0800 1111** |

*Full, formatted version: `03_Emergency_Signpost_Screen`. Re-verify numbers and URLs at publish and quarterly.*

---

## Build / verification notes

- This playbook deliberately keeps homework/hallucination (everyday, no helpline) separate from deepfake imagery (safeguarding, signpost-only). Preserve that split.
- Re-verify every helpline number, URL and the Report Remove AI-image scope at publish and quarterly.
- The deepfake/intimate-image offence landscape has moved fast — confirm the current legal position and commencement dates before publishing rather than relying on this draft.
- Keep any statistic dated and attributed; do not publish the IWF AI-CSAM or Ofcom AI-use figures without checking the latest source.
- No efficacy claims: this teaches habits and signposts; it does not promise to stop cheating or prevent deepfakes.

---

## Sources

- **Ofcom** — *Children and parents: media use and attitudes* and *Children's Media Lives* (children's generative-AI use; media literacy). `[verify edition/year]`
- **Ofcom — Making Sense of Media** — media literacy resources on AI, misinformation and source-checking.
- **gov.uk / Department for Education** — generative AI in education guidance. `[verify current version]`
- **IWF (Internet Watch Foundation)** — reporting on AI-generated child sexual abuse imagery; Report Remove. `[verify latest figures]`
- **Report Remove (Childline + IWF)** — childline.org.uk/remove — removal of nude/sexual images of under-18s, including AI-generated and AI-altered.
- **CEOP / NCA (Thinkuknow)** — ceop.police.uk/ceop-reporting — online child sexual abuse reporting.
- **NSPCC** — 0808 800 5000 — advice for worried adults; online-safety guidance.
- **Childline** — 0800 1111 — support for children and young people.
- **Internet Matters** — parent guides on AI tools, deepfakes and online safety.

*Re-verify every link, figure and setting path against the live source before publishing.*


---

## Doxxing & Swatting

**DRAFT — fact-check every setting path, figure and link against the live source before publishing.**

Last drafted: 2026-06

A short, practical playbook on two linked threats most parents have never had named for them: **doxxing** (someone publishing your child's private details) and **swatting** (someone making a hoax emergency call to send armed police to a real address). Both are rare compared with bullying or scams, but they sit at the serious end and they almost always start with something small and ordinary — a leaked address in a game lobby, a screenshot from a fight in a group chat. The good news is that the same quiet habits that reduce one reduce the other. This is calm, prevention-first guidance; it is not a crisis manual, and where an incident is live it points only to the right people, never to bespoke steps.

---

## What they are

**Doxxing** is publishing or sharing someone's private information — real name, home address, school, phone number, photos, parents' workplaces — usually without consent and usually to intimidate, embarrass or invite others to pile on. The information is often not "hacked" at all; it's pieced together from things already online. ([Police Scotland](https://www.scotland.police.uk/advice/cybercrime/doxxing/))

**Swatting** is making a false report of a serious emergency — a hostage situation, a weapon, a threat to life — to provoke an armed or large police response to someone else's address. It is dangerous precisely because the people who turn up believe the threat is real. Swatting almost always depends on doxxing first: the caller needs the target's real address. ([CPS](https://www.cps.gov.uk/cps/news/three-charged-making-alleged-swatting-calls-usa-and-canada))

A note on scale, kept honest: these are not everyday risks for most children. They cluster around **public-facing online activity** — streaming, competitive gaming, having a following — and around **conflicts that escalate**. Naming them is useful not because they are common but because the prevention is cheap and the consequences, when it does happen, are severe.

---

## The UK picture now

There is **no specific "swatting" offence** in UK law. False emergency reports are prosecuted under existing law — typically **perverting the course of justice**, and potentially offences relating to wasting police time or malicious communications. UK police have charged people in connection with swatting calls. ([CPS](https://www.cps.gov.uk/cps/news/three-charged-making-alleged-swatting-calls-usa-and-canada)) `[verify — current charging framing and any new OSA-era provisions]`

Doxxing, similarly, isn't a single named offence but is covered by a patchwork: **harassment, malicious communications, threats, and data-protection breaches** depending on what was shared and why. ([Police Scotland](https://www.scotland.police.uk/advice/cybercrime/doxxing/)) `[verify]`

Both threats are strongly associated with **gaming and live-streaming culture**, where rivalries, "owning" an opponent, and audience attention create motive, and where voice chat and shared servers create opportunity. ([Police Scotland](https://www.scotland.police.uk/advice/cybercrime/doxxing/); [Internet Matters](https://www.internetmatters.org/)) `[verify — exact Internet Matters page on doxxing/streaming]`

---

## How they start

Understanding the on-ramp is most of the prevention. It is rarely a dramatic breach. It's usually:

- **A leak during a game.** Someone shares their town, school, or a landmark on voice chat; a screen-share shows a delivery label, a school logo, a location in a photo's background. A determined rival keeps the fragments.
- **Cross-referencing the ordinary.** A username reused across a game, a social account and a forum lets someone link an anonymous handle to a real identity, then to a real place.
- **A fall-out that escalates.** A gaming argument or group-chat fight moves from insults to "I know where you live." Doxxing is the threat; for a small number, swatting is the follow-through.
- **Metadata and tagged photos.** Location data on images, geotagged posts, "first day at [school]" pictures, sports-club tags and visible house numbers stitch together an address.
- **An "IP grabber" or fake link.** A teen is talked into clicking a link that reveals their approximate location or IP — often framed as a game tool or a dare. `[verify — keep framing general, do not name specific tools]`

The pattern to teach: **private information leaks in small, boring pieces, and the danger is in the assembly, not any single piece.**

---

## The prevention conversation

Calm, specific, and framed around control rather than fear. The aim is fewer fragments online and a child who tells you early if a threat appears.

**Make the principle concrete.** "Anything that points to where you actually are — your address, your school, your area, your routine, your real full name next to your gaming handle — stays off public chat and public profiles. Not because something will happen, but because you can't un-share it."

**Separate the handle from the human.** Encourage **different usernames** for gaming, social media and forums, so an anonymous handle can't be linked back to a real identity by simple cross-referencing. Avoid usernames built from a real name, birth year or school.

**Tidy the obvious leaks together.** Review what's public on each account — who can see profiles, posts and friend lists. Turn off or restrict **location sharing** app by app. Check that photos aren't sharing location, and look at backgrounds before posting (uniforms, house numbers, street signs, the view from a window). ([NSPCC](https://www.nspcc.org.uk/keeping-children-safe/online-safety/); [Internet Matters](https://www.internetmatters.org/)) `[verify exact settings paths per platform/device]`

**Lock down the accounts that matter.** Strong, unique passwords and **two-factor authentication** on email, gaming and social accounts mean a leak of one thing doesn't cascade. The NCSC has plain guidance on this. ([NCSC](https://www.ncsc.gov.uk/collection/top-tips-for-staying-secure-online)) `[verify]`

**Name the escalation script out loud.** "If a game argument turns into 'I know where you live,' that's the moment to stop, screenshot, and tell me — not to fire back. People say it to scare you; reacting is what they want." This both reduces retaliation and makes early disclosure normal.

**Most important — remove the fear of telling you.** Make it explicit they will **not lose the device or be blamed** for telling you something has gone wrong. Children who fear confiscation or punishment stay silent, and silence is what lets a small leak grow. (This mirrors the single most evidence-aligned move across the wider library.)

**For children who stream or play competitively.** Treat a public profile as a public address book: no real location ever on stream, a delay on live location reveals, careful camera framing, and a clear rule that prizes, meet-ups or "drops" are checked with a parent first. `[verify]`

---

## If it happens — signpost only

If your child has been doxxed, threatened with it, or you believe an address is being used to provoke a police call-out, the right move is to get the right people involved early. This playbook does not give incident-handling steps; it points you to those who do.

- **Immediate danger to anyone, or you believe a hoax call may bring an emergency response to your home → 999.** If you're worried a hoax emergency call could be made about your home, the official routes below are the ones to use. Do not improvise beyond that.
- **A real but non-emergency crime — harassment, threats, private information published → 101**, or report online via your local force.Use the official routes below. `[verify reporting route]`
- **If an adult is involved, or there's any sexual element, grooming or coercion → CEOP** (the Child Exploitation and Online Protection command of the NCA): **ceop.police.uk/ceop-reporting**.
- **To remove a nude or sexual image of an under-18** that has been shared as part of this → **Report Remove**, run by the IWF with Childline: **childline.org.uk/remove**.
- **Non-criminal harmful content you want taken down → Report Harmful Content** (reportharmfulcontent.com, for ages 13+), alongside reporting in the app or game itself.
- **Worried about a child generally, or want to talk it through → NSPCC 0808 800 5000.** For the child themselves → **Childline 0800 1111** (free, confidential, 24/7).

A human should always be in the loop for anything at this end of the spectrum — a parent, the school's designated safeguarding lead, the platform, and where relevant the police. No tool, setting or guide replaces that.

---

## Sources

- Police Scotland — *Doxxing* (advice): https://www.scotland.police.uk/advice/cybercrime/doxxing/
- Crown Prosecution Service — *Three charged with making alleged 'swatting' calls*: https://www.cps.gov.uk/cps/news/three-charged-making-alleged-swatting-calls-usa-and-canada
- NSPCC — *Online abuse* and *Online safety*: https://www.nspcc.org.uk/keeping-children-safe/types-of-abuse/online-abuse/ · https://www.nspcc.org.uk/keeping-children-safe/online-safety/
- NSPCC — *Reporting online safety concerns*: https://www.nspcc.org.uk/keeping-children-safe/online-safety/online-reporting/
- Internet Matters — online safety guidance hub: https://www.internetmatters.org/ `[verify specific doxxing/streaming page]`
- NCSC — *Top tips for staying secure online* (passwords, 2FA): https://www.ncsc.gov.uk/collection/top-tips-for-staying-secure-online `[verify]`
- CEOP Safety Centre (NCA): https://www.ceop.police.uk/ceop-reporting/
- Report Remove (IWF / Childline): https://www.childline.org.uk/remove
- Report Harmful Content (SWGfL): https://reportharmfulcontent.com/

*Re-verify all numbers, URLs and platform setting paths at publish and quarterly. Cross-references: Module H (Privacy, data & digital footprint), Playbook A (Cyberbullying), Module J (Livestreaming).*


---

## Subscription Traps & Dark Patterns: Loot Boxes, Drip Pricing and the Money Conversation

**DRAFT — fact-check every setting path, figure and link against the live source before publishing.**

Last drafted: 2026-06

This playbook is about the money side of a child's online life: the design choices that nudge spending, the randomised "rewards" that borrow gambling's machinery, and the subscriptions and "free" games engineered to be easy to start and hard to leave. None of this is your child being careless. These mechanics are built by teams whose job is to convert attention into spend, and they work on adults too. The aim here is to recognise the patterns, set the few controls that matter, and have a steady money conversation that lasts longer than any one app. It sits alongside Playbook D (Gambling, loot boxes & in-game spending) in the main library and goes wider — into subscriptions, drip pricing and manipulative design across the apps, stores and games your family already uses.

Confidence: `[V]` verified to a named UK source · `[verify]` re-check the exact figure, path or link before publishing.

---

## What we mean by "dark patterns"

A "dark pattern" (regulators increasingly say "deceptive" or "manipulative" design) is an interface deliberately built to push you toward a choice you would not freely make — spending more, sharing more, or staying subscribed. The UK's Competition and Markets Authority (CMA) and the Digital Markets, Competition and Consumers Act (DMCCA) now treat several of these as enforceable consumer-law problems, not just bad manners. `[V — CMA / DMCCA 2024]`

The common families you will meet:

- **Drip pricing.** A low headline price that grows as unavoidable fees are added at each step of checkout. The DMCCA specifically targets the dripping of *unavoidable* fees, and on **18 November 2025** the CMA launched a consumer-protection drive into online pricing tactics including drip pricing and pressure selling. `[V — CMA]`
- **Pressure and urgency.** Countdown timers, "only 2 left," "37 people are viewing this" — manufactured scarcity that rushes a decision.
- **Confirmshaming.** The opt-out worded to make you feel foolish ("No thanks, I don't want to save money").
- **Forced or default opt-ins.** A pre-ticked box, or a sign-up flow that quietly enrols you in marketing or a trial.
- **Roach-motel subscriptions.** One tap to subscribe; a maze to cancel.
- **Disguised ads.** "Play now" buttons in a children's app that are actually adverts or in-app-purchase prompts.

For children, the same techniques arrive dressed as fun — a glowing chest, a limited-time skin, a streak you mustn't break.

---

## Loot boxes & randomised rewards

**What it is.** A loot box is paying real money (often via an in-game currency you topped up earlier) for a randomised reward — you don't know what you'll get. Skins betting, "packs," gacha pulls and spin-the-wheel mechanics are the same idea. The concern is twofold: money spent chasing an outcome, and the way the near-miss, variable-reward loop *conditions* a young brain toward gambling.

**The UK picture (2025–26).** Loot boxes are **not currently regulated as gambling** in the UK, so the gap falls to parents to manage. In the past 12 months **30% of 11–17s spent their own money gambling** (Gambling Commission, *Young People and Gambling 2024*), and **27% of 11–17s have paid to open loot boxes** (same source). Paying to open loot boxes has been **associated with markedly higher odds (around 4.4×) of problem gambling in one study of 16–24s** (Wardle & Zendle, 2021) — an association, not proof of cause, and not a finding about younger children. `[V — Gambling Commission, Young People and Gambling 2024; consistent with Playbook D]`

**How to spot it.** Look for in-game currencies bought with real money (gems, V-Bucks, coins), "open for a chance to get…," packs and crates, and the PEGI "In-Game Purchases (Includes Random Items)" descriptor on the game's store page. `[verify the exact descriptor wording]`

**The settings that matter.** The single most effective control is to **require authentication for every purchase** and remove stored payment cards, so nothing can be bought on a stored balance without a deliberate step:

- **Apple (iPhone/iPad):** Settings → Screen Time → Content & Privacy Restrictions → iTunes & App Store Purchases → set In-app Purchases to *Don't Allow*, and require a password "Always." `[verify path on current iOS]`
- **Google Play (Android):** Play Store → profile → Settings → Authentication → Require authentication for purchases → *For all purchases through Google Play on this device*. `[verify path on current Play Store]`
- **Consoles:** use the family/child account settings to require a passkey for spending and to cap or disable in-game purchases — PlayStation, Xbox and Nintendo Switch each have a parental-controls area for this. `[verify exact menu names per console]`
- **Remove stored cards** from the account and consider a prepaid card or fixed allowance instead of an open card on file.

Check the game's PEGI rating and the "in-game purchases" descriptor before downloading; **PEGI** and **Internet Matters** both publish plain guides to what these mean.

---

## In-app spend & "free-to-play" design

"Free" rarely means free. Free-to-play games are designed so the game is enjoyable until a wall — a wait timer, a difficulty spike, a limited-time event — that a small payment removes. Common mechanics to recognise:

- **Two-currency systems** — a "soft" currency you earn and a "hard" currency you buy, so the real cost is one step removed from the play.
- **Streaks, battle passes and FOMO events** — time-limited rewards that punish a day off and reward spending to "catch up."
- **Starter bundles and near-misses** — a cheap first offer to get a card on file; "so close" results that nudge one more go.

The settings above (purchase authentication off/locked, cards removed, allowances) do most of the work. Beyond that, turn on **purchase notifications** so a receipt lands with you, and review your app-store **purchase history** monthly so spend is visible rather than discovered.

---

## Subscriptions & drip pricing

**What it is.** The trial that auto-converts; the family plan that's easy to start and hard to stop; the headline price that swells with fees at checkout. Children encounter this through game subscriptions, streaming, creator memberships and "premium" tiers inside apps.

**The UK picture (2025–26).** The DMCCA introduces a tighter regime for subscription contracts and bans the drip pricing of unavoidable fees; the CMA's November 2025 enforcement drive opened investigations into online pricing practices and issued advisory letters to a large number of firms. The direction of travel is clearer pre-contract information, easier exit and honest headline prices — but it is still bedding in, so vigilance remains on you for now. `[V — CMA / DMCCA; re-verify enforcement specifics]`

**What to do.**

- **Audit recurring spend.** In Apple: Settings → your name → Subscriptions. In Google Play: profile → Payments & subscriptions → Subscriptions. `[verify both paths]` Review what's active, who's using it, and what auto-renews.
- **Treat free trials as paid.** Diary the renewal date the moment a trial starts, or cancel immediately (most trials run to the end of the period regardless).
- **Read the total, not the headline.** Before paying for anything, find the all-in price at the final step.
- **Know your cancellation rights.** Under UK consumer law you can complain to the trader and escalate to **Citizens Advice** / the CMA's guidance if cancellation is being made unreasonably difficult. `[verify current consumer-rights route]`

---

## Spotting manipulative design with your child

This is where the lasting protection lives — naming the trick out loud turns it from a feeling into a skill. Some prompts that work, by rough age band:

- **5–8s:** "Some buttons in games are really adverts. If a button says *buy* or shows money, come and get me." Keep purchasing fully locked behind your authentication.
- **9–12s:** "Loot boxes are designed to feel like *almost* winning, so you'll try again. That feeling is the product." Walk through a game's store page together and find the "random items" label.
- **13–18s:** "Drip pricing, countdown timers and pre-ticked boxes are deliberate — and now partly illegal under UK rules. Spotting them is a life skill, not nagging." Show them your own subscriptions audit so it's a shared habit, not surveillance.

The point is not to ban games or stores, but to make the machinery visible.

---

## The money conversation

A few principles that hold up well:

1. **No shame for spending — especially unplanned spending.** A child who fears your reaction hides the next charge. "Tell me and we'll sort it" keeps the line open.
2. **Talk about *why* it pulled them in,** not just the number. The design is the thing to name, not the child's self-control.
3. **Agree a model in advance** — a fixed allowance, prepaid balance, or "ask first" rule — so spending is a decision, not an accident.
4. **Make spend visible together.** Going through purchase history side by side is a calmer ritual than discovering a bill.
5. **Keep the human in the loop.** These controls are tools to support a conversation you lead — not a substitute for it, and no setting removes the need for it.

---

## If money has already been spent — signpost only

If unexpected or large charges appear, this is a calm, practical clean-up, not an emergency:

1. **Remove the payment method** and review recent transactions.
2. **Check for refunds.** Apple, Google and the console stores can sometimes refund unauthorised or child purchases; your bank may be able to dispute charges. Follow each store's own help pages for the current process. `[verify refund routes]`
3. **Talk before you confiscate** — understanding *why* it happened prevents the next time.

If the worry is about **gambling itself** — chasing losses, distress around play, betting — the route is support, not panic:

- **National Gambling Helpline 0808 8020 133** (24/7; supports under-18s and worried parents), operated by **GamCare**.
- **GamCare** and **YGAM** publish youth and parent resources.

This playbook does not provide bespoke incident-handling. If anything tips into a child being coerced, blackmailed or contacted by an adult around money or images, follow the main library's signposts: **CEOP** (ceop.police.uk/ceop-reporting), **Childline 0800 1111**, **NSPCC 0808 800 5000**, **Report Remove** via Childline (childline.org.uk/remove), and **999** in an emergency.

---

## Quick reference

| Goal | Where to look |
|---|---|
| Lock in-app purchases (Apple) | Screen Time → Content & Privacy → iTunes & App Store Purchases `[verify]` |
| Lock in-app purchases (Android) | Play Store → Settings → Authentication `[verify]` |
| Lock console spending | PlayStation / Xbox / Switch family parental controls `[verify]` |
| Audit subscriptions | Apple: Settings → name → Subscriptions · Google Play: Payments & subscriptions `[verify]` |
| Understand a game's spend | PEGI rating + "In-Game Purchases (Random Items)" descriptor `[verify wording]` |
| Gambling support | National Gambling Helpline **0808 8020 133** (operated by GamCare) |
| Consumer rights / unfair pricing | Citizens Advice · CMA guidance `[verify route]` |

*Re-verify every path, figure and link at publish and quarterly.*

---

## Sources

- Competition and Markets Authority — consumer protection under the Digital Markets, Competition and Consumers Act 2024; November 2025 online-pricing enforcement drive (drip pricing, pressure selling, dark patterns). gov.uk / CMA. `[verify exact page]`
- Gambling Commission — *Young People and Gambling* statistics (gambling among 11–17s; loot-box participation). gamblingcommission.gov.uk. `[verify latest report year]`
- Internet Matters — guides to in-game spending, loot boxes and money controls. internetmatters.org.
- NSPCC — online safety and in-app purchasing guidance for parents. nspcc.org.uk.
- PEGI — age ratings and content descriptors, including in-game purchases (random items). pegi.info.
- Ofcom — children and parents media use and attitudes (context on time online and platform use). ofcom.org.uk.
- Apple — *Use parental controls on your child's iPhone, iPad* / Screen Time help. support.apple.com. `[verify current path]`
- Google — *Set up parental controls on Google Play* / require authentication for purchases. support.google.com. `[verify current path]`
- Citizens Advice — consumer rights on subscriptions, cancellations and unfair charges. citizensadvice.org.uk.
- GambleAware / National Gambling Helpline — support for gambling harm including young people. gambleaware.org.

*All statistics should be dated and re-attributed to the named UK source before publication; helpline numbers and URLs link-checked at publish and quarterly.*


---

## Online challenges & hoaxes

**DRAFT — fact-check every setting path, figure and link against the live source before publishing.**

Last drafted: 2026-06

Few topics generate more parent panic — and less proportionate response — than viral "challenges" and the warnings that circulate about them. A screenshot of a sinister character lands in a class WhatsApp group; a local news segment runs a worried-parent interview; a school sends a "be aware of…" email. Within days, half the playground is talking about a danger that, on close inspection, is mostly a story about the warning itself.

This module is deliberately led with proportion, not alarm. The single most useful thing a parent can know here is that **the warning is very often the hoax**. Once you understand how these scares spread, you can respond calmly, check before you forward, and have the kind of open conversation that actually helps — rather than amplifying fear your child may never otherwise have encountered.

---

## What we mean by "challenges" and "hoaxes"

Three different things tend to get blended together:

- **Genuine social-media challenges** — a dance, a recipe, a fitness streak, a charity trend. The overwhelming majority are harmless, often positive, and pass quickly.
- **Risky dares** — a smaller set of trends that involve real physical risk (e.g. ingesting something, holding your breath, an endurance or "blackout" dare). These are real but far rarer than coverage suggests, and they shift constantly.
- **"Scare hoaxes"** — viral warnings about a supposed sinister game, character or "suicide challenge" said to be targeting children. These are typically the *story* of a danger rather than the danger itself, and they spread fastest of all because fear is shareable.

The crucial point: a frightening warning is not evidence that a threat is real or widespread. Often the warning **is** the phenomenon.

---

## The UK picture now

Online safety bodies have repeatedly cautioned parents and schools **against sharing unverified challenge warnings**, because doing so amplifies fear and can introduce children to ideas they had never encountered. The NSPCC, the UK Safer Internet Centre and others have publicly addressed specific scares of this kind, advising a calm, evidence-led response rather than mass warnings. [verify — confirm current NSPCC / UK Safer Internet Centre wording and which named scares they reference]

The most-cited real-world example is the **"Momo" scare** (2018–2019): a viral warning that a creepy figure was appearing in children's videos and instructing them to harm themselves. Investigations by fact-checkers and safety organisations found **no verified cases of harm** traced to it; the dominant harm came from the panic and the warnings themselves, which frightened children who would otherwise never have seen the image. [verify — confirm Momo dates and the "no confirmed cases" framing against a reputable source such as the BBC, Samaritans or UK Safer Internet Centre]

More broadly, Ofcom's research shows that **misinformation is the single most-encountered online harm** in the UK — around **41% of users aged 13+** met potential misinformation in a four-week period (Ofcom *Online Nation* 2025) — meaning the average parent and teen is far more likely to meet a false viral claim than a genuine dangerous dare. `[verify the 13+ base and four-week framing against Ofcom Online Nation 2025]`

Some risks in this space are nonetheless real and have caused tragedies — for example certain breath-holding or "blackout" dares, or the ingesting of dangerous substances. These are serious but uncommon, and they are best handled through ongoing conversation about risk and pressure, not through forwarding a panic message. [verify — keep this deliberately non-specific; do not name or describe method, in line with safe-messaging guidance]

---

## Why scare hoaxes spread (and why most viral warnings are themselves the hoax)

Understanding the mechanism is what lets you stay calm:

- **Fear is the most shareable emotion.** A warning that says "protect your child from X" feels responsible to pass on, so it travels through parent groups, schools and local news far faster than the quiet correction that follows.
- **A warning needs no proof to spread.** "I heard there's a game where…" requires no verification to feel urgent, while debunking requires effort few people see.
- **Recycling.** The same scare (a sinister character, a "suicide game," a hidden challenge in kids' videos) reappears every year or two with a new name, often using old or unrelated images.
- **The warning can create the thing it warns about.** Detailed descriptions of a "challenge" can introduce the idea to children who had never heard of it — which is exactly why safety organisations ask adults not to broadcast specifics.
- **Algorithms reward outrage.** Content that provokes a strong reaction is amplified, so the alarming version out-travels the measured one.

This is why the calm default is: **a viral warning is unverified until a reputable source confirms it.** Treat the warning itself with the same scepticism you'd apply to any other misinformation (see this library's *Critical thinking & misinformation* module).

---

## Warning signs to watch for (in your child, not in your feed)

The useful signals are about your child's wellbeing and behaviour, not about whether a scary screenshot is going round:

- Sudden anxiety or sleep disruption after seeing something online, or fear of a specific image, character or "game."
- Talking about a dare or trend with pressure attached — "everyone's doing it," "you get dared," "you have to film it."
- Secretive filming, or asking to do something risky "for a video."
- Repeating an alarming claim as fact without knowing where it came from.
- A younger child frightened by playground rumours of a scary character.

Note what's **not** on this list: a viral warning landing in your own group chat is a prompt to *check*, not a sign your child is at risk.

---

## The calm, evidence-led parent response

**Prevention is mostly conversation, not control.**

1. **Pause before you forward.** If a warning arrives, don't share it onward until you've checked it. Forwarding is the main way these scares spread. If it turns out to be unverified, you've contained it rather than fuelled it.
2. **Check it against a reputable source.** Look for confirmation from Ofcom, NSPCC, the UK Safer Internet Centre, Internet Matters, an established broadcaster, or a recognised fact-checker — not another parent group or a viral post. No confirmation usually means no story.
3. **Don't over-describe.** When you talk to your child, you don't need to detail a specific "challenge" — that can introduce it. Ask open questions instead: "Have you seen anything online lately that worried you or that people are talking about?"
4. **Teach the pause and the "why."** The most durable protection is a child who can ask *who made this, why am I seeing it, and is this true?* — and who knows that real friends don't pressure you into dares. This is media literacy and peer-pressure resilience, the same skills that help across many online risks.
5. **Make it safe to come to you.** Reassure your child they can show you anything — a frightening image, a dare, a video they were pushed to make — **without being in trouble or losing the device.** Fear of your reaction is what keeps children silent.
6. **Set up reporting together.** Show them how to report and block on the apps they use, so an upsetting post or a pushy dare becomes something they can act on, not just endure. [verify — keep generic; specific report paths live in the Platform Settings Library]
7. **Use trusted resources, not viral ones.** Internet Matters, Childnet and the UK Safer Internet Centre publish calm, age-banded guidance you can lean on instead of the rumour mill.

These steps support good judgement; they are not a guarantee, and no setting or conversation removes risk entirely. The aim is proportion and openness, which is what the evidence supports.

---

## If something has actually happened — signpost only

Most challenge and hoax scares need no emergency response at all. But if a genuine risk emerges, route to the people whose job this is — and do not attempt bespoke intervention.

- **A child is in immediate danger, or has been seriously hurt → 999.**
- **A child is distressed or struggling, or you're worried about their mental health →** they can talk to **Childline on 0800 1111** (free, 24/7); you can speak to the **NSPCC on 0808 800 5000**. In an urgent mental-health situation, **NHS 111** (select mental health) is available 24/7.
- **A dare or "challenge" has tipped into grooming, coercion to film, or sexual content** (e.g. a child pressured into recording something) **→** this is a child-protection matter: report to **CEOP** (ceop.police.uk/ceop-reporting), and **999** if a child is in danger.
- **A nude or sexual image of an under-18 has been shared →** an under-18 can use **Report Remove via Childline** (childline.org.uk/remove) to have it taken down. (See this library's *Sexting & peer image-sharing* playbook.)
- **Harmful but non-criminal content you want removed →** Report Harmful Content (reportharmfulcontent.com, 13+).

If you're personally affected or distressed by any of this, the **Samaritans (116 123, free, 24/7)** are there for adults too.

---

## A note on safe messaging

When discussing risky dares — particularly anything involving self-harm — follow safe-messaging principles: don't describe method, don't sensationalise, and don't share detailed warnings widely. Naming a danger in vivid detail can do more harm than the danger itself. This is the central lesson of every scare-hoax cycle, and it is why this module names no specific current "challenge." [verify — align with Samaritans media guidelines / safe-messaging guidance current at publish]

---

## Sources

- Ofcom — *Online Nation* and *Making Sense of Media* research on misinformation as the most-encountered online harm. ofcom.org.uk [verify figure and report year]
- NSPCC — guidance for parents on online challenges and viral hoax warnings; helpline 0808 800 5000. nspcc.org.uk [verify current page and wording]
- UK Safer Internet Centre / Childnet — guidance on responding to scare hoaxes and challenges; advice against sharing unverified warnings. saferinternet.org.uk; childnet.com [verify]
- CEOP / Thinkuknow (National Crime Agency) — reporting route for online child sexual abuse and coercion. ceop.police.uk/ceop-reporting; thinkuknow.co.uk
- Childline — Report Remove tool and 24/7 support line 0800 1111. childline.org.uk/remove
- Internet Matters — age-banded advice on online trends, peer pressure and critical thinking. internetmatters.org
- Samaritans — safe-messaging / media guidelines and 24/7 support line 116 123. samaritans.org [verify guidelines reference]
- BBC / established fact-checkers — reporting on the "Momo" scare and the absence of confirmed harm. [verify specific source before publishing]

*Re-verify all numbers, dates, named scares and URLs at publish and quarterly. Do not name or describe any specific current "challenge" without checking it against a reputable source first.*


---

## Playbook K — Crypto, "finance-bro" hype & get-rich-quick content aimed at teen boys

**DRAFT — fact-check every setting path, figure and link against the live source before publishing.**

Last drafted: 2026-06

This playbook covers the wave of get-rich-quick, crypto and trading content — and the "finance-bro" influencers behind it — that is heavily targeted at teen boys. It sits in the same arc as the rest of the library: what it is → the UK picture now → warning signs → prevention → what to do if it's already happening (calm steps, signpost only). It deliberately overlaps two existing modules: the **money-scam** thread (Core Five — Scams, fraud & money-muling) and the **critical-thinking** thread (Module I). The single most useful thing a parent can do here is the critical-thinking conversation, not a ban.

Confidence: `[V]` verified to a named UK source · `[PV]` partly verified · `[NV]` re-check before publishing. Treat every figure and link as `[verify]` until checked against the live source at publish time.

---

## PLAYBOOK K — Crypto, "finance-bro" hype & get-rich-quick content

**What it is.** A cluster of online content promising fast, easy money: cryptocurrency and "trading" hype, foreign-exchange (forex) and contracts-for-difference (CFD) "signals", drop-shipping and "side-hustle" courses, "passive income" claims, and the **"finance-bro" / "hustle culture" influencer** persona — usually a young man showing off cars, watches and a laptop-on-a-beach lifestyle. Much of it shades into three real risks: **scams and fraud** (fake exchanges, pump-and-dump tokens, "investment" schemes that take a deposit and vanish), **gambling-style speculation** dressed up as "investing", and **paid courses or "mentorships"** that mostly teach the buyer to recruit the next buyer. The content is engineered to feel aspirational and aimed squarely at teenage boys.

**Why teen boys specifically.** The aspirational framing — status, independence, "escaping the 9-to-5", out-earning your mates — is pitched at adolescent boys, and algorithms then push more of it once a boy engages. It often arrives bundled with broader "manosphere" / hustle-culture content, so the financial hype is rarely encountered in isolation. `[PV — describe the pattern; do not overstate a single named study]`

**The UK picture 2025–26.**
- **Crypto promotions are now regulated.** Since the Financial Conduct Authority's cryptoasset financial-promotions regime took effect on **8 October 2023**, it is illegal to promote cryptoassets to UK consumers without complying with FCA rules — including a clear risk warning and a ban on "refer-a-friend" incentives. Promotions must carry the standard warning: *"Don't invest unless you're prepared to lose all the money you invest. This is a high-risk investment and you should not expect to be protected if something goes wrong. Take 2 mins to learn more."* Much of the influencer content teens see does **not** comply. `[V — FCA]`
- **Young adults are heavily exposed to crypto.** FCA research has found crypto ownership skews young, and that many buyers act on social-media hype and "fear of missing out" rather than research. `[PV — FCA crypto consumer research; verify the latest figures]`
- **"Finfluencers" are an enforcement priority.** The FCA has publicly warned about unauthorised "finfluencers" promoting financial products, and has taken action against some. The regulator's line is blunt: many finfluencers are promoting products they don't understand, and some are running scams. `[V — FCA finfluencer campaign; verify specifics]`
- **It overlaps with money-muling.** "Make money fast using your bank account" recruitment (see Core Five — Scams) frequently travels in the same influencer ecosystem; some get-rich-quick offers are mule recruitment in disguise — a criminal offence committed in the child's name. `[V — see Core Five]`
- **Loot-box / gambling crossover.** The "thrill of the trade" and constant price-checking sit close to the gambling-conditioning concerns in Playbook D; some products (high-risk CFDs, "demo to live" trading apps) are gambling-shaped. `[PV — cross-reference Playbook D]`

> Mark the **average age / exposure figures** "[verify]". Do not publish a specific "X% of teen boys follow finance influencers" statistic unless it is sourced to Ofcom, the FCA or a named survey. If no robust UK teen-specific figure exists, describe the pattern qualitatively instead.

**Warning signs.** New fixation on getting rich quickly, or talking about "passive income", "the grind", "escaping the matrix" or named finance influencers. Asking for money to "invest", buy crypto, or sign up to a "course" or "mentorship". Mentions of trading apps, crypto wallets, or being added to a "signals" group (often on Telegram, Discord or WhatsApp). Unexplained small payments out — or in. Requests to use a parent's bank card, ID or address to open an account (many platforms are 18+). Selling possessions to fund "an opportunity". Secrecy, or sudden expertise in jargon. Disappointment, anxiety or chasing behaviour after a "loss". A friend who is recruiting others into the same scheme.

**Prevention — lead with critical thinking, not a ban.**
1. **Have the critical-thinking conversation (Module I applied to money).** Teach a few questions to ask of any money claim: *Who is telling me this, and how do they actually make their money? If it were this easy, why would they sell it instead of just doing it? What am I being asked to pay or deposit? Who is on the other side of this trade?* The honest answer to "how does the influencer make money" is usually **selling courses, affiliate links and your attention — not the trading itself.**
2. **Name the business model out loud.** Most "mentorships" and "signals groups" earn from sign-ups and referrals. Pump-and-dump schemes earn when newcomers buy in and the early holders sell. Saying this plainly is more durable than any block.
3. **Set the "if it sounds too good to be true" rule, and the FCA test.** Legitimate UK investment firms are authorised by the FCA and listed on the FCA Register; legitimate crypto promotions carry the standard risk warning and never use "refer a friend" bonuses. Teach the child to check the **FCA Register** and the **FCA ScamSmart Warning List** before anyone puts money anywhere. `[V — fca.org.uk/scamsmart; verify]`
4. **Lock down spending (shared with Playbook D).** Require a password for every purchase and remove stored cards (Apple Screen Time; Google Play; console family settings) — exact menu paths "[verify]". Most trading and crypto platforms require users to be 18+, so a teen account usually means borrowed adult ID — a conversation to have before it happens.
5. **Separate "interested in money/investing" from "falling for hype".** Curiosity about how money works is healthy and worth encouraging. Point it at credible, age-appropriate sources (see below) rather than influencers. The goal is a sceptical, financially literate teen — not a teen who thinks all money talk is a scam.
6. **Human-in-the-loop on any spending.** Agree that no money goes into any app, token, course or group without talking to you first — framed as a second pair of eyes, not a permission gate, so they actually come to you.

**If it's already happening.**
1. **Stay calm and don't shame.** These schemes are professionally designed to be persuasive; falling for one is not stupidity. Shame guarantees they hide the next one.
2. **Screenshot first — don't delete.** Capture the offer, the chat, the influencer's account, any transaction confirmations and the platform name before anything is removed or blocked.
3. **Stop further payments.** Remove the payment method and check for recurring charges or "deposit more to withdraw" demands (a classic trap — never pay to "release" funds).
4. **If money has gone or details were shared, treat it as fraud.** Contact the **bank straight away** (they may be able to stop or recover a payment), and report to **Action Fraud 0300 123 2040** (or reportfraud.police.uk). `[V]`
5. **Check for money-muling.** If the "opportunity" involved receiving money into the child's account and passing it on, treat it as the muling scenario in Core Five — contact the bank and Action Fraud; this can be a criminal offence in the child's name.
6. **Report the content and the account** in-app, and report misleading financial promotions or suspected scam firms to the **FCA** via its reporting form / consumer helpline. `[V — fca.org.uk; verify route]`
7. **Don't just confiscate the phone — debrief.** Walk back through *how* it hooked them; that conversation is the prevention for next time.

> **Signpost only.** This playbook does not give bespoke incident-handling beyond the calm steps above. If a child is being threatened or coerced over money (for example, blackmail or pressure to keep paying), route to the relevant emergency contacts: **999** if there is immediate danger; **CEOP** (ceop.police.uk/ceop-reporting) if an adult is involved or it crosses into grooming/coercion; **NSPCC 0808 800 5000** if you are worried about a child generally; **Childline 0800 1111** for the child. For fraud, the routes are the **bank** and **Action Fraud 0300 123 2040**.

**No guarantees.** Settings, conversations and checks reduce exposure and build judgement — they do not "keep your child safe" or prevent every scam. The durable protection here is a teenager who can spot the business model behind the hype, plus an agreement that no money moves without a second pair of eyes.

---

### How this connects to the rest of the library
- **Core Five — Scams, fraud & money-muling:** the same fraud routes (bank, Action Fraud) and the muling crossover. This playbook is the "investment / get-rich-quick" face of the same threat.
- **Playbook D — Gambling, loot boxes & in-game spending:** speculation-as-entertainment, chasing losses, and locking down in-app/payment settings overlap directly.
- **Module I — Critical thinking & misinformation:** the core skill (who's saying this, why, and how do they really make money) is the same media-literacy muscle, applied to money.

---

## Sources
*(Re-verify every link, figure and date at publish time and quarterly.)*

- **Financial Conduct Authority (FCA)** — cryptoasset financial-promotions regime and rules; warnings on unauthorised "finfluencers"; FCA Register and reporting routes. fca.org.uk `[verify exact pages and dates]`
- **FCA ScamSmart** — investment-scam warning signs and the Warning List. fca.org.uk/scamsmart `[verify]`
- **Action Fraud (City of London Police)** — reporting fraud and online investment scams; 0300 123 2040. reportfraud.police.uk `[verify]`
- **Ofcom** — children's media use and online harms (misinformation as the most-encountered harm; exposure to financial/scam content). ofcom.org.uk `[verify latest Children's Media Lives / Online Nation figures]`
- **Internet Matters** — guidance for parents on money scams, online financial pressure and critical thinking. internetmatters.org `[verify]`
- **NSPCC / Childline** — support for worried parents and children; Childline 0800 1111; NSPCC 0808 800 5000. nspcc.org.uk `[verify]`
- **CEOP / Thinkuknow (NCA)** — where an adult, coercion or grooming is involved. ceop.police.uk/ceop-reporting · thinkuknow.co.uk `[verify]`
- **Gambling Commission** — young people, gambling-style mechanics and the gambling/speculation crossover (cross-reference Playbook D). gamblingcommission.gov.uk `[verify]`

*Build note: do not publish a teen-specific "% follow finance influencers" statistic unless sourced to Ofcom, the FCA or a named survey; otherwise keep the qualitative framing. Confirm the FCA crypto-promotion wording, dates and reporting routes against the live FCA pages before release.*


---

## Parasocial & Influencer Pressure

**DRAFT — fact-check every setting path, figure and link against the live source before publishing.**

Last drafted: 2026-06

This playbook follows the same arc as the rest of the Bearings library: what it is → the UK picture now → warning signs → prevention → keeping it in perspective if it's already taken hold. It's about one of the quieter pressures of growing up online — the feeling of *knowing* a streamer or influencer who has no idea you exist, and the spending and comparison that can ride along with it. This is a wellbeing and media-literacy topic, not an emergency one; there's no crisis line at the bottom, only the general safeguarding routes if something tips over into harm. Confidence markers match the library: `[V]` verified to a named UK source · `[PV]` partly verified · `[NV]` re-check before publishing.

---

## What it is

A **parasocial relationship** is a one-sided bond: your child feels they know a YouTuber, streamer, TikToker or gamer — their voice, their in-jokes, their daily life — while the creator doesn't know your child exists. This is normal and mostly harmless; adults form them with sports stars and podcast hosts too. The repetition is what makes it feel real: hours of someone talking straight to camera, often in a bedroom that looks like your child's, builds a sense of friendship that a film star never could. `[PV — academic literature on parasocial interaction; confirm framing before print]`

It becomes worth attending to when three things stack up:

- **Attachment** — the creator starts to feel like a *primary* friend, and a missed stream or a creator's break lands like a real falling-out.
- **Spending** — the bond is monetised: paid subscriptions, "gifting" during livestreams, merch, donations for a shout-out, or buying whatever the creator is paid to promote.
- **Comparison** — a curated, sponsored, filtered life gets read as the normal one, so your child's ordinary life feels like it's falling short.

The creator's living often *depends* on keeping that bond strong — which is the honest thing to name with your child. The warmth is real to them; the business model behind it is real too.

## The UK picture now

- Watching vloggers and YouTubers is among the most common things children do online — mainstream, not fringe. `[verify against the current Ofcom Children's Media Lives / Media Use & Attitudes report; do not publish a specific percentage unless it appears in the named source]`
- Influencer culture and money are entangled. Around **two in five parents (43%)** are concerned about children spending money online on games and apps (Internet Matters spending/loot-box poll — *not* the Wellbeing Index), yet only a minority had talked to their child about it recently. **Livestream "gifting"** — paying real money for virtual gifts that creators convert to income — is a recognised pressure point, with documented cases of creators soliciting gifts in exchange for shout-outs. `[V — Internet Matters spending/loot-box poll]`
- The encouraging part: many teenagers **can** spot a paid endorsement when it's labelled. Recognition isn't automatic for younger children, but it's teachable — which makes this a coaching topic rather than a lockdown one. `[PV — Ofcom; confirm]`
- Regulation is catching up at the edges. Advertising rules require influencers to clearly label paid content (look for "Ad" / "Paid partnership"), and the Online Safety Act's child-safety duties (live since 25 July 2025) push platforms toward age assurance and safer defaults — but neither stops the day-to-day pull of a favourite creator. Treat this as a **parenting-and-conversation** issue, not one a setting solves. `[V — ASA influencer guidance; OSA timeline as per library legal backdrop]`

## Warning signs

Most of these are matters of *degree* — a favourite creator is healthy; the list below is about a bond that's crowding other things out.

- A creator is talked about like a close friend ("we" did this, "we" think that) and a missed upload or a creator's break causes genuine distress.
- Real money flowing out: subscription charges, in-app gift purchases, donations, or a steady stream of merch and "the thing [creator] uses."
- Pestering to buy specific products, with the creator cited as the reason.
- Comparison talk — feeling boring, poor, ugly or behind next to a creator's life or body.
- Wanting to copy a creator's risky or age-inappropriate content, or to "become famous" as the main life plan.
- Secrecy about how much is being watched or spent; defensiveness if you question the creator.
- Sleep, schoolwork, hobbies or in-person friendships being displaced by keeping up with a creator's schedule.

## Prevention — keeping it in healthy perspective

The goal is not to stop your child enjoying creators. It's to keep the bond **one of many** good things, and to make spending and comparison conscious rather than automatic.

- **Watch *with* them, sometimes.** Ask who they follow and why; watch an episode together. Curiosity ("what do you like about them?") opens far more than disapproval, and it lets you see what's actually being modelled.
- **Name the business gently.** Explain that creators are running a business: subscriptions, gifts, sponsorship and merch are how many of them earn a living. This isn't cynicism — it's the single most useful frame for a child to carry. Teach the labels to look for: **"Ad," "Paid partnership," "Sponsored," "#ad."** `[V — ASA/CAP influencer disclosure rules]`
- **Separate the person from the product.** "You can love watching them *and* not buy what they're paid to sell" is a distinction children can hold once it's said out loud.
- **Make spending deliberate.** Turn on a password or approval for every purchase (Apple Screen Time, Google Play, console family settings) and keep stored cards off the account, so gifting and subscriptions can't happen on impulse. Agree in advance how money on creators works — pocket money, a set allowance, or "ask first." `[verify exact current setting paths on each platform]`
- **Talk about the highlight reel.** A creator's life is curated, filtered, edited and often sponsored — comparing your whole ordinary life to their best, paid moments isn't a fair fight. This links closely to the library's **Critical thinking & misinformation** module and **Screen-time, sleep & digital wellbeing** playbook.
- **Protect the rest of life.** A child with sport, friends, hobbies and family time has the bond in proportion automatically. The defence against any one relationship looming too large is a full life around it, not a ban.
- **Watch the livestream "gifting" mechanics.** These are designed to feel like real-time connection and approval. Naming that out loud — "they're built to make you want to spend to be noticed" — takes some of the pull out of them. `[PV — Internet Matters gifting guidance; confirm]`

## If it's already taken hold

This isn't an emergency — it's a recalibration, best done with conversation rather than confiscation (the library's consistent steer).

1. **Don't mock the creator or ban abruptly.** Belittling someone your child feels close to usually deepens the attachment and closes the conversation. Stay curious instead.
2. **Get the money in view together.** Look at recent subscriptions, gifts and purchases side by side, calmly. Seeing the total is often the most persuasive single step. Where charges were unauthorised or a child spent without understanding, Apple, Google and console stores can sometimes refund, and the bank may dispute charges — the same route as the **Gambling & in-game spending** playbook.
3. **Reset the spending rules, not just the balance.** Agree what's allowed going forward and put the approval/password controls in place so the next impulse has a pause built in.
4. **Rebalance rather than remove.** Protect sleep and add back offline anchors — the bond shrinks to a healthy size when other things grow, not when the creator is taken away overnight.
5. **Talk about the comparison, not just the spend.** If your child is measuring themselves against a creator's looks or lifestyle and coming up short, that's the part worth the longer conversation.

**Where this tips into something more serious — signpost only.** If a creator or someone in a fan community is *soliciting* private contact, images, or money from your child, or moving them to private/disappearing apps, that's grooming or sextortion territory — see the library's Core Five and **CEOP** (ceop.police.uk/ceop-reporting); **999** if a child is in immediate danger. If the worry is your child's mood, self-esteem or eating in the context of comparison, route via the **GP**, and for the child directly there's **Childline 0800 1111**; if you're worried about a child generally, **NSPCC 0808 800 5000**. We don't give bespoke incident-handling steps — these are the people who do. `[V — routes per Emergency Signpost Screen; re-verify numbers/URLs at publish]`

---

## Build / verification notes
- The earlier vlogger-watching age-split percentages (5–7 / 8–11 / 12–15) could not be verified against any Ofcom report and have been removed as suspected fabrication; do not reinstate any specific figure unless it appears verbatim in a named Ofcom report.
- The Internet Matters spending-concern stat (43%) is from the Internet Matters spending/loot-box poll, not the Wellbeing Index; keep that attribution and date it. Confirm the livestream-gifting framing against the live page.
- Re-check current per-platform purchase-approval setting paths (Apple Screen Time, Google Play, consoles) — these change.
- Keep this filed as a **wellbeing/media-literacy** playbook: no crisis line of its own, only the general safeguarding signposts.

## Sources
- Ofcom — *Children and Parents: Media Use and Attitudes / Children's Media Lives* (2025). https://www.ofcom.org.uk/research-and-data/media-literacy-research [verify exact report and figures]
- Ofcom (via EPRA) — Key findings from Ofcom's 2025 UK adults' and children's media lives research. https://www.epra.org/news_items/key-findings-from-ofcom-s-2025-uk-adults-and-children-s-media-lives-research
- Internet Matters — *Online money management guide* (in-game spending, gifting gaming influencers). https://www.internetmatters.org/advice/by-activity/online-money-management-guide/
- Internet Matters — *Do influencers have an impact on a child's behaviour?* https://www.internetmatters.org/hub/question/do-influencers-have-an-impact-on-a-childs-behaviour/
- Internet Matters — *Helping children think critically about online influencers.* https://www.internetmatters.org/hub/question/how-can-i-help-my-child-think-critically-about-the-social-media-influencers-they-follow/
- Advertising Standards Authority (ASA) / CAP — *Influencers' guide to making clear that ads are ads.* https://www.asa.org.uk/ [verify exact page]
- CEOP Safety Centre (report online child sexual abuse / grooming). https://www.ceop.police.uk/ceop-reporting
- NSPCC — advice and helpline 0808 800 5000. https://www.nspcc.org.uk/
- Childline — 0800 1111. https://www.childline.org.uk/

*Re-verify all numbers, setting paths and URLs at publish and quarterly, per the library's standing rule.*
