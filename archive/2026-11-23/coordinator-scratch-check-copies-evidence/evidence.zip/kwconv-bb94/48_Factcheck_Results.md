# 48 — Fact-Check Results (2026-06-21)

Live-source verification of the 45 worklist items in `47_Draft_Review_and_Factcheck.md`. Every figure, date, helpline number, URL and menu path in drafts 40–45 was checked against the official source. **Verdict: the batch is not publish-ready** — there are real errors, two suspected fabrications, one wrong criminal statute, and several stale figures.

Legend: ✅ confirmed · ✏️ confirmed-but-fix-wording · ❌ wrong · 🚫 unverifiable / suspected fabricated.

---

## 🔴 Must-fix before publishing (errors, not nitpicks)

| # | Claim (draft) | Verdict | Correct value / action | Source |
|---|---|---|---|---|
| 1 | Deepfake = offence under **Online Safety Act 2023** | ❌ | It's the **Data (Use and Access) Act 2025, s.138** (creation offence, in force 6 Feb 2026). Sharing was already an offence earlier. | legislation.gov.uk DUAA 2025 |
| 2 | CEOP report path `ceop.police.uk/Safety-Centre` | ❌ | Reporting now lives at **`ceop.police.uk/ceop-reporting/`** (or just `ceop.police.uk`). Keep education site `thinkuknow.co.uk` separate. | ceop.police.uk |
| 3 | National Gambling Helpline "via **GambleAware**" | ❌ | Operated by **GamCare**; GambleAware is the funder. Number `0808 8020 133` ✅ 24/7. | gamcare.org.uk |
| 4 | Internet Matters "**77%** of 9–17s experienced harm" | ❌ | Actual harm figure is **67%**. The 77% is the share who *feel safe online*. (Index 2025, Year 4.) | internetmatters.org |
| 5 | Loot boxes "**23% of 11–16s**" paid to open | ❌ stale | That's the **2019** figure. Current: **27% of 11–17s** (Young People & Gambling 2024). | gamblingcommission.gov.uk |
| 6 | Ofcom "**77% of 8–17** have own profile / **60% of 8–12s**" | ❌ | **79% of 3–17s** have a profile; **40% of under-13s** have a social-media profile. Metric + band garbled. | Ofcom 2025 report |
| 7 | Ofcom "**96% of 13–17s use social media**" | ❌ | 96% = **3–17s who *went online*** in 2024. Wrong metric. | Ofcom 2025 report |
| 8 | "65%/34% watch-vs-post (Ofcom **May 2025**)" | ❌ wrong year | Those are the **2026** figures. The 2025 split was **70% / 29%**. Re-date or re-figure. | Ofcom 2026 report |
| 9 | PEGI administered by **Video Standards Council (VSC)** | ❌ | Renamed **Games Rating Authority (GRA)** on 30 Sep 2024. "Statutory" ✅. | gov.uk / GRA |
| 10 | Pinterest link "expires after 3 days or **5 new followers**" | ❌ | "3 days or **5 uses/people**, whichever comes first" (private profiles only). | help.pinterest.com |

## 🚫 Suspected fabrications — remove or re-source (could not be tied to any real figure)

| # | Claim | Note |
|---|---|---|
| 11 | "**38% of 5–7s use social media**, up from 30%" (Ofcom May 2026) | No Ofcom source matches. Nearest real: 3–5s at 37% (up from 29%); the "30% of 5–7s" is TikTok-specific. Conflation — **cut or re-source**. |
| 12 | Vloggers "~half; **8–11s 47%, 12–15s 49%, 5–7s 34%**" | No single Ofcom report supports this triplet. Different years give conflicting numbers. **Cut or re-source.** |

## 🟠 Roblox — major real-world change, content is stale

| # | Claim | Verdict |
|---|---|---|
| 13 | "Roblox changed its controls substantially in 2026" | ✅ **and bigger than the draft says.** Roblox launched **Kids (5–8)** and **Select (9–15)** account types (announced 13 Apr 2026, global ~16 Jun 2026): curated catalogues, comms off by default for younger kids, facial age-estimation, parental controls extended through age 15. Any Roblox/console guidance written before April 2026 — incl. the existing `content/platforms/roblox.mdx` — is now out of date and should be refreshed. |

## ✏️ Confirmed but tighten the wording

| # | Claim | Fix |
|---|---|---|
| 14 | OSA "came fully into force July 2025" vs "live since 25 July 2025" | Reconcile to one line: **"From 25 July 2025, services likely to be accessed by children must apply highly effective age assurance and the Protection of Children duties under Ofcom's Children's Codes."** (Pornography age-assurance commenced earlier, 17 Jan 2025.) Drop the vague version. |
| 15 | FCA crypto risk warning "lose all the money you put in" | Use the exact mandated wording: **"Don't invest unless you're prepared to lose all the money you invest. This is a high-risk investment and you should not expect to be protected if something goes wrong. Take 2 mins to learn more."** Date: **8 Oct 2023**. |
| 16 | KCSIE "legal duty" to provide "appropriate filtering and monitoring"; current edition | Soften to **"statutory guidance (KCSIE) schools must follow"**. Current edition is **2025** (in force 1 Sep 2025), not 2026. |
| 17 | Under-16 social-media restriction "law-in-principle… Spring 2027" | Framing is accurate — keep "not yet in force". Soften "law-in-principle" → **"announced UK government policy; regulations expected to be laid late 2026, implementation ~Spring 2027."** Do **not** imply it's already law. (Australia's under-16 ban is the only one live — don't conflate.) |
| 18 | NSPCC "Half use AI; a third of parents realise" (52%/31%) | ✅ keep — but band-specific to **12–15s**; usage figures came from Ofcom. Cite the band. |
| 19 | Ofcom "11% of 8–17s" use AI as a friend | ✅ figure right; it's **11% of 8–17 *AI users***, not all 8–17s. Reword. |
| 20 | Internet Matters "43% of parents concerned about spending" | ✅ figure right but from a **separate spending poll**, not the Wellbeing Index. Fix the citation. |
| 21 | Gambling "30% of 11–17s" | ✅ — use the **"spent own money"** framing (49% is the broader "any experience" measure). |
| 22 | Loot boxes "4.4× higher odds of problem gambling" | ✅ (Wardle & Zendle 2021) — it's an **association, sample 16–24**, not causation in younger kids. Phrase carefully. |
| 23 | Twitch "thumbnail blur on by default" | ✅ — caveat: does **not** apply to channels the user already follows. |
| 24 | UK broadband filters "strengthened as a default" | Overstated. Filters are **default-presented but opt-out**; government softened the mandatory stance in 2017. Soften the phrasing. |
| 25 | Online Nation "41% misinformation, users 13+, four-week period" | ✅ **CONFIRMED** (Ofcom Online Nation 2025, pub. Dec 2025): misinformation was the most-encountered harm at 41% among users aged 13+ in the past four weeks. Existing `critical-thinking.mdx` stat is correct. |
| 26 | Action Fraud `0300 123 2040` / `actionfraud.police.uk` | Number ✅; site superseded by **`reportfraud.police.uk`** (old one redirects). Update URL. |
| 27 | Report Remove `childline.org.uk/remove` | Service/operators ✅. Childline's site hard-blocks automated fetches (403 = bot protection, not a 404), so the short URL can't be tool-verified. New Wave-2 files use the guaranteed `childline.org.uk` homepage; existing files keep the long-published `/remove` deep-link. **Only residual: one browser click at publish.** |
| 28 | NSPCC Helpline `0808 800 5000` | ✅ — but phone is **Mon–Fri 10–4**, not 24/7. Don't imply round-the-clock. |
| 29 | Report Harmful Content, users 13+ | ✅ — note it runs on a **limited basis since 1 Apr 2025** (funding ended); don't promise a full review. |

## ✅ Clean as written (no change)

Childline `0800 1111` / under-19s · Samaritans `116 123` 24/7 · Shout `text SHOUT to 85258` · 999/101 routing · IWF `iwf.org.uk` · Ofcom smartphone 56%→83% · ¾ of 8–9s use a tablet (77%) · ~⅓ of 8–17s have a user age of 18+ (32%) · time online 1 day / 2 days a week · AI 56% of 8–17s rising to 66% of 16–17s · four-in-five teens use gen AI (79%, Nov 2023 — dated) · Snapchat My AI ~half of 7–17s (51%, Nov 2023 — dated) · Internet Matters harm breakdown 41/27/22/19 · Character.AI under-18 change late Nov 2025 · CMA drip-pricing drive Nov 2025 · CEOP/NCA sextortion campaign (Mar 2025, targets boys 15–17) · YouTube Kids under-13 · Minecraft Realms + Java player reporting · Steam block/report · Ofcom report dates 7 May 2025 & 21 May 2026.

---

## Per-file fix checklist

**40_Platform_Guides_Wave2** — CEOP path (#2) · Pinterest 5 uses not followers (#10) · OSA date reconcile (#14) · KCSIE wording + 2025 edition (#16) · Twitch followed-channel caveat (#23) · NSPCC/AI stat band note (#18) · Roblox/console staleness if referenced (#13) · keep "safest way"→relative reframe (polish).

**41_Threat_Playbooks_Wave2** — Deepfake statute → DUAA 2025 (#1) · National Gambling Helpline → GamCare (#3) · loot boxes 27%/11–17 (#5) · OSA date (#14) · FCA exact wording + 8 Oct 2023 (#15) · gambling "spent own money" (#21) · 4.4× association caveat (#22) · Internet Matters 43% citation (#20) · vloggers triplet → cut/re-source (#12) · Action Fraud URL (#26) · misinformation 13+ base (#25).

**42_Incident_Disclosure_Scripts** — CEOP path (#2) · Report Remove URL (#27) · NSPCC not-24/7 (#28) · RHC limited-service note (#29) · numbers otherwise ✅.

**43_AgeUp_Cards** — Roblox 2026 Kids/Select rewrite (#13) · CEOP path (#2) · "13 minimum age" ✅-ish keep verify · sextortion claim ✅ (#CEOP/NCA) · helpline numbers ✅.

**44_Proportion_Guide** — 38% of 5–7s → cut/re-source (#11) · 77%/60% own-profile → 79% of 3–17s, 40% of under-13s (#6) · 96% of 13–17s → fix metric (#7) · 65%/34% → re-date to 2026 (#8) · Internet Matters 77%→67% (#4) · 11% AI-users wording (#19) · under-16 ban wording (#17) · keep confirmed figures.

**45_Room_by_Room_Setup** — PEGI → Games Rating Authority (#9) · broadband "strengthened as a default" soften (#24) · YouTube Kids under-13 ✅ · Roblox/console refresh (#13).

---

*Method: five parallel web-verification passes (helplines/routes, legal/regulatory, Ofcom child-media stats, NSPCC/Internet Matters/Gambling stats, platform settings). Every CONFIRMED carries a cited live source; every WRONG carries the corrected value and source. No figure was confirmed from memory.*
