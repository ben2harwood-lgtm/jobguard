# 100 — Tool Build Specs: the Worth-£49 Bundle

**For:** Ben · **Date:** 5 July 2026 · **Status:** Build-ready specs, in build order
**Source of truth:** blueprint `99` (§2.6 tool table, §9 Guided Setup addendum), `21_MASTER_BUILD_SPEC.md` §7.5 (revised, block-gated) + §2 guardrails + §10.3 lint. Where this file and 21/99 disagree, 21 §2 (guardrails) wins, then 99.
**Revision note (2026-07-05):** `100_Automated_Build_Plan.md` v1.1 (adjudicated external critique) amends this file where marked *(v1.1)* below — Spec 1 split/log fields/render modes/admin security/severity layer, Spec 4 lookup rule, claims wording, digest decoupling, Gates A0/B0. Where the two files disagree, 100 v1.1 wins.
**Rules that apply to every spec below:**
- **Zero child-identifiable data.** No child name, DOB, school, photo, screenshot, incident detail, anywhere. Age = band only. Device labels = enumerated slots, never free text. *(v1.1)* This is the internal design North Star; the public promise is the enumerated wording in 100 §1.9, and band+platforms tied to a parent account is still personal data — Gate B0 treats it as such.
- **No LLM in any delivery path.** All customer-visible words come from published content blocks (spec 1's publish gate). The authoring prompt lives at `scripts/editorial/plan-prompt.ts` *(v1.1 — relocated from `lib/`, CI import guard in place, done 2026-07-05)* and is an authoring aid only.
- **Claims lint (21 §10.3) runs at block level** — banned: "safe", "protected", "pass", "prevents", "monitors", "we noticed", verdicts of any kind.
- Hours = **specification + iteration for an AI-assisted non-technical founder**, not hand-coding. All [INF], consistent with 99 §2.6.
- **Naming:** "Keepwise" per 95–99; reconcile with "Bearings" (file 25) once, everywhere, before any offer page ships.

---

## Spec 1 — Block-Assembly Plan Engine (+ per-block publish admin, assembly log, `verifySignpost`)

**User stories.**
- *Parent:* "I paid £49 and answered 25 questions; within two minutes I get a household plan where every guidance block is editor-reviewed, dated, versioned and traceable to a source, matched to my children's age bands, apps and devices — and no AI writes or assembles a word of it at delivery." *(v1.1 claims wording — "written by" claims are retired, 100 §1.6.)*
- *Editor (admin):* "I can draft, lint, source-stamp, publish, and retire content blocks one at a time, and reconstruct exactly what any customer ever received."

**Sub-spec split *(v1.1)*.** This spec is now six sub-specs, estimated and tracked separately: **1a** block schema/registry · **1b** assembly engine · **1c** publish admin + reviewer workflow · **1d** audit log/re-render · **1e** safety lint + CI · **1f** customer render/delivery. The 60–80 h figure below was optimistic for the full set — re-estimate per sub-spec at kickoff.

**Components.** (a) `content_blocks` schema + admin publish flow; (b) deterministic assembler; (c) immutable publish + assembly logs; (d) `lib/signpost.ts` locked constant + `verifySignpost()`; (e) plan render (web `/library/start` + PDF) + delivery email.

**Admin security *(v1.1 — the publish admin is a safety surface)*.** Admin-only routes; 2FA; role separation (author ≠ checker where possible; **second reviewer mandatory** for emergency/sextortion/grooming/self-harm blocks); explicit publish confirmation for high-risk blocks; append-only audit log; withdrawal flow; an emergency pause-plan-generation switch; backups; staleness and unreviewed-change alerts.

**Acceptance criteria.**
1. Assembler can select **only** blocks with `status='published'` AND `review_by` in the future. A stale block is auto-withdrawn, its slot filled by its designated evergreen fallback, and an editor queue alert fires. (CI test for all three behaviours.)
2. Publishing writes an **immutable** `block_publish_log` row *(v1.1 field list)*: block id, version, content-hash, source file + hash, author, checker, sources, publish timestamp, `review_by`, withdrawal timestamp. Rows cannot be updated or deleted (DB policy + test). This is the ASA/CAP 3.7 authorship record.
3. Scoring: answers → six exposure domains → Lower/Moderate/Higher per `01` §2.3. A "Don't know" **never creates a factual claim and never raises a verdict or exposure band** — it emits a "find this out" action block (unit tests for both). *(v1.1)* For the defined high-stakes settings list — private accounts unknown, who-can-message unknown, location sharing unknown, payment access unknown, content filters unknown — a Don't-know **raises the action priority of the discovery task** (never the band; unit test).
4. Runtime interpolation limited to: age band(s), ticked platform/device names, sibling count. The content lint **fails the build** on any other template variable.
5. Multi-child households: one plan, sectioned per band via splice connectors (persona test: three children in opposing bands).
6. Every plan embeds the `SIGNPOST` constant verbatim (999/101, CEOP, Report Remove, NSPCC 0808 800 5000, Childline 0800 1111). `verifySignpost()` hash-checks at **build and at render**; a mismatch hard-fails delivery to a safe error page — no path delivers a plan without a verified signpost.
7. Every delivered plan writes a `plan_assemblies` row *(v1.1 field list — captured in full from sale #1)*: assembly id, pseudonymous household id, answer option ids, ordered block ids/versions/content-hashes, interpolation values, rule trace, render engine version, code Git SHA, signpost version/hash, PDF/template version, offer-page version at purchase, timestamp. *(v1.1 render modes)* Two modes: **audit render** — byte-identical reconstruction from this log alone (original block versions + interpolation values + signpost version + code Git SHA + template version); **customer current render** — latest published blocks + current signpost, logged as a new assembly. The re-render *tooling* may land post-pilot; the complete *log* may not.
8. Honesty signature renders *(v1.1 wording)*: per-section footer "Editor-reviewed by [editor], checked [date], version [v], sources: […]" + the top line "How this plan was made… assembled deterministically from editor-reviewed, dated, versioned blocks; no AI writes any word at delivery." Never "written by".
9. p95 questionnaire-submit → delivered email < 2 minutes.
10. 20 adversarial persona plans (all-Don't-know; single platform + high concern; 3-band household; empty-platform household; urgent-concern interrupt) generated and editor-signed before Gate A.
11. `plans.status` retains dormant `in_review` (the future human-tier socket); no code path uses it yet.
12. *(v1.1)* **Severity/interrupt layer:** urgent-concern answers (sextortion, grooming, self-harm, coercion indicators) trigger a signpost-first interrupt **above** the standard 11-slot flow — routing only, never advice. `calm` blocks never render above urgent action blocks and never render alone for a high-risk concern; calm-but-act wording carries the estate's under-18-image non-preservation carve-out (persona + lint tests).

**Data touched (child-PII-free):** `questionnaires` (answers_jsonb, `child_age_band` band-only; free_text purged ≤30 days; the child-first-name field no longer exists), NEW `content_blocks` (id, slug, class, version, version_hash, status, review_by, author, checker, sources_jsonb, body_mdx, age_bands[], platforms[], concerns[]), NEW `block_publish_log` (immutable), `plans`, NEW `plan_assemblies`, `events`.

**Guardrail notes.** Implements 21 §7.5 (revised) exactly; this is a guardrail feature, so any later change re-triggers safeguarding review. Signpost constant is the architectural fix for the `7df540c` wrong-number failure class. No monitoring, no verdicts, no child-facing anything.

**Est. hours:** engine + admin + logs **60–80** — *(v1.1)* optimistic for the six-sub-spec scope; re-estimate per sub-spec. (Separate editorial track: MVP pool ~140 blocks ≈ 110 hrs — *(v1.1)* now an estimate; the coverage criterion in 100 §2 M1 is the exit test — runs in parallel, Sprint 0.)

**Dependencies:** none — this is the foundation. **Gates A and B0 block the first sale** *(v1.1)*.

---

## Spec 2 — Guided Setup Session (co-hero)

**User story.** "Plan in hand, I tap 'Set up our devices'. For each device I declared, I get an exact click-path — screen by screen, for my device model and my choices — phone in one hand, this in the other, ~25 minutes — ending in a dated completion record I can see again later."

**Acceptance criteria.**
1. Session generator composes a per-household session from published **wizard-flow blocks** matching declared devices/platforms (same publish gate + `review_by` rules as spec 1).
2. Each flow: numbered steps, per-OS variants, screenshots optional, a "can't find this screen?" fallback step, and OS **deep-links** into the right settings screens where the platform supports them, with graceful text fallback where not.
3. Completing a flow writes a **dated completion record** rendering as "Checked and completed [date] · **next review due [date + 6 months]**" — never "pass"/"safe"/"secured" (lint on record templates). *(v1.2)* The next-review-due line is the file-98 "Review Certificate" renewal seed: it sits in the household's records for months as the visible reason the renewal exists, with no certification framing.
4. Devices are **enumerated slots** ("Child 1 — Android phone", "Family tablet"); free-text device names are not accepted (blocks "Molly's iPhone" child-PII by construction).
5. Records store `flow_version`; when a flow re-publishes, prior completions display "settings may have moved since you did this" and surface in the re-check (spec 8).
6. Printable per-device card for the manual remainder (feeds spec 9).
7. Launch coverage: top-10 flows from `16`/`27` (candidate set: iOS Screen Time, Android Family Link, PlayStation, Xbox, Switch, YouTube, Roblox, WhatsApp, Snapchat, TikTok — final list from diagnostic tick-rates).

**Flagged sub-feature — tap-to-install DNS filter profile (feature-flag OFF until Gate B).**
- Generates a standard configuration profile / router instruction set pointing the household's devices or router DNS at a family-safe resolver, chosen from their diagnostic; fully transparent, one-tap/one-page reversal instructions included.
- **No credentials collected, ever. No traffic visible to us, ever** — copy must say "we see nothing".
- The claims wording is a **single fixed reviewed string**: "filters common adult content — not a guarantee, and never monitoring; we see nothing." Ships only after Gate B legal sign-off; env flag until then.
- This is the closest the product comes to technical control (99 §9); everything beyond it (driving the child's apps, MDM) is out of scope permanently.

**Data touched (child-PII-free):** wizard flows as `content_blocks` (class `setup-flow`), NEW `setup_completions` (user_id, flow_id, flow_version, device_slot enum, completed_at). No device serials/MACs/identifiers, no credentials, no child names.

**Guardrail notes.** Education posture preserved: the product instructs, the parent performs — except the DNS profile, which is transparent + reversible + credential-free. The completion record is a record of *doing*, never a certification of safety. No monitoring claims anywhere.

**Est. hours:** ~25 framework + ~2/flow × 10 ≈ 45; session-composer wrapper +10; DNS sub-feature +12–15. **Total ~55–70.**

**Dependencies:** Spec 1 (publish infra, household diagnostic). DNS flag-on depends on **Gate B**.

---

## Spec 3 — Changed-For-You Digest

**User story.** "Once a month Keepwise emails me only what changed in the guidance that touches *my* declared ages and apps — and most months it honestly says 'nothing changed for your household'."

**Launch decoupling *(v1.1 — Option B, 100 §2 M4)*.** The digest is decoupled from launch: the offer page promises "first year of updates included" with **no calendar promise** until Gate B1 **and** the minimal digest machinery (honest empty-month template, service-only email lint — no marketing content in service emails, unsubscribe/cancel logic, run/send logs) are both done; only then may the offer-page claim upgrade.

**Pre-requisite change (FLAG FOR PRIVACY NOTICE — Gate B):** today the working questionnaire detail purges at 30 days. The digest needs a retained, consented **household profile** (bands, platforms, devices, declared flags — nothing else). Implement: NEW `household_profiles` derived at plan delivery (age_bands[], platforms[], devices[], first_phone_flag/date, updated_at); retained while entitlement is current, deleted on request or entitlement-lapse + 90 days; `free_text` is **never** copied in and still purges at 30 days. Lawful basis: contract (the digest is a promised deliverable, year 1 bundled); the retention change and deletion path must be added to `05_Privacy_and_Data_Notice` **before the first digest sends**.

**Acceptance criteria.**
1. Monthly run diffs block versions published since the last run against each current profile's tags; the email lists only matching changes, each with the editor's one-liner "what changed → what to do".
2. **The honest empty month is mandatory:** no matches → the verbatim "nothing changed for your household — enjoy the quiet" template. Never suppressed, never padded.
3. Copy watches the **public landscape**, never the child: "Snapchat moved a setting that affects 13–14s" ✅; "we noticed on Snapchat" ❌ (template lint).
4. Sends only to entitlement-current users (`updates_until >= today` OR active subscription). Digest is a service email for entitled customers (PECR); no marketing content inside it.
5. Profile deletion is self-serve, takes effect immediately, and the confirmation states plainly that the digest stops because we no longer know their household shape.
6. Run + send logs: NEW `digest_runs` (period, changed block-versions) and `digest_sends` (run_id, user_id, matched jsonb, sent_at) — substantiation for "we told you first".

**Data touched (child-PII-free):** `household_profiles` (band/platform/device tags only — PII-free by construction), `digest_runs`, `digest_sends`, `subscriptions`/`purchases` (read).

**Guardrail notes.** This asset carries the £29/yr renewal (99 condition 2) — protect its honesty above its impressiveness. "We monitor"/"we noticed" permanently banned.

**Est. hours:** **30–40** build (+ privacy-notice wording through Gate B).

**Dependencies:** Spec 1 (block versioning), profile retention change + notice update (Gate B, privacy checkpoint), email cron.

---

## Spec 4 — New App? Ask Keepwise

**User story.** "My child asks for an app in the kitchen; I type its name and in ten seconds get a calm one-screen brief tuned to their age band — or an unmistakable 'we haven't covered this yet'."

**Acceptance criteria.**
1. Lookup matches against human-maintained **app-card blocks** (~30 at launch, ~50 target), fuzzy-matched on a known-names/aliases dictionary only.
2. Card contents: what it is, stated age rating vs reality, the 2–3 settings that matter (deep-link to the spec-2 wizard where one exists), one conversation starter, sources + checked date. **No verdicts, ever** — "safe/unsafe/fine/avoid" banned by lint.
3. *(v1.1)* Unmatched query → the "not yet covered" template + link to general principles. Lookup is **client-side normalisation against the known-names/aliases dictionary**; **raw free text from the lookup box is never stored** (a parent could type a child's name). Matched → log app_id. Unmatched → nothing is stored from the lookup itself; a **separate, optional, opt-in "suggest this app" field** stores **the app name only** — no age band, no household id, no other answers attached.
4. The opt-in "suggest this app" field (AC3) feeds the authoring queue (this is the live-data long-tail authoring signal from 99 §2.1).
5. Public SEO variant: static per-app pages ("is [app] OK for my 12-year-old?") showing generic band guidance; personalisation only when signed in.
6. App-card blocks carry `review_by` 6-monthly, same as platform blocks.

**Data touched (child-PII-free):** app cards as `content_blocks` (class `app-card`), NEW `lookup_events` (matched app_id or an 'unmatched' counter, band context for matched lookups only, timestamp — no raw query text), NEW `app_suggestions` *(v1.1)* (opt-in app name only — nothing else).

**Guardrail notes.** No verdicts is the hard rule; "not yet covered" is a feature, not a failure. SEO pages carry the same lint.

**Est. hours:** ~20 build + ~40 editorial (30 cards). **Total 60 (20 eng).**

**Dependencies:** Spec 1 publish infra. SEO pages need marketing routes but not the paid product.

---

## Spec 5 — Family Agreement builder (completion)

Already specified (21 §7.10); this closes it out.

**User story.** "I pick my children's bands, tick suggested clauses, tweak the words, and print 'Our Family Online Agreement' for the fridge."

**Acceptance criteria.**
1. Clause menus per band from published clause blocks (`19`/`09` §G; AI clauses cross-fed from `53` Worksheet 1). Multi-band households merge menus with band labels.
2. Clauses editable before render; printable PDF, dated, signpost footer.
3. **Stores nothing about the child, and nothing server-side at all**: pure client-side state + client PDF render. Optional "email me my PDF" sends and discards. The only persistence is an `agreement_generated` counter event.
4. Suggested clauses never imply surveillance products or monitoring commitments (lint on clause blocks).

**Data touched:** none persisted (clause menus are content blocks; `events` counter only).

**Guardrail notes.** The agreement is the family's words, not our certification. No monitoring clauses.

**Est. hours:** **~10.**

**Dependencies:** Spec 1 block infra (or ship v1 with static menus and migrate).

---

## Spec 6 — Age-Up / First-Phone kits + 72-hour email sequence

**User story.** "I told Keepwise the first phone is coming this term. Two days before handover I get the prep email; on the day, the 25-minute setup session; three days after, a calm check-in. When my child approaches a band boundary I get the age-up drill pack."

**Acceptance criteria.**
1. Triggers use **only parent-declared flags**: declared band + "first phone expected [rough date]" + "eldest turns 11/13/16 this year" toggles. **No DOBs, no birthday inference** — band roll-overs are parent-confirmed via the re-check (spec 8), never auto-assumed from elapsed time.
2. Kit content from `32`/`43` published as blocks: printable age-up card + refreshed plan sections + links to the relevant spec-2 flows.
3. First-phone sequence keyed to the parent-set date: **T-48h** (prep + agreement builder link), **T-0** (Guided Setup Session for the new phone), **T+72h** (check-in, "what's normal in week one", no fear framing). One-click pause/cancel; service email for entitled buyers (PECR).
4. First-phone kit included in year 1; age-up kits require current entitlement (a designed renewal draw).
5. The `first_phone_date` field is documented in the privacy notice as *a date about the parent's plan*, explicitly not a child DOB (Gate B privacy checkpoint).

**Data touched (child-PII-free):** `household_profiles` flags (first_phone_date, band-boundary toggles), scheduled email events.

**Guardrail notes.** No countdown-to-birthday mechanics (would need DOB — banned). Copy lint: no "72 hours to protect your child" fear framing — this is the highest-anxiety moment in the funnel and the calmest copy in the product.

**Est. hours:** **~25** (content exists in `32`/`43`).

**Dependencies:** Specs 1, 2 (session links), 3 (profile retention), email cron.

---

## Spec 7 — AI-homework family-policy generator

**User story.** "I answer six quick questions (ages, our school's stance, subjects) and print a one-page family policy for AI and homework we can take to parents' evening."

**Acceptance criteria.**
1. Clause menus from published blocks sourced from the `ai-schoolwork` playbook + `53` Worksheet 4 (Schoolwork Ladder).
2. Output header states: a family agreement to adapt with your school — **not** compliance advice, **not** a cheating-detection tool.
3. **No authorship/verdict clauses**: nothing that claims to verify whether work is the child's (21 §2 hard rule); ask-first rules, explain-back habits, source-checking clauses only.
4. Reuses spec 5's clause-menu + client-PDF machinery; stores nothing; counter event only.
5. Public SEO teaser ("family AI homework rules") with generic output; personalised menus for buyers.

**Data touched:** none persisted (`events` counter only).

**Guardrail notes.** School-policy claims carry confidence tags + sources (existing content convention). Bridge to spec 10 (Lab).

**Est. hours:** **15–20.**

**Dependencies:** Spec 5 (build immediately after; shares machinery), Spec 1 blocks.

---

## Spec 8 — Quarterly re-check

**User story.** "Every three months: 'Since March, 2 blocks in your plan updated; you said your eldest turns 13 this year — confirm and we'll refresh the plan; 3 device checkups still not done.' No scores, no grades."

**Acceptance criteria.**
1. Composes from existing engines: block diffs (spec 3), incomplete/stale setup flows (spec 2), and profile-confirmation prompts (band roll-over, new platforms) via a 60-second diff questionnaire that updates `household_profiles`.
2. **Score-free by rule**: no grade, rating, percentage, or pass/fail anywhere (lint). "Nothing to do this quarter" is a first-class output.
3. "Re-render my plan" button produces a fresh assembly against current published blocks — "plan current as of [today]" (the living plan, 99 §4.2d).
4. Entitlement-current users only; this is the renewal heartbeat between digests.

**Data touched (child-PII-free):** `household_profiles` (read/update), `plan_assemblies` (new row on re-render), reuses `digest_runs`, `setup_completions`.

**Guardrail notes.** Confirmation, not inference, for every band change. Never framed as an audit or MOT (banned renewal claims, 99 §4.2).

**Est. hours:** **~15.**

**Dependencies:** Specs 2 and 3 (it is mostly their reuse).

---

## Spec 9 — Printables bundling

**User story.** "One 'Print pack' page: the fridge emergency card, quick-ref cards for our apps, the weekend checklist for our bands, our agreement and policy PDFs, and the per-device setup cards."

**Acceptance criteria.**
1. Emergency card renders **from the `SIGNPOST` constant** — a single source of numbers, hash-verified; no second hand-maintained copy that can drift from `03`/`84`.
2. Pack personalised by declared platforms/bands (quick-ref cards from `27`, checklists from `32`); print CSS, A4.
3. Includes the user's generated PDFs (specs 5/7) if they choose to re-render them client-side; nothing stored.
4. Emergency card page stays non-monetised and reachable ungated (21 §7.7 unchanged).

**Data touched:** none new.

**Guardrail notes.** No "certified safe home" framing on any printable; the fridge card is signpost-only.

**Est. hours:** **~5.**

**Dependencies:** Specs 1, 2, 5.

---

## Spec 10 — AI Readiness Lab (course module; review-gated)

Fold-in of `74` (four module scripts: The AI Safety Map · Private Stays Private · Tool, Not Person · Verify Before Trust) + `53` (ten worksheets) as **fully self-serve** lessons + workbook. Per 99 §6 the course survives *only* in this mode: no cohort, no feedback, no grading, no per-customer human anything — ever.

**User story.** "I work through four self-paced lessons with my child's workbook pages printed beside me, and we finish with our Family AI Agreement."

**Acceptance criteria.**
1. Lessons authored as `content_blocks` class `module` (same publish gate, lint, `review_by`); `74`'s live-pilot framing ("pilot boundary", session voice) rewritten to self-serve voice.
2. Workbook: `53`'s ten worksheets as fillable/printable PDFs; nothing submitted anywhere; no "send us your worksheet" surface.
3. Bridges wired: Worksheet 1 ↔ Family Agreement builder AI clauses (spec 5); Worksheet 4 ↔ AI-homework generator (spec 7).
4. **Review-gated:** feature-flagged off and unsellable until the safeguarding pass explicitly covers the Lab lessons (Gate A extension or a second pass). Claim register `57` applies to every lesson claim.
5. Adult-facing only: worksheets are parent-mediated print materials; no child accounts, no child-facing screens (21 §2).
6. Packaging supports both options via entitlement flag — **£49 satellite** beside the System (99 §6 default) or bundle sweetener; decision is Ben's, not this spec's.
7. Lesson progress stored as (user_id, lesson_id, completed_at) only.

**Data touched (child-PII-free):** lesson blocks, NEW `lesson_progress`, product/entitlement flag on `purchases`. Workbook stores nothing.

**Guardrail notes.** No efficacy claims ("teaches your child to be safe with AI" banned); no authorship verdicts (Worksheet 4 is rules, not detection); same honest-claims regime as the System.

**Est. hours:** **30–40** (content exists; slicing, voice rewrite, PDFs, gating).

**Dependencies:** Spec 1 infra; its safeguarding pass; specs 5/7 bridges (optional at launch).

---

## Sprint sequence

| Sprint | Contents | Hours [INF] | Exit |
|---|---|---|---|
| **0 (parallel, editorial)** | MVP block pool (~140 blocks est. — *(v1.1)* exit is the coverage criterion, 100 §2 M1) + taxonomy + Gate A0 pre-read + evergreen fallbacks | ~110 editorial | Coverage list met, lint green |
| **1** | Spec 1 (1a–1f *(v1.1)*): engine, admin publish, logs, signpost constant; 20 persona plans QA'd | 60–80 (optimistic — re-estimate per sub-spec) | Plans assemble deterministically |
| **2** | Spec 2 (10 flows, DNS **flagged off**) + Spec 5 + Spec 9 + launch ops | ~60–75 | **→ GATE A + GATE B0** *(v1.1)* → pilot at £49 via free-quiz funnel (the £39 soft-launch figure is superseded — 100 §2) |
| **3 (early trading)** | Spec 3 digest *(v1.1: decoupled from launch — Option B; calendar claim only after **Gate B1** + minimal digest machinery)*; Spec 6 first-phone sequence | ~55–65 | Digest machinery verified; first-phone trigger live |
| **4** | Spec 4 (build + 30 cards) + Spec 7 + Spec 8 (due by month 3) | ~50–60 eng + 40 ed. | Full seven-tool bundle live; test £49 |
| **5 (post-pilot)** | DNS sub-feature ON after **Gate B legal checkpoint**; Spec 10 Lab after its safeguarding pass; long-tail blocks from live diagnostic data | 45–55 + editorial | Ladder complete |

**Ships for the pilot (Gates A + B0 passed):** Instant Plan, Guided Setup Sessions, Family Agreement builder, Printables — four "doing" tools available in week one (meets 99 §2.6's three-tools-in-week-one rule) — with the offer page promising "**first year of updates included**" and **no calendar promise** for the digest *(v1.1 — Option B, 100 §2 M4)*.
**Ships after the pilot starts:** Digest (on merit, not calendar — claim upgrades only after B1 + minimal machinery), first-phone sequence, App lookup, AI-homework generator, quarterly re-check (month 3), DNS profile (post-legal), AI Readiness Lab (post-safeguarding).
**Totals:** ~300–345 build hours + ~150 editorial — inside 99's ~350–400 founder-hour envelope. *(v1.1: Spec 1 hours pending the per-sub-spec re-estimate; M3-equivalent sprints also carry the launch-ops and B0-wiring items — see 100 §6.)*

---

## The professional-review gates *(v1.1: four — A0 and B0 added; full text in 100 §5)*

**GATE A0 — Safeguarding architecture pre-read *(v1.1; after the taxonomy draft, before bulk authoring)*.** Taxonomy; severity model; emergency/urgent handling; Don't-know handling; fallback strategy; high-risk list; blocked claims. Prevents authoring rework; does not replace Gate A.

**GATE A — Block-library safeguarding review (blocks the first sale; 21 §7.5 hard rule; satisfies file 97's non-waivable condition 5 by design-verification).**
Scope: block taxonomy and classes; assembly rules incl. Don't-know handling, the severity/interrupt layer *(v1.1)* and fallbacks; the crisis constant and its full verification chain (build test + `verifySignpost()` + `03`/`84`/`68` cross-check); the claims set and block-level lint; the 20 adversarial persona plans; setup-flow content and completion-record wording ("checked and completed", never "safe"). **Extension:** the Lab lessons (spec 10) — may run as a second pass later; the Lab stays flagged off until it passes.

**GATE B0 — Launch privacy, terms, checkout & data model *(v1.1; blocks the first sale)*.** Privacy notice (diagnostic answers, plan assemblies, account/payment metadata, setup completions, deletion, retention, lawful bases, processors, cookieless analytics); terms of sale; refund/cancellation wording incl. the digital-content cancellation acknowledgement (Consumer Contracts Regulations 2013); support mailbox + bounded support process; Stripe metadata minimisation; the enumerated data promise (100 §1.9); assembly logs classified as personal data; VAT position note. **Lifts from existing assets — `86` scaffolds, `79` support/boundary templates, audit-register F24/F25/F71 — wiring plus solicitor sign-off, not fresh invention.** Full scope in 100 §5.

**GATE B — Legal/privacy wording review (two checkpoints, one engagement).**
- *B1, privacy (blocks the digest and first-phone sequence — and the digest calendar-claim upgrade, v1.1):* the household-profile retention change — lawful basis, retention period, self-serve deletion path — added to `05_Privacy_and_Data_Notice`; PECR classification of digest/sequence as service email; the `first_phone_date` field characterised as a parent's plan date, not child data.
- *B2, DNS claims (blocks the DNS flag-on):* the fixed claims string — "filters common adult content — not a guarantee, and never monitoring; we see nothing" — plus reversibility instructions and the no-credentials/no-traffic architecture description, reviewed against ASA/CAP substantiation and the education-not-control posture that keeps the product insurable (99 §9).

No gate is waivable; all are batched fixed-cost work, consistent with the zero-per-customer-labour rule.
