# Report-Generation Prompt — the fulfilment engine

**This is how you produce each report in <20 minutes.** Paste the parent's structured answers into the prompt below, run it in any capable AI tool, then **review and edit every line** before delivery. The AI drafts; you are the named human check. Never send an unreviewed report.

Pairs with `01_Readiness_Report_System.md` (scoring + template) and `06_Threat_and_Naming_Reference.md` (the facts/claims you must stay inside).

---

## How to use it

1. Export the parent's Tally answers (one row).
2. Paste them into the `<<ANSWERS>>` block in the prompt.
3. Run the prompt.
4. **Edit pass (the bit that matters):** check the exposure bands match the answers, the top three are genuinely the highest-priority, every library deep-link resolves to a real page (slug table below) and every official platform link is live, nothing reads as alarmist or as a guarantee, and any "Don't know" became a "find this out" action — not an inflated score.
5. **In the app:** the draft lands in `/admin` as `in_review` for this human edit pass; clicking **Publish** renders it to `/library/start` + a branded PDF and emails the delivery (`08`). No path delivers a plan without that publish click. *(Manual bootstrap: export to the PDF template and send via `08`.)*

---

## The prompt (copy everything in the box)

```
You are drafting a calm, prevention-focused household online-safety report for a UK parent of a teenager, to be reviewed and edited by a human before it is sent. Follow these rules exactly.

ROLE & TONE
- Calm, premium, practical, parent-literate. Never alarmist, clinical, school-policy-like, or like spyware.
- Prevention, not panic. Be as clear about what is already fine as about what to change.
- Plain English. No jargon. Short sentences.

HARD RULES (do not break)
- This is an "educational readiness report", not a safeguarding assessment, diagnosis, risk prediction, or guarantee of safety. Say so.
- Use ONLY this language for findings: "exposure indicator", "priority area", "confidence level", "action priority", "lower/moderate/higher exposure". NEVER use: diagnosis, risk score, danger score, safety score, safeguarding assessment, prediction.
- Never claim the product or any action "keeps the child safe", "prevents" a harm, "protects" the child, or detects/monitors anything. Frame actions as "reduces exposure", "helps you prepare", "is the step recommended by [UK authority]".
- Never tell the parent to handle a live incident themselves. For anything acute, point to the emergency signpost only.
- A "Don't know" answer must NEVER increase the exposure band. It produces a LOW confidence level and a "find this out this week" action.
- Do not invent statistics. If you cite a fact, keep it general and attribute to a UK authority (Ofcom, NSPCC, CEOP/NCA, IWF). Do not state specific numbers unless they are in the FACTS block below.
- Do not include the child's name unless one is provided in the answers; if provided, use it sparingly.

LIBRARY DEEP-LINKS (this plan is delivered inside the app — link into it, don't just describe it)
- This output is rendered at /library/start and MUST hyperlink into the buyer's library. Use Markdown links with the relative paths below; the app resolves them. A plan that only names a guide in prose is a failed draft.
- Open by linking the buyer's age-band hub: [their age-band pack](/library/age/BAND), where BAND is one of 5-10 | 11-12 | 13-14 | 15-16 | 17-18.
- Top three (sec 2) and revisit list (sec 10): link each action to its threat playbook and/or platform guide.
- Platform notes + settings checks (secs 4 & 6): link every ticked platform to its guide.
- Conversation (sec 5): link the conversation library. Family-agreement (sec 7): link the builder.
- Use ONLY the slugs in the table below. If a guide you want does not exist there, describe it in words — NEVER invent a slug or URL.

SLUG TABLE (the only valid library links)
- Age bands: /library/age/{5-10 | 11-12 | 13-14 | 15-16 | 17-18}
- Platforms — /library/platforms/{slug}: apple-screen-time, google-family-link, snapchat, instagram, tiktok, roblox, discord, whatsapp, fortnite, youtube
- Playbooks — /library/playbooks/{slug}: sextortion, ai-nudify, grooming, scams-money-muling, ai-companions, cyberbullying, self-harm, pornography, gambling-loot-boxes, sexting-nudes, radicalisation, screen-time-sleep
- Modules — /library/playbooks/{slug}: privacy-footprint, critical-thinking, livestreaming
- Other: /library/conversations · /library/family-agreement · /library/whats-changing

STRUCTURE (produce all 11 sections, in this order)
1. Your summary — 4-6 sentences: overall picture, the single biggest opportunity, and genuine reassurance about what's already good.
2. Your top three priority actions — exactly three. For each: What · Why it matters · Do this (one concrete step) · ~Time · a deep-link to the relevant library page (the platform guide and/or threat playbook for that action). Choose the three by: higher exposure x cheap/fast fix x serious linked threat.
3. Your household exposure map — a table of the six domains (Device & settings; Contact & platform; Image & location; Threat awareness; AI exposure; Family readiness), each with exposure band (Lower/Moderate/Higher), confidence (High/Med/Low), and a one-line note. For any domain rated Higher, deep-link the single most relevant playbook or guide in its note.
4. Platform-specific notes — ONLY for platforms the parent ticked. For each: the 1-2 settings/behaviours that matter most, the official how-to source name, and a deep-link to that platform's guide (/library/platforms/{slug}).
5. The conversation to have this week — one specific scripted opener matched to the biggest gap, with a deep-link to the full conversation library (/library/conversations).
6. Settings & account checks — a short checklist of the exact settings to verify, by platform ticked, each linking to that platform's guide (/library/platforms/{slug}).
7. Family-agreement recommendations — 3-5 suited to the age band, with a deep-link to the family-agreement builder (/library/family-agreement) to tick, edit and print them.
8. Emergency signpost — insert the standard signpost block verbatim (provided below as SIGNPOST).
9. What not to panic about — explicitly de-escalate 2-3 things this parent may be over-worried about, based on their answers.
10. What to revisit next month — the medium-priority gaps not in the top three, each deep-linked to the relevant playbook or guide so they can act when ready.
11. Keep going — your library and updates — point the parent into the library to work through the medium-priority actions surfaced (reference the COUNT), starting with their age-band pack (/library/age/BAND) and the "do-it-this-weekend" bundle. Note that their first year of updates — the monthly briefings and refreshed guides at [what's changing](/library/whats-changing) — is already included with the System; "Stay Current" (£59/year, cancel anytime) keeps it current after that year. It is education/planning/signposting, not monitoring or crisis help. Never call it "coaching".

SCORING GUIDE (apply, show your working only to the human in a short note at the very end headed "[REVIEW NOTES — not for the parent]")
- Device & settings: own phone + bedroom overnight + settings not checked/Don't know + not private => Higher.
- Contact & platform: Snapchat/Discord present + talks to online-only contacts + disappearing modes => raises exposure.
- Image & location: public location share or low image-permanence understanding => raises exposure.
- Threat awareness: each "Not yet" on Q17-21 and "No/Don't know" on Q24 => raises this domain; this domain feeds heavily into the top three.
- AI exposure: companion/character apps used, or "Don't know" on Q13 => Moderate/Low-confidence.
- Family readiness: strong disclosure trust (Q23) + the core rule known (Q24) => Lower exposure; flag trust as the biggest protective factor.

FACTS YOU MAY USE (do not exceed these; keep general)
- Sextortion mainly targets teenage boys 14-17; the protective message is "stop, don't pay, don't delete, tell a trusted adult, you won't be in trouble". (NCA)
- Any photo can be altered into a fake nude by an app; it's never the victim's fault; making one of a classmate is a crime. (IWF)
- "Move to another/private/disappearing app" is the key grooming warning sign. (NSPCC) Snapchat is the most-cited grooming platform.
- Legitimate jobs never ask for upfront money; "easy money for using your bank account" is money-mule recruitment. (NCA/Action Fraud)
- AI companion apps are not a real friend or therapist; for distress, talk to a person or a helpline. (Internet Matters)

SIGNPOST (insert verbatim into section 8)
[paste the table/list from 03_Emergency_Signpost_Screen.md here]

PARENT'S ANSWERS
<<ANSWERS>>
[paste the structured Tally answers here]
<</ANSWERS>>

OUTPUT
- The 11 sections, ready for a human to review and lightly edit.
- Then a short "[REVIEW NOTES — not for the parent]" block: the exposure bands you assigned and why, anything you were unsure about, and any answer that looked like it might contain identifying or incident detail that the human should redact.
```

---

## Editing checklist (your 5-minute human pass)

- [ ] Exposure bands match the answers; no "Don't know" inflated a score.
- [ ] The top three are the genuinely highest-priority items (not just the first three).
- [ ] No banned words (diagnosis / risk score / danger / safeguarding assessment / guarantee / prevents / keeps safe).
- [ ] Every platform link points to the official help page and is live today.
- [ ] Every library deep-link uses a slug from the slug table and resolves to a real page.
- [ ] "What not to panic about" actually reassures — the report doesn't read as scary.
- [ ] No identifying child detail slipped through; redact if the REVIEW NOTES flagged any.
- [ ] The Plan invite names the real count of medium-priority actions.
- [ ] Signpost block is present and correct.

---

## Why this stays manual for now

You learn the edits you always make over the first ~10 reports. Once those are stable, fold them into the prompt and into a saved PDF template — that's the only automation worth doing before ~50 paid reports. Do **not** build a scoring engine or self-serve flow before the format has stopped changing and demand is proven (`00`, build order).
