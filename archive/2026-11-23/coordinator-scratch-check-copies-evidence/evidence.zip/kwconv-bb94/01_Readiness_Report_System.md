# Readiness Report System — the wedge

**The build spec for the paid product. Questionnaire → scoring → report template → production workflow.**

Design constraints carried through: minimal data, **no child-identifiable information**, no screenshots/uploads, prevention framing, signpost-only emergencies, no clinical/diagnostic language.

---

## 2.1 What the report diagnoses (exposure areas)

Each area becomes an **exposure indicator**, not a risk score. The report maps the household across:

Child age band · devices used · platforms used · social media access · messaging apps · gaming platforms · AI tools used · privacy-settings awareness · location-sharing exposure · image-sharing exposure · stranger/contact exposure · group-chat exposure · scam/phishing exposure · AI deepfake awareness · sextortion awareness · grooming/coercion awareness · AI-companion/chatbot exposure · parent–child communication readiness · existing family rules · whether the child knows what to do if threatened or blackmailed.

---

## 2.2 The questionnaire (paste straight into Tally/Typeform)

~25 questions, all structured (multiple-choice / scale), parent-answered, 5–7 minutes. **No free-text about the child, no names, no school.** One optional free-text box at the end for the parent's own worry, with a notice not to include identifying details or incident specifics.

**Section A — Household context (no child identifiers)**

1. Which age band is the child this report is about? `□ 11–12 □ 13–14 □ 15–16 □ 17–18`
2. How many children in the household use connected devices? `□ 1 □ 2 □ 3+`
3. *(Optional)* The child's first name or just an initial, if you'd like the report personalised. **You can skip this — we don't need it.** `[free text, optional]`

> Build note: Q3 is the *only* place a name could enter, it's optional, clearly skippable, and stored only for the duration of report production then deleted. Defaulting to "skip" keeps you cleanly outside child-data territory. See `05_Privacy_and_Data_Notice.md`.

**Section B — Devices & access**

4. What does the child use? *(tick all)* `□ Own smartphone □ Shared phone/tablet □ Own laptop/PC □ Games console □ Smart TV/streaming □ VR headset □ Smartwatch`
5. Where are devices mostly used? `□ Anywhere incl. bedroom overnight □ Bedroom but not overnight □ Shared family spaces only`
6. Who set up the device privacy/parental settings? `□ No one / not sure □ Came as default □ I set them up □ We set them up together`

**Section C — Platforms & messaging**

7. Which social/video platforms does the child use? *(tick all)* `□ Snapchat □ TikTok □ Instagram □ YouTube □ Discord □ BeReal □ X □ Reddit □ Other □ None that I know of`
8. Which messaging apps? *(tick all)* `□ WhatsApp □ Snapchat □ iMessage/SMS □ Instagram DMs □ Discord □ Telegram □ Signal □ In-game chat □ Don't know`
9. Does the child use disappearing/secret-message modes? `□ Yes □ No □ Don't know`
10. Are their accounts set to private/friends-only? `□ Yes, checked recently □ Think so, not checked □ No □ Don't know`

**Section D — Gaming & AI**

11. Which gaming platforms? *(tick all)* `□ Roblox □ Fortnite □ Minecraft □ Console online (PS/Xbox) □ PC/Steam □ Mobile games with chat □ None`
12. Does the child talk to people they only know online (games/apps)? `□ Regularly □ Sometimes □ Rarely □ Not that I know of □ Don't know`
13. Which AI tools does the child use? *(tick all)* `□ ChatGPT/assistants for schoolwork □ AI image generators □ AI "companion"/character chat apps □ AI built into apps they use □ None that I know of □ Don't know`
14. Have you tried the AI apps your child uses yourself? `□ Yes □ No □ N/A`

**Section E — Exposure awareness (the threat-readiness core)**

15. Location sharing — does the child share live location publicly or with non-close contacts? `□ Yes □ No □ Don't know`
16. Image sharing — how confident are you the child understands that any photo can be copied or altered? `□ Very □ Somewhat □ Not very □ Not at all/Don't know`
17. Has the household talked about **sextortion** (someone threatening to share a nude unless paid)? `□ Clearly, child knows what to do □ Briefly □ Not yet`
18. Has the household talked about **fake/AI-generated nude images** ("nudify" apps)? `□ Yes □ Briefly □ Not yet`
19. Has the household talked about **grooming / being asked to move to a private app**? `□ Yes □ Briefly □ Not yet`
20. Has the household talked about **scams** (fake tickets, jobs asking for upfront money, "money-mule" account use)? `□ Yes □ Briefly □ Not yet`
21. Has the household talked about **AI companion apps not being a real friend or therapist**? `□ Yes □ Briefly □ Not yet`

**Section F — Family readiness**

22. Do you have any agreed family rules about devices/apps? `□ Written/clear □ Informal □ None`
23. If something scary happened online, how confident are you the child would tell you? `□ Very □ Fairly □ Not very □ Unsure`
24. Does the child know the single most important rule — **if threatened or blackmailed, stop, don't pay, don't delete, tell a trusted adult**? `□ Yes □ Partly □ No/Don't know`
25. *(Optional, free text)* Anything specific you'd like this report to prioritise? **Please don't include names, your child's school, or details of any live incident — if something is happening right now, see the emergency signpost.** `[free text, optional]`

---

## 2.3 Scoring / structure — exposure indicators, not a risk score

**Language used:** *exposure indicator, priority area, confidence level, action priority.* **Never used:** diagnosis, risk prediction, safeguarding assessment, safety score, danger score.

**Model (simple, transparent, defensible):**

Group answers into **six exposure domains**, each rated **Lower / Moderate / Higher exposure** plus a **confidence level** (High/Medium/Low — Low whenever the parent answered "Don't know", which itself becomes a finding).

| Domain | Fed by questions |
|---|---|
| Device & settings exposure | 4, 5, 6, 10 |
| Contact & platform exposure | 7, 8, 9, 11, 12 |
| Image & location exposure | 15, 16 |
| Threat-awareness gaps | 17, 18, 19, 20, 21, 24 |
| AI exposure | 13, 14, 21 |
| Family-readiness | 22, 23, 24 |

**How priority is calculated (manual, rule-based — no engine in V1):**

- Each domain gets an exposure band from its answers (e.g. "own phone + bedroom overnight + settings not checked + accounts not private" → Higher exposure).
- **Action priority** = exposure band × how cheap/fast the fix is × how serious the linked threat is. A *Higher-exposure, quick-fix, serious-threat* item floats to the top three.
- A **"Don't know"** answer never inflates the score; it produces a low-confidence flag and a "find this out this week" action — honest about uncertainty rather than guessing.

**What the score can mean:** "here is where, relative to current UK guidance, your household has the most room to reduce exposure, ordered by what to do first." **What it cannot mean:** a prediction that harm will or won't happen, a clinical or safeguarding judgement, or any guarantee. The report states this in plain words.

**How uncertainty is shown:** every domain shows its confidence level; low-confidence domains are explicitly labelled "we couldn't assess this well because…", turning gaps into actions.

---

## 2.4 Finished report format (section by section)

A 6–9 page PDF, calm and premium, plenty of white space. Structure:

1. **Plain-English summary** — 4–6 sentences: the household's overall picture, the single biggest opportunity, and reassurance about what's already in good shape. No jargon, no alarm.
2. **Your top three priority actions** — the three highest-priority items, each as: *what · why it matters · do this (concrete step) · ~time it takes.*
3. **Household exposure map** — the six domains with their exposure band and confidence level, shown as a simple calm visual (not a red "danger" dial).
4. **Platform-specific notes** — for each platform the child actually uses, the 1–2 settings/behaviours that matter most, with the official how-to link.
5. **The conversation to have this week** — one specific, scripted opener matched to their biggest gap (e.g. the sextortion "if this ever happens, I will help and won't be angry" conversation).
6. **Settings & account checks** — a short checklist of the specific privacy/settings to verify, by platform.
7. **Family-agreement recommendations** — 3–5 suggested agreements suited to the age band (link to the editable template).
8. **Emergency signpost page** — the verified who-to-contact-now screen (from `03`), included in every report.
9. **What not to panic about** — explicitly de-escalates 2–3 things the parent may be over-worried about, given their answers. This section is a deliberate trust- and calm-builder.
10. **What to revisit next month** — the medium-priority backlog (the gaps not in the top three), framed as the natural on-ramp to the Plan.
11. **Invitation into the AI Safety Planner** — specific to their backlog: "your report flagged N medium-priority actions; the Family Safety Plan walks you through one a fortnight, plus a monthly briefing on what's changed."

---

## 2.5 Launch production method (lightly manual)

**Per report, target <20 minutes of founder time:**

1. Parent completes the Tally form → answers land in a row of a Google Sheet.
2. A prompt template (kept in the build folder) turns the structured answers into a first-draft report against the section template — AI-assisted drafting, *not* an automated scoring engine.
3. **Founder reviews and edits every report** — corrects the exposure bands, sanity-checks the top three, removes anything that reads as alarmist or as a guarantee, confirms platform links are live.
4. Export to PDF (templated) → deliver by the delivery email within 48h.
5. Log the report in the funnel sheet; send the feedback form 3 days later.

**Acceptable now:** lightly manual fulfilment, structured questionnaire, founder review, AI-assisted draft, human check before delivery, PDF/email delivery. **Not assumed:** automated scoring engine, user dashboard, app, account system, any child-facing workflow.

**Automate only after sales justify it, in this order:** (1) the answers→draft prompt becomes a saved template/macro once you've done ~10 reports and know the edits you always make; (2) PDF templating; (3) only after ~50+ paid reports and a stable format, consider a light self-serve scoring tool. Manual first; automation is a reward for proven demand, not a launch requirement.

---

*Pairs with `02_Sample_Readiness_Report.md` (a full worked example) and `03_Emergency_Signpost_Screen.md` (embedded as section 8 of every report).*
