# Build-Plan Audit — Master Build Spec (`21`) vs the content canon

**Audited 20 June 2026.** Method: every factual claim the spec makes about the content files (`00`–`20`) was verified against the source, the existing content was tested against the spec's own guardrail lint, and the spec was read for internal contradictions and buildability. This document records the result and the fixes applied.

---

## Verdict

**GO to build.** The spec is internally consistent and faithful to the content. Of the dozens of concrete claims it makes, nearly all verified exactly; three real gaps were found and **all three have been patched** (see §3). **Milestones M1 and M2 are fully unblocked.** The patched items unblock M3–M5.

---

## 1. What was verified (all PASS unless noted)

| # | Spec claim | Source | Result |
|---|---|---|---|
| 1 | Questionnaire = 25 structured questions, no child PII; one optional, skippable first-name field | `01` §2.2 | ✅ exactly 25; only Q3 (optional first name) |
| 2 | Plan works on six exposure domains, rated Lower/Moderate/Higher, + top-3 actions | `01`, `07` | ✅ (spec says "bands"; source says "domains" — see §4) |
| 3 | Quiz = 8 questions, additive scoring, bands good ≤4 / opportunities 5–9 / focus ≥10, no localStorage, no child PII | `10` | ✅ exact match |
| 4 | 10 platform guides | `16` | ✅ all 10 (Apple Screen Time, Google Family Link, Snapchat, Instagram, TikTok, Roblox, Discord, WhatsApp, Fortnite/Epic, YouTube) |
| 5 | 12 playbooks + 3 modules | `18` | ✅ "Core Five" + Full A–G = 12 playbooks; modules H/I/J = 3 |
| 6 | 4 age-band packs, labels `11-12 / 13-14 / 15-16 / 17-18` | `19` | ✅ exact — safe to use as a code enum |
| 7 | Conversation library + "what not to say" card | `17` | ✅ both present (15 scripts + a 7-row card) |
| 8 | Currency layer → `/library/whats-changing` + briefing backlog | `20` | ✅ ~12-topic seed backlog, monthly cadence |
| 9 | Prices £99 / founding £79 / £179 / £59-yr; tier names System / System+Setup / Stay Current | `14` | ✅ matched `14` as audited; **£179 tier since revised → "The Concierge" from £650 (see `26`)** |
| 10 | Privacy: contract + legitimate-interests bases, separate PECR opt-in, 30-day purge, no child-identifiable data | `05` | ✅ all four |
| 11 | Existing content passes the banned-phrase content lint | `00`–`21` | ✅ zero real violations; only negated disclaimers + the age-band posture term (see §3.3) |

**Non-issue flagged in passing:** the spec correctly assumes the quiz uses **no** localStorage — `10` confirms it. No conflict.

---

## 2. Internal-consistency check

- **Pricing/framing divergence is intentional and reconciled.** Execution plan `00` still carries the *old* £39 report + £7/mo Plan model; `14`/`21` carry the *premium* £99 / £59-yr model. Spec §0 rule 1 resolves it: content files win on copy, **but `14` supersedes `00` on pricing**, and `00` is internal-only (guardrails + decision gates), never a copy source. **A coding agent must not seed any price/copy from `00`.**
- Data-model enums (`child_age_band`, `quiz_responses.band`, `purchases.tier`) all match the source content. No mismatches.
- Route map (§5.2) and content-ingestion map (§8) are complete and consistent with the file set.

---

## 3. Gaps found — and the fixes applied

### 3.1 The plan-generation prompt did not deep-link into the library *(was the biggest gap)*
**Problem:** Spec §7.5 makes "deep-links into the library" the hero behaviour of the personalised plan, but `07_Report_Generation_Prompt.md` was written to produce a **self-contained standalone PDF** with no concept of library URLs.
**Fix (applied to `07`):** added a `LIBRARY DEEP-LINKS` rule block + a **canonical SLUG TABLE** (the only valid links), and rewrote structure sections 2, 3, 4, 5, 6, 7, 10, 11 to emit Markdown deep-links (age-band hub, per-platform guides, per-gap playbooks, conversation library, family-agreement builder, what's-changing). Section 11 was reframed off the dead "£7/mo Planner" onto the premium model (library + 12 months' updates included; Stay Current £59/yr to continue). Updated the use-steps to the app's draft → `/admin` review → Publish flow, and added an edit-pass check that every deep-link resolves.

> **Builder action required:** the SLUG TABLE in `07` is now the canonical slug set. **Mirror these exact slugs in the MDX frontmatter** when ingesting `16`/`18`/`19` (spec §7.6), or the plan's links will 404.

### 3.2 Two lifecycle emails referenced by the spec did not exist
**Problem:** Spec §7.8 needs a **library-onboarding (+7d)** email and a **Stay Current renewal (month-11)** email; `08` had neither, and its email 5 was a stale "£7/month or £70/year" Plan upsell.
**Fix (applied to `08`):** reframed email 5 into **Library onboarding** ("your plan's done — here's everything else that's included; your first year of updates is part of what you paid"), added **email 6 — Stay Current renewal** (£59/yr, fires ~30 days before `updates_until`), renumbered Refund to email 7, and updated the header/placeholder list (`[LIBRARY LINK]`, `[RENEWAL LINK]`, `[FEEDBACK LINK]`).

### 3.3 The content lint, as specified, would have false-failed CI on day one
**Problem:** §10.3 said "grep … → fail on a non-negated match," but a plain grep has **no concept of negation**. The *required* "what this isn't" disclaimers ("…or a guarantee of safety" in `04`/`10`; "does **not** monitor children or guarantee safety") contain banned substrings and would have broken the build immediately.
**Fix (applied to `21` §10.3):** rewrote the lint as **negation-aware** — sentence-level negation-marker exemption + a checked-in `content-lint.allow.json` allow-list, with `coach` permitted only as the age-band parenting-posture term (`coaching` as service framing never exempt). Documented that current content PASSES and a naive grep would FALSE-FAIL.

---

## 4. Recommended follow-up patches (NOT done — scope was the three gaps above)

Listed in priority order so the founder can greenlight:

1. ~~Emails 1–4 still use the singular-"report"/PDF framing~~ **DONE (20 Jun 2026).** Emails 1–4 in `08` reframed to the premium "plan + library" model, and the **magic-link** added to email 1 (spec §7.3). *(In a no-code launch, swap the magic link for the gated-library share link — see `24` §A.)*
2. **Vocabulary discipline in code.** Keep the two banding systems distinct: the plan's **six exposure *domains*** (each Lower/Moderate/Higher) vs the quiz's **three result *bands*** (good/opportunities/focus). The spec uses "bands" for both in prose — don't collapse them in the schema.
3. **Preserve `18`'s grouping in MDX** ("Core Five" + "Full A–G" + "Modules H–J") so the library can surface the core threats first.
4. **Open founder decisions** (spec §14, not code-blockers): final brand + domain, final Stripe price point, and solicitor sign-off on marketing copy + disclaimer + ToS + OSA-scope confirmation before go-live.

---

## 5. Build-readiness by milestone

| Milestone | Status | Notes |
|---|---|---|
| **M1 — Shell & top-of-funnel** | ✅ unblocked | All source content present and verified; lint will pass |
| **M2 — Pay & gate** | ✅ unblocked | Prices/tiers confirmed; age-band enum confirmed; slug table now defined |
| **M3 — Diagnose & deliver** | ✅ unblocked by this audit | `07` now deep-links; emails 5/6 exist. Do follow-up #1 (magic-link in email 1) first |
| **M4 — Retain & expand** | ✅ unblocked | Renewal email + briefing backlog ready |
| **M5 — Instrument & harden** | ✅ unblocked | Lint is now implementable (negation-aware spec); compliance checklist intact |

---

## 6. Files changed / added by this audit
- `07_Report_Generation_Prompt.md` — library deep-linking + premium-model reframe (gap 3.1)
- `08_Email_Templates.md` — library-onboarding + renewal emails (gap 3.2); emails 1–4 reframed to plan+library + magic link (follow-up #1)
- `21_MASTER_BUILD_SPEC.md` — §10.3 negation-aware content lint (gap 3.3)
- `22_Build_Plan_Audit.md` — this document
- `23_Landing_Page_v2.html` — premium-framed landing page (supersedes the £39 `04`); passes the content lint
- `24_NoCode_Launch_Runbook.md` — lean no-code path to first sales + compliance gate + when-to-graduate
- `05_Privacy_and_Data_Notice.html` — hostable parent-facing privacy page (from `05` Part 2)
- `terms.html` — Terms of Service **placeholder skeleton** for solicitor review (spec §9 / `00` §10)
