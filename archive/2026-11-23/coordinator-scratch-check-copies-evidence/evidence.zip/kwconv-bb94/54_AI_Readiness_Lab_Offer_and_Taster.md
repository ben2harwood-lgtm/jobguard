# AI Readiness Lab for Families - Offer Copy and School Taster

*Draft 1.0. Created 24 June 2026. Use after review with `51`, `52`, and `53`.*

## 1. Parent Offer Page

### Page Purpose

Sell a calm, practical AI course for parents who want to understand what their child is doing with AI and set household rules that can actually be used.

### Hero

**AI Readiness Lab for Families**

Help your child use AI with better judgement.

A four-part parent course on AI homework, prompts, privacy, deepfakes, companion apps, and small supervised projects. Built for parents who do not want to chase every new tool, but do want clear family rules and better conversations.

**CTA:** Join the next parent lab

Secondary CTA: See what is covered

### The Problem

AI has arrived in family life before most families have agreed what counts as sensible use.

Children are using AI for schoolwork, revision, images, coding, chat, and creative projects. Some of that is useful. Some of it is unreliable. Some of it raises real questions about privacy, school rules, synthetic media, and emotional dependence.

Most parents do not need a technical course. They need orientation: what matters, what to ignore, what to ask, and where to put a human check.

### What This Is

AI Readiness Lab is a parent-first course. You learn the concepts, then use short optional family activities to turn them into household rules.

You will build:

- A family AI agreement.
- A prompt card that supports learning rather than substitution.
- A schoolwork rule for homework and assessment.
- A synthetic-media rule for image, video, and voice tools.
- A source-checking habit.
- A small project canvas for one supervised AI project.
- A monthly reset habit for new tools.

### What This Is Not

This is not a coding bootcamp.

It is not monitoring software.

It does not create child accounts.

It does not ask for child-identifiable data.

It is not a school policy or legal advice.

It does not handle urgent online incidents. If something is happening now, use the emergency signpost.

### Who It Is For

Best fit for parents of children aged 11-16.

Also useful if:

- Your 9-11-year-old is beginning to ask about AI tools.
- Your older teen is using AI for revision, research, writing, or coding.
- Your school has mentioned AI but the family rules are still vague.
- You are worried about AI homework but do not want every conversation to become an accusation.
- You want a small supervised project that teaches judgement, not just tool use.

### The Four Sessions

**1. The AI Map And The Household Rules**

Understand chatbots, generative AI, assistants, agents, and automation. Draft your first family AI agreement.

**2. Prompting As Clear Thinking**

Learn a prompt pattern that asks for hints, questions, explanations, and feedback without hiding the child's thinking.

**3. Schoolwork, Creativity, And Synthetic Media**

Set rules for homework, acknowledgement, source-checking, AI images, deepfakes, voice tools, and consent.

**4. Small Projects, Agents, And Human Review**

Choose one small project and map the goal, data, steps, review points, and stop conditions before using a tool.

### Included Materials

- Four parent lessons.
- Parent workbook.
- Family AI Agreement.
- Prompt card.
- Schoolwork ladder.
- Source-check sheet.
- Synthetic-media rules.
- Small project canvas.
- Project review checklist.
- Next-month reset sheet.

### Parent Promise

You will leave with a clearer map of AI in family life, a practical household agreement, and a way to help your child use AI without handing over the thinking.

### Proof Points To Add Later

Only add these after real delivery:

- Parent feedback.
- Completion numbers.
- Common questions answered.
- Screenshots of anonymised worksheets with all family detail removed.

Do not invent testimonials or quantified outcomes.

### FAQ

**Do I need to be technical?**

No. The course is designed for parents who want plain-English judgement, not a technical deep dive.

**Will children attend the sessions?**

The first version is parent-facing. Each session includes an optional family activity you can do at home.

**Will my child need their own AI account?**

No. The course is designed so parents can use their own accounts, paper prototypes, or tool-free examples.

**Which AI tools do you teach?**

The course is tool-agnostic. Examples can be adapted to the tools families already meet, but the main skill is knowing what to ask, what not to enter, and what to check.

**Does this replace school rules?**

No. School policy comes first for homework, coursework, and assessments. The course helps families ask better questions and set household expectations.

**What if I am worried something serious has happened?**

Use the Bearings emergency signpost or the appropriate authority. This course is education and planning, not incident support.

## 2. Pricing Options

### Recorded Add-On

**AI Readiness Lab recording + workbook**

Indicative price: GBP 49 founding (GBP 59-79 later).

Best use: add to The System once the core product is live.

### Live Parent Cohort

**Four weekly parent sessions + workbook**

Indicative price: GBP 99-129 beta (GBP 149-199 later).

Best use: test willingness to pay and collect real questions before producing polished recordings.

### School/PTA Parent Evening

**One live parent taster + take-home workbook sample**

Indicative price: GBP 300-750.

Best use: warm school/PTA introductions.

## 3. School/PTA Taster Session

### Title

AI At Home: Homework, Privacy, Deepfakes, And The Family Rules Parents Need Now

### Format

60 minutes live or recorded for parents/carers.

No child data collected. No child participation required. No school systems accessed.

### Session Promise

Parents leave with a plain-English AI map, a schoolwork ladder, and the first clauses of a family AI agreement.

### Agenda

| Time | Segment | Detail |
|---|---|---|
| 0-5 | Welcome | Set the tone: useful, calm, not technical. |
| 5-12 | The AI map | Chatbots, generative AI, assistants, agents, automation. |
| 12-22 | What parents should know | Inaccuracy, privacy, schoolwork, synthetic media, companion-style tools. |
| 22-32 | Homework boundaries | Help versus substitution. School policy first. |
| 32-42 | Private stays private | What not to enter into AI tools. |
| 42-50 | Synthetic media | Images, voice, consent, and what to say at home. |
| 50-56 | Family AI agreement | Parents draft three clauses. |
| 56-60 | Close | Where to go next, emergency signpost, optional full course. |

### Take-Home Handout

One A4 page:

- The schoolwork ladder.
- The private-data rule.
- Three family AI agreement clauses.
- One prompt pattern.
- Emergency signpost link.

### School Boundary Slide

This session is parent education. It does not replace the school's safeguarding lead, homework policy, malpractice policy, or assessment rules. Families should follow the school's current guidance on AI use in homework, coursework, and assessments.

## 4. School Outreach Email

**Subject:** Calm AI guidance for your parent community

Hi [NAME],

I run Bearings, a parent-facing digital-readiness service. We are developing a calm AI session for parents on the questions schools are now hearing at home: AI homework, privacy, deepfakes, companion-style tools, and what family rules should look like.

The session is practical rather than technical. Parents leave with a plain-English AI map, a schoolwork ladder, and the first version of a family AI agreement. It does not involve pupils directly, does not collect child data, and does not replace your safeguarding or assessment policies.

Would it be useful for me to send the one-page outline for [School]'s PTA or parent newsletter?

Best,

[NAME]

## 5. Parent Newsletter Blurb

**AI at home: a calm parent session**

Many families are now trying to work out what to do about AI tools: when they help with learning, when they cross a homework line, what not to put into them, and how to talk about AI images, voice tools, and online trust.

Bearings is offering a practical parent session on AI at home. It is not a coding course and does not involve children directly. Parents will leave with a simple AI map, a schoolwork ladder, and starter clauses for a family AI agreement.

[DATE / LINK]

## 6. Post-Purchase Email

**Subject:** Your AI Readiness Lab is ready

Hi [FIRST NAME],

Thanks for joining AI Readiness Lab.

Start with session 1 and the parent workbook. You do not need to be technical, and you do not need to create any child accounts. The course is built around plain-English judgement: what AI can help with, what stays private, when school rules matter, and where a human check belongs.

Before you begin, one simple rule: please do not enter your child's name, school, private messages, images, health details, account details, or any live concern into an AI tool or workbook activity.

Start here: [COURSE LINK]

Emergency signpost: [LINK]

Best,

[NAME]

## 7. Conversion Notes

Lead with parent relief:

- "I finally know what to say."
- "I know what counts as help versus doing it for them."
- "I know what we do not put into AI tools."
- "We have a family rule now."

Do not lead with:

- Career certainty.
- Earnings claims.
- "AI natives."
- Tool lists.
- Competitive pressure between children.
- Fear of being left behind.

## 8. Delivery Notes

Before launch:

- Check the current DfE AI education page.
- Check the current JCQ assessment guidance.
- Check the current age restrictions and data settings of any tool used in a demo.
- Ask a school contact to review the homework/assessment wording.
- Run content lint.
- Run a separate guardrail pass if any child-facing version is proposed.
