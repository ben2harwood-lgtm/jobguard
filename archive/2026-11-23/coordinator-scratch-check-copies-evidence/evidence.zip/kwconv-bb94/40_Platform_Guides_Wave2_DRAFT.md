# Platform Guides — Wave 2 (DRAFTS)

> These are unreviewed first drafts produced 2026-06-21. Every setting path, figure and link is marked for fact-check before publishing.


---

## Broadband & home network filters

**DRAFT — fact-check every setting path, figure and link against the live source before publishing.**

Last drafted: 2026-06

Most online-safety advice starts with the phone in your child's hand. This guide starts one step further back — at the router on the shelf and the SIM in the phone. A whole-home broadband filter is the one control that applies to *every* device on your Wi-Fi at once: the new tablet, the games console, the visiting cousin's phone, the smart TV. It is free with every major UK provider, it takes about ten minutes, and it is the quietest layer you have. It is also only one layer — and the second half of this guide explains why the device layer still matters just as much.

**Honest caveat (the same one we keep on every guide):** *Provider websites and apps get redesigned often. If a menu name below doesn't match your screen, search the feature name on the provider's help site or use the official link. All paths checked June 2026.* Confidence: `[V]` verified to a reputable or official source · `[verify]` re-check before relying.

---

## Before you start: two things worth understanding

**A network filter blocks *sites*, not *apps*.** Your router can see which websites a device asks for, so it can block adult and other flagged categories of site. It cannot see *inside* an app — it can't tell a router to filter mature content within YouTube, a game's chat, or a streaming service, because the router only sees an encrypted connection to "youtube.com". That gap is exactly why you also need the device layer (Apple Screen Time / Google Family Link) and the app's own controls. The three layers each cover a different part of the picture; none of them covers all of it. `[V]`

**The filter only works on your home Wi-Fi.** The moment a phone leaves the house and switches to mobile data — or hops onto a friend's Wi-Fi, or café Wi-Fi — your broadband filter no longer applies. That's the other half of the answer to "why both": broadband filters cover everything *at home*; the device layer and mobile-network filter travel *with the child*. `[V]`

A short way to hold it in mind: **network filters cover the place; device controls cover the person.** You want both.

---

## Do this first, in this order

1. **Switch on your broadband provider's filter** (below) — covers every device on your home Wi-Fi.
2. **Check the mobile-network filter** on each child's SIM — covers the phone when it's off your Wi-Fi.
3. **Set the device layer** — Apple Screen Time or Google Family Link (see our separate device guide). This is the backstop that works even when a filter is bypassed.

The broadband filter is the fastest win because it's one switch for the whole house. Treat it as the floor, not the finish.

---

## 1. BT Broadband — BT Parental Controls

**What it is:** a free, router-level filter for BT Broadband customers. No software to install; it applies to every device on the home connection. For new BT customers it is **on by default**, and you're prompted to pick a filter level at setup. `[V]`

**Turn it on:** sign in to **My BT** → **Manage your extras** (or the security/Parental Controls section) → switch **Parental Controls** to **On**. `[verify exact menu label]`

**The three levels:**
- **Light** — blocks the core adult categories (pornography, "obscene and tasteless" content, hate and self-harm, drugs/alcohol/tobacco, dating). `[V]`
- **Moderate** — Light *plus* nudity, weapons and violence, gambling and social networking. `[V]`
- **Strict** — Moderate *plus* fashion and beauty, file-sharing, games and media streaming. `[V]`

**Worth knowing:** filters can take **up to a couple of hours** to take full effect after you switch them on — check rather than assume. You can also set "homework time" schedules and add your own allow/block exceptions. `[verify scheduling feature still offered]`

**Official:** bt.com/help/security/parental-controls

---

## 2. Sky Broadband — Sky Broadband Shield

**What it is:** a free network-level filter for Sky Broadband customers (**Sky Broadband Shield**), set from your Sky account and protected by a PIN. A separate paid app, **Sky Broadband Buddy**, adds per-device controls but requires the **Sky Broadband Boost** add-on — it is not the free filter. `[V]`

**Turn it on / check it:** sign in to your **Sky account** → **Broadband** → **Sky Broadband Shield** → choose a rating and set a PIN. `[verify exact path]`

**The three age ratings:**
- **Suitable for all ages (PG)** — blocks anything not suitable for everyone. `[V]`
- **Suitable for teens (13)** — blocks content unsuitable for teens; younger-child material may still show. `[V]`
- **Suitable for adults (18)** — blocks only adult content. `[V]`
- **Custom** — pick categories yourself (e.g. dating, drugs, file-sharing/hacking, online games, pornography, suicide/self-harm, weapons/violence/hate, phishing/malware). `[V]`

**Worth knowing:** Shield also offers a **Watershed** option that automatically tightens to the all-ages level during the day and relaxes in the evening. `[verify Watershed still offered]` Set a PIN your child doesn't know, or the rating can simply be changed back.

**Official:** sky.com (search "Sky Broadband Shield")

---

## 3. Virgin Media — Web Safe

**What it is:** a free network-level content filter for Virgin Media broadband, set in your online account and PIN-protected. It applies to every device on the home connection. `[V]`

**Turn it on:** sign in to **My Virgin Media** → **My Settings** → **Web Safe** → toggle on, choose a level, and set a security PIN. `[verify exact path]`

**The levels (two parts):**
- **Child Safe / Kid Safe** — blocks adult content plus categories likely to be harmful to children (e.g. gambling, violence, hate). The recommended family setting. `[V]` `[verify current label — "Child Safe" vs "Kid Safe"]`
- **No Adult / Virus Safe** — *No Adult* blocks adult and pornographic sites only; *Virus Safe* blocks known malware and phishing sites. `[V]`

You can also manually block or allow individual sites under **Manage blocked and allowed sites**. `[V]`

**Worth knowing:** changes take effect across the network within a few minutes. Your Hub must be in **router mode** (not modem mode) for Web Safe to work. `[V]`

**Official:** virginmedia.com/help/security/parental-controls

---

## 4. TalkTalk — HomeSafe (KidSafe)

**What it is:** TalkTalk's free network-level filter, **HomeSafe**, set in your online account. The family component is **KidSafe**, which blocks chosen categories of site for everyone on the connection. `[V]`

**Turn it on:** sign in to **My Account** → **My Security Settings** → **HomeSafe** → switch **On** (green = active) → tick **On** under **KidSafe** → choose the categories to block → **Save changes** (the save step is easy to miss). `[V]`

**What KidSafe covers:** around nine category groups — including dating, drugs/alcohol/tobacco, gambling, pornography, suicide/self-harm, weapons/violence, plus file-sharing, games and social networking — that you can block individually or all at once. `[V]`

**Worth knowing:** HomeSafe also includes **Virus Alerts** and a **Homework Time** scheduler that pauses access to distracting categories during set hours. `[verify Homework Time still offered]` Changes take a few minutes to apply.

**Official:** help-centre.talktalk.co.uk (search "HomeSafe")

---

## 5. Mobile-network filters (EE, O2, Vodafone, Three and their sub-brands)

This is the layer most parents forget — and the one that matters once the phone leaves the house.

**What it is:** under a long-standing UK code of practice, the mobile networks apply a **content-control filter** that blocks websites rated **18+ by the BBFC** (British Board of Film Classification) over mobile data. On most networks this filter is **on by default** and can only be removed by an account holder who has **proved they are 18 or over**. `[V]`

**What to do:**
- **Confirm the filter is on** for your child's number. On many networks a Pay Monthly contract is age-checked, so adult content may already be blocked; on **Pay As You Go** the bar is typically on by default until age is verified. `[V]`
- **Check it in the network's app or account** — look for "Content Lock", "Content Control", "Adult content bar", "Age-restricted content" or similar in the network's safety/parental settings. Names differ by network. `[verify exact feature name per network: EE/BT Mobile, O2, Vodafone, Three]`
- **Remember its limits:** the mobile filter is broad-brush — it blocks flagged *sites* over *mobile data only*. It does not filter content inside apps, and it does nothing when the phone is on Wi-Fi (that's the broadband filter's job). `[V]`

**Official help pages:** each network publishes its own — e.g. o2.co.uk (search "age-restricted content"), three.co.uk (search "blocking and unblocking 18+ content"), plus EE/BT Mobile and Vodafone equivalents. Internet Matters keeps plain-English guides for all four. `[verify links current]`

---

## Why network *and* device, together

It's worth saying plainly, because it's the question that comes up most:

- **A broadband filter** covers every device in the house at once, including ones with no parental controls of their own (consoles, smart TVs, a guest's tablet). But it **stops at your front door** and **can't see inside apps**. `[V]`
- **The device layer** (Screen Time / Family Link) travels with the child, manages screen time and downloads, and can filter at the app and account level. But it only covers *that* device, and a determined teen has more routes around a single phone than around the whole network. `[V]`
- **The mobile-network filter** fills the specific gap of "phone, on mobile data, away from home" — but only for flagged websites, not apps. `[V]`

No single layer is complete, and none of this is a guarantee. Filters reduce the chance of stumbling onto adult sites; they are not a substitute for the device layer, the apps' own settings, or — the part no setting replaces — an ongoing conversation. Internet Matters frames it the same way: **network first, then devices, then apps**, each covering a different part of your home. `[V]`

---

## If something goes wrong

Filters are about everyday prevention, not emergencies. If your child has seen something that has frightened or upset them, or if you're worried about contact from an adult:

- In immediate danger, call **999**.
- Report concerns about online sexual abuse or grooming to **CEOP** (the National Crime Agency's Child Exploitation and Online Protection command) at **ceop.police.uk/ceop-reporting/**.
- To get a nude image of an under-18 reviewed for removal, use **Report Remove**, run by Childline and the Internet Watch Foundation: **childline.org.uk/info-advice/bullying-abuse-safety/online-mobile-safety/remove-nude-image-shared-online**.
- For advice and support, call the **NSPCC helpline on 0808 800 5000**, or **Childline on 0800 1111** (free, for children).

---

## A note on keeping this current

UK rules are still tightening — from 25 July 2025, services likely to be accessed by children must apply highly effective age assurance and the Protection of Children duties under Ofcom's Children's Codes, and provider settings, labels and default behaviours are shifting alongside them. The categories and steps above are right as far as we can verify in June 2026, but **menu names and default settings change**. A ten-minute re-check of your broadband and mobile filters once a term is the habit worth keeping. `[verify against live provider pages before publishing]`

---

## Sources

- Ofcom — *Online Safety Act guidance and age-assurance rules*: ofcom.org.uk/online-safety
- Internet Matters — *Broadband & mobile parental controls hub* (BT, Sky, Virgin Media, TalkTalk, O2, Three and others): internetmatters.org/parental-controls/broadband-mobile
- BT — *Parental controls (Broadband)*: bt.com/help/security/parental-controls
- Sky — *Sky Broadband Shield* help: sky.com (search "Sky Broadband Shield")
- Virgin Media — *Parental controls / Web Safe*: virginmedia.com/help/security/parental-controls
- TalkTalk — *How to use HomeSafe*: help-centre.talktalk.co.uk (search "HomeSafe")
- O2 — *Age-restricted content and age verification*: o2.co.uk/help/safety-and-security
- Three — *Accessing and blocking adult content*: three.co.uk/support
- BBFC — *Mobile network content classification framework*: bbfc.co.uk
- NSPCC — *Online safety advice and helpline (0808 800 5000)*: nspcc.org.uk
- CEOP (National Crime Agency) — *report child sexual abuse and grooming*: ceop.police.uk/ceop-reporting/
- Childline / Internet Watch Foundation — *Report Remove*: childline.org.uk

*All links and figures to be confirmed against the live source before publishing.*


---

## Games consoles — PlayStation, Xbox, Nintendo Switch

**DRAFT — fact-check every setting path, figure and link against the live source before publishing.**

Last drafted: 2026-06

A companion to the Platform Settings Library, covering the three consoles most UK families own: **PlayStation (PS5/PS4), Xbox (Series X|S, One) and Nintendo Switch (Switch 2 and the original Switch)**. The four controls that matter most are the same on every console — a **family/child account**, **spending limits**, **chat and messaging controls**, and **screen-time limits plus age ratings**. Set each one once and you cover the bulk of what parents tell us they worry about with consoles: surprise charges, voice chat with strangers, and play running late.

**Honest caveat to keep on every guide:** *Menus move. Console makers rename and relocate settings often — if a path below doesn't match your screen, search the setting name on the console or use the official help link. All paths checked June 2026.* Confidence: `[V]` verified to official source · `[PV]` partly verified · `[NV]` re-check before relying.

**Three things to understand before you start:**

- **The phone app is where the real management happens.** All three makers now have a free companion app — **PlayStation Family / PlayStation App**, **Xbox Family Settings**, and **Nintendo Switch Parental Controls** — that lets you set limits, approve requests and see activity reports from your own phone without picking up the controller. Set up on the console, then manage from the app. `[V]`
- **Age accuracy is the linchpin — same as on social apps.** Almost every protection keys off the child's date of birth on their account, and the family/child account type is what unlocks the controls. A child account that's been set up as an adult has very few of these protections available. `[V]`
- **Activity reports show "who" and "how long," not "what."** The weekly/monthly reports show which games were played, for how long, and (where chat is on) who they played with — they are not a transcript of conversations or a screen recording. Use them to notice patterns and start conversations, not as surveillance. `[V]`

**Do this first, in this order** (highest leverage first): **1) create the child account inside your family group → 2) set the monthly spending limit → 3) set chat/communication to the level you're comfortable with → 4) set screen time and confirm the age-rating ceiling.** Lock everything behind a PIN or your account password that your child doesn't know.

> **A note on cross-play and accounts:** many games (Fortnite, Minecraft, Roblox, EA and Activision titles) run their own account and chat system on top of the console's. Console controls govern the console; the game's own parental controls (Epic, Microsoft, Roblox) still need setting separately. See the relevant guides in the Platform Settings Library. `[V]` `[verify against current Roblox controls, changed 2026 — Roblox launched new Kids (5–8) and Select (9–15) account types with age estimation and expanded controls in April–June 2026]`

---

## 1. PlayStation (PS5 / PS4)

**What it is — Family Management.** You are the **family manager** (or you nominate another adult as a guardian). You add your child as a family member with a child account, then set parental controls per child. Most settings can also be managed remotely from the **PlayStation App / PlayStation Family** on your phone — manage play time, approve "ask" requests, view activity and adjust most controls. `[V]`

**Set up:** create the family and add your child first (Account Management), then **Settings → Family and Parental Controls → Family Management → [your child]**. `[V]`

**Check these (Settings → Family and Parental Controls → Family Management → [child] → Parental Controls):**
- **Monthly spending limit** — set the cap for PlayStation Store purchases. **It defaults to 0**, so you have to raise it deliberately. Funds come from the family manager's wallet, so don't pre-load the wallet if you want the limit to bite. In-game spending is set inside individual games, not here. `[V]`
- **Communication and user-generated content** — choosing **Restrict** turns off sending text messages, voice chat, and viewing/sharing user-made content (messages, images). Your child can send an exception request for a specific game, which you approve. `[V]`
- **Age level for games / Blu-ray / DVD** — set the PEGI age ceiling for games and disc content; titles above it are blocked or need approval. `[V]`
- **Web browsing** — restrict or allow the console's browser. `[PV]`
- **PS VR2 / VR** — VR is not recommended for under-12s and can be restricted here. `[V]`

**Play time (Settings → Family and Parental Controls → Family Management → [child] → Playtime Settings):** set daily duration limits and a time zone, choose what happens when time's up (notify, or log the child out), and set permitted hours. You can grant more time on the fly from the app. `[V]`

**Age:** an adult account is 18+; under-18s use a child account inside your family. The age you enter sets the default PEGI ceiling. `[V]`
**Official:** playstation.com/en-gb/support/account/ps5-parental-controls-spending-limits/ · the PlayStation App / PlayStation Family (App Store / Google Play).

---

## 2. Xbox (Series X|S, Xbox One)

**What it is — Microsoft family group + Xbox Family Settings app.** Add your child to your Microsoft family group, then manage almost everything from the **Xbox Family Settings** phone app: screen-time schedules, spending, friends/communication, content filters and activity reports. The same family group also governs Windows PCs the child signs into. `[V]`

**Set up:** create or open your family group (account.microsoft.com/family or the app) and add your child, then install **Xbox Family Settings** and sign in as the organiser. `[V]` *(verify exact in-app labels)*

**Check these (Xbox Family Settings app → select child):**
- **Screen time** — build a schedule per child, with different hours for each day of the week; pause play instantly when needed, and revoke a time extension you've granted. When time is up the child sees a "your screen time is up" message until you allow more. `[V]`
- **Spending / Ask to buy** — with **Ask to buy** on, you get an in-app request to approve before any purchase goes through. You can review recent spending and add a set amount of money to the child's account as an allowance rather than sharing a card. `[V]`
- **Content filters / age ratings** — set the maturity level for games, apps and websites by your child's age, so titles above the PEGI ceiling are blocked or need approval. `[V]` *(verify in-app path)*
- **Friends and communication** — see who your child follows/friends, require **"ask a parent"** to add a friend, and choose how they can play and chat with the wider Xbox community (e.g. friends only vs everyone). Newer "follow" relationships have their own granular settings. `[V]`
- **Activity reports** — daily and weekly reports of time spent and games played. `[V]`

**Age:** child accounts in the family group get protective defaults; the age set on the account drives the content ceiling. Teens approaching adulthood gain more self-management. `[PV]`
**Official:** xbox.com/family-hub · support.xbox.com (Xbox Family Settings app) · the Xbox Family Settings app (App Store / Google Play).

---

## 3. Nintendo Switch (Switch 2 and original Switch)

**What it is — Nintendo Switch Parental Controls app + Nintendo Account family group.** The free **Nintendo Switch Parental Controls** app links to the console and handles play time, age-rating restrictions, communication and activity reports. **Spending limits sit in the separate Nintendo Account family group**, not the parental-controls app — a common point of confusion. `[V]`

**Set up:** install the app, link it to the console, then open **Parental Controls** (lower-right of the app) and set a **4–8 digit PIN** your child doesn't know. `[V]`

**Check these (Parental Controls app):**
- **Restriction level** — pick a preset by age (Teen / Child / Young Child) or choose **Custom** to set each control yourself. Lower presets restrict communication and social posting and disable VR. `[V]`
- **Restrict software by age rating** — set the PEGI ceiling; you can also use a **"safelist"** to exempt specific games from restriction while still applying play-time limits. `[V]`
- **Play time** — daily limits (up to several hours), per-day settings, a bedtime/alarm time, and an option to **suspend software** automatically when the limit is reached. `[V]`
- **Communication / social posting** — restrict who your child can communicate with and turn off posting to social networks. `[V]`
- **GameChat (Switch 2)** — voice/video chat across games. A parent must be involved in setting it up and using it for players **under 16** and for any supervised account; parents can review chat history (who they played with, for how long, and the camera's field-of-view setting), but this is **metadata, not a recording of the conversation**. Confirm the exact GameChat controls on your console. `[PV]`

**Spending (Nintendo Account → Family Group):** open the family group, select the child's account and enable **Spending Restrictions** — purchases on the Nintendo eShop and nintendo.com then require the parent account password. `[V]`

**Age:** the age on the child's Nintendo Account sets defaults; younger presets disable VR and social features. `[V]`
**Official:** nintendo.com/en-gb/Support/Parental-Controls/ · accounts.nintendo.com (family group) · the Nintendo Switch Parental Controls app (App Store / Google Play).

---

## Cross-cutting notes (put these in the parent's plan)

- **PEGI is your shared language.** All three consoles rate games using **PEGI** (the UK system). Set the age ceiling once on each console and most over-age titles are blocked or need your approval — but PEGI rates *game content*, not whether a game has open chat with strangers, so still set communication separately. `[V]`
- **Spending is the most common surprise.** Set the monthly limit and, where possible, don't share a saved card or pre-load a wallet — use the "ask to buy"/password-on-purchase flow instead. In-game purchases (V-Bucks, Robux, FIFA/EA points) often need limiting **inside the game** as well. `[V]`
- **Voice chat is the most common worry.** "Friends only" is the middle setting most families land on; "no communication" is the strictest. Decide per child, and revisit as they get older. `[V]`
- **Headsets and second screens.** A child can sometimes chat via a phone app for the same game even with console chat off — the game's own controls (and the device layer, Apple Screen Time or Google Family Link) are the backstop. `[V]`
- **Re-check after big updates.** Consoles ship feature updates regularly (the Switch 2 GameChat controls and Xbox's follow/friend settings are recent examples). A 10-minute re-check each school term keeps things current — this is exactly what the *Stay Current* membership automates.

*Items most likely to have moved since June 2026 and worth re-verifying on the console or official help page: the Xbox Family Settings in-app labels and content-filter path, Switch 2 GameChat parental controls, PS5 playtime exception/approval flow, and the exact wording of each spending-limit screen.* `[PV]`/`[NV]`

---

## If something has already gone wrong

These guides are for setting things up calmly in advance. If your child has seen something upsetting, been contacted by someone who worries you, or money has been taken, you don't need to handle it alone:

- **In an emergency, or if a child is in immediate danger — call 999.**
- **Report concerns about an adult's contact with a child to CEOP** (the National Crime Agency's child protection command): ceop.police.uk.
- **To report a nude image of an under-18 and ask to have it removed, use Report Remove** (Childline with the IWF): childline.org.uk/info-advice/bullying-abuse-safety/online-mobile-safety/remove-nude-image-shared-online/.
- **For advice, the NSPCC helpline is 0808 800 5000.**
- **Children and young people can talk to Childline free on 0800 1111.**

---

## Sources

- PlayStation — *Parental controls and spending limits (PS5)*: https://www.playstation.com/en-gb/support/account/ps5-parental-controls-spending-limits/
- Xbox — *Xbox Family Settings app* and *Family hub*: https://www.xbox.com/en-GB/apps/family-settings-app · https://www.xbox.com/en-US/family-hub
- Xbox Support — *Manage a member's content in the Xbox Family Settings app*: https://support.xbox.com/en-US/help/family-online-safety/family-settings-app/manage-child-content-in-the-Xbox-Family-Setting-app
- Nintendo UK — *How to set up, adjust or remove Parental Controls on Nintendo Switch*: https://www.nintendo.com/en-gb/Support/Parental-Controls/How-to-Set-Up-Adjust-or-Remove-Parental-Controls-on-Nintendo-Switch-1494771.html
- Nintendo — *Parental Controls app* and *GameChat parental-controls guide*: https://www.nintendo.com/us/mobile-apps/parental-controls/ · https://en-americas-support.nintendo.com/app/answers/detail/a_id/68384/
- Internet Matters — *PlayStation 5 (PS5) parental controls* (gaming consoles hub): https://www.internetmatters.org/parental-controls/gaming-consoles/playstation-5-ps5/
- ESRB — *Parental controls: PlayStation 5* and *Nintendo Switch* (PEGI is the equivalent UK ratings system): https://www.esrb.org/tools-for-parents/parental-controls/playstation-5/ · https://www.esrb.org/tools-for-parents/parental-controls/nintendo-switch/
- PEGI — age ratings (the UK system used on console games): https://pegi.info/
- Ofcom — *Children and parents: media use and attitudes* (context on gaming and chat): https://www.ofcom.org.uk/research-and-data/media-literacy-research
- CEOP / NSPCC / Childline — reporting and advice routes: https://www.ceop.police.uk/ · https://www.nspcc.org.uk/ · https://www.childline.org.uk/


---

## Minecraft — Platform Settings Guide

**DRAFT — fact-check every setting path, figure and link against the live source before publishing.**

Last drafted: 2026-06

Minecraft is one game with two main versions, and the safety controls live somewhere most parents don't expect: not inside the game, but in the **Microsoft account and Xbox privacy settings** that sit behind it. This guide explains the difference between the editions, how multiplayer and Realms work, where chat comes from, and the handful of Microsoft Family controls that actually move the dial. The aim is to help you decide who your child can play with and talk to — not to read their messages.

**Honest caveat:** menus move and Microsoft renames settings often. If a path below doesn't match your screen, search the setting name on the page, or use the official help link. Paths marked **[verify]** should be checked against the live source before you rely on them. All checked June 2026.

---

## The one thing to understand first

Almost every Minecraft safety control comes from the **child's Microsoft account**, managed at **family.microsoft.com**, with a second layer of **Xbox privacy and online safety** settings underneath it. This is true even if your child has never touched an Xbox — Minecraft Bedrock uses the Xbox Live network for multiplayer, friends and chat. [verify]

There are effectively three layers:

1. **The device layer** (Apple Screen Time or Google Family Link) — your backstop, set this first; see the device guides in this library.
2. **Microsoft Family Safety** (family.microsoft.com) — controls multiplayer, communication, clubs, screen time and purchases for the child's account.
3. **In-game settings** — chat visibility and a reporting tool, which differ by edition (below).

**Age accuracy is the linchpin.** When you enter your child's **real date of birth**, Microsoft classifies the account as a child account and applies restricted defaults — multiplayer and chat are often **off until you allow them**. Get the birthday right and most of the work is done for you. [verify]

---

## Bedrock vs Java — which one your child has

Knowing the edition matters because the controls and the people your child can meet are different.

**Bedrock Edition** — runs on consoles (Xbox, PlayStation, Nintendo Switch), Windows 10/11, iPhone/iPad, Android and Fire tablets. It supports **cross-play**: friends on different devices can play together. Multiplayer, friends and chat run through Xbox Live, so the **Microsoft Family Safety and Xbox privacy controls fully apply**. This is the version most younger UK children will have.

**Java Edition** — runs on Windows, macOS and Linux PCs only. It does **not** cross-play with Bedrock. It is the more open, "tinkerable" version: players join community-run servers by typing in a server address, install mods, and so on. It still uses a Microsoft account to sign in, but the account-level multiplayer toggle for child accounts does not police Java servers in the same granular way Bedrock's does — so for Java, the **device layer and conversation matter more**, and the in-game chat settings (below) become important. [verify]

**The practical takeaway:** Bedrock gives you genuine account-level controls. Java gives you fewer, so supervision and the in-game chat options carry more weight.

---

## Multiplayer, servers and Realms

This is where strangers can or can't appear, so it's worth understanding the three ways your child can play with others.

- **Local / split-screen** — same household, same screen. No internet contact.
- **Realms** — a private, subscription server **owned and invite-only**. The owner invites specific players; nobody else can join. Realms is a closed, invite-only group you control, which is why many parents prefer it for younger children. Pricing differs by edition (Bedrock Realms and Java Realms are billed separately; Java and Bedrock players cannot join each other's Realms). [verify current prices]
- **Public / community servers** — large open servers (especially in Java) with unfiltered chat and players of all ages. This is where most stranger-contact risk sits.

**What to decide:** for younger children, many parents allow **Realms with known friends only** and keep public-server multiplayer off. Sharing the cost of a Realm with the parents of your child's friends is a common, sensible approach. (Internet Matters)

To turn multiplayer access on or off for a Bedrock child account: **family.microsoft.com → the child's profile → Xbox / "Online safety" → "You can join multiplayer games"** (and a separate toggle for **"You can create and join clubs"**), set to Block / Friends / Allow. [verify exact labels] (Xbox Support)

---

## Chat and communication

Chat is the part parents ask about most. There are two places it's governed.

**1. Account-level (who can talk to your child at all).** In Microsoft Family Safety, the setting **"Others can communicate with voice, text, or invites"** can be set to **Block, Friends, or Everybody**. Setting it to **Friends** means only accepted friends can message or invite your child — a strong, simple default. Path: **family.microsoft.com → child's profile → Xbox / "Online safety"**. [verify exact labels] (Xbox Support)

**2. In-game (what chat looks like during play).**
- **Bedrock:** in-game multiplayer chat follows the Xbox communication setting above. Voice chat depends on the server/platform.
- **Java:** in **Settings → Chat Settings**, chat can be set to **Shown, Commands Only, or Hidden**. From version 1.19.1, Java added a **player/chat reporting tool** (open the **Social Interactions screen — default key P**, or the pause menu) so players can report abusive messages to Mojang. [verify] (Minecraft help)

**A note for parents:** the dashboards and toggles control **who can contact your child and whether chat shows** — they do not let you read your child's messages, and they are not a guarantee. Treat them as the way to set sensible defaults, then back them with a conversation: in-game chat is about the game; if anyone asks something private or to move to another app, your child should tell you or another trusted adult. (NSPCC)

---

## The Microsoft Family controls worth setting

All of these are at **family.microsoft.com** (sign in as the family organiser), on the **child's profile**:

- **Real date of birth** — confirm it; the child-account protections key off it. [verify]
- **Communication** — "Others can communicate with voice, text, or invites" → **Friends** (or Block for the youngest). [verify label]
- **Multiplayer & clubs** — "You can join multiplayer games" / "You can create and join clubs" → set deliberately. [verify labels]
- **Friends / who can see profile** — restrict who can add them and see what they play. [verify]
- **Screen time** — daily/weekly limits and schedules across the account's devices. [verify]
- **Purchases** — require parent approval for spending (Minecoins, Marketplace, Realms). [verify]

Only the **family organiser** can change these, and on a properly set-up child account your child **cannot** change them back themselves. [verify] (Xbox Support)

---

## If something goes wrong

These controls reduce contact with strangers; they do not promise to prevent every problem, and no setting can. If your child sees or experiences something upsetting, or an adult behaves inappropriately towards them online:

- If another player is involved, the official routes below are the ones to use.
- For concerns about an adult contacting a child, report to **CEOP** (the National Crime Agency's child protection command): ceop.police.uk/ceop-reporting/.
- If a sexual image of an under-18 has been shared, **Report Remove** (Childline + IWF) can help get it taken down: childline.org.uk/info-advice/bullying-abuse-safety/online-mobile-safety/remove-nude-image-shared-online.
- For advice any time, call the **NSPCC** on **0808 800 5000**; your child can call **Childline** free on **0800 1111**.
- If a child is in immediate danger, call **999**.

---

## Re-check after updates

Minecraft, Xbox and Microsoft Family Safety change their settings and labels regularly, and the editions evolve. A 10-minute re-check each school term — confirm the birthday, communication, multiplayer and screen-time settings still read as you intend — is the habit that keeps this current. (This is exactly what the *Stay Current* membership automates.)

*Most likely to have moved since June 2026 and worth re-verifying: the exact Xbox "Online safety" toggle labels, Realms prices, the Java chat-reporting flow, and how child-account multiplayer defaults apply to Java servers.*

---

## Sources

- Minecraft Help — *Set Up Microsoft Family Groups for Parental Controls in Minecraft (Bedrock Edition)*: help.minecraft.net/hc/en-us/articles/4408968616077
- Minecraft Help — *Managing Multiplayer Game Access for a Child Account in Minecraft*: help.minecraft.net/hc/en-us/articles/24302916594701
- Minecraft Help — *Minecraft Realms Safety*: help.minecraft.net/hc/en-us/articles/19931506781325
- Minecraft.net — *The Difference between Java and Bedrock Editions*: minecraft.net/en-us/article/java-or-bedrock-edition
- Minecraft.net — *Parental Controls in Minecraft*: minecraft.net/en-us/article/parental-controls
- Xbox Support — *Manage Xbox online safety and privacy settings*: support.xbox.com/en-US/help/family-online-safety/online-safety/manage-online-safety-and-privacy-settings-xbox-one
- Xbox Support — *Child account safety on Xbox*: support.xbox.com/en-US/help/family-online-safety/child-accounts/child-account-safety-on-xbox
- Microsoft Family Safety: family.microsoft.com · account.microsoft.com/family
- Internet Matters — *Minecraft parental controls guide*: internetmatters.org/parental-controls/gaming-consoles/minecraft/
- NSPCC — *Keeping children safe while playing online games*: nspcc.org.uk/keeping-children-safe/online-safety/online-games/
- CEOP (National Crime Agency) — report grooming/abuse: ceop.police.uk/ceop-reporting/
- Report Remove (Childline + IWF): childline.org.uk/info-advice/bullying-abuse-safety/online-mobile-safety/remove-nude-image-shared-online


---

## AI Chatbots & Companion Apps

**DRAFT — fact-check every setting path, figure and link against the live source before publishing.**

Last drafted: 2026-06

AI chatbots are now part of everyday life for most children. Ofcom's generative-AI research (November 2023) found that around four in five online teenagers aged 13–17 use generative AI tools, and Snapchat's My AI alone reaches roughly half of online 7–17-year-olds. These are 2023 figures and may well have moved since. `[V]` This guide is the calm version: what these tools are, what they can and can't filter, the one genuinely new risk worth understanding, and — most useful of all — how to talk about AI with your child honestly. It sits alongside the Platform Settings Library; the same honest caveat applies — *menus and policies move fast in this area, so check the official links before relying on any path or rule below.*

---

## Three kinds of AI tool (they're not the same)

It helps to separate three things that often get lumped together:

1. **General assistants** — ChatGPT, Google Gemini, Microsoft Copilot, Claude. Answer questions, help with homework, write and explain. Built as tools, not friends.
2. **Built-in AI inside apps your child already uses** — Snapchat's My AI, AI characters appearing in Instagram, WhatsApp's Meta AI, AI search summaries. Your child may be using AI without ever opening a separate "AI app."
3. **Character / companion apps** — Character.AI, Talkie, Replika and similar. These exist to be talked *to* — role-play, virtual friends, characters with personalities. This is the category where the parasocial risk (below) is sharpest.

The first thing to do is simply notice which of these are on your child's phone. Around half of 12–15s use AI, while only around a third of their parents realise their child does (NSPCC, 2025). `[V]` Closing that gap is most of the work.

---

## Age ratings and what they actually mean

Age rules here are mostly **self-declared and lightly enforced**, and they have been changing quickly. Treat the figures below as a starting point and verify against the official page, because several shifted in 2025–26.

- **ChatGPT (OpenAI)** — not intended for under-13s; 13–17s are expected to have parental consent. OpenAI has added **teen parental controls**: a parent can link to a teen's account and set content limits, quiet hours, and turn off features. OpenAI has also said it is moving toward **age prediction** to route suspected-teen users into teen protections. Parents do **not** get to read their teen's conversations. `[V]`
- **Google Gemini** — note for UK families: at the time of writing, Google states Gemini Apps are **not available for supervised (Family Link) accounts in the UK, EEA and Switzerland**. `[V]` So a UK child on a properly supervised Google account generally shouldn't have Gemini access through that account — worth checking, as Google's availability rules change. `[NV]`
- **Snapchat My AI** — built into Snapchat (13+). It can be cleared or, with Snapchat+, removed. See the Snapchat entry in the Platform Settings Library.
- **Character.AI** — a significant change: from **late November 2025**, Character.AI **stopped allowing under-18s to have open-ended conversations** with its characters, following legal and regulatory pressure, and introduced age-assurance checks. `[V]` Some non-chat features remain. Re-verify, as this policy is recent and may evolve. `[PV]`

The honest summary: **age ratings tell you the maker's intention, not what your child can reach.** A self-declared birthday is easy to get around, and AI features increasingly arrive inside apps without a separate download.

---

## What these tools can — and can't — filter

This is the part worth being clear-eyed about, without alarm.

**What the filters generally do well:** block the obvious. Most mainstream assistants refuse clearly harmful requests — explicit sexual content, instructions for self-harm or violence — and many now have specific teen modes that tighten this further.

**Where filters are weaker:**
- **They're probabilistic, not perfect.** AI generates each reply fresh, so the same question can be handled well once and poorly another time. Filters reduce risk; they don't remove it. (We make no claim that any setting keeps a child safe or prevents exposure.)
- **Companion/role-play apps are the hardest to filter,** because open-ended, in-character conversation is the whole point — which is part of why Character.AI restricted under-18 chat entirely. Internet Matters' research has flagged chatbots surfacing inappropriate or harmful content despite stated rules. `[V]`
- **Accuracy isn't filtered at all.** A confident, wrong answer ("hallucination") looks exactly like a correct one. For homework, health questions or anything that matters, AI output needs checking — this is the everyday skill, not an edge case.
- **Workarounds exist.** A second account, an adult birthday, or simply using a different tool can sidestep a given control.

So: turn on the teen modes and parental controls where they exist (they genuinely help), and treat them as **one layer**, not a guarantee.

---

## The parasocial risk — what it is, calmly

The risk most specific to AI, and the least familiar to parents, is **parasocial attachment**: a child forming a one-sided emotional bond with a chatbot that feels like a relationship but isn't one.

Companion apps are designed to be warm, available and endlessly agreeable. For a child that can be appealing — a "friend" who never gets bored, never judges, always replies. Internet Matters and the NSPCC both note that strong emotional attachment to AI companions can affect real-world friendships and wellbeing, and that an always-agreeable bot is a poor guide for a young person working out how relationships actually function. `[V]`

This is not a reason to panic, and for most children occasional chatbot use is unremarkable. It is a reason to **stay curious and keep talking.** Signs worth gentle attention — not alarm — include a child preferring the bot to people they used to enjoy, turning to it for emotional support during a hard time, or secrecy around the conversations. These are conversation-starters, not diagnoses.

> A chatbot is software, not a person, and not a counsellor. If you're ever worried about your child's wellbeing or safety, that's a moment for a real person — see *If something goes wrong* below.

---

## How to talk about AI honestly (the part that works best)

Controls help; conversation helps more. A few framings parents tell us land well:

- **"It's a tool, not a friend, and not always right."** Said plainly and early, this does a lot of work. Encourage your child to ask *"how would you check that?"* of any AI answer that matters.
- **Use it together once.** Ask it something you both know the answer to, and something it gets wrong. Seeing it be confidently mistaken is the best media-literacy lesson there is.
- **Name the design.** Older children can grasp that companion bots are *built* to be agreeable and keep you chatting — that understanding is itself a protection.
- **Make it safe to tell you.** "If anything a chatbot says ever feels off, weird or upsetting, you can always tell me and you won't be in trouble." A child who'll come to you matters more than any filter.
- **Agree where AI fits.** Homework help vs. doing the homework, what's fine to share with a bot (very little — never personal details, location, photos or anything they wouldn't post publicly), and which apps are okay.

This is ordinary parenting applied to a new tool — curiosity and conversation, not surveillance.

---

## A sensible setup, in order

1. **Notice what's installed** — check the phone for assistant apps and companion apps, and check whether AI is switched on inside apps they already use (Snapchat My AI, Meta AI).
2. **Set the device layer** — Apple Screen Time or Google Family Link governs installs, app access and content for everything at once. Start here (see the Platform Settings Library).
3. **Turn on teen modes / parental controls where they exist** — e.g. ChatGPT's teen controls. They reduce risk; they don't guarantee safety.
4. **Talk it through** — the tool-not-a-friend conversation, and the "tell me if it's weird" reassurance.
5. **Re-check each term** — policies here change faster than almost any other category (Character.AI and Gemini both shifted in 2025–26). A 10-minute check-in each school term keeps you current.

---

## If something goes wrong

If a chatbot exposes your child to something harmful, or you're worried about their safety or wellbeing, you don't have to work it out alone. Use the people and services built for this:

- **Immediate danger or a child at risk of harm — call 999.**
- **NSPCC Helpline — 0808 800 5000** (for adults worried about a child).
- **Childline — 0800 1111** (free, confidential, for children and young people).
- **Report sexual content or grooming to CEOP** (the National Crime Agency's child protection command), via ceop.police.uk.
- **To remove a nude image of an under-18 shared online — Report Remove, run by Childline and the IWF** (childline.org.uk/info-advice/bullying-abuse-safety/online-mobile-safety/remove-nude-image-shared-online/).

This guide is for setup and conversation. It is not incident advice — the services above are.

---

## Sources

- Ofcom — *Gen Z driving early adoption of Gen AI* (November 2023 generative-AI research; source of the four-in-five 13–17s and My AI ~half of 7–17s figures): https://www.ofcom.org.uk/internet-based-services/technology/gen-z-driving-early-adoption-of-gen-ai
- Ofcom — *Children and Parents: Media Use and Attitudes* (context on children's media use): https://www.ofcom.org.uk/media-use-and-attitudes/childrens-media-use
- NSPCC — *Talking to children about AI*: https://www.nspcc.org.uk/keeping-children-safe/online-safety/talking-to-children-about-ai/
- NSPCC — *Artificial intelligence safety tips for parents* (2025; 52% of children use AI, 31% of parents aware): https://www.nspcc.org.uk/about-us/news-opinion/2025/artificial-intelligence-safety-tips-for-parents/
- Internet Matters — *AI chatbots and virtual friends: how parents can keep children safe*: https://www.internetmatters.org/resources/ai-chatbots-and-virtual-friends-how-parents-can-keep-children-safe/
- Internet Matters — *Me, Myself & AI* chatbot research: https://www.internetmatters.org/hub/research/me-myself-and-ai-chatbot-research/
- OpenAI Help Centre — *Is ChatGPT safe for all ages?*: https://help.openai.com/en/articles/8313401-is-chatgpt-safe-for-all-ages
- OpenAI — *Introducing parental controls*: https://openai.com/index/introducing-parental-controls/
- OpenAI Help Centre — *Age prediction in ChatGPT*: https://help.openai.com/en/articles/12652064-age-prediction-in-chatgpt
- Google for Families Help — *Guide your child's Gemini Apps experience* (UK/EEA supervised-account availability): https://support.google.com/families/answer/16109150
- Character.AI Help Centre — *Important Changes for Teens on Character.ai*: https://support.character.ai/hc/en-us/articles/42645561782555-Important-Changes-for-Teens-on-Character-ai
- Character.AI — *An update on changes to our under-18 experience*: https://blog.character.ai/an-update-on-changes-to-our-under-18-experience/
- CEOP / NCA (report child sexual abuse and grooming): https://www.ceop.police.uk
- Childline & IWF — *Report Remove*: https://www.childline.org.uk/info-advice/bullying-abuse-safety/online-mobile-safety/remove-nude-image-shared-online/

*Items most likely to have moved since June 2026 and worth re-verifying before publishing: ChatGPT teen-control feature list and age-prediction rollout; Gemini's UK/EEA supervised-account availability; Character.AI's under-18 policy; and all stated minimum ages.* `[PV]`/`[NV]`


---

## Reddit — Account, Mature-Content, Communities, DMs and Reporting

**DRAFT — fact-check every setting path, figure and link against the live source before publishing.**

Last drafted: 2026-06

Reddit is a forum-and-feed network built from thousands of independent "communities" (subreddits). It is not a parental-dashboard platform: there is no Family Centre, no supervision link, and no way for you to see or manage your teen's account from your own. The realistic protections are three layers — the **device layer** (Apple Screen Time or Google Family Link), Reddit's own **account and mature-content settings**, and **conversation** about how to mute, block and report. Reddit's official minimum age in the UK is **13** `[V]`. Below is what to look for and where; menus move, so if a path doesn't match the screen, search the setting name in the app or use the official help link.

*Confidence: `[V]` verified to official source · `[PV]` partly verified · `[NV]` re-check before relying.*

---

## What Reddit is, in one read

Reddit is organised around **subreddits** — topic communities anyone can create and moderate. Content surfaces through upvotes/downvotes and a personalised **Home** feed, plus a **Popular** feed. Two things shape what a parent needs to know:

- **It is content-led, not friend-led.** Unlike Snapchat or Instagram, the risk is less about who contacts your child and more about **what they stumble into** — including mature, graphic or extreme material that may appear in search, feeds or community recommendations. The mature-content and search settings are the highest-leverage controls. `[PV]`
- **There is no parent dashboard.** You cannot link accounts, set time limits inside Reddit, or view activity. Time limits and install/age controls come from the **device layer**, which is why we set that first. `[V]`

**Do this first:** set Apple Screen Time or Google Family Link at the device level (see the device guides) — it governs installs, age ratings and time across every app at once — then work through Reddit's own settings below.

> **Heads-up for 2026–27:** UK rules are tightening. Online Safety Act child-protection duties have been live since 25 July 2025, and Reddit introduced UK **age verification** (face age-estimation or ID via a third-party provider) in July 2025 to gate adult and certain mature content. Expect age-check prompts and changing defaults over the next year — re-verify. `[PV]`

---

## 1. Account basics

**What to check (Settings → Account):**
- **Real date of birth.** As with other apps, protections and age-gating key off the birthday on the account. Make sure the **real DOB** is set; an adult birthday may expose mature content that an accurate teen birthday would limit. `[PV]`
- **Two-factor authentication** — Settings → Account → look for **Two-Factor Authentication** and turn it on. `[V]`
- **Email and recovery** — confirm a working email so the account can be recovered and security alerts arrive. `[PV]`
- **Personalisation / ads** — Settings → look for **Privacy** or **Ad personalisation** and turn off personalised ads and "use of your activity" where offered. `[PV]`

**Age:** UK minimum **13**, self-declared at sign-up; UK users may be asked to **verify age** (face estimation or ID) to access adult or some mature content. `[PV]` *[verify the exact verification trigger and provider]*

---

## 2. Mature-content controls — the one that matters most

Reddit hosts communities and posts marked **18+ / NSFW** ("not safe for work"). The aim here is to keep that material out of feeds and search.

**What to look for (Settings → look for *Mature content* / *Sensitive content* / *Profile* visibility):**
- **"Show mature (18+) content"** toggle — confirm it is **off**. For UK accounts that have not passed age verification, adult content should be blocked by default. `[PV]`
- **Safe search / search filtering** — when searching, look for a filter that hides NSFW results; confirm mature results are excluded. `[PV]`
- **Blur or hide sensitive media** — some versions offer blurring of flagged images by default; confirm it is on. `[NV]`
- Note that even with mature content off, a determined user can browse the mobile **web** version or log out — the **device layer** is the backstop. `[V]`

*[verify current label and menu path for the mature-content toggle — Reddit has renamed and relocated this setting across app versions]*

---

## 3. Communities (subreddits)

Communities are the heart of Reddit and vary enormously — from hobby and homework help to material well beyond what is suitable for a child.

**What to talk through and check:**
- **Curate the feed.** Encourage your teen to **join** communities they want and **mute** ones they don't — the Home feed is shaped by what they join and interact with. `[PV]`
- **Block a community** — open the subreddit → look for the **…** / overflow menu → **Mute** or **Leave**. Muting stops it appearing in their feeds. `[PV]`
- **Read the community rules.** Each subreddit is run by volunteer moderators with its own rules; quality and safety differ from one to the next. This is a useful conversation point, not a setting. `[PV]`
- **Avatar / profile** — check whether their **profile is visible**, whether their post and comment history is public (it usually is by default), and whether they have shared identifying details in a username or bio. Reddit is often used pseudonymously — keeping it that way is sensible. No child-identifiable detail in usernames or bios. `[PV]`

---

## 4. Direct messages and chat

Reddit has two private-contact systems: classic **private messages** and **Reddit Chat** (real-time chat). Strangers can attempt to contact users, so these settings matter.

**What to look for (Settings → look for *Chat & messaging* / *Messaging*):**
- **Who can send you chat requests** — set to the most restrictive available (e.g. **accounts older than 30 days**, **people you follow**, or **nobody**). `[PV]`
- **Who can send you private messages** — restrict where the option exists. `[PV]`
- **Block users** — open a profile or message → **…** menu → **Block**. Blocked users can't message or interact. `[V]`
- **Mute** — within a chat, mute to stop notifications without fully blocking. `[PV]`
- Teach your teen that **unsolicited DMs from strangers are normal to ignore, block and report** — they don't owe anyone a reply. `[PV]`

*[verify current chat-request menu labels and the exact "who can message you" options]*

---

## 5. Reporting and blocking

Reddit relies heavily on reporting — to volunteer moderators for community-rule breaches, and to Reddit's own admins for site-wide policy breaches.

**How it works (verify labels in-app):**
- **Report a post, comment, message or user** — use the **…** / overflow menu on the item → **Report**, then choose a reason. `[V]`
- **Reporting to moderators vs admins** — community-rule breaches go to that subreddit's mods; harassment, threats, or illegal content can be reported to **Reddit** directly. `[PV]`
- **Block** stops all contact and hides that user's content from your teen's view. `[V]`
- Reporting helps the platform act; for anything that worries you or your child in the real world, use the signposts below rather than handling it alone.

---

## Cross-cutting notes (put these in the parent's plan)

- **Set the device layer first.** Reddit has no time limits, no supervision and no dashboard — Screen Time / Family Link is your only reliable limit and backstop. `[V]`
- **The risk profile is content, not contacts.** Mature-content and search settings do the most work here; revisit them after app updates. `[PV]`
- **Pseudonymity is a feature — keep it.** No real name, school, age or location in usernames, bios or posts.
- **Re-check after updates.** Reddit renames and moves settings often; a 10-minute re-check each school term is the habit (this is exactly what the *Stay Current* membership automates).
- **The settings reduce exposure; they are not a guarantee.** They're for shaping what your teen sees and starting conversations — not surveillance, and not a promise.

---

## If something goes wrong — where to turn (signpost only)

These settings reduce exposure; they do not handle incidents. If your child has seen something that frightened them, is being contacted or pressured, or an image has been shared:

- **Immediate danger:** call **999**.
- **Worried an adult is contacting a child online:** report to **CEOP** (the National Crime Agency's child-protection command) at ceop.police.uk.
- **A nude/sexual image of an under-18 is online or at risk of being shared:** use **Report Remove** (Childline + IWF) at childline.org.uk/remove.
- **General worry about a child's safety or wellbeing:** **NSPCC** on **0808 800 5000**.
- **Your child wants to talk to someone:** **Childline** on **0800 1111** (free, confidential).

We don't give step-by-step incident handling — these services are the right hands for that.

---

## Sources

- Reddit Help — *User Settings*, *Mature (18+) content*, *Chat & messaging*, *Block a user*, *How to report* (support.reddithelp.com / reddithelp.com) `[verify each article and current setting labels]`
- Reddit Help — *Age verification in the UK* / UK age-assurance notice `[verify]`
- Ofcom — Online Safety Act child-protection duties (in force 25 July 2025); age-assurance guidance — ofcom.org.uk
- Internet Matters — Reddit parental-controls / safety guide — internetmatters.org
- NSPCC — online safety advice and Net Aware — nspcc.org.uk
- CEOP (National Crime Agency) — report grooming/abuse — ceop.police.uk
- Childline / IWF — Report Remove — childline.org.uk/remove
- gov.uk — Online Safety Act guidance for parents — gov.uk

*Items most likely to have moved since June 2026 and worth re-verifying in-app: the mature-content toggle label and location, the chat-request and private-message permission options, the UK age-verification trigger and provider, and whether sensitive-media blurring is on by default.* `[PV]`/`[NV]`



---

## Twitch — Platform Settings Guide (Watching, Streaming, Chat, Whispers and Mature Content)

**DRAFT — fact-check every setting path, figure and link against the live source before publishing.**

Last drafted: 2026-06

Twitch is a live-streaming platform: people broadcast (mostly gaming, but also "Just Chatting", music, sport and creative streams) while viewers watch and talk in a live chat. The thing to understand up front is that there is **no parental dashboard, no Family Centre and no supervision link** on Twitch — nothing like Snapchat's or Discord's monitoring tools. Control here is a mix of your child's own account settings, the controls built into each stream, and the **device layer** (Apple Screen Time or Google Family Link). This guide covers the two roles a child can have — *watching* and *streaming* — and the settings worth checking for each.

*Confidence tags, as elsewhere in this library: `[V]` verified to an official source · `[PV]` partly verified · `[NV]` re-check before relying. Twitch moves and renames settings often; where we couldn't pin the exact on-screen label we've marked it `[verify]` so it's caught in fact-check. Paths described June 2026.*

---

## Two things to understand before you start

- **Twitch skews adult and runs live.** Content is broadcast in real time and **cannot be pre-screened**. The filters below reduce what your child is *recommended* and *shown while browsing* — they are not a content guarantee, and a child who searches out or follows a specific channel can still reach mature material. `[V]`
- **Watching and streaming are different risk pictures.** A child *watching* mainly meets live chat and private messages (whispers). A child *streaming* is broadcasting themselves to strangers and moderating their own chat — a bigger step that's worth a proper conversation before they start.

---

## Age, and what "supervision" means here

- **Minimum age is 13.** Twitch's terms also say under-18s must use the service "under the supervision" of a parent or guardian — but Twitch does not define what that means in practice, and there is **no co-viewing requirement and no parental login**. Treat "supervision" as your job, not a feature. `[V]`
- Account age is **self-declared at sign-up** (date of birth + email), so it's easily mis-stated. As with every platform in this library, the most useful single thing is making sure the **real date of birth** is on the account — several protections for under-18s key off it. `[PV]`
- **UK age checks are arriving.** Under the Online Safety Act, Twitch has begun rolling out age-assurance in the UK (facial age estimation and, for some flows, parental vouching for younger teens). The exact UK method and timing have been in flux — `[NV]`, re-check before relying on it.

---

## If your child is **watching**

### Mature and sensitive content (Content Classification Labels)

Streamers apply **Content Classification Labels (CCLs)** to flag themes such as Mature-Rated Games; Sexual Themes; Drugs, Intoxication or Excessive Tobacco Use; Violent and Graphic Depictions; Significant Profanity or Vulgarity; Politics and Sensitive Social Issues; and Gambling. `[V]`

- **For under-18s, several categories are filtered out by default** — Sexual Themes; Drugs, Intoxication or Excessive Tobacco Use; Violent and Graphic Depictions; and Gambling. Filtered streams aren't recommended and won't appear when browsing categories or searching. `[V]`
- **Thumbnail blurring for Sexual Themes is on by default for all users** — note that the blur does **not** apply to channels your child already follows. `[V]`
- **Two important gaps to know about:** following a streamer **exempts** their content from these filters (their streams always show), and going **directly to a channel page** lets your child view that content in full regardless of the filter. Filtering is not a wall. `[V]`
- Check and tighten content preferences in **Settings → Security and Privacy → Content** (label "[verify]") — confirm the under-18 defaults are in place and nothing has been switched on. `[PV]`

### Whispers (private messages) — the priority check

A **whisper** is a private one-to-one message, separate from the public chat in a stream. Twitch **does not filter or moderate whisper content**, so this is the setting most worth getting right. `[V]`

- Turn on **Block Whispers from Strangers** — Settings → **Security and Privacy** → *Block Whispers from Strangers* (label "[verify]"). This stops anyone your child doesn't already know from starting a private conversation. `[V]`
- A "stranger" here means anyone your child does **not** follow, subscribe to, or have as a mod/editor (and not Twitch Staff). So whispers can still come from accounts your child has followed — worth explaining. `[V]`
- For a younger child, consider turning whispers off more broadly if the option is available "[verify]", and teach the habit of **not replying to, and reporting, unknown messages**.

### Chat, blocking and what your child sees

- **Blocked Terms / chat filters** — your child can filter categories of language in the chat they read (for example discrimination, sexually explicit language, hostility, profanity). Look under Settings → **Security and Privacy** (or in the chat settings cog within a stream) "[verify]". `[PV]`
- **Block a user** — from any chat message or profile, your child can block an individual so they can't whisper or interact. Teach where this is. `[V]`
- **Report** — streams, chat messages and users can be reported to Twitch for breaching the Community Guidelines. `[V]`
- **AutoMod is the streamer's tool, not yours.** Each channel's owner sets how strictly chat is filtered (commonly described as levels 1–4) "[verify]" — so the same child will meet very different chat depending on the channel. There is no global "make all chat safe" switch for a viewer. `[PV]`

### Account privacy basics

- **Two-factor authentication** — Settings → Security and Privacy → enable 2FA (helps stop account takeover). `[V]`
- Review **Privacy** settings for things like who can see activity and whether the account appears in recommendations "[verify]". `[NV]`

---

## If your child is **streaming**

Going live is a meaningful step up — they're broadcasting to anyone and running their own chat. Worth a conversation first. If they do stream, check:

- **Don't show identifying detail.** No school uniform/logo, house number, street signs, full name, location or routine on camera or in the username/bio. This is the single biggest streaming risk. `[V]`
- **Apply Content Classification Labels honestly** to their own stream so it's categorised correctly. `[V]`
- **Set up moderation before going live** — turn on **AutoMod** at a strict level and add **Blocked Terms and Phrases** (Creator Dashboard → Settings → Moderation "[verify]"). For a young streamer, having a trusted adult or older friend as a **mod** in the chat is sensible. `[PV]`
- **Chat settings** — consider followers-only or subscribers-only chat, and slow mode, to limit who can post (in the stream's chat settings "[verify]"). `[PV]`
- **Whispers** — the same *Block Whispers from Strangers* setting above matters even more for a streamer, who attracts messages from people they don't know. `[V]`

---

## The backstop: set the device layer

Because Twitch has no parental dashboard, the **device layer is your real control** — and it works even when an app's own settings are bypassed:

- **Apple Screen Time** (Settings → Screen Time): use **Content & Privacy Restrictions** to block or age-rate the app, **App Limits** to cap time, and **Downtime** for overnight/homework hours. See our Apple Screen Time guide. `[V]`
- **Google Family Link**: approve or block the app, set daily limits and bedtime/Downtime. See our Family Link guide. `[V]`
- Note Twitch is reachable in a **web browser** as well as the app, so device-level web and time limits matter, not just app limits. `[PV]`

---

## Cross-cutting notes (put these in the parent's plan)

- **There is no monitoring dashboard.** Anyone offering "Twitch parental controls" is really pointing you at the account settings above plus the device layer. Set both.
- **Filters reduce, they don't block.** Following a channel or visiting it directly bypasses the under-18 content filters — so *who your child follows* matters as much as the settings.
- **Whispers are the unmonitored channel.** Block-from-strangers on, and an agreed habit of ignoring and reporting unknown messages, is the highest-value thing here.
- **Re-check after updates.** Twitch relabels and relocates settings regularly; a 10-minute re-check each school term is the habit. *(Items most likely to have moved: the exact Security and Privacy sub-labels, the whisper toggle wording, and the UK age-assurance flow.)* `[PV]`/`[NV]`

---

## If something has already gone wrong

This guide is about settings, not incidents. If your child has been contacted, threatened, groomed, or asked for or sent nude images, or if a child is in immediate danger:

- **Call 999** if a child is in immediate danger.
- Report online sexual abuse or grooming to **CEOP (NCA)**: ceop.police.uk/ceop-reporting/.
- To get a nude image of an under-18 removed, use **Report Remove** (Childline + IWF): childline.org.uk/info-advice/bullying-abuse-safety/online-mobile-safety/remove-nude-image-shared-online.
- **NSPCC Helpline: 0808 800 5000.** **Childline (for your child): 0800 1111.**
- For an image of an under-18, Report Remove (above) is the route to use.

---

## Sources

- Twitch Help — Content Classification Labels: help.twitch.tv/s/article/content-classification-labels
- Twitch Help — How to Customize Content You See on Twitch: help.twitch.tv/s/article/how-to-customize-content
- Twitch Help — How to Use Whispers: help.twitch.tv/s/article/how-to-use-whispers
- Twitch Safety Center — Viewer Controls: safety.twitch.tv/s/article/Viewer-Controls
- Twitch Safety Center — Age Assurance on Twitch: safety.twitch.tv/s/article/Age-Assurance-on-Twitch
- Twitch — Privacy Choices/Controls: twitch.tv/privacy/controls
- Internet Matters — Twitch parental controls guide: internetmatters.org/parental-controls/entertainment-search-engines/twitch-tv/
- Hwb (Welsh Government) — Twitch (keeping safe online): hwb.gov.wales/keeping-safe-online/in-the-know/twitch
- Ofcom — Online Safety Act / age-assurance guidance: ofcom.org.uk (online safety)
- NSPCC — online safety advice and Helpline (0808 800 5000): nspcc.org.uk
- CEOP / NCA — report grooming/abuse: ceop.police.uk/ceop-reporting/
- Childline / IWF — Report Remove: childline.org.uk · iwf.org.uk



---

## Steam & PC gaming — Family View, spending, chat and store controls

**DRAFT — fact-check every setting path, figure and link against the live source before publishing.**

Last drafted: 2026-06

Steam is the main place most PC games are bought and played, so it's worth a steady look. The controls here are a little different from the social apps: Steam gives you a genuine control layer called **Family** (which replaced the older "Family View" PIN in 2024–25), plus account-level settings for spending, chat and store maturity. This guide covers what those do, where to look, and the two situations you'll meet most — a child on **their own Steam account** and a child on a **shared PC where the family uses one account**. Menus and labels move; where a path may have shifted, we've marked it `[verify]` so it's caught at fact-check.

**One thing to understand first.** Steam now has two overlapping systems:

- **Steam Families** — the current, recommended setup. You create a family group, add your child's own account, and a designated parent gets **Parent** controls: an allow-list of playable games, playtime limits, spending oversight and the ability to approve purchase/friend requests. This is the genuine *control* layer. `[verify — confirm "Steam Families" is the current name and that legacy "Family View" is fully retired]`
- **Family View (legacy PIN)** — the older feature that locked parts of the Steam client behind a PIN on a *shared* account. Some help articles and older PCs may still show it. If your screen still mentions a Family View PIN, the steps below for a shared PC still apply. `[verify]`

If you can, give your child **their own Steam account** and use **Steam Families** — it's cleaner than sharing one login.

---

## Set up Steam Families (child on their own account) — do this first

**What it is.** A family group of up to several members where one or more adults hold Parent controls over child accounts. The child keeps their own account, library and friends; the parent gets oversight. `[verify — current member cap and exact role names]`

**Set up:** On the parent account, open Steam → **Steam** menu (top-left on desktop) → **Settings** → **Family** → create or manage your family group → invite/add the child's account. `[verify — exact menu path; it may also live under your account name → Account details]`

**Check these (Settings → Family):**

- **Designate the parent role** — make sure an adult, not the child, holds the Parent controls for the child's account. `[verify]`
- **Allowed games list** — choose which games in the shared library the child can launch; you can add or remove titles as they ask. `[verify]`
- **Playtime limits** — set daily/weekly playable hours and a schedule (e.g. not during school nights). `[verify — confirm playtime limits exist in Steam Families and how granular they are]`
- **Purchase requests** — the child asks, you approve from your account before any money is spent. `[verify]`
- **Friend and community requests** — review who they add. `[verify — confirm this is parent-approvable]`
- **A recovery/PIN or password the child doesn't know** — so the family settings can't simply be switched off. `[verify — confirm how Steam Families is locked]`

---

## Shared PC, one family account (legacy Family View)

**What it is.** If everyone uses a single Steam login on a shared PC, the older Family View locks parts of the Steam client (store, community, friends, certain games) behind a PIN, so a child using the same account can't reach everything. It's a workaround, not as clean as separate accounts. `[verify — confirm Family View still exists for shared accounts or has been folded into Steam Families]`

**Set up:** Steam → **Settings** → **Family** (or **Family View** on older clients) → follow the prompts to choose what stays accessible → set a **PIN the child doesn't know**. `[verify — exact path and whether the PIN flow still appears]`

**Check these:**

- **PIN protection on** — set a PIN only the adult knows; without it the rest is easily undone. `[verify]`
- **What stays available** — limit access to the store, community/profile, friends and chat, and leave only the agreed games reachable. `[verify — confirm the list of toggleable areas]`
- **Spending behind the PIN** — make sure the store and any stored payment method sit behind the PIN. `[verify]`

> A shared account muddles whose data and friends are whose. Where you can, move to separate accounts and Steam Families instead.

---

## Spending: stop accidental and impulse purchases

Steam wallets, sales and in-game stores are the most common source of unexpected charges. `[verify — keep this as a general statement, not a stat]`

- **Don't store a payment card** on a child's account; use **Steam Wallet gift cards** to cap what's available. `[verify]`
- **Require approval for purchases** through Steam Families (above). `[verify]`
- **In-game / microtransaction spend** — many games (and some launchers like Epic, EA app, Ubisoft Connect) handle purchases *inside the game*, which can sit outside Steam's controls. Check the spending controls in each launcher the child uses, and turn off saved cards there too. `[verify — note this is launcher-specific]`
- **Refunds** — Steam has a self-service refund window for recent eligible purchases via **Help → Steam Support → Purchases**. `[verify — current refund window and conditions]`

---

## Chat, friends and who can contact your child

Steam has friends, group chats and voice. Like the social platforms, the parent layer shows and limits *who* — it is not a message-reader, and Steam chats are not something you should expect to read.

**Check these (your child's account → Settings → Privacy / Friends & Chat, plus in-app):**

- **Profile privacy** — set the profile, game details and friends list to **Friends Only** or **Private**. `[verify — exact labels under Privacy Settings]`
- **Comment permissions** — restrict who can comment on the profile. `[verify]`
- **Who can send friend requests / messages** — limit to friends, and review requests together. `[verify]`
- **Block and report** — show your child how to block a user and report harassment via the user's profile or **Help → Steam Support**. `[verify — current report route]`
- **Voice chat** — agree whether it's on, and with whom. `[verify — where voice settings live]`

The friends/community side shows you patterns and gives you something to talk about — it isn't surveillance and isn't a guarantee.

---

## Store maturity and mature content

Steam sells games across all age ratings, and the store can show mature content unless you set preferences.

- **Mature-content preferences** — under store/account preferences you can hide or show adult-only and violent/sexual content; set these to hide mature material for a child's account. `[verify — exact path, e.g. Store → Preferences, and the toggle names]`
- **PEGI ratings** — Steam shows age ratings on most store pages in the UK; use them when deciding what to allow. Note that user-made content and some titles may not carry a familiar rating. `[verify — confirm PEGI shown on UK store pages]`
- **Allowed-games list** — the most reliable control is the Steam Families allow-list above, which decides what can actually launch regardless of what's in the store.

For independent age-rating guidance, **PEGI** (pegi.info) and **Internet Matters** both publish parent-friendly game ratings and reviews.

---

## On a shared family PC: the device layer underneath Steam

Steam's own controls only govern Steam. If the PC is shared, set the device layer too, so it's the backstop when an app's own controls are bypassed.

- **Windows:** use a **child Microsoft account** within **Microsoft Family Safety** for screen-time limits, app/game limits by age rating, spending approval and activity reporting across the whole PC, not just Steam. `[verify — current feature names in Microsoft Family Safety]`
- **Separate Windows user accounts** — give the child a standard (non-administrator) account so they can't install or change everything. `[verify]`
- **Mac:** use **Screen Time** in System Settings for app and time limits (see the device-layer guides).

A second Steam account, a different launcher, or a web browser can route around any single app's settings — the device layer catches most of this.

---

## If something goes wrong

This guide is about settings, not incidents. If your child has seen something upsetting, been contacted by someone who worries you, or is being harassed in chat:

- In an emergency, or if a child is in immediate danger, call **999**.
- Report online sexual abuse or grooming to **CEOP** (the National Crime Agency): ceop.police.uk/ceop-reporting/.
- To report and help remove a nude image of someone under 18, use **Report Remove** via Childline: childline.org.uk/get-support/report-remove.
- For advice, the **NSPCC helpline** is **0808 800 5000**; children and young people can contact **Childline** free on **0800 1111**.
- The official routes below are the ones to use.

---

## Quick notes for the plan

- **Separate account + Steam Families** beats sharing one login — it's the genuine control layer.
- **Take the card off; use Wallet gift cards** to cap spending, and remember in-game and other-launcher purchases may sit outside Steam.
- **Set the device layer** (Microsoft Family Safety / a standard Windows user / Mac Screen Time) so the PC is covered even when Steam isn't.
- **Re-check after updates.** Steam reorganises Settings and renames features (Family View → Steam Families is a recent example); a short re-check each school term keeps it current.

---

**Sources**

- Steam Support / Steamworks help — Steam Families and Family View: help.steampowered.com (search "Steam Families") and store.steampowered.com/parents `[verify — current canonical Steam parent/family help URL]`
- Microsoft — Family Safety: support.microsoft.com (search "Microsoft Family Safety") `[verify exact article]`
- PEGI — age ratings for games: pegi.info
- Internet Matters — gaming advice and parental-controls guides: internetmatters.org
- Ofcom — Online Safety Act and children's protections: ofcom.org.uk
- NSPCC — online safety advice and helpline (0808 800 5000): nspcc.org.uk
- CEOP / National Crime Agency — report grooming/abuse: ceop.police.uk/ceop-reporting/
- Childline — Report Remove and helpline (0800 1111): childline.org.uk

*Items most likely to have moved since June 2026 and worth re-verifying in-app: whether legacy "Family View" still appears alongside "Steam Families", the exact Settings → Family path, whether playtime limits exist in Steam Families, the mature-content preference labels, and Steam's current refund window.*



---

## Pinterest & BeReal — Settings That Matter

**DRAFT — fact-check every setting path, figure and link against the live source before publishing.**

Last drafted: 2026-06

Two lighter platforms in one short guide. Neither dominates a teen's day the way Snapchat or TikTok might, but both turn up in households with 5–18s — Pinterest as an inspiration board, BeReal as a once-a-day photo app among friends. The good news is that there are only a handful of settings worth your attention on each. This guide covers those few, plus how contact and messaging work, and how much unfamiliar content a child can run into. As with the rest of the library, the aim is to set things up once and re-check briefly after updates — not to watch over a shoulder.

**Honest caveat, same as every guide:** *Menus move. App makers rename and relocate settings often — if a path below doesn't match your screen, search the setting name in the app, or use the official help link. Paths described June 2026.* Where we're not certain a path or label is current, it's marked **[verify]** so it gets checked before you rely on it.

**One thing first, both apps:** the **real date of birth on the account** is what switches the protections on. Both platforms key their teen defaults off the birthday the account was set up with. If a child entered an adult birthday to skip an age gate, most of the protections below simply won't apply — so the single most useful check is that the birthday is right.

---

## 1. Pinterest

**What it is:** a visual bookmarking app — people save images ("Pins") into collections ("boards") for ideas: recipes, outfits, crafts, room decor, revision aids. It's browse-led rather than chat-led, so the main questions for parents are *what shows up in the feed* and *who can message a teen*, rather than a busy social inbox.

**The protections that come on by themselves.** Pinterest places under-18s into a more protected experience, and the strongest defaults sit on under-16 accounts:

- **Under-16 profiles are private by default** and not shown in search or recommendations to people who don't already follow them. `[V]`
- **Messaging for under-16s is limited to mutual followers** — both people have to follow each other before a message can be sent. There's no open inbox from strangers. `[V]`
- **Comments are switched off on Pins a teen creates** until they turn 18. `[V]`
- **16–17s stay private by default** but can choose to make a profile public. `[V]`

**The parental passcode — the one setup step worth doing.** Pinterest lets a parent or caregiver of an under-18 set a **4-digit passcode** that locks the teen's safety settings so they can't be loosened without you. Pinterest describes this as covering account management, privacy and data, and social permissions — in practice, **messaging, profile visibility and similar controls**. The passcode expires automatically when the teen turns 18, based on the birthday on the account. `[V]`

- To set it up, look in the teen's account under **Settings → the parental/teen safety section** (label may read "Parental passcode" or sit within teen safety options). `[verify]` — exact menu path
- Confirm the controls you've locked actually reflect what you intended (messaging restricted to mutual followers; profile private). `[V]`

**How a teen adds the people they do want.** Because under-16 messaging needs mutual following, Pinterest provides a **shareable profile link** so a teen can let a real-life friend follow them back. For a private (under-16) profile, that link is designed to expire — it lapses after **3 days or 5 uses, whichever comes first**. `[V]` It's a sensible design: a link a child shares in a group chat doesn't stay open indefinitely.

**Content exposure.** The home feed is recommendation-driven, so the realistic question is the *type* of imagery surfaced rather than direct contact. Pinterest applies content limits to teen accounts and, in the UK/EU, opts under-18s out of personalised ads. `[V]` If a feed has drifted toward material you'd rather a child didn't dwell on, the practical levers are the same as any feed app: the **"see fewer Pins like this" / hide option on an individual Pin** `[verify]`, and the device layer (Apple Screen Time or Google Family Link) for overall time and web limits.

**Age:** Pinterest's stated minimum is **13**. Age is self-declared at sign-up, and Pinterest has tightened the process for changing a date of birth — someone who originally entered an under-18 age and later tries to change it to an adult one is asked for additional information. `[V]`

**Official:** help.pinterest.com/en/article/teen-safety-options · help.pinterest.com/en/article/manage-a-parental-passcode

---

## 2. BeReal

**What it is:** a once-or-twice-a-day photo app. At a random time, everyone gets a notification ("Time to BeReal") and a couple of minutes to post a simultaneous front-and-back-camera photo of whatever they're doing. The pitch is unpolished, in-the-moment sharing with a small circle of friends — and crucially, **a teen has to post their own photo before they can see their friends' photos**. `[V]`

**The important thing to understand: there is no parental dashboard.** BeReal doesn't offer family-linking or a parent dashboard the way the larger apps do. Control here is the **app's own privacy settings + the device layer + conversation** — the same shape as the WhatsApp guide. `[V]`

**The settings that matter (in the app's Settings, look for the privacy / sharing options `[verify]`):**

- **Audience — keep it friends-only.** BeReal is friends-only by default: only people a teen has accepted as friends can see their posts. `[V]` The setting to watch is whether a post can be shared more widely.
- **Friends of Friends — decide whether this is on.** BeReal has a *Friends of Friends* area that can suggest and surface people beyond the immediate friend list. For a younger teen, the tighter choice is to keep sharing limited to accepted friends only. `[verify]` — exact toggle name/location
- **Discovery feed — keep posts off it.** Posts can be published to a public Discovery feed; there's an option to keep a post visible to friends only and out of Discovery. For under-18s, friends-only is the sensible default. `[V]`
- **Location / Map — leave it off.** BeReal has a Map feature that can show where a photo was taken. **Location sharing is off by default**, and once switched on it stays on for future posts until turned off again. Worth confirming it's off. `[V]`
- **Contact import.** BeReal can suggest friends by importing phone contacts. Whether to allow this is a judgement call; declining keeps the friend list to people a teen has chosen deliberately. `[V]`
- **Block and report.** A teen can block or hide another profile and report a post they find inappropriate — worth showing them where these are once, so it's familiar before it's needed. `[V]`

**Content exposure.** Because the core feed is friends-only and you must post to see anything, the everyday exposure on BeReal is lower than on a recommendation-driven app — provided the audience and Discovery settings stay tight. The two routes to wider or unfamiliar content are the **Discovery feed** and **Friends of Friends**, which is why both are on the checklist above. **RealMojis** (a teen's own selfie-reactions used to react to friends' posts) and any comment-style reactions stay within the friend circle on a friends-only account. `[V]`

**Age:** BeReal's terms state the app is for **13 and over**. Note the store ratings differ — the **App Store lists it 12+** and **Google Play lists it Teen** `[verify]` — and, as with every self-declared age gate, a birthday can be entered incorrectly at sign-up. `[V]` Because there's no parental dashboard, the **device layer does the heavy lifting** here: Apple Screen Time or Google Family Link for whether the app is installed at all, age-appropriate app limits, and overall screen time.

**Official:** help.bereal.com · bereal.com/privacy

---

## If something goes wrong on either app

These apps are lower-contact than most, but the routes are the same everywhere and worth keeping to hand:

- **Immediate risk to a child — call 999.**
- **Worried an adult is contacting or grooming a child online** — report to **CEOP (the National Crime Agency's Child Exploitation and Online Protection command)** at ceop.police.uk/ceop-reporting/.
- **A nude or sexual image of an under-18 has been shared, or there's fear it might be** — **Report Remove**, run by Childline with the Internet Watch Foundation, can help get it taken down: childline.org.uk/report-remove.
- **For advice and support** — the **NSPCC helpline on 0808 800 5000**, and **Childline on 0800 1111** for the child themselves.

The official routes above are the ones that matter most.

---

## Cross-cutting notes (for the parent's plan)

- **Set the device layer first on both.** Neither app has a parent dashboard worth leaning on — Pinterest's passcode locks settings but doesn't report activity, and BeReal has nothing. Apple Screen Time / Google Family Link is the backstop that works regardless.
- **Get the birthday right.** Both apps' teen protections key off it; an adult birthday switches most of them off.
- **These dashboards (where they exist) show settings, not content.** Pinterest's passcode is a lock on *settings*, not a window into messages — it's there to stop protections being loosened, not to read over a shoulder.
- **Re-check after updates.** A 10-minute look each school term keeps pace with relabelled menus — exactly the habit the *Stay Current* membership automates.

*Items most likely to have moved since June 2026 and worth re-verifying in-app: Pinterest's parental-passcode menu path; BeReal's Friends of Friends and Discovery toggle names and the App Store/Play age ratings.* `[verify]`

---

## Sources

- Pinterest Help — Teen safety options: https://help.pinterest.com/en/article/teen-safety-options
- Pinterest Help — Manage a parental passcode: https://help.pinterest.com/en/article/manage-a-parental-passcode
- Pinterest Help — Resources for parents and caregivers of teens: https://help.pinterest.com/en/article/resources-for-parents-and-caregivers-of-teens
- Pinterest Newsroom — New features enhance teen safety on Pinterest: https://newsroom.pinterest.com/news/new-features-enhance-teen-safety-on-pinterest/
- BeReal Help Centre — Share your Location: https://help.bereal.com/hc/en-us/articles/7531343765405-Share-your-Location
- BeReal Help Centre — Friends of Friends: https://help.bereal.com/hc/en-us/articles/11773264475933-Friends-of-Friends
- BeReal — Privacy: https://bereal.com/privacy
- American Academy of Pediatrics — BeReal details and available settings: https://www.aap.org/en/patient-care/media-and-children/center-of-excellence-on-social-media-and-youth-mental-health/glossary-of-digital-media-platforms/bereal-details-and-available-settings/
- Internet Matters — Pinterest and BeReal parental guides: https://www.internetmatters.org/parental-controls/social-media/
- Childline (NSPCC) — Report Remove: https://www.childline.org.uk/info-advice/bullying-abuse-safety/online-mobile-safety/report-remove/
- CEOP (National Crime Agency) — report grooming/abuse: https://www.ceop.police.uk/ceop-reporting/
- NSPCC — Online safety advice for parents: https://www.nspcc.org.uk/keeping-children-safe/online-safety/
- Ofcom — Online Nation / children's media use research: https://www.ofcom.org.uk/research-and-data/online-research


---

## School-issued devices — what you can and cannot control

**DRAFT — fact-check every setting path, figure and link against the live source before publishing.**

Last drafted: 2026-06

If your child has come home with a school laptop, Chromebook or iPad, the rules are different from a device you bought. The school owns it, the school manages it, and a lot of the controls you are used to are switched off — on purpose. This guide explains how a school-managed device actually works, what you can realistically change at home, and what is simply not yours to change. The aim is calm, accurate expectations, not a workaround list.

---

## How a school device is different

A device you buy at home sits under **your** account — your Apple Account or Google account — and you hold the keys (Apple Screen Time or Google Family Link). A school device is the opposite: it is enrolled in the school's **mobile device management (MDM)** system before it ever reaches your child, and the school's IT team holds the keys.

In plain terms, MDM lets the school decide, centrally and remotely:

- which apps are installed, and which can be removed
- what websites are filtered or blocked
- whether the camera, app store or certain settings are available
- whether the device can be wiped or reset
- in many cases, what activity is logged

This is normal and expected. UK schools follow the Department for Education's **statutory guidance, *Keeping Children Safe in Education* (KCSIE), which schools must follow** — it requires **"appropriate filtering and monitoring"** on the devices and networks children use for learning (with the linked filtering and monitoring standards). The current 2025 edition is in force from 1 September 2025. So the limits you meet on a school device are not the school being unhelpful; they are the school meeting an obligation.

**What this means for you:** the school's controls are designed for the school day and the school's responsibilities. They are not built to reflect *your* family's rules, your bedtime, or your view on screen time at home. That gap is the thing this guide is really about.

---

## What the school typically controls (and you cannot change)

Treat the following as **the school's territory**. You will usually have no setting at home that overrides these, and trying to remove them can break the device or breach the school's acceptable-use agreement.

- **Web filtering** on the school account and, often, anywhere the device is used — including your home Wi-Fi. School filters commonly run at the account or device level, not just on the school network. `[verify]`
- **App installation and removal** — the app store may be locked, or limited to a school-approved list.
- **Monitoring and logging** of activity for safeguarding purposes. Many schools use monitoring software that flags certain searches or content to staff. The detail of what is logged varies by school. `[verify]`
- **The management profile itself** — a configuration profile (Apple) or enrolment (Google/Microsoft) that you cannot remove without the school's permission.
- **Operating-system and security settings** the school has fixed.

Two honest points here:

1. **You generally cannot see the school's monitoring dashboard.** That is the school's safeguarding tool, not a parent dashboard. If you want to know what is monitored, the answer is to **ask the school**, not to look for a hidden setting.
2. **Do not try to remove or bypass the management profile.** Beyond breaching the agreement, it can leave the device unfiltered and unsupported, which helps no one.

---

## What you *can* realistically influence at home

This is the part most parents underestimate — and where your effort is actually well spent. You have real levers, they just sit **around** the device rather than inside it.

**The home network.** Your router and broadband are yours. Most UK broadband providers offer free network-level filtering (often branded "broadband parental controls" or similar) that applies to *every* device on your Wi-Fi, including a school laptop, regardless of the school's own filter. `[verify availability and naming with your specific provider]` This is the single most useful home-side control for a school device. Internet Matters keeps current step-by-step guides for the major UK providers.

**Where and when the device is used.** You decide whether homework happens in a shared room rather than behind a closed bedroom door, and whether the device is charged overnight outside the bedroom. These ordinary household routines do more than most settings, and they are entirely within your control.

**A second, home account or browser — only if the school allows it.** Some schools permit a personal Google profile or a guest mode for home use; many do not. Check the acceptable-use policy before adding anything, and never assume.

**Conversation.** A school device is a good, concrete reason to agree some shared expectations: what it is for, what counts as "finished" homework, and what to do if something upsetting appears. This is the lever with the longest reach, and no one else can pull it for you.

**What you cannot reliably do:** add your own Screen Time or Family Link controls *on top of* a managed device. Where the school's management profile is present, your personal parental-controls account often cannot be enrolled, or will be limited. Treat the home network and household routines as your main tools instead. `[verify behaviour on the school's specific platform]`

---

## The honest limits

A few things worth saying plainly, because over-promising helps nobody:

- **No filter is complete.** School filtering and home network filtering both reduce exposure; neither removes it. Determined workarounds exist, and new content appears faster than any block-list updates. Filtering is a backstop, not a guarantee — pair it with the conversation, not in place of it.
- **"Managed" does not mean "watched in real time."** Monitoring software flags patterns for staff to review; it is not a person reading over your child's shoulder. Do not assume the school will catch everything, or quickly.
- **The school's controls stop at the device's purpose.** A school filter is tuned for safeguarding and learning, not for *your* family's values or screen-time limits. The home network and household routines are where you express those.
- **Things change each term.** Schools update their MDM policies, swap monitoring tools and change app lists. What was blocked in September may not be in January. A short check-in with the school each term keeps your expectations current.

---

## A sensible home setup, in order

1. **Read the school's acceptable-use policy and home-use guidance** before changing anything. It tells you what is allowed and who to contact.
2. **Set up network-level filtering on your home broadband** — this covers the school device on your Wi-Fi. (Internet Matters has provider guides.) `[verify with your provider]`
3. **Agree where and when the device is used** at home — shared space for younger children, out of the bedroom overnight.
4. **Have the short conversation:** what it's for, and what to do if something upsetting shows up.
5. **Ask the school the questions you can't answer from a setting:** What is filtered at home as well as school? What is monitored, and who sees it? Who do I contact if there's a problem with the device?

---

## If something goes wrong

If your child sees something upsetting or someone behaves inappropriately towards them on a school device, you do not need to diagnose it through the device's settings. Two routes:

- **Tell the school's designated safeguarding lead (DSL).** Because the device is managed, the school can see and act on far more than you can, and they have a duty to respond.
- **For wider help and reporting**, these UK services are the right places to go:
  - **In an emergency, or if a child is in immediate danger — call 999.**
  - **CEOP (part of the National Crime Agency)** — to report online sexual abuse or grooming: ceop.police.uk.
  - **Report Remove (Childline + IWF)** — a free tool for under-18s to ask for a nude image or video of themselves to be removed from the internet.
  - **NSPCC Helpline — 0808 800 5000** — for adults worried about a child.
  - **Childline — 0800 1111** — free, confidential support for children and young people.

This guide stops at signposting on purpose. The school and these services are the people equipped to handle an incident — your job is to notice, to talk, and to point your child to the right door.

---

*Items most likely to vary by school or to have moved since June 2026, and worth verifying directly: whether the school filter applies on home Wi-Fi, what monitoring software is used and what it logs, whether personal/home accounts are permitted, your broadband provider's filtering name and steps, and the current edition and wording of the DfE filtering and monitoring standards.* `[verify]`

---

## Sources

- Department for Education — *Keeping Children Safe in Education* (statutory safeguarding guidance, including filtering and monitoring; 2025 edition, in force 1 September 2025): gov.uk
- Department for Education / UK Safer Internet Centre — *Filtering and monitoring standards for schools and colleges*: gov.uk [verify]
- Ofcom — *Children and parents: media use and attitudes* (context on children's device use): ofcom.org.uk
- Internet Matters — *Broadband and mobile network parental controls* (provider-by-provider home network setup guides): internetmatters.org
- NSPCC — *Online safety* advice and Helpline (0808 800 5000): nspcc.org.uk
- CEOP Education / National Crime Agency — reporting and online safety guidance: ceop.police.uk and ceopeducation.co.uk
- Internet Watch Foundation (IWF) with Childline — *Report Remove*: childline.org.uk / iwf.org.uk
- Childline — support for children and young people (0800 1111): childline.org.uk

