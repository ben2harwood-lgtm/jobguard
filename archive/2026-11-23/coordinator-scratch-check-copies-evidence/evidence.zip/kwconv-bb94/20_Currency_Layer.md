# Currency Layer — the renewal engine

**Threats, apps and settings change constantly — that's the honest reason a premium product renews annually, and the thing free static content can't match.** Two parts: (1) an evergreen **"What the law now requires / what's changing"** explainer that ships inside the System and gives every playbook a regulatory spine; (2) the **monthly briefing** system that is the "Stay Current" membership, with a worked example. Confidence tags as elsewhere; re-date everything each cycle.

---

## Part 1 — "What the law now requires / what's changing" (evergreen explainer)

*Last updated 20 June 2026. We keep this current — that's the point of the membership.*

UK online-safety law is mid-transition. Here's where it actually stands, in plain English — and crucially, **what's live now vs what's only announced.**

**Live now (since 25 July 2025): the Online Safety Act child-protection duties.** Platforms that children are likely to use must now use "highly effective age assurance" and keep under-18s away from the most harmful content — pornography, and content that encourages suicide, self-harm or eating disorders. Fines can reach £18m or 10% of global turnover. This is why you're seeing more face-scan and ID age checks across apps. **What it means for you:** protections are improving, but enforcement is still ramping and easily side-stepped — so you still can't outsource this to the platforms. `[V]`

**Announced, not yet law: the under-16 social-media restriction.** In June 2026 the government announced under-16s will be blocked from certain social media, expected around **Spring 2027**, with legislation expected late 2026. Alongside it: restrictions on livestreaming and stranger-contact features for under-18s, and a ban on romantic/sexual AI chatbots for under-18s. **What it means for you:** nothing changes for your household yet — and anyone telling you "under-16s are banned from social media" is jumping the gun. We'll tell you the moment it's real. `[V]`

**The honest takeaway.** Between now and ~Spring 2027 you're in a transition: rules tightening, enforcement patchy, and the day-to-day load still on parents. That's exactly the gap this System is built to cover.

> Why this matters for the product: a dated, accurate "here's the actual legal state" section is something free alarmist content gets *wrong* constantly (it routinely reports announcements as law). Being the calm, correct source is a trust and premium signal. Keep this section ruthlessly current and clearly split "live" from "announced."

---

## Part 2 — The monthly briefing (the membership)

**What it is.** Once a month, a short, calm email: what actually changed in the risks facing teenagers, whether it matters for the member's household, and the one thing (if anything) to do. **What it is not:** a fear digest, a news roundup, or a reason to panic. The discipline: *most months, the honest answer is "nothing urgent — here's one small thing." Say that.*

**Standing structure (keep it tight):**
1. **The one thing worth knowing this month** (1 short item, plain English, sourced).
2. **Does it affect you?** (who it's relevant to — e.g. "only if your teen uses X").
3. **Do this** (one concrete action, or explicitly "nothing to do").
4. **A setting that changed** (if an app moved/added a control — ties to the platform library).
5. **Nothing-to-panic-about line** (proportion, every month).
6. **Next action lands in two weeks** (the fortnightly cadence from the Plan).

**Cadence & sourcing.** Draft from the same trusted sources the library uses (Ofcom, NSPCC, CEOP/NCA, IWF, gov.uk, Internet Matters, Gambling Commission). Keep a running "what changed" log so refreshed playbooks and setting-alerts are easy. Don't automate sending until manual sends prove members open and act (tracker `12`).

---

### Worked example — Monthly Briefing #1

**Subject:** This month: AI fakes, a Roblox change, and one calm thing to do

Hi [FIRST NAME],

The point of this is to save you from doomscrolling safety news. Here's what's worth knowing this month — in proportion.

**The one thing worth knowing.** AI "nudify" apps — which turn an ordinary photo into a fake nude — are the fastest-rising issue for teens, and new UK law now criminalises the tools themselves. Your child can be targeted without ever sending anything, because any public photo is raw material. `[V — IWF; Crime and Policing Act 2026]`

**Does it affect you?** Relevant to every household with a teen who has photos online (so, almost all). More so if your teen's accounts are public.

**Do this — one 5-minute thing.** Have the short version of the conversation: *"any photo can be faked, it's never the victim's fault, and if it ever happens to you or a friend there's a way to get images removed."* (Full script: conversation #5/#6 in your library. Removal route: Report Remove, childline.org.uk/remove.)

**A setting that changed.** Roblox now requires a quick **video-selfie age check to use chat**, and is rolling out new under-16 account types. If your child uses Roblox, it's worth re-opening the parental controls and confirming the maturity and chat settings (your Roblox guide has the steps). `[V]`

**Nothing to panic about.** The under-16 "social media ban" in the headlines is **not in force** — it's an announcement for ~2027. Nothing changes for you today.

**Next.** Your next fortnightly action (the "AI is not your friend" conversation) lands in two weeks. Nothing to do until then.

[NAME]

*General guidance from UK authorities, not a prediction or safeguarding assessment. Emergency signpost: [LINK].*

---

### Briefing topic backlog (so you're never scrambling for content)

Seed list, rotate one per month, refresh with whatever's genuinely new:

- AI nudify/deepfake law + removal routes *(used above)*
- Roblox age-check + account-type changes
- The under-16 restriction — status check (update as it firms up toward 2027)
- Instagram/Meta AI age-estimation — what it does to your teen's account
- Snapchat Family Centre's new insights — what you can now see
- Money-muling recruitment in the new school year (seasonal: September)
- Loot boxes & in-game spending before the holidays (seasonal: November)
- Sextortion awareness (NCA campaign refreshes)
- "Finsta"/second accounts and why pairing isn't the whole answer
- New-school-year device-and-settings reset checklist (seasonal: September)
- Exam-season screen-time & sleep (seasonal: spring)
- AI companion apps — what's changed since the under-18 rules

*Each briefing should take <30 min to produce once the backlog and sources are set up — it's curation, not original research.*
