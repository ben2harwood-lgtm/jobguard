# Age-Band Quick-Reference Cards + Weekend Checklists (System library)

**Generated 20 Jun 2026. One printable card per age band (5–18), each ending with a 'Do this weekend' checklist — the finishable artefact promised in `26` §3. Fill `Bearings`/`[DATE]`.**

---

## Ages 5-10

# Ages 5–10 Quick-Reference Card — "The first tablet / Foundations"

**Bearings** · Age-band card · Posture: **CO-USE** · Updated [DATE]

---

**What matters most at this age.** These are the on-ramp years: a shared family tablet, YouTube Kids, simple games and — increasingly — Roblox. The single best habit you can build now is calm co-use: the device is something you use *with* them, in shared rooms, not something they take away alone. Front-load the controls before you hand the tablet over, then sit alongside. The aim is to build calm habits early, not to lock a child down.

**The settings worth your time** *(set the device layer first; a menu may have moved — search the setting name or use the platform's official help page):*
- **Apple Screen Time** or **Google Family Link** — downtime, app limits and age/content ratings, set before handover → `/library/platforms/apple-screen-time` · `/library/platforms/google-family-link`
- **Ask-to-Buy / purchase approval ON** — so buying anything in a game or app needs a grown-up's tap, not theirs.
- **YouTube Kids, not the standard app** — autoplay off, approved/curated-content mode on → `/library/platforms/youtube`
- **Roblox** — youngest-appropriate account type, chat off or restricted, and a spend cap → `/library/platforms/roblox`
- **Network level** — SafeSearch on and the broadband adult-content filter on; keep the tablet a shared device used in shared rooms.

**The conversations that matter** *(keep them simple and age-right →* `/library/conversations`*):*
- **"Tell me if anything is weird or scary — you won't be in trouble."** The cornerstone: come and find me, you're never in trouble for telling.
- **"Things that ask for money are a grown-up's job."** If a game asks to buy something, stop and come and get me.
- **"We don't chat with people we don't know in games"** — and you tell me if someone you don't know tries to talk to you. And: **"the tablet sleeps outside the bedroom."**

**If something's wrong.** Sit with them and see what they saw — most things at this age are accidental and first-time. Close or block it together and adjust the setting. **Immediate danger: call 999.** A worried or upset child, or you're not sure: **Childline 0800 1111** (free, under-19s, 24/7). An adult contacting or pressuring your child: **CEOP** (ceop.police.uk). Worried but not urgent: **NSPCC 0808 800 5000**. Full list: **Bearings/emergency**. A calm response teaches them that coming to you works — the habit you most want carried into the teen years.

---

### Do this weekend
- [ ] Set up **Apple Screen Time** or **Google Family Link** with downtime and app limits — *before* handing the tablet back.
- [ ] Turn **Ask-to-Buy / purchase approval ON**.
- [ ] Switch to **YouTube Kids**, autoplay **off**, approved-content mode **on**.
- [ ] Set Roblox to the youngest-appropriate account, chat **off/restricted**, spend cap on.
- [ ] Turn on **SafeSearch** and the **broadband adult-content filter**.
- [ ] Agree the family rule: the **tablet sleeps outside the bedroom**, and "you can tell me anything — you won't be in trouble."

---

## Ages 11-12

# Bearings — Quick-Reference Card: Ages 11–12

**"First device" · Posture: CO-USE** · Updated [DATE]

---

### What matters most at this age
Starting secondary school brings a jump in varied use — YouTube, WhatsApp, gaming (Roblox, Minecraft), and often a first smartphone. The desire for independence runs ahead of self-control, so you stay hands-on: co-using, not policing. Honest birthdays are still likely — keep them, because age-specific protections depend on the real date of birth.

### Priority settings & actions
- **Set the device layer first** — Apple Screen Time ([/library/platforms/apple-screen-time](/library/platforms/apple-screen-time)) or Google Family Link ([/library/platforms/google-family-link](/library/platforms/google-family-link)): limits, downtime, Ask-to-Buy, content filters. Lock it with a passcode they don't know.
- **Turn on SafeSearch and your broadband provider's adult-content filter** at the router level ([/library/platforms/google-family-link](/library/platforms/google-family-link) covers SafeSearch).
- **Roblox parental controls + a spend cap** to limit in-game spending and loot boxes ([/library/platforms/roblox](/library/platforms/roblox)). *Roblox changed a lot in 2026 — if a menu has moved, here's the official menu: about.roblox.com/parental-controls*
- **Use YouTube Kids or a supervised account** rather than standard YouTube ([/library/platforms/youtube](/library/platforms/youtube)).
- **Keep social apps on shared devices in shared rooms**, and charge devices outside the bedroom overnight.

### Key conversations
- **The cornerstone: "come to me, and you won't be in trouble."** ([/library/conversations/cornerstone](/library/conversations/cornerstone)) — CEOP-NCA's evidence points to this as the single most protective line.
- **New-app check** — talk through any app before they download it ([/library/conversations/new-app-check](/library/conversations/new-app-check)).
- **Strangers / early grooming** — who messages them, and what to do ([/library/conversations/strangers-grooming](/library/conversations/strangers-grooming)).

### If something's wrong
You're hands-on now — sit with them, screenshot, and block/report together. **Report abuse or grooming to CEOP (CEOP-NCA): ceop.police.uk/safety-centre.** **Worried about a child? NSPCC: 0808 800 5000.** **Childline (for them): 0800 1111.** **Nude images of an under-18 shared or threatened — Report Remove (IWF/Childline).** In immediate danger, call **999**. See [/emergency](/emergency).

---

### Do this weekend
- [ ] Lock Screen Time or Family Link with a passcode your child doesn't know
- [ ] Switch on SafeSearch and your broadband adult-content filter
- [ ] Set a Roblox spend cap and check parental controls
- [ ] Move YouTube to YouTube Kids or a supervised account
- [ ] Agree where devices charge overnight (outside the bedroom)
- [ ] Say the cornerstone line out loud: "You can always come to me, and you won't be in trouble."

---

## Ages 13-14

# Bearings — Quick-Reference Card: Ages 13–14

**The threshold year · Co-set** · Updated **[DATE]**

### What matters most at this age
They've hit the 13+ minimum, so Instagram, Snapchat and TikTok arrive fast — and this is the developmental peak of peer-influence and reward-seeking. Your posture shifts from "here are the rules" to "let's agree them together." The single most useful thing you do here isn't a setting; it's staying the calm, non-blaming person they'd come to.

### Priority settings & actions (do these first)
- **Set the real birthday on every app** — most teen protections key off it. → `/library/platforms`
- **Snapchat:** turn on Family Centre, **Ghost Mode**, and set Contact-Me to *Friends only*. → `/library/platforms/snapchat`
- **Instagram:** link a **Teen Account** for supervision; confirm private profile + strict-message defaults. → `/library/platforms/instagram`
- **TikTok:** set up **Family Pairing**; confirm under-16 no-DM and private defaults. *(TikTok moves menus often — if a path has moved, search the setting name in-app or see tiktok.com/safety/en/guardians-guide.)* → `/library/platforms/tiktok`
- **Keep the device-layer limits running** (Apple Screen Time / Google Family Link) and a phone-out-of-the-bedroom-at-night habit. → `/library/platforms`

### Key conversations to have
- **The cornerstone — "come to me, you won't be in trouble."** Lead here, and repeat it. → `/library/conversations`
- **Sextortion — have this one early.** Name the scam plainly so it isn't a shock if it lands. → `/library/conversations`
- **AI chatbots & companions, plus screen-time set together** — agree limits collaboratively, not imposed. → `/library/conversations`

### If something's wrong
**Immediate danger: call 999.** Nude image of an under-18 shared or threatened: **Childline Report Remove** (childline.org.uk/remove) and **Childline 0800 1111**. Online sexual pressure or grooming: **CEOP** (ceop.police.uk/Safety-Centre). General worry: **NSPCC 0808 800 5000**. Full routing: **Bearings/emergency**. For sextortion: *stop, don't pay, don't delete, screenshot, block, tell — and report.*

---

**Do this weekend**
- [ ] Check the **real birthday** is set on every app they use
- [ ] Snapchat: Family Centre on, **Ghost Mode** on, Contact-Me = Friends
- [ ] Instagram: Teen Account linked; profile private + messaging strict
- [ ] TikTok: Family Pairing set; confirm no-DM / private defaults
- [ ] Say the cornerstone line out loud — "if anything goes wrong online, come to me, you won't be in trouble"
- [ ] Save **Bearings/emergency** and **999 · Childline 0800 1111 · CEOP** where you'll find them fast

---

## Ages 15-16

# Bearings — Quick-Reference Card: Ages 15–16

**Autonomy / GCSE years · Posture: coach** · Updated [DATE]

### What matters most at this age
Use is heavier and more private — Snapchat, Instagram, Discord, group chats — and romantic and sexual life has moved substantially online. Self-control is catching up but reward-sensitivity stays high. Your job now is supervision *with* conversation, not control: stay the person they come back to.

### Priority settings & actions
- **Hand day-to-day screen-time to them, keep a parental backstop** at the device layer — review together weekly. → [/library/platforms/apple-screen-time](/library/platforms/apple-screen-time) · [/library/platforms/google-family-link](/library/platforms/google-family-link)
- **Review privacy & contact settings *with* them, not over them** — agree who can message and find them. → [/library/platforms/snapchat](/library/platforms/snapchat) · [/library/platforms/instagram](/library/platforms/instagram)
- **Set up Discord Family Centre if they use it** — you see who and where, never message content. → [/library/platforms/discord](/library/platforms/discord)
- **Keep purchase controls on** as a money-muling and scam backstop. → [/library/platforms/apple-screen-time](/library/platforms/apple-screen-time)

*Menus move often — if a path has changed, here's the current menu: parents.snapchat.com · familycenter.meta.com · support.discord.com.*

### Key conversations
- **The cornerstone — "come to me, you won't be in trouble."** Lead here, return often. → [/library/conversations/cornerstone](/library/conversations/cornerstone)
- **Scams & money, including money-muling** — "never let anyone use your bank account for a fee; it's a crime, in your name." → [/library/conversations/scams-and-money](/library/conversations/scams-and-money)
- **Mistakes & repair** — that they can tell you about a wrong turn and you'll help fix it. → [/library/conversations/mistakes-and-repair](/library/conversations/mistakes-and-repair)

### If something's wrong
Coach, don't seize control — help them think it through and point to the route. **Sextortion / leaked nudes (under-18): stop, don't pay, don't delete, block, report — Report Remove at childline.org.uk/remove · CEOP at ceop.police.uk/Safety-Centre.** Childline **0800 1111** · Samaritans **116 123** · 999 if there's immediate danger. Full routes: [Bearings/emergency](/emergency)

---

**Do this weekend**
- [ ] Confirm the device-layer backstop is on, then hand the day-to-day screen-time tool to them
- [ ] Sit down together and review privacy & contact settings on the app they use most
- [ ] Set up Discord Family Centre (if used) and check purchase controls are on
- [ ] Say the cornerstone line out loud: "Whatever happens, come to me and you won't be in trouble"
- [ ] Agree a shared "what we'd do if…" plan for a leaked image or sextortion message
- [ ] Save Report Remove, Childline 0800 1111 and Bearings/emergency where you'll find them fast

---

## Ages 17-18

# Bearings — Quick-Reference Card · Age 17–18

**"Launch / near-adult" · Your posture: consult**
*Updated [DATE]*

---

## What matters most at this age
They're running a full adult pattern online and are about to age out of child-specific protections (e.g. Report Remove is under-18; at 18 they move to adult routes). Decisions are now largely self-governed. Your job shifts from setting rules to being the trusted sounding board they choose to call.

## Priority actions (mostly self-managed — review together)
- **Turn on two-factor authentication** on their key accounts — [/library/platforms/two-factor-authentication](/library/platforms/two-factor-authentication)
- **Set unique passwords** + a password manager, following NCSC guidance — [/library/platforms/account-security](/library/platforms/account-security)
- **Review their public footprint together** — "what would a university or employer find?" — [/library/platforms/footprint-review](/library/platforms/footprint-review)
- **Bookmark the adult reporting routes:** StopNCII, Action Fraud, Revenge Porn Helpline — [/library/platforms/adult-reporting-routes](/library/platforms/adult-reporting-routes)

*(Settings menus may have moved — here's the official menu: ncsc.gov.uk/collection/top-tips-for-staying-secure-online)*

## Key conversations to have
- **#1 The cornerstone — "come to me, you won't be in trouble"** (never expires) — [/library/conversations/1-cornerstone](/library/conversations/1-cornerstone)
- **#9 Scams & money — adult-grade** (crypto "flips", fake job DMs, money-muling) — [/library/conversations/9-scams-money](/library/conversations/9-scams-money)
- **#4 Sextortion — adult routes** (StopNCII rather than Report Remove) — [/library/conversations/4-sextortion](/library/conversations/4-sextortion)
- **#13 Mistakes & repair** + a footprint/reputation talk — [/library/conversations/13-mistakes-repair](/library/conversations/13-mistakes-repair)

## If something's wrong
- **Immediate danger:** 999 · non-urgent police 101
- **Fraud / scams:** Action Fraud — reportfraud.police.uk · 0300 123 2040 (Scotland: Police Scotland 101)
- **Image shared without consent (18+):** StopNCII.org · Revenge Porn Helpline 0345 6000 459
- **Worried, any reason:** Samaritans 116 123 · NSPCC 0808 800 5000
- More routes: [Bearings/emergency](/emergency)

---

## Do this weekend
- [ ] Switch on 2FA on email + main social and banking apps
- [ ] Move passwords into a manager; make the important ones unique
- [ ] Sit down and search their own name together — note anything to clean up
- [ ] Save StopNCII, Action Fraud and the Revenge Porn Helpline to their phone
- [ ] Have conversation #1 — restate the open door, no judgement, any time
- [ ] Talk through one real scam example (#9) before they next job-hunt

---
