# AI Safety Course - Readiness Self-Check Spec

*Created 2026-06-27. Status: Phase 3 draft for the navigation-only Readiness Self-Check described in `62_AI_Safety_Course_Phase3_Tools_Spec.md`. This is not a diagnostic, risk assessment, safeguarding assessment, child profile, or outcome claim. It must remain unpublished until wording and route-out behaviour are reviewed.*

## Purpose

The Readiness Self-Check helps a parent choose which AI Safety Course module or printable asset to use next. It is a navigation tool only. It does not score the child, rate household risk, diagnose a problem, judge real messages or images, predict harm, monitor anyone, or guarantee outcomes. [GAP-001, GAP-007, AIC-003, ORW-004]

The result language is:

- "Start with..."
- "Print or complete..."
- "Review next..."
- "If this is already happening, stop and use the routing page."

The result language is not:

- "safe" or "unsafe";
- "high risk" or "low risk";
- "your child is...";
- "this identifies...";
- "this means grooming/scam/deepfake";
- "this means harm will not happen."

## Boundary

The self-check uses selection-only prompts. It must not ask a parent to paste, upload, describe, summarise, or classify a real message, image, voice note, screenshot, schoolwork item, private chat, prompt, account, or incident. It must not ask for a child name, date of birth, school, handle, location, contact detail, or identifying event detail. [PRI-003, PRI-004, GRM-002, VBT-004, GAP-013]

If a parent selects an "already happening" answer, the tool ends the check and links to the ungated emergency signpost or reviewed routing card. It does not ask follow-up questions. [RTE-007]

## Flow

1. Parent chooses an age band.
2. Parent chooses the household rule they most want to settle this week.
3. Parent chooses the situation they feel least ready to explain.
4. Parent chooses the asset that would make the next conversation easier.
5. Parent answers one route-out gate: "Is something already happening now?"
6. Tool returns one primary module, one printable asset, and one next-step line.

No additive points, no numeric output, no colour-coded risk, no child profile. [AIC-003, ORW-004, GAP-007]

## Prompt Set

| Prompt ID | Prompt | Allowed answers | Handling |
|---|---|---|---|
| SELF-AGE | Which age band are you planning for? | 9-11; 12-14; 15-17 | Used only to adapt examples and choose age-relevant clauses. |
| SELF-RULE | Which household rule do you most want to settle this week? | Private stays private; Tool, not person; Verify before trust; Schoolwork ask-first; Image and media boundaries; Contact, pressure and scams | Maps to the matching module and asset. |
| SELF-WORRY | Which situation do you feel least ready to explain calmly? | AI homework answer; Chatbot privacy; AI companion use; Fake image or voice; Unknown contact pressure; Urgent money or code request; Upsetting content | Maps to one supporting scenario family and route note. |
| SELF-ASSET | Which asset would help you finish the next conversation? | Family AI Safety Agreement; Private Stays Private card; Tool, Not Person script; Verify Before Trust sheet; Schoolwork Ask-First sheet; Synthetic-media rules card; Contact and scams pause card; Incident-routing card | Returns the chosen printable plus one suggested companion asset. |
| SELF-LIVE | Is something already happening now? | No, I am planning ahead; Yes, there may be immediate danger; Yes, this involves sexual contact, coercion, image pressure, or online sexual abuse; Yes, this involves fraud, money, codes, or account access; Yes, this is school-linked or peer-linked; Yes, I am worried about wellbeing or harmful content | "No" continues. Any "Yes" ends the self-check and routes out. |

## Result Mapping

| Selected rule | Primary module | Primary asset | Claim IDs |
|---|---|---|---|
| Private stays private | Module 2: Private Stays Private | Private Stays Private card | PRI-001, PRI-002, PRI-004 |
| Tool, not person | Module 3: Tool, Not Person | Tool, Not Person script | AIC-001, AIC-003, HAW-002 |
| Verify before trust | Module 4: Verify Before Trust | Verify Before Trust sheet | VBT-001, VBT-002, HCM-004 |
| Schoolwork ask-first | Module 5: Schoolwork Boundaries | Schoolwork Ask-First sheet | ORW-001, ORW-003, VBT-002 |
| Image and media boundaries | Module 6: Synthetic Media, Consent, And Image Risk | Synthetic-media rules card | SMI-001, SMI-002, SMI-004, SMI-006 |
| Contact, pressure and scams | Module 7: Contact, Pressure, Scams, And Routing | Contact and scams pause card | GRM-001, GRM-003, SCF-001, SCF-003 |

## Worry Mapping

| Selected worry | Support module | Suggested scenario family | Tool note |
|---|---|---|---|
| AI homework answer | Module 4 and Module 5 | Confident AI answer | Check source, evidence, date, consequence, and school policy. [VBT-001, ORW-003] |
| Chatbot privacy | Module 2 | Private disclosure into chatbot | Use made-up examples only; real worries go to trusted people. [PRI-001, PRI-002] |
| AI companion use | Module 3 | Companion-style attachment | Watchpoints are conversation prompts, not diagnosis. [AIC-003, ORW-004] |
| Fake image or voice | Module 1 and Module 6 | Convincing generated media | Pause before forwarding; check source and context. [SMI-001, HAW-003] |
| Unknown contact pressure | Module 7 | Move-apps secrecy pressure | Unknown person plus secrecy or pressure means show a trusted adult. [GRM-001, GRM-003] |
| Urgent money or code request | Module 7 | Urgent money or code request | Verify through a separate route before anyone acts. [SCF-001, SCF-002] |
| Upsetting content | Module 3 and Module 7 | Upsetting or harmful content | Stop the interaction and decide whether this is a settings/reporting issue or a route-now concern. [HCM-003, HCM-005] |

## Route-Out Mapping

| Live answer | Result |
|---|---|
| No, I am planning ahead | Continue to module/asset result. |
| Yes, there may be immediate danger | End the self-check. Show the emergency signpost and 999 route. [RTE-001] |
| Yes, this involves sexual contact, coercion, image pressure, or online sexual abuse | End the self-check. Show CEOP, Report Remove/IWF/Childline where eligible, school DSL, and police routing note. Include no-save/no-screenshot/no-copy/no-download/no-forward wording for suspected under-18 sexual images. [RTE-002, RTE-003, RTE-006, GAP-015] |
| Yes, this involves fraud, money, codes, or account access | End the self-check. Show Report Fraud for England/Wales/Northern Ireland, Police Scotland 101 in Scotland, bank/platform, and 999 if immediate danger. [RTE-001, RTE-005] |
| Yes, this is school-linked or peer-linked | End the self-check. Show school DSL or equivalent route, plus emergency/specialist routes if urgent or sexual/coercive. [RTE-006, RTE-007] |
| Yes, I am worried about wellbeing or harmful content | End the self-check. Show Childline, NSPCC, school DSL, platform report, and 999 if immediate danger. [RTE-001, RTE-004, RTE-006, RTE-007] |

## Result Copy Template

For planning-ahead results:

> Start with {primary_module}. It matches the household rule you want to settle this week: {selected_rule}. Print or complete {primary_asset}, then use {support_module_or_scenario} if you want a practice example before the conversation.

Footer:

> This self-check is for education and planning. It does not assess a child, judge a live situation, monitor anyone, or guarantee outcomes. If something is happening now, stop using the self-check and use the emergency signpost.

For route-out results:

> Stop the self-check and use the routing page. This tool does not ask follow-up questions about live situations.

Image-risk addition:

> Do not save, screenshot, copy, download, forward, or ask a child to resend suspected nude or sexual images of under-18s.

[GAP-001, SMI-002, SMI-006, RTE-007, GAP-015]

## Implementation Shape

- Static data only.
- Selection-only UI.
- No free text.
- No upload.
- No account creation.
- No localStorage, sessionStorage, IndexedDB, cookies, or server writes for selected answers.
- If analytics are later added, track only `self_check_started` and `self_check_completed`, with no answer payload.
- No AI calls, inference calls, verdict engine, or generated advice.
- Keep unpublished until wording review clears the result and route-out copy.

## Acceptance Criteria

- Parent can complete the self-check using selections only.
- Planning-ahead results return one primary module, one primary asset, and one supporting scenario or module.
- Any live-situation answer ends the flow and links to routing.
- No scores, risk bands, child profiles, diagnostic labels, or verdict words are shown as results.
- No child PII or incident detail can be entered.
- Content lint passes.
- Structural tests confirm the draft data is not exposed as a library route or hub card until approved.

## Human Review Gate

Before release:

- Safeguarding reviewer clears all route-out answers and the "already happening" stop logic.
- Legal reviewer clears image-risk wording and under-18 image carve-out.
- Route names, URLs, eligibility, and jurisdiction notes are re-checked.
- Privacy/data wording is checked so the no-storage design is not represented as a legal compliance conclusion.
