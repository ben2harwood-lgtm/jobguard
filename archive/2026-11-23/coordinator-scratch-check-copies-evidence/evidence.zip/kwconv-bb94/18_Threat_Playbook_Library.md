# Threat & Scenario Playbook Library

**Twelve playbooks + three foundations modules. Each playbook follows one arc: what it is → the UK picture now → warning signs → prevention → what to do if it's already happening (calm steps + signpost only).** Prevention-framed, never alarmist; emergencies route to authorities, never bespoke intervention. Confidence: `[V]` verified to named UK source · `[PV]` partly verified · `[NV]` re-check before publishing. Helpline numbers and the under-16 timeline should be link-checked at publish time.

> **The legal backdrop (put a short version at the top of the library).** Online Safety Act child-protection duties have been live since **25 July 2025** — platforms likely accessed by UK children must use "highly effective age assurance" and keep under-18s from the most harmful content (pornography; suicide/self-harm/eating-disorder content), with fines up to £18m or 10% of global turnover. An **under-16 social-media restriction** is expected around **Spring 2027** (legislation expected late 2026), alongside limits on livestreaming/stranger-contact for under-18s and a ban on romantic/sexual AI chatbots for under-18s. Market this as a **transition-period** resource: rules are tightening but not fully in force, and parents still carry the load until then. `[V]`

---

## CORE FIVE — refresh notes (full content in `06`)

Light here because they're already detailed; each carries the same arc in the live library.

- **Sextortion.** Financially-motivated; targets teen boys 14–17; "nine reports a week" to Report Remove. *If it's happening:* stop, don't pay, don't delete, screenshot, tell a trusted adult → **CEOP** / **Report Remove**; 999 if immediate risk. `[V]`
- **AI deepfake / nudify.** Any photo can be made into a fake nude; making one of a classmate is a crime. *If it's happening:* **Report Remove** works for AI-generated nude imagery of under-18s too; report the platform. `[V]`
- **Grooming & coerced app migration.** Sexual Communication with a Child offences topped 7,000 in a year (~+89% since 2017/18), ~40–48% on Snapchat. Red flag: "move to a private/disappearing app." *If it's happening:* **CEOP**; 999 if immediate danger. `[V]`
- **Scams, fraud & money-muling.** Fraud is among the most-encountered online harms; "easy money for using your account" is mule recruitment (a crime in the child's name). *If it's happening:* **Action Fraud 0300 123 2040**; the bank. `[V]`
- **AI companions / chatbots.** Dependency and unsafe advice; under-18 romantic/companion bots being banned. *If it's happening:* report the platform / Report Harmful Content; reinforce "AI isn't a friend or therapist." `[V]`

---

## PLAYBOOK A — Cyberbullying & peer-on-peer abuse

**What it is.** Bullying through phones, games and social media — nasty group chats, exclusion, rumours, impersonation, pile-ons, harassment; also peer sexual harassment and coercion.

**UK picture 2025–26.** 39% of 8–17s have experienced bullying; of those, **84% experienced it on a device** vs 61% face-to-face. Most common channels: messaging apps (56%), social media (43%), games (30%). Prevalence roughly **doubles from age 11 to 15**. Bullying was the **single biggest reason** children contacted Childline (6,617 counselling sessions in 2024/25). `[V — Ofcom; NSPCC/Childline]` `[PV on the 2022-era channel split — refresh before print]`

**Warning signs.** Sudden reluctance to use the phone (or compulsive checking with visible distress); withdrawing from friends; mood crash after going online; faking illness to avoid school; deleting or creating secret accounts; unexplained anger or tears.

**Prevention.** Agree early they can show you anything **without losing the device** (the single most evidence-aligned move — fear of confiscation is why teens stay silent). Set up blocking/reporting on each app *together*. Keep group-chat drama in perspective. Model not retaliating. Know the school's anti-bullying policy.

**If it's already happening.**
1. **Screenshot first — don't delete.** Evidence vanishes when you block.
2. **Then block and report in-app.**
3. **Don't reply or retaliate.**
4. **Tell the school** if classmates are involved — schools must act on bullying affecting a pupil's wellbeing, even off-site.
5. **Signpost:** **Report Harmful Content** (reportharmfulcontent.com, 13+, run by SWGfL) helps remove non-criminal harmful content. If it crosses into **harassment, threats or hate → police 101** (999 if immediate). **Childline 0800 1111** for the child. `[V]`

---

## PLAYBOOK B — Self-harm, suicide & eating-disorder content

*Signpost only — no bespoke crisis intervention. This is a sensitive topic; if you're personally affected, the helplines below are there for you too.*

**What it is.** Online content that depicts, encourages or normalises self-harm, suicide, or eating disorders — including "pro-ana"/"pro-mia" communities that frame an eating disorder as a lifestyle. Risk runs both ways: a teen may *encounter* it, or may be *seeking* it because they're already struggling.

**UK picture 2025–26.** Now **named harm categories under the Online Safety Act** — since 25 July 2025 platforms must use age assurance to keep under-18s from suicide/self-harm/ED content; enforcement is ramping but incomplete. ~**10% of 9–16s** have seen eating-disorder content (girls more than boys). Instagram/Facebook began blocking under-18s from this content even from followed accounts. `[V — Ofcom; Beat]`

**Warning signs.** Covering arms/legs in warm weather; unexplained cuts/burns; withdrawal, hopelessness; giving away possessions; big changes in eating, secrecy around food, excessive exercise, frequent bathroom trips after meals; following accounts with coded ED/self-harm language.

**Prevention.** Turn on sensitive-content controls *with* them. Talk openly — **asking about suicidal feelings does not plant the idea** (a key myth to dispel). Keep means of self-harm less accessible. Build offline coping and connection. Note that *some* peer content is genuinely supportive, so the goal is reducing *harmful* exposure, not policing all discussion of feelings.

**If it's already happening.**
1. **Stay calm and non-judgemental** — open with curiosity ("I've noticed… I'm here, not angry").
2. **Don't force instant deletion** of an online community a struggling teen leans on — work on safer settings and reducing harmful feeds.
3. **Report the harmful content** in-app.
4. **Signpost by severity:** immediate danger → **999**; urgent mental-health crisis → **NHS 111** (select mental health, 24/7) or A&E; **Samaritans 116 123** (24/7, for them or you); **Shout — text 85258**; eating disorders → **Beat 0808 801 0677**; **Childline 0800 1111**; non-urgent route via the **GP** to CAMHS. `[V]`

---

## PLAYBOOK C — Pornography exposure

**What it is.** Teens encountering pornography — increasingly **by accident** via feeds and links — and the way violent/degrading content shapes expectations about sex, consent and bodies.

**UK picture 2025–26.** Average age of first exposure is **13** (10% by 9, 27% by 11). 2025 data: **70%** had seen porn before 18 (up from 64%), **accidental** exposure up from 38% to **59%**, and **79%** had seen violent pornography before 18. The platform young people most often saw it on was **X/Twitter**. OSA age-checks for porn sites came into force **25 July 2025** (though social feeds and VPNs remain sideways routes). `[V — Children's Commissioner; Ofcom]`

**Warning signs.** Often *not* signalled by obvious behaviour change (so much is accidental) — prevention rests on conversation, not surveillance. Possible flags: parroting degrading attitudes about sex/consent; newly cleared browser history; distress after "something they saw."

**Prevention.** Start age-appropriate conversations *before* 11–13. Set network-level filters (broadband adult-content filter, **SafeSearch**, restricted modes). Use the new age-check era as a natural hook. Frame it as "porn isn't a documentary about real sex," with consent at the centre. Reassure that **accidental exposure isn't their fault** so they'll tell you.

**If it's already happening.**
1. **Don't shame or punish** — especially for accidental exposure; shame guarantees silence.
2. **Have the conversation, not the lecture:** what did they see, how did it feel, what questions do they have.
3. **Tighten filters** on network and devices together.
4. **Signpost:** **Internet Matters** and **Childnet** have age-banded scripts; **CEOP/Thinkuknow** for harmful sexual behaviour. If a child was *sent* porn by an adult, or shows harmful sexual behaviour toward another child → safeguarding: **CEOP** / school DSL / **NSPCC 0808 800 5000**. `[V]`

---

## PLAYBOOK D — Gambling, loot boxes & in-game spending

**What it is.** Gambling-style mechanics reaching teens — **loot boxes** (paying for a randomised reward), skins betting, in-game currencies — plus underage betting. The harm is both money lost and **conditioning toward gambling**.

**UK picture 2025–26.** Gambling among **11–17s rose to 30% in 2025** (from 27%); **1.2%** are problem gamblers. **23% of 11–16s have paid to open loot boxes**, which is associated with **4.4× higher odds** of problem gambling. Loot boxes are **not currently regulated as gambling** in the UK — so parents must self-manage this gap. `[V — Gambling Commission]`

**Warning signs.** Money disappearing / requests for gift cards or top-ups; secrecy about spending; unexplained card charges; distress or chasing behaviour after gaming; talk of "wins," "odds," or owing other players; selling things for in-game currency.

**Prevention.** **Turn off in-app purchases / require a password for every purchase** (Apple Screen Time, Google Play, console family settings). Remove stored cards; use prepaid/allowance models. Talk about how loot boxes are *designed* to feel like a near-miss win. Check **PEGI** ratings and the "in-game purchases (random items)" descriptor.

**If it's already happening.**
1. **Remove the payment method** and audit recent transactions.
2. **Check refunds** — Apple/Google/console stores can sometimes refund child or unauthorised purchases; the bank may dispute charges.
3. **Don't just confiscate** — talk about *why* it pulled them in.
4. **Signpost:** **GambleAware** / **National Gambling Helpline 0808 8020 133** (24/7, supports under-18s and worried parents); **YGAM** and **GamCare** youth resources. `[V]`

---

## PLAYBOOK E — Sexting & peer image-sharing ("nudes")

**What it is.** Young people creating/sharing nude or sexual images of themselves — often consensually with a partner — which can then be forwarded, leaked, or used to coerce. Legally fraught: a nude image of an under-18 is technically illegal indecent imagery even if the teen took it themselves.

**UK picture 2025–26.** "Self-generated" imagery now **dominates** what the IWF tackles: ~**85%** of actioned reports in 2025 contained at least one self-generated image. **Report Remove** had 1,894 child reports in 2025 and is rising. Overlaps heavily with sextortion. `[V — IWF]`

**Warning signs.** Secrecy or panic around the phone; a new/older or online-only "boyfriend/girlfriend"; sudden fear of a specific person; distress after a breakup; mentions of an image "getting out."

**Prevention.** Explain the law and permanence ("once it's sent, you've lost control of it") **without** fear-mongering. Emphasise that **if it goes wrong they can come to you and won't be in trouble** — UK police use **Outcome 21** to avoid criminalising children in consensual-sharing cases, so the reassurance is honest. Teach that requests for images are a red flag, and that re-sharing someone else's image is itself harmful and potentially illegal.

**If it's already happening.**
1. **Stay calm — do not blame the child.** Their fear of your reaction is exactly what predators exploit.
2. **Screenshot threats** (don't delete) — but **do not** save or forward the image itself.
3. **Use Report Remove** (report-remove.iwf.org.uk) — an under-18 can report their own nude image to have it taken down and pre-emptively blocked.
4. **Report the platform**; if an adult or coercion/blackmail is involved → **CEOP** and 101/999.
5. **Signpost:** **Childline 0800 1111**; **CEOP/Thinkuknow**. Reassure: children are **not** prosecuted for being victims. `[V]`

---

## PLAYBOOK F — Radicalisation & extremist content *(concise)*

**What it is.** Online content and communities pulling young people toward extremist ideologies or a **fixation with violence** — increasingly mixed, nihilistic, gore-and-violence-obsessed subcultures rather than one clear cause.

**UK picture 2025–26.** Prevent referrals rose to **142 per million** (education made 36% of referrals). **MI5 investigations into under-18s have tripled in three years**, including young people radicalised online with **no fixed ideology, just a fixation with violence**. New Youth Diversion Orders being created. `[V — gov.uk Prevent stats]`

**Warning signs.** Sudden absolutist "us vs them" language; new secrecy about online groups; fixation with violence/weapons/mass-casualty events; demonising a group; withdrawal; switching to encrypted/fringe platforms; conspiracy-extremism crossover.

**Prevention.** Keep dialogue open and non-judgemental (debate, don't shut down). Build critical thinking. Know who they talk to and where. Don't over-react to an edgy phase, but don't ignore genuine escalation. Use **Educate Against Hate** (gov.uk) resources.

**If you're worried.**
1. **Don't confront aggressively or cut off their relationships abruptly** — isolation deepens it.
2. **Keep talking; note what you're seeing** (platforms, content).
3. **Signpost: ACT Early** — the police service for worried families: **actearly.uk** / **0800 011 3764** (confidential; support, not prosecution, for most cases). **999** if there's an imminent threat to life. `[V]`

---

## PLAYBOOK G — Screen-time, sleep & digital wellbeing

**What it is.** Not one "threat" but the everyday battleground — how much, *what kind* of use, and the knock-on effects on sleep, mood, attention and real-world connection. Usually the topic that brings parents through the door.

**UK picture 2025–26.** Children spend **~23 hours/week online** (up from 16 in 2022). Night-time use is significant: **15–24%** of 8–14s' time on YouTube/Snap/TikTok/WhatsApp happens 9pm–5am; **59%** of children stay up late on a device. The evidence-led message: **how** they use it matters more than raw hours (active/creative beats passive scrolling). `[V — Ofcom; Internet Matters]`

**Warning signs.** Persistent tiredness, falling asleep in class, dropping grades; irritability/anxiety when offline; phone in the bedroom overnight; meals and hobbies displaced; "five more minutes" becoming conflict.

**Prevention.** **Charge phones outside the bedroom overnight** (highest-impact single habit). Enable Sleep/Do Not Disturb and bedtime modes. Different limits for school vs non-school nights. Co-create rules. Protect "green time" and family meals. Use Screen Time / Family Link for visibility, not just blocking. Swap passive scroll for active use.

**If it's already a problem.**
1. **Avoid the all-or-nothing battle** — sudden total bans usually escalate conflict; negotiate.
2. **Start with sleep** (the bedroom-charging rule) — sleep loss amplifies every other harm.
3. **Look at content, not just the clock** — what's driving the long sessions?
4. **Signpost:** **Internet Matters** screen-time hub; **NHS** teen sleep advice; if screen use is masking anxiety/depression, route via the **GP**. (No crisis line — this is wellbeing, not emergency.) `[V]`

---

## MODULE H — Privacy, data & digital footprint *(absorbs location-sharing & physical safety)*

**What it is.** What teens reveal — location, school, routines, oversharing — and the long tail of a permanent footprint.

**UK picture 2025–26.** Location is the sharp end: **Snap Map** shows precise location; accidental location-sharing is "super risky," and ~40–48% of Sexual Communication with a Child offences occur on Snapchat. Snap Map is off by default, but **only the child can disable it from their account** (Family Centre lets you *see* who they share with, not switch it off). `[V — NSPCC; Internet Matters]`

**Actions & if it's happening.** Turn on **Ghost Mode** (Snap) / disable precise location app-by-app; review which apps have location permission; lock down "who can see/contact me"; teach not to post uniform, address, real-time location or holiday plans. For **stalking / an adult tracking a child → 101/999 and CEOP**. Signpost: Internet Matters privacy guides, **NCSC** for account security, **Get Safe Online**.

---

## MODULE I — Critical thinking & misinformation / conspiracy

**What it is.** Helping teens spot false, manipulated or conspiratorial content — now supercharged by AI-generated images/video.

**UK picture 2025–26.** Misinformation is the **single most-encountered online harm: 41%** of UK users 13+ saw it in the past four weeks. ~4 in 10 children 9–16 are unsure whether what they see is true; 16–17s' confidence in spotting fake news **fell** to 75%. `[V — Ofcom]`

**Actions.** Teach lateral reading (who's saying it, cross-reference); discuss how algorithms reward outrage; treat AI-generated media with healthy scepticism. Use **Ofcom "Making Sense of Media,"** **Internet Matters** fake-news hub, **Childnet**. No crisis route — this is media literacy; escalate only if conspiracy tips into extremism (→ Playbook F).

---

## MODULE J — Livestreaming safety *(cross-referenced)*

**What it is.** Live video (Twitch, YouTube Live, TikTok Live) — no editing, real-time stranger contact, and coercion risk (being talked into doing things on camera).

**UK picture 2025–26.** Livestreaming is expected to be **restricted for under-16s/under-18s** under the new measures. The IWF has documented large numbers of children groomed/coerced into livestreaming their own abuse. `[V — gov.uk; IWF]`

**Actions & if it's happening.** Review privacy + who can contact/comment together; turn off live features for younger teens; watch for requests to "go live" privately or move to webcam. **Coercion-to-stream is grooming/sextortion → CEOP / Report Remove, and 999 if a child is in danger.** Cross-references Playbooks C-grooming, E-nudes, G-screen-time.

---

## Library-wide signpost quick-reference

| Situation | Route |
|---|---|
| Immediate danger to life | **999** |
| Sextortion / grooming / online child sexual abuse | **CEOP** (ceop.police.uk/Safety-Centre) |
| Remove a nude image of an under-18 | **Report Remove** (childline.org.uk/remove) |
| Scam / fraud | **Action Fraud 0300 123 2040** |
| Bullying / harmful content (non-criminal) | **Report Harmful Content** (reportharmfulcontent.com) |
| Self-harm / suicide risk | **999** / **NHS 111** / **Samaritans 116 123** / **Shout 85258** |
| Eating disorder | **Beat 0808 801 0677** |
| Gambling | **National Gambling Helpline 0808 8020 133** |
| Radicalisation worry | **ACT Early 0800 011 3764** |
| Worried about a child generally | **NSPCC 0808 800 5000** · child: **Childline 0800 1111** |

*Full, formatted version: `03_Emergency_Signpost_Screen`. Re-verify numbers/URLs at publish and quarterly.*

---

## Build/verification notes
- Refresh the `[PV]` cyberbullying channel-split (2022 tracker) to the latest Ofcom figure before print.
- The under-16 ban (Spring 2027) is an announced proposal, not yet law — always label "expected."
- Keep every statistic dated and attributed; recency + citation is the premium signal that beats free content.
