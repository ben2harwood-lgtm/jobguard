# School / PTA Outreach Pack

**The B2B stretch leg — a later second channel, not a V1 dependency.** Don't let this slow the consumer launch. Use it only when a *warm* school/PTA contact appears, and treat one booked/paid session as the gate before building anything more for schools (`00`, §7). Keep the consumer brand's calm register; for schools, the umbrella term shifts to **"digital readiness."**

A realistic note up front: school sales cycles are slow and relationship-led, and the institutional filtering/safeguarding space is already owned by players like Qoria/Smoothwall (`06`). Your angle is **not** software for the school — it's a calm, credible offer for the school's *parent community*.

---

## A. One-pager (send as PDF or paste into an email)

### Helping your parents get ahead of the online risks facing teenagers

**What this is.** A calm, practical online-safety offer for the parents in your school community — built around prevention, not panic. Parents complete a short questionnaire and receive a personalised household readiness report: their top three actions, the settings that matter on the apps their teen actually uses, and the conversation to have this week. It's grounded in current UK guidance from Ofcom, the NSPCC, CEOP and the Internet Watch Foundation.

**Why now.** The risks have moved faster than most parents' knowledge — financially-motivated sextortion, AI-generated fake images, and AI "companion" apps are all recent shifts. Parents want to help but don't know where to start. This gives them a clear, proportionate starting point.

**What it is not.** It's not monitoring or surveillance software, it doesn't involve the children directly, and it doesn't collect children's data. It's parent education and planning. It does not replace the school's designated safeguarding lead or any professional service — and it signposts parents to the right authorities for anything urgent.

**Ways to work together**

- **Community briefing** — a calm session (in person or recorded) for your parents on the current risks and the few things worth doing, with a readiness offer for families who want to go further.
- **Parent readiness offer** — your families get the household report at a community rate; optional ongoing Family Safety Plan.
- **Newsletter / comms pack** — ready-to-send, non-alarmist content for your existing parent channels.

**About data & safeguarding.** We collect the minimum needed and no child-identifiable data. We're registered with the ICO and work within UK GDPR. Happy to share our privacy notice and the boundaries of what we do and don't do before anything goes to your parents.

*Contact: [NAME] · [EMAIL] · [SITE]*

---

## B. Cold-warm outreach email (to a known contact / introduction)

**Subject:** A calm online-safety option for [School]'s parents

Hi [NAME],

[Personal line — how you know them / who introduced you / why this school.]

I run Bearings, a prevention-focused online-safety service for parents of teenagers. Rather than monitoring software, it gives parents a short personalised report — the three things to do first, the settings that matter on the apps their child uses, and the conversation to have this week — all based on current UK guidance.

A lot of schools tell us parents ask for online-safety help but existing options are either alarmist or aimed at the school's systems rather than the family. I'd love to show you a calm version built for your parent community — either a briefing, a community readiness offer, or just some ready-to-send content for your newsletter.

Could I send our one-pager and a sample report? No cost and no obligation — and if it's not right for [School], a five-minute look will tell us.

Thanks, [NAME]

*Bearings is parent education and planning, not monitoring, and not a replacement for your safeguarding lead. We collect no child data and signpost anything urgent to the proper authorities.*

---

## C. Offer & pricing outline (for your reference, not the parent)

| Option | What it is | Indicative price | Notes |
|---|---|---|---|
| Newsletter/comms pack | Ready-to-send parent content | Free → low | Foot in the door; builds trust and a list |
| Community briefing | Talk + recording for parents | £300–£750 | Often the first paid yes; recordable to reuse |
| Parent readiness offer | Reports at a community rate | Report rev-share or flat | The scalable bit if briefings land |
| Workshop / programme | Larger or multi-school | £750–£1,500+ | Only after one school proves it |

`ASSUMPTION` — these are starting points; let your first real conversation set the number. Don't discount the consumer report so deeply that it undercuts direct sales.

---

## D. Guardrails for the school channel

- Lead with **parent education**, never "we'll keep your pupils safe" — same efficacy-claim limits as the consumer copy (`00`/`06`).
- Be explicit that you **don't replace the DSL** and **don't handle incidents** — schools are safeguarding-sensitive and will (rightly) check this first.
- Offer your **privacy notice and "what we don't do"** upfront; it's a trust accelerator, not a hurdle.
- **No child data, ever**, including via schools.
- Keep it to a **second channel**: one booked or paid session is the trigger to invest more here — until then, the consumer wedge is the priority.
