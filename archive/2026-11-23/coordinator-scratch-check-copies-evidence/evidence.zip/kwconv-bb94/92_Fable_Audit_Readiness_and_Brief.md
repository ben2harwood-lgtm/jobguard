# Fable Audit Readiness And Brief

*Created 2026-07-02. Purpose: make the platform ready for a full Fable audit without sending Fable down stale brand, no-code, or legacy-prototype paths.*

## Current Readiness

The current platform is the **Keepwise** Next.js app in `app/`, `components/`, `lib/`, `content/`, and `tests/`.

Local verification completed on 2026-07-02:

- `npm run content-lint` passed: 0 violations across 92 files.
- `npm run typecheck` passed.
- `npm test` passed: 7 files, 286 tests.
- `npm run build` passed and generated 24 routes.

Treat the app as ready for a rigorous audit of product, code, copy, trust, and conversion. Do **not** treat it as ready for live sales until the first-sale/legal/account setup blockers below are closed.

## What Is Current

- Working brand in code: **Keepwise**.
- Core position: personalised household online-safety and AI-readiness system for UK parents of 5-18s.
- Primary user-facing route: `/` -> `/start` -> recommendation -> checkout/enquiry/emergency route.
- Public routes: `/`, `/start`, `/quiz`, `/pricing`, `/sample`, `/how-it-works`, `/for-schools`, `/concierge`, `/privacy`, `/terms`, `/emergency`, `/checkout/system`, `/checkout/stay-current`.
- Gated-content shell: `/library/**`, default-deny until auth/purchase is wired.
- Static/design history: `brand-mockups/`, `brand-design/`, `brand-review/`, `brand-worlds/`, `brand-test-site/`, `keepwise-skins-site/`.

## Source Hierarchy For Fable

Use these in order:

1. `21_MASTER_BUILD_SPEC.md` for guardrails, behaviour, routes, data constraints, and hard safety boundaries.
2. The current app code in `app/`, `components/`, `lib/`, `content/`, and `tests/`.
3. `91_Full_Offering_Site_Assimilation_Plan.md` for expanded offer direction.
4. `audit/keepwise-full-adversarial/00-executive-validity-audit.md` and `06-prioritised-backlog.md` for the previous audit's key findings.
5. `73_AI_Safety_Course_PreRevenue_AI_Review_Findings.md`, `83_AI_Safety_Course_Claude_Pilot_Review_Findings.md`, `84_AI_Safety_Course_Emergency_Signpost_Verification.md`, and `85_AI_Safety_Course_First_Sale_Legal_Admin_Pack.md` for safety/legal issue context.

Treat older Bearings/no-code docs as historical unless they contain guardrails or content sources explicitly referenced by `21`.

## Non-Negotiable Guardrails

Fable should preserve these. It should flag breaches, not optimise around them.

- No safety guarantees: no "keeps children safe", "prevents harm", "fully compliant", "safe by design", or similar.
- No monitoring, surveillance, account scraping, child-facing content, child accounts, user-to-user features, forums, comments, chat, or community.
- No child-identifiable data: no child names, schools, DOBs, screenshots, messages, images, handles, prompts, schoolwork, or incident details.
- Emergencies are signpost-only, public, ungated, and non-monetised.
- No AI judging real messages, images, schoolwork, incidents, or whether a child is safe.
- Human review must remain bounded: age fit, obvious gaps, priority order, source dates, over-claiming. It is not incident handling, legal advice, clinical advice, or safeguarding determination.

## Known Platform State

Ready to audit:

- Public conversion journey.
- Start safety check.
- Quiz.
- Pricing and checkout handoff copy.
- Concierge/school enquiry routes.
- Emergency signpost route.
- Locked library architecture and access guard.
- MDX content ingestion and content guardrails.
- Family Agreement builder behaviour.
- Tests and static safety checks.
- Mobile/responsive UX.

Not live-sale ready yet:

- Stripe Payment Links are not configured in the repo.
- Magic-link auth, real purchase grants, Stripe webhooks, Resend delivery, admin plan review/publish, and retention cron are not fully wired.
- Legal/solicitor/safeguarding sign-off is not complete.
- Refund/cancellation and first-sale terms need final approval.
- Domain, live support email, ICO/admin operating details, and production account setup need Ben decisions.

## Not Built - Do Not Audit As Live Functionality

Fable should not spend time criticising these as broken customer-facing features. They are either intentionally deferred, account-setup dependent, or outside the product boundary. Fable may still check that the current app is honest about them and does not pretend they are live.

### Deferred Or Account-Setup Dependent

- **Live Stripe payment completion** is not built in-code. Current checkout pages are handoff/setup pages unless payment-link env vars are configured.
- **Stripe webhooks, paid-purchase grants, subscriptions, Customer Portal, refund handling, and live checkout success/cancel states** are not implemented.
- **Magic-link authentication and account pages** are not implemented.
- **Admin fulfilment queue, admin plan review, publish controls, and PDF plan delivery** are not implemented.
- **The full post-purchase 25-question diagnostic questionnaire** is not implemented as an app route. The current `/start` flow is a pre-purchase triage/safety-check, not the full paid diagnostic.
- **AI-assisted personalised plan generation from questionnaire answers** is not wired.
- **Email lifecycle through Resend** is not wired: purchase confirmation, questionnaire nudge, plan delivery, feedback request, renewal, monthly briefings.
- **Retention cron and data purge automation** are not wired.
- **Data-subject request route and account data controls** are not wired.
- **Production Supabase persistence** is not active without secrets. Event and quiz APIs should degrade gracefully locally.
- **A live production domain, support inbox, ICO/admin details, and payment account configuration** are not part of this repo state.

### Built Only As Shell, Preview, Or Guarded Experience

- **`/library/**` is default-deny. Fable should audit the locked experience, access guard, and content architecture, but should not treat missing buyer authentication as a bug.
- **The MDX library content can be reviewed as content**, but the authenticated post-purchase customer journey is not complete.
- **Checkout pages should be reviewed for clarity and compliance expectations**, not as working payment pages.
- **Terms/privacy should be reviewed as launch-readiness surfaces**, not treated as professional legal sign-off.

### Intentionally Out Of Scope

- No child accounts, child-facing flow, native app, parent community, forum, comments, DMs, chat, public profiles, monitoring software, screenshot upload, message upload, account scanning, or AI judgement of real incidents.
- No emergency/crisis handling beyond the public signpost route.
- No claims of legal, safeguarding, clinical, educational, or compliance approval unless separately evidenced and approved.

## Improvement Plan - What Fable Should Make Better

Fable should look at the whole platform and recommend improvements that add value, clarify what Keepwise is, and increase trust without weakening the safety boundaries.

### 1. Category And Positioning

Goal: make the product instantly understandable.

Questions for Fable:

- Can a cold parent say, in one sentence, what Keepwise is?
- Does the page make clear it is a **parent planning system**, not monitoring software, a course-only product, a crisis service, or generic articles?
- Is the phrase "online-safety and AI-readiness system" clear enough, or should the copy use a simpler category label?
- Is the main promise concrete enough: "know what to check, set and say"?

Potential improvements to propose:

- Sharper hero variants.
- A plain-English "Keepwise is / is not" block above the fold.
- A one-line category statement repeated in nav/footer/pricing.
- Better distinction between System, AI Lab, Stay Current, and Concierge.

### 2. Value Stack And Offer Depth

Goal: make the product feel more valuable than a checklist or free article collection.

Fable should assess whether the site clearly shows:

- The reviewed Household Plan.
- The first-three-actions output.
- The Control Centre.
- Age-band packs.
- Platform setting guides.
- Threat playbooks.
- Conversation scripts.
- Family Agreement builder.
- AI readiness tools.
- Printables and templates.
- Evidence/source notes.
- Stay Current updates.
- Concierge guided setup.

Potential improvements to propose:

- More tangible product previews.
- A "what you get inside" tool gallery.
- A sample source note.
- A sample monthly "what changed" briefing.
- A clearer AI-readiness bundle or add-on.
- More visible printables and household artefacts.
- A stronger comparison between "free advice online" and "prioritised plan for your household."

### 3. Copy Clarity

Goal: make every page easier to understand, more specific, and more useful.

Fable should review:

- Hero headline and lede.
- CTA wording.
- Pricing plan names and descriptions.
- Review-process explanation.
- Data-minimisation language.
- "Not monitoring / not emergency response" language.
- Sample plan copy.
- School/Concierge copy.
- Footer and trust disclaimers.

Potential improvements to propose:

- Replace abstract nouns with concrete outputs.
- Use parent-language: "what to check, what to set, what to say, what to ignore for now."
- Explain "human-reviewed" without making it sound like professional safeguarding advice.
- Make the active-concern route clearer without making the page alarmist.
- Remove jargon where possible.
- Preserve all banned-claim guardrails.

### 4. Journey And Conversion

Goal: make the first paid-pilot path obvious and confidence-building.

Fable should inspect:

- `/` to `/start` to recommendation to checkout/enquiry.
- Whether the user understands what happens after checkout.
- Whether pricing appears before enough value/trust is shown.
- Whether active concerns are routed out early enough.
- Whether the locked library creates interest without frustration.
- Whether CTAs are specific and consistent.

Potential improvements to propose:

- A clearer "after you buy" sequence.
- A stronger confirmation/preview state for checkout setup.
- A buyer timeline: check -> pay -> diagnostic -> human review -> plan -> library.
- Better risk reversal: refund/cancellation wording, support route, delivery expectations.
- Fewer competing CTAs.

### 5. Trust, Evidence, And Safeguarding

Goal: make the product feel careful, current, and bounded.

Fable should inspect:

- Emergency signpost placement.
- Whether "signpost-only" is clear.
- Whether source-backed guidance is shown with real examples.
- Whether review dates and update promises are credible.
- Whether privacy/data claims match forms and API routes.
- Whether terms/privacy/refund/support are good enough for first paid pilot.

Potential improvements to propose:

- A parent-facing evidence page or evidence section.
- One real source-note card per major content type.
- Review rubric shown in plain English.
- Last-reviewed stamps where they matter.
- First-sale legal/admin checklist surfaced near checkout.
- Clear support boundaries for non-urgent questions.

### 6. Product And Content Architecture

Goal: make the paid product easier to navigate and easier to believe in.

Fable should review:

- Library taxonomy.
- Age-band navigation.
- Platform/playbook/conversation cross-links.
- AI readiness content placement.
- Family Agreement builder role.
- Whether the sample plan deep-links convincingly into the library.

Potential improvements to propose:

- Better "start here" path inside the library.
- AI toolkit category.
- More cross-links between platform guides, playbooks, scripts, and agreements.
- Stronger sample plan showing direct guide links.
- A "this weekend" bundle for immediate usefulness.

### 7. UX, Mobile, And Accessibility

Goal: make the site easy to use on a phone by a busy parent.

Fable should inspect:

- Mobile nav and primary CTA visibility.
- Text fit and no overflow.
- Button labels and tap targets.
- Form states in `/start` and `/quiz`.
- Focus states and keyboard navigation.
- Layout stability.
- Scanability of long sections.

Potential improvements to propose:

- Shorter mobile sections.
- Sticky or repeated primary action where appropriate.
- Better hierarchy in pricing cards.
- More scannable tool previews.
- Improved empty/locked states.

### 8. Code, Tests, And Guardrails

Goal: make the implementation safer and easier to improve.

Fable should inspect:

- Shared brand/pricing tokens.
- Hard-coded copy that should be centralised.
- Input validation and PII rejection.
- Access gating and no content leakage.
- Event naming and funnel tracking.
- Content lint coverage.
- Tests for newly suggested copy/flow changes.

Potential improvements to propose:

- Tests for any new high-risk copy.
- Tests for checkout setup expectations.
- Stronger assertions around library locking.
- Tracking events aligned to the audit funnel.
- Small refactors only where they reduce risk or duplication.

### 9. Operations And Pilot Readiness

Goal: separate "ready to audit" from "ready to sell."

Fable should identify what must be true before a first controlled paid pilot:

- Payment link configured.
- Terms/privacy/refund/cancellation wording approved.
- Emergency signpost rechecked.
- Support inbox and non-urgent boundary reply ready.
- Diagnostic/fulfilment path ready.
- Manual plan review process documented.
- Legal/safeguarding review dependencies clear.
- First-pilot scope and stop conditions documented.

## Priority Question For Fable

The most useful Fable answer is not "is this nice?" It is:

> What are the smallest high-leverage changes that make Keepwise clearer, more valuable, more trustworthy, and safer to pilot, while preserving the product boundaries?

## Fable Audit Mission

Audit the platform as if preparing it for a first controlled paid pilot, not a mass public launch.

Fable should answer:

1. Is the value proposition clear within the first two scrolls?
2. Can a cold parent understand exactly what they get, what happens next, and why it is worth paying for?
3. Does the start/check/pricing flow reduce anxiety and increase trust without drifting into safety promises?
4. Are the safety/data boundaries visible early enough and repeated at the right moments?
5. Does "human-reviewed" feel credible, specific, and bounded?
6. Do checkout, concierge, privacy, terms, emergency, and library routes create a coherent journey?
7. What code/copy/UX issues create the largest conversion, trust, accessibility, or safety risks?
8. What should be fixed before Fable or Ben recommends a paid pilot?

## Fable Audit Passes

### Pass 1 - Product And Journey

- Walk `/`, `/start`, `/pricing`, `/checkout/system`, `/sample`, `/emergency`, `/concierge`, `/for-schools`, and `/library`.
- Identify drop-off points, confusing CTAs, missing next-step expectations, and unsupported value claims.
- Compare current journey with `audit/keepwise-full-adversarial/06-prioritised-backlog.md`.

### Pass 2 - Copy And Claims

- Look for anything that implies guaranteed safety, prevention, compliance, monitoring, live support, diagnosis, incident handling, or professional sign-off.
- Check whether parent-facing copy is practical, specific, calm, and valuable.
- Suggest replacements that preserve cautious language.

### Pass 3 - Trust, Evidence, And Safeguarding

- Check emergency signpost visibility, routing, and no-upsell treatment.
- Check the data-minimisation story: what we ask vs what we never ask.
- Check whether "human-reviewed" has enough process detail.
- Check whether terms/privacy/refund/support expectations are credible enough for a paid pilot.

### Pass 4 - Code And Architecture

- Inspect access gating, API input validation, event tracking, checkout handoff, content ingestion, and tests.
- Look for ways gated content could leak.
- Look for API routes that accept child-PII keys or free-text risk.
- Look for brittle hard-coded brand/pricing/copy that should use shared tokens.

### Pass 5 - UX, Mobile, Accessibility

- Check mobile navigation, overflow, focus states, button labels, form controls, layout stability, and scanability.
- Check that text does not overlap or get hidden on small screens.
- Check that the primary action remains visible and clear.

### Pass 6 - Value Expansion

- Assess whether the current app shows enough of the full value stack from `91`: tools, AI readiness, Control Centre, evidence/resources, Stay Current, Concierge.
- Recommend the smallest changes that make the offer feel more valuable without adding unsupported proof or overbuilding.

## Requested Output From Fable

Ask Fable for:

1. A ranked issue list with severity, affected route/file, why it matters, and exact fix.
2. A short "before paid pilot" checklist split into blocker/high/medium.
3. Concrete copy rewrites where copy is the problem.
4. Code-level recommendations where implementation is the problem.
5. A test/verification plan for any suggested changes.
6. A final "pilot readiness" verdict with remaining human/legal/safeguarding dependencies.

## Instructions To Fable

- Do not invent testimonials, credentials, source claims, legal status, school partnerships, or efficacy evidence.
- Do not recommend features that collect child data or turn the product into monitoring, incident support, or a community.
- Prefer small, reviewable fixes over sweeping rewrites.
- Preserve the current cautious safety language unless replacing it with something more cautious and clearer.
- If a concern requires professional legal/safeguarding review, mark it as such rather than treating an AI suggestion as sign-off.

## Best First Prompt For Fable

> Audit this Keepwise build for first paid-pilot readiness. Use `92_Fable_Audit_Readiness_and_Brief.md` as your operating brief, `21_MASTER_BUILD_SPEC.md` for guardrails, the current Next app as the source of implementation truth, and `audit/keepwise-full-adversarial/` for previous findings. Give me a ranked list of what to fix before a paid pilot, with exact code/copy recommendations, while preserving the no-monitoring, no-child-data, signpost-only emergency, and no-safety-guarantee boundaries.
