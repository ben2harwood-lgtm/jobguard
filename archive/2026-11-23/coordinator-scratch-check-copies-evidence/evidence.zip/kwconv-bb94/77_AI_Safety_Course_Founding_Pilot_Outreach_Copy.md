# AI Safety Course - Founding Pilot Outreach Copy

*Created 2026-06-27. Status: draft outreach copy for a small warm-network pilot. Do not send until the AI legal/safeguarding review briefs have been run and blocker/high findings are patched.*

## Boundary

These messages should not claim legal review, safeguarding review, expert approval, compliance, or safety outcomes. They should invite a small number of parents to try a practical education pilot and give feedback.

## One-To-One Warm Parent Message

Hi [NAME],

I am testing a small parent course on AI safety at home and wondered if you might be the right kind of early reader/user.

It is not a child-facing thing, and it does not look at children's messages or screenshots. It is a parent course for setting a few practical household AI rules: what stays private, why AI is a tool rather than a person, how to check confident answers before trusting them, and how to talk about AI without making it a panic lecture.

I am keeping the first pilot small because the topic needs careful wording. The founding version is GBP 49, and I am mainly looking for parents who will tell me what is clear, what feels useful, and what still feels confusing.

No pressure at all, but if you would like to see the pilot page I can send it over.

If there is something live or urgent happening, this is not the right route - use the emergency signpost instead.

Ben

## Parent Group Post

I am looking for a small number of parents to try a founding pilot of a new AI safety course for families.

It is parent-facing, not child-facing. It does not ask for children's messages, screenshots, school details, names, images, or incident details. It is about setting household AI rules calmly: what stays private, why AI is a tool rather than a person, how to check before trusting AI output, and how to set a short family agreement.

The first pilot is deliberately small and practical:

- four short parent modules;
- printable rule cards;
- a Family AI Safety Agreement starter;
- no live-incident advice or message/image review.

Founding pilot price is GBP 49. I am looking for parents who are willing to try it and give honest feedback on the clarity and usefulness of the material.

Comment or message me if you would like the details. Please do not post or send child details, screenshots, messages, images, or anything about a live situation.

## LinkedIn / Founder Network Post

I am putting together a small founding pilot for Bearings, a parent-led AI safety course for families.

The goal is simple: help parents set practical household AI rules before habits get messy. The pilot covers privacy, companion-style AI boundaries, checking confident AI answers, schoolwork ask-first rules, and a short Family AI Safety Agreement.

It is not monitoring software, not child-facing, and not a tool for reviewing live situations. No child details, screenshots, messages, images, or incident details are collected.

I am keeping the pilot small while the review process develops. If you are a parent/carer of a child or teen using AI tools and would be willing to try an early version, I would love to hear from you.

Founding pilot: GBP 49. Feedback very welcome.

Please do not send child details or live-incident information. If something is happening now, use the emergency signpost.

## Follow-Up After Interest

Thanks, [NAME].

Here is the pilot page: [LINK]

The important boundary is that it is parent education and household planning only. Please do not send child details, screenshots, messages, school details, images, or anything about a live incident. If something is happening now, use the emergency signpost instead.

If you join, I will ask for feedback on:

- whether the rules are clear;
- whether the assets are usable;
- what felt confusing;
- what wording felt too strong or too soft;
- what nearly stopped you buying.

Thank you if you do. This is exactly the kind of early feedback that makes the material better before I widen it.

Ben

## Follow-Up After No Reply

Hi [NAME],

No need to reply if now is not the moment. I am just keeping the first AI safety course pilot small and thought of you because it is for practical, thoughtful parents rather than people who want scare stories.

If you would like the link later, just say the word.

Ben

## First Buyer Feedback Email

Subject: Quick feedback on the AI safety pilot

Hi [NAME],

Thank you again for joining the founding pilot.

I am trying to learn whether the material is clear and useful, not whether it produces any particular outcome. Could you reply with quick answers to these?

1. Which rule felt easiest to explain at home?
2. Which rule still felt unclear?
3. Which asset would you actually use?
4. What wording felt too strong, too soft, or confusing?
5. What nearly stopped you joining?

Please do not include child names, school details, screenshots, messages, images, or incident details.

Thank you,

Ben

## Copy Checks

Before sending:

- Replace [LINK].
- Replace [NAME].
- Check price.
- Confirm emergency signpost is live.
- Run final content lint if copied into site or email templates.
- Do not add claims about legal review, safeguarding review, expert approval, or outcomes.
