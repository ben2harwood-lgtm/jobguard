# Pricing, Library Tiers & Content Plan — V3 (decisions locked 20 Jun 2026)

**This supersedes the price ladder in `14` (the £99/£179/£59 shape) and the tier mapping in `15`.** Positioning, segments and the market-gap analysis in `14` still stand; only the **top tier and the content depth** change. Founder decisions taken this session are recorded in §1 and are now canon for the landing page, emails and (when it's built) the coded app `21`.

> **Design rule that governs everything below (the pushback, codified):** we win on **value density, not volume.** Our wedge is "we're against overwhelm — we don't hand you 200 articles." So the test for any content is *"does this make the tier feel 3× its price?"* — not *"can we add more?"* Curated, personalised, current beats big.

---

## 1. Locked decisions

| Decision | Choice |
|---|---|
| £99 one-off System | **Keep** (founding £79). The hero / cash engine. |
| Old £179 "System + Setup" | **Replaced** by **The Concierge — from £650, scoped per household**, capped at ~4 slots/month. |
| Middle rung between £99 and £650 | **None.** Three clean tiers (anchor psychology); add a mid-tier later only if data shows the gap. |
| Membership tiers | **One** — Stay Current £59/yr, year 1 bundled. Prove it renews (>~50%) before adding any premium recurring. |
| Video | **Yes — founder will produce it.** Core content pillar for the System and the primary renewal hook. |
| Webinars / live group / community | **No.** Live = capacity + the "coach trap" (`00`); community = Online Safety Act scope breach. Use *recorded* masterclasses instead. |

---

## 2. The tier architecture

| Tier | Price | Who it's for | Role |
|---|---|---|---|
| **Free quiz** | £0 | Any anxious parent | Email capture, top of funnel |
| **The System** | **£99** (founding £79) | The core — anxious-but-engaged parents | Volume + cash engine; everything anchors to it |
| **The Concierge** | **from £650** (scoped; ~4/month) | Affluent / time-poor / post-incident | High-margin, low-volume; validates premium WTP; fills the empty UK concierge gap |
| **Stay Current** | **£59/yr** (year 1 bundled into System) | System owners, a year on | Renewal / LTV layer |

**Anchor logic:** the £650 ceiling makes £99 read as a no-brainer ("the *whole system* is £99; white-glove is £650"). The £99 lifts *because* the top tier went up — repricing the concierge up is pro-conversion for the hero, not a distraction from it.

**Revenue shape in one line:** Free quiz → **£99 System** as the volume engine → **Concierge (from £650)** as high-margin scarcity for the affluent/post-incident buyer → **Stay Current £59/yr** as the renewal layer once year-1 currency lapses.

---

## 3. What goes in each tier (the value stack)

### Free quiz — £0
8-question readiness snapshot + a calm result band. One job: capture the email and earn enough trust to come back. (Already built — `10`.)

### The System — £99 (the "I can't believe this is £99" stack)
1. **Personalised plan** — the diagnostic → top-3 actions + six-domain exposure map, deep-linked into the library (`07`).
2. **Their age-band pack** — the spine they navigate by (`19`).
3. **Platform setting guides (10)** — text *plus* **short step-by-step setup videos** (the new lever).
4. **Threat playbooks (12) + foundations modules (3)** (`18`).
5. **Conversation library + "what not to say" card** (`17`).
6. **A recorded masterclass for their stage** (e.g. "The first tablet" (5–10), "The first phone" (11–12), "The threshold year: 13–14").
7. **Printable quick-reference cards** — per-platform, per-age, and a "do-it-this-weekend" checklist (cheap to produce, high perceived value).
8. **Family-agreement builder** (`09`/builder).
9. **Year-1 currency included** — monthly briefing, setting-change alerts, refreshed guides/videos.
10. **Emergency signpost** (`03`), always free to reach.

> Almost all of this already exists or is low-effort to derive. The one genuinely new production cost is **video** — which is also the strongest renewal hook. That's the whole reason video earns its place.

### The Concierge — from £650 (scoped)
**Everything in the System, plus** the things only 1:1 time can deliver:
- A live **done-*with*-you setup/audit call** (60–90 min) — you guide, *they* click. **You never take control of their family accounts** (kills the liability + the "you accessed my kid's phone" ick).
- A **bespoke written household report** covering *all* their children, not one age band.
- **One follow-up check-in** (+30–60 days) — makes it a relationship, not a transaction.
- **Priority email Q&A for 12 months** — guidance only, never live-incident advice (signpost stays the rule).

Capped at ~4 households/month. Scarcity *is* the premium signal and it protects the calendar. Scoping rubric in §7.

### Stay Current — £59/yr (year 1 bundled)
The currency layer — kept genuinely worth £59 (~£1.15/week) by cadence, not live events. See §8.

---

## 4. The full content & library inventory → tier map

Effort column is honest about a **solo, non-technical founder's** time.

| Content | System £99 | Concierge £650+ | Stay Current £59/yr | Effort | Notes |
|---|---|---|---|---|---|
| Personalised plan (top-3 + exposure map) | ✓ | ✓ deeper, all children | — | Med (AI-assisted) | The hero (`07`) |
| Platform setting guides (10, text) | ✓ | ✓ | refreshed | Done | `16` |
| **Setup how-to videos** (screen-recordings) | ✓ | ✓ + walked through live | re-recorded on UI changes | **High, high-payoff** | §6. Best £99 lever + renewal hook |
| Threat playbooks (12) + modules (3) | ✓ | ✓ | new/refreshed | Done | `18` |
| Conversation library + "what not to say" card | ✓ | ✓ | new scripts | Done | `17` |
| **Quick-reference PDF cards** | ✓ | ✓ | new cards | **Low** (derive) | Pack freely; near-zero cost |
| **Recorded masterclass(es)** | their stage | all | new ones added | High once, evergreen | Replaces live webinars |
| Family-agreement builder | ✓ | ✓ facilitated | — | Done | `09` |
| Monthly briefing + setting-change alerts | yr 1 | yr 1 | ✓ | Med, ongoing | `20` |
| **Seasonal template packs** (back-to-school, exam screen-time, holidays) | ✓ | ✓ | new each season | Low | Ties to `20` backlog |
| Annual plan + quiz refresh | — | — | ✓ | Low | Concrete renewal reason |
| Live 1:1 setup/audit (done-*with*-you) | — | ✓ 60–90 min | — | High (time) | Justifies £650 |
| Bespoke written household report / all children | — | ✓ | — | High | Concierge depth |
| Priority email Q&A (bounded, signpost-safe) | — | ✓ 12 mo | — | Med — watch scope | Guidance only |
| Follow-up check-in (+30–60d) | — | ✓ | — | Med | Relationship, not transaction |
| Community / forum / live webinars | ✗ | ✗ | ✗ | — | **No** — OSA scope / coach-trap |

---

## 5. The video plan (you committed — here's how to do it without it eating your life)

**Format:** 2–5 min, **one task per video**, plain screen-recording, on-screen date (dating it = the currency signal), captions burned in (people watch muted). No talking-head needed; your calm voiceover over the screen is enough.

**Tooling (all free, Mac):**
- Mac screen: **QuickTime** (built-in) or **Loom** (free tier).
- iPhone screen: cable → **QuickTime → New Movie Recording → select iPhone**. Clean capture.
- Android: **scrcpy** (free) or the phone's built-in recorder, then import.
- Trim + captions: **iMovie** or **CapCut** (free; auto-captions).
- Host: **unlisted YouTube or Vimeo**, embedded/linked in the gated library. (Unlisted ≠ user-to-user — no OSA issue.)

**Production order (device layer first, per `15`):**
- **Batch 1 (do first — highest demand):** Apple Screen Time · Google Family Link · Snapchat · Instagram · TikTok.
- **Batch 2:** Roblox · Discord · WhatsApp · Fortnite · YouTube.
- **Masterclasses:** "The first tablet" (5–10) → "The first phone — a calm 30-min setup" (11–12) → **"The threshold year: 13–14"** (flagship, do this one well) → 15–16 → 17–18.

**Effort:** your `16` guides *are* the scripts — you're reading what's already written while you tap. Batch ~5 short videos in a focused half-day.

**The renewal flywheel:** when a platform changes its UI (they do, constantly), you re-record that one short video → that's both a Stay Current "what's changed" briefing item *and* visible proof the membership keeps things current. Video is the only asset that decays, which is exactly why it's the best reason to renew.

---

## 6. Concierge scoping — how to quote "from £650"

A simple, defensible rubric (adjust once you've done a few):

| Component | Price |
|---|---|
| **Base** (1 child: full System + 60–90 min setup/audit call + bespoke report + 1 follow-up + 12-mo priority email) | **£650** |
| Each additional child | +£150 |
| Multiple households (e.g. separated parents, grandparents) | +£200 |
| Post-incident priority turnaround | +£100 |

Always "from £650"; never undercut the floor. Cap ~4/month and say so — the cap is the luxury signal.

---

## 7. What makes the £59 membership actually renew (cadence, not live events)

- **Monthly:** a short, calm briefing — what changed, what to do (from the `20` backlog).
- **When-it-happens:** setting-change alerts with the **re-recorded video** for the changed setting.
- **Quarterly:** one new/refreshed playbook *or* a new masterclass *or* a seasonal template pack.
- **Annually:** plan + quiz refresh ("your household, re-run a year on").

That's a credible £59/yr without a single live commitment. **Gate before expanding:** if this doesn't renew above ~50%, a premium recurring tier won't fix it — fix this one first.

---

## 8. Knock-on changes (what gets updated to match)

- ✅ **Landing page `23`** — tiers updated to System £99 / Concierge from £650 / Stay Current £59; System tile packed with videos, cards, masterclass.
- ✅ **`14`** ladder table + revenue line + anchor rationale → Concierge model.
- ✅ **`15`** tier-mapping table + diagram → Concierge; video/cards/masterclass added as content types.
- ✅ **`21`** (deferred coded build) — pricing table, `tier` enum (`system_setup` → `concierge`), and `STRIPE_PRICE_SETUP` → `STRIPE_PRICE_CONCIERGE` updated so it's not stale when the build resumes.
- ✅ **5–10 "First Tablet" band added (20 Jun 2026)** — the product now spans **5–18** across 5 bands; new band pack in `19`, masterclass in `29`, a per-age card; landing/quiz/`07`/`21`/`14`/`15` updated. Resolves the review's under-11 gap and the "a masterclass for their stage" promise.
- **Open / your call later:** exact founding-cohort size for £79; whether the Concierge needs a short application form (to keep the 4 slots high-quality); video voiceover — your voice (more trust) vs text-only screencasts (faster).
