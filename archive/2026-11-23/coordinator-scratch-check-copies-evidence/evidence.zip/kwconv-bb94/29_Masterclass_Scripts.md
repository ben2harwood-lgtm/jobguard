# Masterclass Scripts (recorded, by age band)

**Updated 20 Jun 2026 — corrected against review `31` (distress signpost added where harms are raised; missing conversations restored; helpline contacts completed; superlatives varied; library deep-links added). Plus the new 5–10 'First Tablet' masterclass. Fill `Bearings`/`[DATE]`.**

---

## Band 5-10 — The First Tablet — Ages 5–10: A Calm Masterclass for Parents

# The First Tablet — Ages 5–10

*Bearings Masterclass · Age Band 5–10 · "First tablet" · Posture: CO-USE · Recorded [DATE] · Runtime ~15–20 min*

> **Format note for the producer.** First-person, warm, premium, unhurried. [ON SCREEN] = on-screen text / lower-thirds / graphics. [B-ROLL] = footage to cut over the voice. Pace: calm. We are against overwhelm — this is the right few things, done well, not a long list. This is the youngest band, so the whole posture is *co-use*: you're in it with them.

---

## COLD OPEN — the hook (≈1.5 min)

[B-ROLL: A living-room floor on a quiet Saturday morning. A small child cross-legged on a rug, a tablet propped against a cushion, cartoon light flickering on their face. A parent's mug of tea going cold on the arm of the sofa. Soft, warm, ordinary.]

[ON SCREEN: The first tablet.]

There's a moment a lot of us reach far earlier than we expected. It's not a phone, and there's no big ceremony. It's a tablet — maybe a hand-me-down, maybe a birthday present from a grandparent — and your five- or six- or eight-year-old is suddenly *very* good at finding the videos they like. And there's this quiet, slightly surprised feeling: *they're so little, and they're already in there.*

I want to start by taking the temperature right down. Because here's the thing I most want you to hear, at the very top:

[ON SCREEN: Most of what your young child does online is ordinary and lovely. A little of it needs setting up. Almost none of it needs panic.]

This is the gentlest, most forgiving stage of the whole journey. Your child is five to ten. They are *delighted* to have you sit next to them. They'll show you everything, narrate everything, want you to watch the same video fourteen times. That closeness — where you're genuinely welcome in their digital world — is the most powerful safety tool you will ever have, and it's strongest right now. So this masterclass is not about locking the world down around a small child. It's about using this easy, warm stage well, so that every harder year afterwards starts from a place of trust.

I'm going to give you a handful of things to set up, the two or three simple conversations that genuinely matter at this age, the few real risks — explained calmly — and a short list of things you honestly do not need to worry about yet. Then a "do this weekend" close you can actually finish on a Sunday afternoon.

Let's go.

---

## WHAT MATTERS AT THIS AGE — the posture (≈2.5 min)

[B-ROLL: A parent and a young child squashed together in one armchair, both looking at the same tablet. The parent pointing at the screen, the child laughing. Side by side, not over the shoulder.]

[ON SCREEN: The posture for 5–10: CO-USE.]

Across the whole of childhood, a parent's job online slides through four postures: *co-use*, then *co-set*, then *coach*, then *consult*. By seventeen you're a consultant — they lead, you advise. But at five to ten, you are at the very, very beginning of that slide, and the posture is the purest version of the first one: **co-use**.

Co-use means hands-on, alongside them, together. At this age it's not a metaphor — it's literal. You are often in the room. You're choosing the apps. You're sitting close enough to see the screen. And crucially, this is not snooping and it never feels like it to them — a six-year-old *wants* you there. The whole game at this age is to make the tablet a shared, out-loud, in-the-open thing, on a device in a family room, rather than a private little world behind a closed door.

[ON SCREEN: Co-use = together, in shared spaces, out loud. At this age it's natural — they want you there.]

Here's why this matters more than any single setting. There's a landmark piece of research — Kerr and Stattin — that found what a parent actually *knows* about their child's life depends far more on the child *choosing to tell them* than on any monitoring or control. Warmth beats surveillance — not as a nice idea, but because it works better. And the lovely thing about five to ten is that the telling-you habit is the *default* here. Your job is simply not to break it. Every time you react calmly and kindly to "Mum, this video was weird," you are training the channel you'll be so grateful for at fourteen.

[ON SCREEN: What you know depends more on your child choosing to tell you than on any control. (Kerr & Stattin)]

So co-use does two jobs at once. You set up sensible, light-touch guardrails — and you build the *channel*. Knowing what they love — their show, their game, the song they can't stop singing — is exactly what makes it easy for them to bring you the thing that worried them, too.

[B-ROLL: A child tugging a parent's sleeve to show them something on the tablet; the parent leaning in, genuinely interested.]

CEOP — that's the UK's child-protection command — has a slogan I love for every age, and it fits this one best of all: *talk little, talk often.* Not one Big Serious Talk a five-year-old wouldn't follow anyway. Lots of tiny, everyday, cheerful moments. We'll come back to that.

---

## THE THINGS TO SET UP NOW (≈4.5 min)

[ON SCREEN: A few setups. In order. That's the whole list.]

We are firmly against overwhelm here, so I'm not going to drown you in toggles. At this age there are four setups worth doing, and there's an order — highest-leverage first.

[ON SCREEN: A caveat we keep on everything — Menus move. App makers rename and relocate settings constantly. If a path doesn't match your screen, search the setting name in the app, or use the official help link. Paths checked [DATE].]

**One: the device layer. Do this first.**

[B-ROLL: A tablet's Settings screen, a finger scrolling toward Screen Time / Family Link.]

Before any individual app, set up the layer that governs *every* app, install and website at once. On an iPad that's **Apple Screen Time** through Family Sharing. On an Android tablet or a Chromebook it's **Google Family Link**.

Why first? Because it's the backstop that sits under everything else. At this age the things that matter most inside it are: **Content & Privacy Restrictions**, set to a young age, to keep age-inappropriate apps and websites off the device; **Ask to Buy** (Apple) or purchase approvals (Family Link), so nothing gets bought or downloaded without your say-so; and **Downtime** or a bedtime schedule, so the tablet simply stops working past a certain hour.

And the one people forget: on Apple, *lock Screen Time with a passcode your child doesn't know* — and pick one that isn't the same as the tablet's unlock code. Do that first, because otherwise a curious eight-year-old can switch the whole lot back off. Family Link is managed from *your* phone, which keeps it out of their reach by design.

[ON SCREEN: Device layer first. Lock it with a passcode they don't know.
Apple: support.apple.com/en-us/108806
Google: support.google.com/families/answer/7101025]

**Two: YouTube — the Kids app, not the open one.**

[B-ROLL: The bright, rounded YouTube Kids interface on a tablet.]

This is the big one at five to ten, because video is where most of this age lives. Use **YouTube Kids**, not the open adult YouTube app. In YouTube Kids you set the content level to their age band, you can turn **search off** entirely so they only see an approved, curated set, and you can block or approve specific channels. Set the built-in **timer**, too — when it runs out, the app politely shuts.

One honest word: no content filter is perfect, and the odd off video does slip through any system, including this one. So YouTube Kids isn't a wall you walk away from — it's a much better starting point that does a lot of quiet work, *plus* the co-use habit of being nearby. If something odd does appear, that's not a failure — it's a chance to show them the "block this" button together.

[ON SCREEN: YouTube Kids — set the age level, consider turning search off, set the timer.
support.google.com/youtubekids]

**Three: the games — Roblox, with the under-13 setup and a spend PIN.**

[B-ROLL: A colourful Roblox world on a tablet; small hands tapping.]

By around seven or eight, Roblox arrives — it's enormous at this age. The single most important step is to set up the account as the child's real age. For a young child that puts them into the more protected experience, with stricter chat and content settings on by default. Then, in the **parental controls**, link your own account, set the **content-maturity** ceiling to the youngest level, manage or switch off chat, and — this is the big one for this band — turn on a **spending PIN** so no Robux can be bought without your code.

A heads-up: Roblox changed a great deal in 2025 and 2026, including age-checks to unlock chat, so the menus may look different from any guide. If your screen doesn't match what you expect, check their official parents' page rather than guessing.

[ON SCREEN: Roblox — set the real age, youngest content level, manage chat, and turn on a spending PIN.
about.roblox.com/parental-controls]

**Four: filters at the network and search level.**

Last, turn on **SafeSearch** on any browser they can reach, and turn on your **broadband provider's adult-content filter** at the router. At this age, almost any exposure to things you'd rather they didn't see is *accidental* — a mistyped search, a stray link from a video. Network filters quietly catch a good chunk of that in the background, they ask nothing of your child, and they cover devices you might forget about. Not perfect — nothing is — but they lower the odds for free.

[ON SCREEN: SafeSearch on + broadband adult-content filter on. Catches a lot of accidental exposure.]

And the simplest rule of all, the one that quietly does more than any toggle: **keep the tablet in shared family rooms, and out of the bedroom — especially at bedtime.** The tablet lives in the kitchen or the lounge, not under the duvet. That single habit makes co-use natural instead of a fight, and it sets a norm now that is far, far easier than clawing it back at eleven.

[ON SCREEN: Tablet stays in shared rooms — out of the bedroom, especially at night.]

That's it. Four setups. If you do nothing else from this whole masterclass, do those — in that order — and you've done the heavy lifting.

---

## THE SIMPLE CONVERSATIONS THAT MATTER HERE (≈3.5 min)

[B-ROLL: A parent and child walking to school, hand in hand, chatting easily about nothing in particular.]

[ON SCREEN: The conversations. Little and often. In your own words. Tiny ones count.]

Settings are the easy half. The conversations are the half that lasts — and at this age they are wonderfully simple, because a five- or eight-year-old doesn't need a lecture. They need a few short, warm ideas, repeated cheerfully, in language they already understand.

**The cornerstone: "if anything is weird or yucky, come and tell me — you won't be in trouble."**

[ON SCREEN: The cornerstone line — say it early, say it often, in tiny-person words.]

This is the single most important idea in this entire masterclass, at every age. It comes straight from CEOP. The reason any child — even a little one — stays quiet when something goes wrong online is almost always that they think they've done something *naughty*, or that something will be taken away. This one idea takes that fear off the table before it ever forms.

For this age, keep it concrete and gentle, in your own words — something like:

> *"Sometimes on the tablet you might see something weird, or yucky, or a bit scary, or someone might say something that feels funny in a not-nice way. If that ever happens, you just come and find me straight away — even if you think you did something wrong. You will never, ever be in trouble for telling me. Telling me is the good thing to do."*

And here's the hard part, the part that makes the words real: you have to actually *mean it* when it's tested. The day your six-year-old comes to you because a video frightened them, or they tapped something and a stranger's chat popped up, your calm, kind, glad-you-told-me face is the thing that keeps this channel open for the next decade. If telling you leads to the tablet being snatched away in anger, they learn — very fast, even this young — to handle the scary thing alone next time. Don't trade a lifetime of them telling you for one moment of being cross.

[ON SCREEN: "Come and tell me — even if you think you did something wrong. You won't be in trouble. Telling me is the good thing."]

**Second: "show me your world."**

[B-ROLL: A child excitedly explaining a game to a parent, who is nodding along, completely lost but delighted.]

This one's a joy and it's strategic. Get genuinely curious about their world: *"Ooh, show me — what's your favourite thing on here? Show me the best video you saw today."* Let them be the expert. Be interested in their game and their show the way you'd be interested in their friends at nursery or school. This is how you build the channel — and bluntly, it's how you'll *notice* if something changes later, because you'll know what their normal looks like. A child who's used to showing you the good stuff finds it natural to show you the bad stuff too.

**Third: the simple online-stranger idea — calmly, like the road-safety version.**

[ON SCREEN: People in games and chats aren't always who they say. We only chat to people we know in real life.]

You don't need to frighten a small child, and you shouldn't. Frame it the way you'd frame crossing the road — a calm, everyday safety rule, not a horror story. Something like: *"In some games, you can talk to other players. The thing is, online you can't always tell who someone really is — a grown-up can pretend to be a kid. So our rule is: we only chat with people we actually know in real life. And if anyone you don't know tries to talk to you, or asks you to go somewhere private to chat just the two of you, that's not your fault at all — you just come and tell me."*

That little phrase — *somewhere private to chat just the two of you* — plants, in age-appropriate words, the one red flag that both CEOP and the NSPCC say matters most: an adult trying to move a child off into a private space. You're not scaring them. You're giving them a simple rule and a clear "come to me."

One quick "don't" that saves a lot of upset, and it works on five-year-olds as well as fifteen-year-olds: ask *"what happened?"* — not *"why did you do that?"* The word "why" makes any child feel told-off and clam up. *"Oh — what happened? Show me"* keeps them talking. Tape that one to the fridge.

[ON SCREEN: Ask "What happened? Show me." — never "Why did you do that?"]

[ON SCREEN: The exact words for every one of these → Bearings/library/conversations · Worried about strangers in games or chats → Bearings/library/playbooks/grooming]

---

## THE TOP RISKS FOR THIS AGE — calmly (≈3.5 min)

[ON SCREEN: The real risks at 5–10 — named plainly, handled calmly.]

Now the part everyone braces for. I'm going to name the genuine risks at this age — but the way I'd want them named to me: factually, with what to *do*, and where to go for help. Not to scare you. The opposite. Naming a thing calmly is how you stop being afraid of it. And I'll be honest up front — the truly serious harms are mostly the homework of *older* bands. At five to ten, there are three to keep a calm eye on.

[B-ROLL: Calm, neutral footage — a tablet face-down on a coffee table, a tidy, quiet living room. Nothing alarming.]

**Accidental exposure to something upsetting.** At this age, the realistic risk isn't a child seeking out anything — it's stumbling onto something frightening or grown-up by accident: an autoplay that wanders, a search that goes sideways, a thumbnail that shouldn't be there. Your YouTube Kids settings and your network filters lower the odds a lot; they don't eliminate them. So the real protection is the same as always — that your child isn't *afraid* to tell you they saw something. *If it happens:* don't shame or punish, especially for an accident — shame just guarantees silence next time. Get down to their level, ask calmly what they saw and how it felt, reassure them it wasn't their fault, and tighten the filters together. And if a child was deliberately *sent* something inappropriate by an adult, that's a safeguarding matter — that's **CEOP** at ceop.police.uk/Safety-Centre, the school, or the **NSPCC on 0808 800 5000**. If something they've seen leaves them genuinely upset or unsettled afterwards, you don't have to carry that alone — there are people whose job this is.

[ON SCREEN: Accidental exposure isn't their fault. Don't shame — get low, ask, reassure. NSPCC 0808 800 5000. · Full playbook → Bearings/library/playbooks/pornography]

**Accidental spending — in-game and in-app.** Very common at this age, rarely dangerous, often expensive. A small child tapping happily through a game does not understand that the bright button costs real money — to them it's just another colourful thing to press. You've already headed off most of this with the device layer's Ask-to-Buy and the Roblox spending PIN. *If money's already gone missing:* remove or unlink the stored card, check recent transactions, and look for a refund — Apple, Google and the consoles can sometimes refund a young child's unauthorised purchases. Then it's a gentle teaching moment about pretend money versus real money, not a telling-off — they genuinely didn't know. *Signpost if spending ever becomes a worry in the household:* the **National Gambling Helpline, 0808 8020 133**, supports worried parents too.

[ON SCREEN: In-app spend — Ask-to-Buy on, Roblox spend PIN on, remove stored cards, check for refunds. National Gambling Helpline 0808 8020 133. · Full playbook → Bearings/library/playbooks]

**Strangers in games and chats.** This is the one to keep most in view at this age, because multiplayer games and their chats are where a young child can brush up against people you don't know. The UK picture, from the NSPCC's analysis of police-recorded data: Sexual Communication with a Child offences topped seven thousand in a single year — and a large share happen on apps and games where a chat can be moved somewhere private. *The red flag, again, is anyone pushing to move the chat off into a private or disappearing space.* Prevention is the calm "we only chat with people we know" rule we just covered, plus chat turned down or off in young children's games, plus the tablet in shared rooms. *If you're ever worried it's happening:* report to **CEOP** at ceop.police.uk/Safety-Centre, and call **999** if a child is in immediate danger.

[ON SCREEN: Worried about strangers in games or chats → CEOP (ceop.police.uk/Safety-Centre). 999 if immediate danger. · Full playbook → Bearings/library/playbooks/grooming]

Notice the pattern across all three: the same calm move underneath every one. *Stay calm, don't blame, sort it out together, and signpost — don't try to be the emergency service yourself.* For anything live and dangerous, the route is always 999, CEOP, or the helplines. That's not you failing. That's you doing exactly the right thing.

---

## WHAT NOT TO PANIC ABOUT (≈1.5 min)

[ON SCREEN: What you can let go of — for now.]

[B-ROLL: A parent exhaling, shoulders dropping, watching their small child giggle at the tablet across the room.]

Being against overwhelm means I owe you the other half of the truth: what you can stop worrying about at *this* age. Because a calm parent is a better-functioning parent, and almost all the frightening headlines are about *teenagers*, not five-to-ten-year-olds.

The big ones — **sextortion, AI companions, the dark corners of social media.** They are real and frightening, and they are the headline risks of the *later* bands, especially the teenage years. At five to ten, with the tablet in shared rooms and you nearby, these are simply not the things to lose sleep over tonight. We go deep on each in the older masterclasses, which is exactly where they belong.

[ON SCREEN: Sextortion, AI companions, "13+" social media — later bands' homework, not this one's.]

You also do not need your young child on the big social apps at all. Instagram, Snapchat, TikTok have a minimum age of thirteen for good reason — and the honest, easy move at five to ten is simply *not yet*, rather than installing them and policing them. That's not depriving your child of anything. It's age-appropriate, and it's allowed.

And here's the reframe I most want to leave you with: you do **not** have to monitor every second or build a perfect, gap-free wall. No system catches everything, and chasing that perfection will exhaust you and steal the easy joy out of this stage. The thing that actually makes the biggest difference at five to ten isn't a flawless set of settings. It's that they'll cheerfully *tell you* when something's wrong — because telling you is just what you do in your house. Build that, and you've built the thing that lasts all the way to eighteen.

---

## THE "DO THIS WEEKEND" CLOSE (≈1.5 min)

[ON SCREEN: This weekend. A few things. You can finish it.]

[B-ROLL: Same living-room rug from the open. The child playing happily on the tablet — and the parent right there beside them on the floor, sharing the screen.]

So here's your weekend. Not a project. An afternoon, with a child who'll probably want to "help."

[ON SCREEN, building as a checklist:
☐ Set up the device layer — Screen Time or Family Link — with Ask-to-Buy on, and lock it with a passcode they don't know.
☐ Switch YouTube to the Kids app, set the age level, set the timer.
☐ Set up Roblox at the real age, youngest content level, and turn on the spending PIN.
☐ Turn on SafeSearch + the broadband filter. Agree the tablet stays in shared rooms, out of the bedroom.
☐ Have the cornerstone chat — short, warm, in tiny-person words: "if it's weird or yucky, come and tell me, you won't be in trouble."]

Do the device layer first and lock it, with Ask-to-Buy on. Switch YouTube over to the Kids app and set the timer. Set up Roblox at the real age with the spending PIN. Turn on your filters, and agree — gently, today — that the tablet belongs in the family rooms. And then, the one that outlasts all of it: have the cornerstone conversation. Curled up on the sofa, no big build-up. *"If anything on the tablet is ever weird or yucky or scary, you come and find me straight away, and you'll never be in trouble. Telling me is always the good thing."*

That's the weekend. Setups that take an afternoon, and a handful of warm words you'll repeat for years.

[ON SCREEN: You're not building a wall. You're building the channel.]

You're at the easiest, warmest, most open stage of this whole journey — the one where your child genuinely *wants* you in it with them. Use it. Set up the few things that matter, plant the simple ideas that matter most, and then go and let them show you their favourite video for the fourteenth time.

That's co-use. That's the whole game at five to ten. You've got this.

[ON SCREEN: If your child is struggling: Childline 0800 1111 · Shout (text) 85258 · Samaritans 116 123 · Papyrus HOPELINE247 0300 102 2470 · full list Bearings/emergency.]

[ON SCREEN: Keep these where you'll find them again —
· Bearings/emergency — the full list, any time
· 999 — immediate danger
· Strangers in games / grooming worry → CEOP (ceop.police.uk/Safety-Centre); 999 if immediate danger
· If a child has been sent something, or you're worried generally → NSPCC 0808 800 5000
· If your child is struggling → Childline 0800 1111 · Shout (text) 85258 · Samaritans 116 123 · Papyrus HOPELINE247 0300 102 2470
· The threat playbooks → Bearings/library/playbooks · The conversation library → Bearings/library/conversations]

[ON SCREEN: Bearings · Next in the series — "The First Phone (11–12)": the one to watch before the first smartphone. · Emergency help any time → Bearings/emergency]

[B-ROLL: Tablet face-down on the rug. The parent and child laughing together at something off-screen. Fade.]

---

*[ON SCREEN, end-of-video disclaimer card:] This masterclass is general guidance for UK parents, drawn from Ofcom, the NSPCC, CEOP/NCA and the IWF. It does not monitor, detect or guarantee anything, and it is not a substitute for emergency help. If a child is in immediate danger, call 999. Platform settings change often — always confirm against the official help pages linked above. Last reviewed [DATE].*

---

*Sources referenced for the producer (attribute on screen where shown): CEOP/Thinkuknow ("talk little, talk often"; the cornerstone line; grooming/private-app red flag); NSPCC (Sexual Communication with a Child offences topped 7,000 in a year, from NSPCC's analysis of police-recorded data; "what happened" not "why"; grooming red flag; signpost numbers); Kerr & Stattin (parental knowledge depends on disclosure); Children's Commissioner / Ofcom (accidental exposure context — much exposure at young ages is accidental); Gambling Commission (in-game/loot-box spending context). Distress signpost wording mirrors the canonical Emergency Signpost (03): Childline 0800 1111, Shout text 85258, Samaritans 116 123, Papyrus HOPELINE247 0300 102 2470. No statistics invented; all attributed to UK authorities. Library deep-links use approved slugs only (/library/conversations, /library/playbooks, /library/playbooks/grooming, /library/playbooks/pornography). Settings paths checked [DATE] — re-verify at publish; menus move.*

*Guardrail check: no efficacy or safety guarantees made (explicitly negated — "no content filter is perfect", "no system catches everything", "not a wall you walk away from", "lower the odds, don't eliminate them"); no claim the product detects, monitors or prevents anything; emergencies signposted only (CEOP/999/Childline/NSPCC); distress/self-harm signpost (Childline 0800 1111 · Shout 85258 · Samaritans 116 123 · Papyrus HOPELINE247 0300 102 2470 · Bearings/emergency) included where accidental-exposure/distress harms are raised and on the end card, mirroring file 03 wording; "coaching" never offered as a service (and the posture word "coach" is not used in this band — posture here is co-use); no child-identifiable data solicited (band only); "may have moved" caveat + official help URLs included throughout the setup section; Bearings/[DATE] placeholders used; no romanticised/dramatised threat language; AI/social-media risks correctly deferred to later bands.*

---

## Band 11-12 — The First Phone (Ages 11–12): A Calm Masterclass for Parents

＃ The First Phone — Ages 11–12

*Bearings Masterclass · Age Band 11–12 · "First device" · Recorded [DATE] · Runtime ~16–18 min*

> **Format note for the producer.** First-person, warm, premium, unhurried. [ON SCREEN] = on-screen text/lower-thirds/graphics. [B-ROLL] = footage to cut over the voice. Pace: calm. We are against overwhelm — this is the right few things, done well, not a long list.

---

## COLD OPEN — the hook (≈1.5 min)

[B-ROLL: A kitchen table, early evening. A small box on the table — a new phone, still in its plastic. A child's hand reaching for it. Slow, warm, ordinary.]

[ON SCREEN: The first phone.]

There's a particular evening a lot of us reach. The phone is bought. It's sitting on the side, maybe still in the box. And there's this quiet feeling that's hard to name — a bit proud, a bit excited for them, and a bit like you've just handed someone a door to a city you can't see all of.

I want to start by taking the temperature down. Because here's the thing I most want you to hear, right at the top:

[ON SCREEN: Most of what your child does online at this age is ordinary. Some of it needs a little setup. Very little of it needs panic.]

This is the easiest of all the years to get the foundations right. Your child is eleven or twelve. They still mostly *tell you things*. They're often happy to sit next to you while you figure out an app together. That window — where you're allowed to be in it *with* them — is wide open right now, and it won't stay this wide. So this isn't a masterclass about locking the world down. It's about using this easy year well, so the harder years are easier too.

I'm going to give you four things to set up, the few conversations that genuinely matter, the handful of risks that are real at this age — explained calmly — and one short list of things you honestly do not need to worry about yet. Then a "do this weekend" close you can actually finish.

Let's go.

---

## WHAT CHANGES AT THIS AGE — the posture (≈2.5 min)

[B-ROLL: A parent and child on a sofa, shoulder to shoulder, both looking at one screen. Not over-the-shoulder surveillance — side by side.]

[ON SCREEN: The posture for 11–12: CO-USE.]

Across the whole of childhood, a parent's job online slides through four postures. It goes from *co-use*, to *co-set*, to *coach*, to *consult*. At seventeen you're a consultant — they lead, you advise. But at eleven and twelve, you're at the very start of that slide, and the posture has a name: **co-use**.

Co-use means hands-on, alongside them, structured. You set things up *together*. A lot is visible — and that's not you snooping, that's just how it works at this age. The apps live on shared devices, in shared rooms, and you're nearby. This is the season where you sit *next* to them, not behind them.

[ON SCREEN: Co-use = alongside, not over the shoulder. You set things up together. A lot is visible — and that's normal.]

Here's why this matters more than any single setting. There's a landmark piece of research — Kerr and Stattin — that found what a parent actually *knows* about their child's life depends far more on the child *choosing to tell them* than on any monitoring or control. Warmth beats surveillance. Not as a nice idea — because it actually works better.

[ON SCREEN: What you know depends more on your child choosing to tell you than on any control. (Kerr & Stattin)]

So co-use is doing two jobs at once. You're setting up sensible guardrails — and you're building the *channel*. The relationship where they come to you. Knowing a little bit about their world — their game, their favourite creator — is what makes it easy for them to raise a problem with you later.

One practical note on age, and it matters. Keep their *real* birthday on everything. The temptation at this age is to fudge it — say they're older to get into an app. Don't. Almost every protection an app offers keys off the date of birth on the account. An honest birthday is one of the most valuable things you can set, and it's free.

[ON SCREEN: Keep the real birthday on every account. Protections key off it.]

[B-ROLL: A child laughing at something on a screen; a parent leaning in to see, genuinely curious.]

CEOP — that's the UK's child-protection command — has a slogan I love for this age: *talk little, talk often.* Not one Big Serious Talk. Lots of small, low-key moments. We'll come back to that.

---

## THE FOUR THINGS TO SET UP NOW (≈4 min)

[ON SCREEN: Four things. In order. That's the whole list.]

We are against overwhelm here, so I'm not going to drown you in toggles. At this age there are four things worth doing, and there's an order. Highest-leverage first.

[ON SCREEN: A quick caveat we keep on everything — Menus move. App makers rename and relocate settings constantly. If a path doesn't match your screen, search the setting name in the app, or use the official help link. Paths checked June 2026.]

**One: the device layer. Do this first.**

[B-ROLL: A phone's Settings screen, finger scrolling to Screen Time / Family Link.]

Before any individual app, set up the layer that governs *every* app, install and website at once. On an iPhone that's **Apple Screen Time** through Family Sharing. On Android or a Chromebook it's **Google Family Link**.

Why first? Because it's the backstop that still works even when a clever child finds a way around an app's own controls. Inside it, the things that matter at this age are: **Downtime** — hours when only allowed apps work, like overnight and homework; **App Limits**; **Content & Privacy Restrictions** to block age-inappropriate sites and apps; and **Ask to Buy**, so your approval is needed before anything is bought or downloaded.

And the one people forget: on Apple, *lock Screen Time with a passcode your child doesn't know.* Do that first — otherwise everything else can simply be switched back off.

[ON SCREEN: Device layer first. Lock it with a passcode they don't know.
Apple: support.apple.com/en-us/108806
Google: support.google.com/families/answer/7101025]

**Two: filters at the network and search level.**

Turn on **SafeSearch**, and turn on your **broadband provider's adult-content filter** at the router. At this age a lot of exposure to things you'd rather they didn't see is *accidental* — a stray link, a search that goes sideways. Network filters quietly catch a good chunk of that in the background. They're not perfect, and nothing is — but they lower the odds, and they ask nothing of your child.

[ON SCREEN: SafeSearch on + broadband adult-content filter on. Catches a lot of accidental exposure.]

**Three: the games — Roblox especially, with a spend cap.**

[B-ROLL: A Roblox or Minecraft world on a tablet.]

Roblox and Minecraft dominate this age. In Roblox, set up the **parental controls** — link your account, set the **content maturity** ceiling, manage chat, and — this is the big one for eleven and twelve — set a **monthly Robux spending cap**. In-game spending is one of the most common complaints parents have, and it's easy to head off here.

A heads-up: Roblox changed a *lot* in 2026, including facial age-estimation to use chat. So if your screen doesn't match what you expect, check their official page rather than guessing.

[ON SCREEN: Roblox — set the maturity level, manage chat, and set a monthly spend cap.
about.roblox.com/parental-controls]

**Four: YouTube — Kids or a supervised account.**

For this age, use **YouTube Kids** or a **supervised account**, not the open adult app. And the simplest rule of all, the one that quietly does more than any toggle: **keep social and chat apps on shared devices, in shared rooms.** The phone lives in the kitchen, not the bedroom. That single habit makes co-use natural instead of a fight.

[ON SCREEN: YouTube Kids or supervised. And — shared devices, shared rooms.]

That's it. Four things. If you do nothing else from this whole masterclass, do those — in that order — and you've done the heavy lifting.

---

## THE CONVERSATIONS THAT MATTER MOST HERE (≈3.5 min)

[B-ROLL: A parent and child in a car, both facing forward, talking easily. No eye contact — that's the point.]

[ON SCREEN: The conversations. Little and often. In your own words.]

Settings are the easy half. The conversations are the half that lasts. At this age there are a few that matter most — and the first one is the one I'd tattoo on the inside of every parent's wrist if I could.

**The cornerstone: "come to me, and you won't be in trouble."**

[ON SCREEN: The cornerstone line — say it early, say it often.]

This is the single most important sentence in this entire masterclass. It comes straight from CEOP. The reason a child stays silent when something goes wrong online is almost always *shame*, or *fear of being punished* — usually fear of losing the phone. This one line dismantles both.

In your own words, something like:

> *"If anything online ever feels weird, or scary, or out of control — even if you broke a rule to get there — I want you to come straight to me, and you will not be in trouble. Helping you matters to me way more than any rule."*

At this age, keep it concrete: *"come and find me, even if it's embarrassing."* And here's the hard part — you have to actually *mean it* in the moment it's tested. The day they come to you having clicked the wrong thing or said the wrong thing, your calm, non-blaming face is the thing that keeps the channel open for the next ten years. Confiscating the phone the first time something goes wrong teaches them to handle the next problem alone. Don't trade a lifetime of them telling you for one moment of being right.

[ON SCREEN: "If anything happens, telling me won't cost you your phone."]

**Second: "show me your world."**

[B-ROLL: A child enthusiastically showing a parent a game or a video; the parent genuinely interested.]

This one's a joy, and it's strategic. Get curious about their actual world. *"Show me something you actually like on here — what's the funniest thing you've seen this week?"* Be interested in their game, their creator, the way you'd be interested in their friends at school. This is how you build the channel — and bluntly, it's how you'll *notice* if something's off later, because you'll know what normal looks like.

Pair this with the **new-app check**: *"What app do you want to use, and what do people mainly do on it? Let's set it up together."* That "let's set it up together" is co-use in one sentence — it's how a new app becomes a shared thing rather than a secret one.

**Third: strangers — calmly.**

[ON SCREEN: Online, people aren't always who they say they are. The red flag: "let's move to a private app."]

You don't need to frighten them. The frame is simple: *"Online, people aren't always who they say they are — someone can seem fourteen and not be. Has anyone you don't know in real life ever added or messaged you? What did you do?"*

And teach them the *one* red flag that matters most — the thing CEOP and the NSPCC both flag: **anyone who wants to move the chat to a private or disappearing app.** That's the move to watch for. If someone says "let's talk on a different app where it's just us" — that's the moment to come and tell you.

One quick "don't" that saves a lot of relationships. Ask *"what happened?"* — not *"why did you do that?"* The word "why" makes a child defensive and they shut down. "What happened, talk me through it" keeps them talking. Tape that one to the fridge.

[ON SCREEN: Ask "What happened?" — never "Why did you do that?"]

**Fourth: where the phone sleeps at night.**

[B-ROLL: A phone charging on a kitchen counter overnight, the house dark and quiet.]

One easy habit worth agreeing now, while it's still uncontroversial — where the phone sleeps. Not a punishment, just a household norm you set early and keep simple. In your own words, something like: *"Can we find a charging spot for phones that isn't your bed? There's solid evidence screens in bed wreck sleep — and I'll do it too; mine charges in the kitchen."* Agreeing it at eleven, before it's a battleground, is far easier than clawing it back at fourteen — and doing it yourself is the whole trick. If a child is already tired, low, or anxious in a way that worries you, that's worth a calm word too — and you don't have to handle it alone; the people below are there for exactly that.

[ON SCREEN: Phones charge outside the bedroom overnight — yours too. Agree it now, while it's easy.]

[ON SCREEN: If your child is struggling: Childline 0800 1111 · Shout (text) 85258 · Samaritans 116 123 · Papyrus HOPELINE247 0300 102 2470 · full list Bearings/emergency.]

[ON SCREEN: The exact words for every one of these → Bearings/library/conversations · Worried about grooming or stranger contact → Bearings/library/playbooks/grooming]

---

## THE TOP THREATS FOR THIS AGE — calmly (≈3.5 min)

[ON SCREEN: The real risks at 11–12 — named plainly, handled calmly.]

Now the part everyone braces for. I'm going to name the genuine risks at this age — but I'm going to name them the way I'd want them named to me: factually, with what to *do*, and where to go for help. Not to scare you. The opposite. Naming a thing calmly is how you stop being afraid of it.

[B-ROLL: Calm, neutral footage — a phone face-down on a table, a quiet room. Nothing alarming.]

**Stranger contact and early grooming.** This is the core one to keep in view at this age, more than any other. The UK picture, from the NSPCC's analysis of police data: over seven thousand Sexual Communication with a Child offences were recorded in a year — and a large share happen on apps where chats can move private. *The red flag, again, is the push to move to a private or disappearing app.* Prevention is the conversation we just had, plus keeping chat apps on shared devices. *If you're ever worried it's happening:* report to **CEOP** — that's ceop.police.uk/Safety-Centre — and call **999** if a child is in immediate danger.

[ON SCREEN: Worried about grooming or stranger contact → CEOP (ceop.police.uk/Safety-Centre). 999 if immediate danger. · Full playbook → Bearings/library/playbooks/grooming]

**In-game spending and loot boxes.** Very common, rarely dangerous, often expensive. Loot boxes — paying for a randomised reward — are designed to feel like a near-miss win, and they're not currently regulated as gambling here, so this gap is one parents manage themselves. You've already handled most of this with the spend cap and Ask to Buy. *If money's already gone missing:* remove the stored card, audit recent transactions, and check for a refund — Apple, Google and the consoles can sometimes refund a child's unauthorised purchases. And talk about *why* it pulled them in, rather than just confiscating. *Signpost if it's become a worry:* the **National Gambling Helpline, 0808 8020 133**, supports worried parents too.

[ON SCREEN: In-game spend — cap it, remove stored cards, check for refunds. National Gambling Helpline: 0808 8020 133. · Full playbook → Bearings/library/playbooks]

**First cyberbullying.** Bullying roughly *doubles* between age eleven and fifteen, so this is often where it starts — and most of it now happens on a device. The move that helps most here is the cornerstone promise: that they can show you anything *without losing the phone* — the most evidence-aligned habit there is. *If it's happening:* **screenshot first** — evidence vanishes when you block — then block and report in-app, don't retaliate, and tell the school if classmates are involved. *Signpost:* **Childline, 0800 1111**, for them; and **Report Harmful Content** at reportharmfulcontent.com for non-criminal stuff. If it crosses into threats or harassment, that's the police on 101.

[ON SCREEN: Cyberbullying — screenshot first, then block & report. Childline 0800 1111 · reportharmfulcontent.com · Full playbook → Bearings/library/playbooks/cyberbullying]

**Accidental pornography exposure.** I'll be plain because pretending otherwise doesn't help: the Children's Commissioner puts the average age of first exposure in the UK at around thirteen, and a growing share is genuinely *accidental* — a feed, a link. Your network filters lower the odds; they don't eliminate them. So the real protection is that they're not *afraid* to tell you they saw something. *If it happens:* don't shame or punish — especially for an accident; shame just guarantees silence next time. Ask what they saw and how it felt, tighten the filters together, and if a child was *sent* such content by an adult, that's a safeguarding matter — **CEOP**, the school, or **NSPCC on 0808 800 5000**. And if something they've seen leaves them genuinely distressed, you don't have to handle that alone — there are people whose job this is.

[ON SCREEN: Accidental exposure isn't their fault. Don't shame — talk. NSPCC 0808 800 5000. · Full playbook → Bearings/library/playbooks/pornography]

[ON SCREEN: If your child is struggling: Childline 0800 1111 · Shout (text) 85258 · Samaritans 116 123 · Papyrus HOPELINE247 0300 102 2470 · full list Bearings/emergency.]

Notice the pattern across all four: the same calm move underneath every one. *Stay calm, don't blame, screenshot before you block, and signpost — don't try to be the emergency service yourself.* For anything live and dangerous, the route is always 999, CEOP, or the helplines. That's not you failing — that's you doing exactly the right thing.

---

## WHAT NOT TO PANIC ABOUT (≈1.5 min)

[ON SCREEN: What you can let go of — for now.]

[B-ROLL: A parent exhaling, shoulders dropping, watching their kid play happily across the room.]

Being against overwhelm means I owe you the other half of the truth: what you can stop worrying about at *this* age. Because a calm parent is a better-functioning parent, and most of the scary headlines are about *older* teenagers.

The big one — **sextortion**. It's real and it's frightening, and it's the headline risk of the *next* band, thirteen to fourteen, especially for boys. At eleven and twelve, with honest birthdays and apps on shared devices, it is not the thing to lose sleep over tonight. We'll go deep on it in the thirteen-to-fourteen masterclass, which is the one to watch *before* they hit the social-media age.

[ON SCREEN: Sextortion, AI companions, "13+" social media — mostly next band's homework, not this one's.]

You also don't need a full lockdown of every app most teenagers use — Instagram, Snapchat, TikTok. The minimum age is thirteen, and the honest move at this age is simply *not yet*, rather than installing them and policing them. Same with AI companion apps and the more grown-up corners of the internet — they belong to later conversations.

And here's the reframe I most want to leave you with: you do **not** have to monitor everything. The family-centre dashboards on these apps mostly show you *who*, not *what* — they're conversation-starters, not surveillance, and not a guarantee. The thing that actually makes the biggest difference at this age isn't a perfect wall of settings. It's that they'll *tell you* when something's wrong. Build that, and you've built the thing that lasts.

---

## THE "DO THIS WEEKEND" CLOSE (≈1.5 min)

[ON SCREEN: This weekend. Four things. You can finish it.]

[B-ROLL: Same kitchen table from the open. The phone is out of the box now, in a child's hands — and the parent is right there beside them, smiling.]

So here's your weekend. Not a project. An afternoon.

[ON SCREEN, building as a checklist:
☐ Set up the device layer — Screen Time or Family Link — and lock it with a passcode they don't know.
☐ Turn on SafeSearch + the broadband filter. Set the Roblox spend cap. Switch YouTube to Kids or supervised.
☐ Check the real birthday is on every account.
☐ Agree where the phone sleeps — a charging spot that isn't the bed, yours too.
☐ Have the cornerstone chat — in the car, low-key: "come to me, and you won't be in trouble."]

Do the device layer first and lock it. Turn on your filters, set the Roblox spend cap, switch YouTube over. Confirm the real birthday everywhere. Agree the overnight charging spot — yours included. And then — the one that outlasts all of it — have the cornerstone conversation. In the car, doing something else, no big build-up. *"If anything online ever feels weird or scary, come straight to me, and you won't be in trouble."*

That's the weekend. Settings that take an afternoon, and one sentence that takes ten seconds and lasts ten years.

[ON SCREEN: You're not building a wall. You're building the channel.]

You're at the easiest, most open stage of this whole journey — the one where they still want you in it with them. Use it. Set up the few things that matter, say the line that matters most, and then go and let them show you the funniest thing they've seen this week.

That's co-use. That's the whole game at eleven and twelve. You've got this.

[ON SCREEN: Keep these where you'll find them again — If your child is struggling: Childline 0800 1111 · Shout (text) 85258 · Samaritans 116 123 · Papyrus HOPELINE247 0300 102 2470 · full list Bearings/emergency. · Worried about grooming or stranger contact → CEOP (ceop.police.uk/Safety-Centre); 999 if immediate danger. · The threat playbooks → Bearings/library/playbooks · The conversation library → Bearings/library/conversations]

[ON SCREEN: Bearings · Next in the series — "The Threshold Year (13–14)": the one to watch before social media. · Emergency help any time → Bearings/emergency]

[B-ROLL: Phone face-down on the table. The parent and child laughing at something off-screen. Fade.]

---

*Sources referenced for the producer (attribute on screen where shown): CEOP/Thinkuknow ("talk little, talk often"; the cornerstone line; grooming red flag); NSPCC (Sexual Communication with a Child offence figure, from NSPCC's analysis of police-recorded data; "what happened" not "why"; grooming red flag; signpost numbers); Kerr & Stattin (parental knowledge depends on disclosure); Ofcom (bullying doubling 11→15, device-based bullying); Children's Commissioner / Ofcom (pornography exposure age); Gambling Commission (loot boxes not regulated as gambling); Internet Matters (co-use, curiosity, phones-at-night/sleep); sleep evidence (phones-at-night habit). Distress signpost wording mirrors the canonical Emergency Signpost (03): Childline 0800 1111, Shout text 85258, Samaritans 116 123, Papyrus HOPELINE247 0300 102 2470. No statistics invented; all attributed to UK authorities. Library deep-links use approved slugs only (/library/conversations, /library/playbooks, /library/playbooks/grooming, /library/playbooks/cyberbullying, /library/playbooks/pornography). Settings paths checked June 2026 — re-verify at publish; menus move.*

*Guardrail check: no efficacy or safety guarantees made; no claim the product detects, monitors or prevents anything; emergencies signposted only (CEOP/999/Childline/NSPCC/Report Harmful Content); distress/self-harm signpost added where mental-health/sleep harms are raised (at the night-phone conversation, in the threats block, and on the end card) — Childline/Shout/Samaritans/Papyrus + /emergency; no child-identifiable data solicited (band only); "may have moved" caveat + official help URLs included; Bearings/[DATE] placeholders used.*

---

## Band 13-14 — The Threshold Year: A Calm Masterclass for Parents of 13–14-Year-Olds

# The Threshold Year
### A Bearings Masterclass · Ages 13–14 · ~28 minutes

---

[ON SCREEN: Title card — "THE THRESHOLD YEAR · Ages 13–14". Soft fade-up. Warm, low-key.]

[B-ROLL: A kitchen at the end of a school day. A teenager at the table, phone face-down beside a glass of water. A parent making tea, not hovering. Ordinary. Calm.]

---

## COLD OPEN — The Tuesday-Night Hook

[ON SCREEN: Presenter, mid-shot, relaxed. No clipboard, no panic.]

Let me start with a Tuesday night. Nothing dramatic.

Your thirteen-year-old has just got a Snapchat account, because everyone in the year group has one, and the conversation about whether they're "ready" has quietly resolved itself the way these things do — somewhere between "no" and "well, all their friends are on it." They're up in their room. You can hear the little notification sounds. And you have that feeling — the one almost every parent of a teenager this age describes to me — which isn't quite fear. It's more like standing at the bottom of the stairs, listening, and realising you genuinely don't know what's happening up there anymore.

That feeling is normal. It is not a sign you've done something wrong. And it is not a sign your child is in danger.

[ON SCREEN: Lower-third — "This is the threshold year."]

Here's what I want you to take from the next half hour. This age — thirteen, fourteen — is the year your child crosses a threshold. They hit the platforms' minimum age of thirteen, so the apps that were "later" suddenly become "now." And at the same time, something is happening in their developing brain that we'll talk about properly in a moment.

So yes — this is the highest-stakes year. But high-stakes is not the same as high-panic. The whole point of this masterclass is that the things that actually matter here are few, they're specific, and you can set most of them up over a single weekend. We are not going to drown you in a hundred settings. We're going to do the right four. We're going to have the two or three conversations that genuinely change the odds. And I'm going to be just as clear with you about what's already fine — what you can stop worrying about — as about what to change.

[B-ROLL: Hands setting down a single sheet of paper with a short list. Not a thick binder. One page.]

Because the enemy here isn't your child's phone. The enemy is overwhelm. Let's get rid of that first.

---

## PART ONE — What Actually Changes At This Age

[ON SCREEN: Section card — "1 · What changes now"]

So what is it about thirteen and fourteen specifically?

Two things land at the same time, and it's the overlap that makes this band the one to take seriously.

[ON SCREEN: Simple two-line build. Line 1: "The apps arrive." Line 2: "The brain is mid-build."]

The first is obvious: the apps arrive. Thirteen is the minimum age for Instagram, Snapchat, TikTok, WhatsApp — so adoption doesn't trickle, it surges. Almost overnight your child goes from the edges of the internet to the middle of it. Identity, self-presentation, who-liked-what — it all intensifies. Likes become a kind of social currency.

The second thing is quieter and it's the one most parents aren't told. In mid-adolescence — right around now — the reward-seeking part of the brain is running hot, while the self-control part is still under construction. That's not a character flaw. That's neurology. It's the same in every generation; we just didn't used to hand it a device with the entire world inside. And on top of that, this is the age where the influence of peers on risk-taking is at its absolute peak. Your child is wired, right now, to care enormously what other thirteen-year-olds think, and to act on it faster than their judgement can catch up.

[ON SCREEN: Quote-style card — "The gap between wanting and self-control is widest now."]

That's the developmental picture. And here's why I'm telling you, rather than just handing you a settings checklist: because it changes the kind of parent this year asks you to be.

[ON SCREEN: The posture slide — four words, the middle one highlighted: "Co-use → CO-SET → Coach → Consult"]

At eleven or twelve — the "first device" year — you're co-using. Hands-on, alongside them, a lot is visible, you set things up together. That was the right posture then.

This year, you move to what I call co-setting. And the shift is small in words but big in practice. It's the move from "here are the rules" to "we need some limits — let's agree them together." You're still the parent. You still hold the line on the things that matter. But you do it with them, out loud, as a team — because a fourteen-year-old who helped build the rule is far more likely to keep it, and far more likely to come to you when it breaks.

Later — fifteen, sixteen — you'll become a coach, then by seventeen, eighteen, a consultant they come to for advice. But not yet. Right now, you're co-setting. That's the posture for this whole masterclass.

[B-ROLL: Parent and teen sitting on the same side of a table, both looking at one phone screen. Side by side, not face to face.]

One more reassurance before we go on, because parents ask me this constantly. "Have I left it too late? They're already on everything." No. Thirteen and fourteen is exactly the right moment for this. The accounts are new enough that setting them up properly feels normal, not like a crackdown. You haven't missed the window — you're standing in the middle of it.

---

## PART TWO — The Settings That Actually Matter (Do These First)

[ON SCREEN: Section card — "2 · The settings to prioritise"]

Right. Let's make this concrete. There are roughly ten platforms a parent could obsess over. We are going to prioritise four things. Four. If you only ever do the next ten minutes of this video, you'll have done the work that matters most.

[ON SCREEN: Standing caveat, kept on screen in smaller text throughout this section — "Menus move. App-makers rename and relocate settings often. If a path doesn't match your screen, search the setting name in the app or use the official help link. Paths current as of [DATE]."]

And one honest note that stays on screen for this whole section: these menus move. App-makers rename and shuffle settings all the time. So if what I describe doesn't match your screen exactly, don't panic and don't assume you've done it wrong — just search the setting's name inside the app, or follow the official help link. The setting is almost always still there; it's just been moved.

### Priority one: the real birthday on every app.

[ON SCREEN: Big, simple — "1. The real date of birth."]

This is the unglamorous one, and it matters more than almost any other setting this year. Almost every protection these apps offer keys off the date of birth on the account. The strict-by-default settings for under-sixteens, the limits on who can message your child, the content filters — all of it switches on automatically based on the age the account thinks your child is.

[B-ROLL: A finger scrolling to a "Date of Birth" field in an app's account settings.]

So if your twelve-year-old put in a fake birthday last year to get onto something early — and many do — that account may be treating them as an adult right now, with every protection switched off. Go and check. On Instagram, Snapchat, TikTok, all of them: make sure the real birthday is set.

And here's something genuinely new for 2026 that's on your side. Meta — Instagram — now uses AI age-estimation, and from this year, visual age estimation, to move accounts it suspects belong to a teenager into the protected settings even if an adult birthday is listed. Roblox now requires a video-selfie age check to use chat. The platforms are finally doing some of this work. But you should not rely on it. The most useful thing you can do on any app is make the birthday honest.

### Priority two: Snapchat — Family Centre, Ghost Mode, and Contact-Me set to Friends.

[ON SCREEN: "2. Snapchat — three toggles."]

Snapchat is where I'd start among the apps, because it's where most thirteen-year-olds land first and it's the one with the location feature parents most need to understand.

Three things. First, set up Family Centre — both of you need accounts, and you both opt in. Go to Profile, the settings cog, Privacy Controls, Family Centre, and send the invite. Now — be clear-eyed about what this gives you. It shows you who your child is friends with and who they've been messaging in the last seven days. It does not show you what they said. Snapchat's Family Centre is a window, not a wiretap. That's actually fine — we're not aiming for surveillance, we're aiming for visibility that starts conversations.

[B-ROLL: A phone screen showing a settings menu; a thumb flicking a toggle from off to on.]

Second — and this is the big one — Snap Map and Ghost Mode. Snap Map can show your child's precise, live location on a map. Turn on Ghost Mode: open the Map, tap the settings cog, switch on Ghost Mode. This hides their live location. One important detail: only your child can switch this off from their account — Family Centre lets you see who they share with, not flip it for them — so this one is a conversation as much as a setting. Do it together.

Third, set "Contact Me" to Friends — not "Friends and Contacts" — so that people they haven't added can't message them. Two minutes, and you've closed the door strangers walk through.

### Priority three: Instagram — confirm the Teen Account defaults.

[ON SCREEN: "3. Instagram — confirm the Teen Account."]

Instagram now places every under-eighteen into a "Teen Account" with the protective settings on by default — and for under-sixteens, your child needs your permission, through supervision, to loosen any of them. That's a real shift in your favour. Your job here is mostly to confirm it's actually on, not to build it from scratch.

Set up supervision through Family Centre. Then check the Teen Account defaults are in place: the account is private, messaging is set to the strictest level so only people they follow can message them, sensitive-content is on its most restrictive setting, and Sleep Mode is muting notifications overnight. Under-sixteens can't go Live or turn off the nudity-blur in messages without your say-so. If those are all on — and they usually are by default now — you're done. Genuinely. That's a case where the right answer is "this is already fine, move on."

### Priority four: keep the device layer running.

[ON SCREEN: "4. The device layer — your backstop."]

Last one. Underneath all the individual apps sits the device itself — Apple Screen Time on an iPhone, Google Family Link on Android. This is your backstop, because it works even when an app's own controls get bypassed by a second account or the web browser.

[B-ROLL: A parent's phone showing a Screen Time summary; calm, not alarmed.]

You likely set this up at the eleven-to-twelve stage. This year, just keep it running and check two things. On Apple: that Screen Time is locked with a passcode your child doesn't know — because if it isn't, everything else can be switched off — and that Downtime covers the overnight hours. On Android, the equivalent lives in Family Link under Screen Time and Controls. You don't need to tighten it dramatically. You need it to still be on.

[ON SCREEN: Recap card — "Real birthday · Snapchat (Ghost Mode + Contact-Me) · Instagram Teen defaults · Device layer running."]

That's it. That's the settings work for this year. Four things. I'll put the official help links for each on screen and in the notes, and I'd genuinely rather you did these four well than thirty badly.

[ON SCREEN: Links — support.apple.com/en-us/108806 · support.google.com/families/answer/7101025 · parents.snapchat.com · familycenter.meta.com · "All settings may have moved — search the setting name in-app."]

---

## PART THREE — The Conversations That Matter Most

[ON SCREEN: Section card — "3 · The conversations"]

Now. If the settings are the locks on the doors, the conversations are the reason your child walks back through the front door when something goes wrong. And I want to be honest with you: the research is unusually clear on this. What you actually know about your child's online life depends far more on them choosing to tell you than on any setting or any monitoring you do. Warmth genuinely beats surveillance — not as a nice sentiment, but because it's what works.

So before the specific scripts, three quick principles to carry into all of them.

[ON SCREEN: Three lines build — "Little and often, not one big talk." · "Be curious, don't lecture." · "Ask 'what happened?' — never 'why did you do that?'"]

One: little and often, not one enormous "we need to talk." The experts at CEOP literally use the slogan "talk little, talk often." A sideways comment in the car, where there's no eye contact, beats a scheduled summit at the kitchen table every time.

Two: be curious, not a lecturer. Ask about their world the way you'd ask about their friends.

Three — and write this one down — ask "what happened?", never "why did you do that?" The word "why" makes a teenager defensive and shuts the whole thing down. "What happened, talk me through it" keeps the door open.

There are several conversations in the full library, but at this age, three matter most. Let's do them.

### Conversation one: the cornerstone. "You won't be in trouble."

[ON SCREEN: Section card — "THE CORNERSTONE. Lead with this. Always."]

[B-ROLL: A parent and teen walking together, talking easily. Late afternoon light.]

This is the one. If you take a single sentence from this entire masterclass, take this one. It leads every age band, it never expires, and at this age it earns its keep more than any other year.

Here's the shape of it — and use your own words, this is scaffolding, not a script to read aloud:

[ON SCREEN: The cornerstone, displayed in full, warm typography —
"If anything online ever feels weird, or scary, or out of control — even if you broke a rule to get there — I want you to come straight to me, and you will not be in trouble. Helping you matters to me way more than any rule."]

Let me tell you why this single line matters so much, because if you understand the why, you'll mean it when you say it. According to CEOP, a lot of the serious online harm aimed at this age group runs on one thing: the child's fear that they'll be in trouble if they tell. Shame and fear of punishment are exactly what keep a teenager silent — and silence is what lets a small problem grow into a much bigger one. This one sentence is designed to take that fear away. It's about as evidence-aligned as anything a parent can say.

And it comes with a pact you have to be willing to keep. The unspoken second half of that sentence is: "...and I won't take your phone away for telling me." Because the moment your child believes that coming to you costs them their phone, they will handle the next problem alone. So the cornerstone and the no-confiscation promise are the same promise. Make it, and then — this is the hard part — keep it, even when your instinct screams to grab the device. Your calm, non-blaming reaction does more to protect them than any setting you'll change this year.

### Conversation two: sextortion — the scam aimed at teenagers. Have this one early.

[ON SCREEN: Section card — "Sextortion. Have this conversation early — before it's needed."]

This is the conversation parents most want to avoid and most need to have, and I'm going to give it to you calmly, because calm is exactly how you should deliver it.

Sextortion is a financially-motivated scam. Someone — usually pretending to be a teenager — gets flirty, fast. They persuade the young person to send a nude image. And then the mask comes off: they threaten to share that image with the victim's friends and family unless they're paid. It is, at its heart, blackmail. And UK authorities — the National Crime Agency — are clear that it targets teenage boys, roughly fourteen to seventeen, the hardest. So if you have a son in this band, this is your priority conversation — and the instinct that "my boy wouldn't" is exactly the instinct these criminals rely on.

[ON SCREEN: Reassurance line — "It is never the victim's fault. And it can be fixed."]

Here's how to have it — sideways, low-key, maybe prompted by something on the news:

[ON SCREEN: The script —
"There's a scam going round aimed at people your age. Someone pretends to be a teenager, gets flirty fast, gets a person to send a nude — then threatens to share it unless they pay. If that ever happens to you or a mate: stop, don't pay, don't delete anything, block them, and come to me. It's never the victim's fault, and it can be fixed."]

Notice what that does. It names the threat without terrifying. It pre-loads the exact steps. And it ends on hope — it can be fixed — which is true, and which is what keeps a panicking teenager from doing the worst thing, which is paying or going silent.

I'll come back to the precise what-to-do steps in the next section, because they matter and I want them clean and memorable. For now, the message is just: have this conversation before it's ever needed. A teenager who's heard this from you, calmly, in advance, is a teenager who has somewhere to turn at the worst moment.

### Conversation three: AI chatbots and companions.

[ON SCREEN: Section card — "AI chatbots — useful tool, not a friend."]

This one's newer, and it catches a lot of parents off guard. Your child is almost certainly using AI chatbots — for homework, for ideas, sometimes just to talk. Some of these apps present themselves as companions, even friends. And because they remember things your child told them, they can feel remarkably like a real relationship.

[B-ROLL: A teen typing to a chatbot interface; the screen glow on their face, neutral, not sinister.]

The conversation here isn't "these are dangerous, stop." It's calmer and more useful than that:

[ON SCREEN: The script —
"Have you used any of the AI chatbot apps? Which are actually useful? One thing worth knowing — they can feel like a friend because they remember stuff, but they can't actually care about you, and they get things confidently wrong. Great for ideas; not the place to go for anything that's really worrying you. That's what people are for."]

The best way to have this one is side by side, while they're actually using one: "Does that sound right to you? How could we check?" You're not banning a tool. You're teaching them where its edges are — that it's brilliant for ideas and useless as a confidant, and that when something really worries them, they go to a human. Ideally you.

And one piece of reassurance that's genuinely on your side: the rules here are tightening. As part of the new online-safety measures, romantic and companion-style AI chatbots are expected to be banned for under-eighteens — it's an announced direction of travel, not fully in force yet, but it's a sign the law is moving to back you up rather than leave you to it.

[ON SCREEN: The "what NOT to say" card — two columns.
"Why did you send that?" → "What happened? Talk me through it."
"They were so stupid to share it." → "That could happen to anyone — it's really common."
"If anything happens I'll take your phone." → "If anything happens, telling me won't cost you your phone."
"How could you be so naive?" → "These scams are designed to fool adults too."]

And keep this card somewhere visible. These are the phrases that reliably shut a teenager down, with the swap for each. Parents tell me they find the "don'ts" as useful as the "do's" — because anything that signals judgement, punishment or blame teaches your child to handle the next problem without you.

[ON SCREEN: Deep-dive — "The full word-for-word scripts, including the nudes-pressure and screen-time conversations, are in the conversation library → /library/conversations."]

---

## PART FOUR — The Top Threats For This Age, Calmly

[ON SCREEN: Section card — "4 · The threats that matter now"]

Now let's talk threats directly — calmly, the way we'd talk through a fire drill. Not because the house is on fire, but because knowing where the exits are is how you stay calm if it ever is. For each one: what it is, and what to do. And every single one of these ends not with you improvising heroics, but with you pointing to people whose actual job this is.

[ON SCREEN: Standing line — "If something is already happening: you are not the emergency service. Stay calm, and signpost. /emergency or 999 if anyone is in immediate danger."]

### Sextortion — the headline risk.

[ON SCREEN: "Sextortion" with the step list building one line at a time.]

We named it already; here are the steps clean, because they're the ones to know by heart. If it's happening — to your child or one of their friends — these are the standard steps UK authorities tell families to take:

[ON SCREEN, building:
"STOP — don't continue the conversation.
DON'T PAY — paying never ends it.
DON'T DELETE — you need the evidence.
SCREENSHOT the threats.
TELL a trusted adult.
REPORT to CEOP / Report Remove.
999 if there's immediate risk."]

Stop. Don't pay — paying never makes it stop, it marks them as someone who pays. Don't delete anything — that's the evidence. Screenshot the threats. Tell a trusted adult. And report to CEOP — that's ceop.police.uk/Safety-Centre — and to Report Remove, run by Childline with the Internet Watch Foundation, at childline.org.uk/remove, which can get a nude image of an under-eighteen taken down and pre-emptively blocked across platforms. If there's immediate danger, 999. UK authorities are clear children are not prosecuted for being the victim here. Your job is calm and signpost — not detective, not negotiator.

[ON SCREEN: Sextortion — CEOP ceop.police.uk/Safety-Centre · Report Remove childline.org.uk/remove · 999 if immediate risk. Full playbook → /library/playbooks/sextortion.]

### Nudes and image-sharing.

[ON SCREEN: "Sharing images ('nudes')"]

Closely related: young people creating and sharing nude images, often consensually with a partner, which can then be forwarded or leaked. The conversation here is the awkward, brilliant one: "What kind of photos do you reckon are okay to send or post, and what isn't? I just want to know what you already think." And give them the gift of an excuse to use: "You can always blame me — 'my mum checks my phone' is a totally fine reason to say no."

If an image is already out: stay calm, don't blame the child, screenshot any threats but don't save or forward the image itself, and use Report Remove at childline.org.uk/remove — an under-eighteen can report their own nude image to have it taken down and pre-emptively blocked. The reassurance you give is honest — UK police use something called Outcome 21 specifically to avoid criminalising children in consensual-sharing cases. So when you say "you won't be in trouble," you're telling the truth.

[ON SCREEN: Sharing images — Report Remove childline.org.uk/remove. Full playbook → /library/playbooks.]

### Grooming and the move to a private app.

[ON SCREEN: "Grooming — the red flag to teach: 'let's move to another app.'"]

Grooming is someone building trust with a child for abuse — and the one red flag worth teaching above all others is this: anyone who wants to move the conversation onto a private or disappearing-message app. That's the move. "Online, people aren't always who they say they are — someone can seem fourteen and not be. Has anyone you don't know ever added or messaged you? What did you do?" If you're worried it's happening, that's CEOP at ceop.police.uk/Safety-Centre — and 999 if there's immediate danger.

[ON SCREEN: Grooming — CEOP ceop.police.uk/Safety-Centre · 999 if immediate danger. Full playbook → /library/playbooks.]

### Cyberbullying.

[ON SCREEN: "Cyberbullying — screenshot first, then block."]

This is the one most likely to actually touch your child this year — and according to Ofcom, prevalence roughly doubles between age eleven and fifteen, so it climbs right through this band. The move that matters most here: agree, early, that they can show you anything without losing the phone. If it's happening: screenshot first — because evidence vanishes the moment you block — then block and report in-app, don't retaliate, and tell the school if classmates are involved; schools have to act even when it happens off-site. Non-criminal harmful content can go to Report Harmful Content at reportharmfulcontent.com. If it tips into threats or harassment, that's the police on 101. And Childline, 0800 1111, is there for your child directly.

[ON SCREEN: Cyberbullying — Report Harmful Content reportharmfulcontent.com · Childline 0800 1111 · police 101 if it's threats or harassment. Full playbook → /library/playbooks.]

### And the quieter one: how it all makes them feel.

[ON SCREEN: "Body image, comparison, the 3am scroll."]

Not every threat is a predator. At this age, where likes are currency and self-presentation is everything, the quieter harm is comparison — and specifically appearance and body-image pressure: the carefully-curated, filtered, edited accounts that leave your child feeling worse about how they look and how their life measures up. The conversation is gentle: "Do you ever notice certain accounts leave you feeling rubbish about yourself? What do you do when that happens?" You're teaching them to notice the feeling and curate their own feed — to unfollow the accounts that drag them down. That's a life skill, not a lockdown.

The other half of this is sleep — the 3am scroll. One habit does more than almost anything else here, and it's worth co-setting together rather than imposing: phones charge somewhere that isn't the bed, overnight. Frame it the way the screen-time conversation in the library does — not a punishment, but "let's agree where phones sleep, and I'll do it too," because there's solid evidence that screens in bed wreck sleep, and lost sleep amplifies every other worry on this list.

[B-ROLL: A teen unfollowing an account, then putting the phone down and picking up something else. Small, ordinary agency.]

If any of this tips from an off-day into something heavier — if your child seems genuinely low, anxious, withdrawn, or you're worried they might hurt themselves — you don't have to be the expert, and you don't have to carry it alone.

[ON SCREEN: If your child is struggling: Childline 0800 1111 · Shout (text) 85258 · Samaritans 116 123 · Papyrus HOPELINE247 0300 102 2470 · full list Bearings/emergency.]

---

## PART FIVE — What NOT To Panic About

[ON SCREEN: Section card — "5 · What NOT to panic about"]

I promised I'd be as clear about what's fine as about what to change. So here's the part nobody else gives you — permission to stop worrying about some things.

[ON SCREEN: Building list, each with a soft check-mark.]

Don't panic that they're on social media at all. Thirteen is the legitimate age. Them being on Snapchat or Instagram is not a failure of parenting — it's the normal texture of being thirteen in the 2020s. The task isn't to prevent it; it's to set it up well, which you're doing.

Don't panic that you can't read their messages. You're not supposed to be able to. The family centres on Snapchat, Instagram and Discord show you the "who," not the "what" — and that's by design, not a flaw. These are not message-readers, and chasing the fantasy of reading every message will cost you the trust that actually keeps your child talking to you. Visibility starts conversations. Surveillance ends them.

Don't panic about every new app. A new app appearing on their phone is a conversation — "what is it, what do people do on there, show me" — not a crisis. Curiosity beats confiscation almost every time.

Don't panic about screen time as a raw number. The evidence is clear that how they use it matters more than the total hours — active and creative use is a world away from passive scrolling. One genuinely high-leverage habit beats a hundred arguments about minutes: phones charging outside the bedroom overnight. Start there and let most of the minute-counting go.

[ON SCREEN: Quote card — "An edgy phase is not a five-alarm fire. Stay curious. Stay calm. Keep the channel open."]

And don't panic at the first sign of an edgy phase — a dark joke, a strange new interest, an opinion designed to provoke you. Teenagers test. Stay curious rather than horrified, because the horrified reaction is precisely what makes them stop telling you things. The goal this entire year is to keep the channel open. Almost everything else is downstream of that.

The point of naming these isn't complacency. It's that worry is a finite resource, and you should spend it on the four settings and the three conversations — not on the things that are already, genuinely, fine.

---

## CLOSE — Do This Weekend

[ON SCREEN: Section card — "Do this weekend"]

[B-ROLL: Saturday morning. Coffee. A parent and teenager on the sofa, one phone between them, both relaxed.]

So let's land this somewhere you can actually act. Here is your weekend — and it's genuinely a weekend, not a project.

[ON SCREEN: The checklist, building line by line, calm pace.]

One. Check the real birthday is set on every app. Ten minutes. The setting that matters most on the list.

Two. On Snapchat: switch on Ghost Mode together, and set Contact-Me to Friends. On Instagram: confirm the Teen Account defaults are on. And make sure your device-layer — Screen Time or Family Link — is still running and locked.

Three. Have the cornerstone conversation. Not as a formal sit-down — sideways, in the car, doing the dishes. "If anything online ever feels off, even if you broke a rule to get there, come to me, and you will not be in trouble." Mean it. Keep it.

Four. Pick one of the other two conversations — sextortion or AI chatbots — and start it this weekend, lightly. You don't have to finish it. You just have to open it.

[ON SCREEN: One line, held — "Settings + conversation + a promise you keep. That's the year."]

That's it. That's the threshold year. Not a fortress — you can't build one, and the families who try usually lose the relationship that matters most. What you're building instead is a child who knows, in their bones, that whatever happens online, the safest move is to turn to you. The settings buy you time. The conversations build trust. And the promise — "you won't be in trouble" — is the thing they'll remember at the exact moment it matters most.

[ON SCREEN: Signpost card — "Keep these somewhere you'll find them again:
· /emergency — the full list, any time
· 999 — immediate danger
· CEOP (sextortion, grooming) — ceop.police.uk/Safety-Centre
· Report Remove (a nude image of an under-18) — childline.org.uk/remove
· Scam or money lost — Action Fraud 0300 123 2040
· If your child is struggling — Childline 0800 1111 · Shout (text) 85258 · Samaritans 116 123 · Papyrus HOPELINE247 0300 102 2470
· Worried about a child generally — NSPCC 0808 800 5000."]

Keep those numbers somewhere you'll find them — not because I think you'll need them, but because the calm parent is the one who already knows where the exits are.

You've got this. One weekend. The right four things. And a door that stays open.

[ON SCREEN: End card — "Bearings · The Threshold Year · Ages 13–14"]

[B-ROLL: The phone, face-down on the table again. The teenager laughing at something the parent said. Fade out.]

---

*[ON SCREEN, end-of-video disclaimer card:] This masterclass is general guidance for UK parents, drawn from Ofcom, the NSPCC, CEOP/NCA and the IWF. It does not monitor, detect or guarantee anything, and it is not a substitute for emergency help. If a child is in immediate danger, call 999. Platform settings change often — always confirm against the official help pages linked above. Last reviewed [DATE].*

---

*Sources referenced for the producer (attribute on screen where spoken): CEOP/Thinkuknow ("talk little, talk often"; the cornerstone line; grooming red flag); National Crime Agency (sextortion targets teenage boys ~14–17 hardest); Ofcom (cyberbullying prevalence roughly doubles 11→15); Kerr & Stattin (parental knowledge depends on disclosure); IWF/Childline (Report Remove); UK police "Outcome 21" (consensual-sharing cases); Online Safety Act / gov.uk (expected under-18 ban on romantic/companion AI chatbots — label "expected", not yet in force); Meta AI age-estimation/visual age estimation and Roblox video-selfie chat age check (file 16, platform settings library). All statistics attributed to a named UK authority in the spoken line; none invented. Settings paths checked [DATE] — re-verify at publish; menus move. All helpline numbers/URLs to be link-checked at publish and quarterly per file 18.*

*Guardrail check: no efficacy or safety guarantees made; no claim the product detects, monitors or prevents anything ("protect" used only of parent behaviour and platform settings, never the product); emergencies signposted only (CEOP/999/Childline/NSPCC/Report Harmful Content/Report Remove); distress/self-harm signpost (Childline 0800 1111 · Shout 85258 · Samaritans 116 123 · Papyrus HOPELINE247 0300 102 2470 · /emergency) added to the body-image/comparison/sleep section and the end signpost card, mirroring file 03 wording; every named helpline carries a number or URL; library deep-links use approved slugs only (/library/conversations · /library/playbooks · /library/playbooks/sextortion); superlatives varied so only the cornerstone keeps one; no child-identifiable data solicited (band only); "may have moved" caveat + official help URLs included; Bearings/[DATE] placeholders used.*

---

## Band 15-16 — The GCSE Years (15–16): How to Coach, Not Control

## Band 15-16 — The GCSE Years (15–16): How to Coach, Not Control

> **Bearings Masterclass — Age Band 15–16 · "Autonomy / the GCSE years"**
> Posture: **Coach** · Target run-time ~15–20 min · Recorded spoken-word script
> Placeholders: Bearings, [DATE]. All settings paths checked June 2026 — *menus move; if a path doesn't match your screen, search the setting name in the app or use the official help link.*

---

## COLD OPEN — the hook (≈1.5 min)

**[ON SCREEN: black screen, single line fades up — "They've stopped showing you their phone. That's not the problem you think it is."]**

Let me start with a moment you might recognise.

Your fifteen-year-old comes in from school, drops their bag, and within about four seconds the phone is in their hand. They're laughing at something. You ask what's funny. And you get the shrug. "Nothing." The screen tilts away — not dramatically, just enough. The door to their room clicks shut.

And somewhere in the back of your mind, a little alarm goes off. *I used to know everything that was on that phone. Now I know almost nothing.*

**[B-ROLL: a teenager walking through a front door, headphones in, thumb already moving on a screen; warm afternoon light, completely ordinary]**

I want to say something to you right at the top, and I mean it. That tilt of the screen? That's not a red flag. That's a fifteen-year-old doing exactly what a fifteen-year-old is supposed to do. Privacy isn't the enemy of safety at this age. It's a sign of healthy development. The job in front of you isn't to win the screen back. It's to make sure that when something on it actually goes wrong — and at some point, for almost every teenager, something will, even if it's small — *you're still the person they turn to.*

**[ON SCREEN: title card — "The GCSE Years. How to coach, not control."]**

So that's what this masterclass is about. I'm going to be honest with you about what changes at this age, and I'm going to be just as clear about what is already fine and doesn't need your worry. We're against overwhelm here. I'm not going to hand you forty things to do. I'm going to give you the few that actually matter. Let's get into it.

---

## WHAT CHANGES AT THIS AGE — the posture shift (≈2.5 min)

**[ON SCREEN: a slider, four stops — Co-use · Co-set · Coach · Consult — with the marker landing on "Coach"]**

If you've followed this system through the younger bands, you'll know we talk about a posture that slides as your child grows. At eleven and twelve, you're *co-using* — sitting right alongside them, setting things up together. At thirteen and fourteen — the big threshold year, social media switching on — you move to *co-setting*: "we need some limits, let's agree them together."

At fifteen and sixteen, you cross into the third posture. **Coach.**

**[B-ROLL: a football coach on the touchline — not on the pitch, not playing, but watching, calling out, fully engaged from the sideline]**

Think about what a coach actually does. A coach doesn't play the game for the player. A coach can't. They stand on the touchline. They've done the training in the week. They call out a few things in the moment. And then they trust the player to make the decisions on the pitch — because that's the entire point of the training.

That's you now. Day-to-day, your teenager is making their own calls online. You are not refereeing every move, and honestly, you couldn't even if you wanted to — the use is more private now, more constant, and a lot of it has moved into places like Discord, Snapchat, private group chats and interest communities. Romantic and sexual relationships are increasingly playing out partly online too. That's all normal for the age.

Here's the developmental piece worth knowing, because it's reassuring. Their self-control is genuinely catching up now — the brain is maturing. But reward-sensitivity is still running high, which is just a clinical way of saying: the pull of the exciting thing, the funny thing, the risky thing, is still strong. So they're more capable than they were at thirteen, and still wired to occasionally leap before they look. Both things are true.

**[ON SCREEN: two lines, stacked — "Supervision WITH conversation." / "Not supervision INSTEAD of conversation."]**

So the shift in one sentence: at this age, the thing that keeps the channel open between you isn't control. It's conversation. The research behind all of this — it goes back to a landmark finding by two researchers, Kerr and Stattin — is blunt about it. What a parent actually *knows* about their child's life depends far more on the child *choosing to tell them* than on any amount of monitoring. Warmth beats surveillance. Not because it's nicer. Because it works better.

Hold onto that, because it's the spine of everything I'm about to say.

---

## THE SETTINGS TO PRIORITISE NOW — the few that matter (≈3 min)

**[ON SCREEN: heading — "Four things. That's the list."]**

Right — settings. This is the part where a lot of online-safety advice buries you under a hundred toggles. We're not doing that. At fifteen and sixteen there are really only a handful of settings moves that earn their place, and the spirit of all of them is different from the younger years. You're not imposing these. Where you can, you're doing them *with* them, out loud, framed as safety, not control.

Quick caveat before I name paths, and it applies to every single one: **app menus move constantly.** Apple, Meta, Snap, Discord — they rename and relocate things all the time. If a path I give doesn't match what's on your screen, just search the setting name inside the app, or go to the official help page for that app. Every path here was checked June 2026.

**[ON SCREEN: numbered list builds, one at a time]**

**One. Hand over the screen-time tool — keep the backstop.**

At this age you stop being the screen-time police and let *them* drive the day-to-day. But — and this is the coach move — you keep a quiet backstop at the device layer. On an iPhone, that's **Screen Time** (Settings → Screen Time), still locked with a passcode they don't know. On Android, it's **Family Link**. You're not micromanaging the daily minutes anymore. You're keeping a safety net underneath, the one that works even when an app's own controls get bypassed. The conversation that goes with this matters more than the toggle, and I'll come to it.

**[B-ROLL: a parent and teen sitting at a kitchen table, phone between them, both looking at the same screen — collaborative, not confrontational]**

**Two. Review the privacy and contact settings — together, not behind their back.**

The instinct at fifteen might be to quietly go in and lock things down. Resist it. Sit with them and look at who can contact them and who can see their stuff. On **Snapchat**, the two that matter most are *Contact Me* set to **Friends** — not "Friends and Contacts" — and **Ghost Mode** on Snap Map, which hides their live location. Worth knowing: on Snap Map, only *they* can switch Ghost Mode on from their own account — the Family Centre lets you *see* who they share with, but not flip it for them. So this one genuinely has to be a conversation. On Instagram, under-eighteens are auto-placed in **Teen Accounts** with private profiles and stricter messaging on by default — your job is just to confirm those defaults are actually on.

**Three. If they use Discord, set up Family Centre.**

Discord is a big one at this age and it often flies under parents' radar. The **Family Centre** (in the mobile app, under User Settings) gives you a weekly activity feed — who they've added, who they've messaged, not the content. For UK teens the sensitive-content filter offers blur or block. Again: this shows you "who," not "what." It's a conversation-starter, not surveillance, and definitely not a guarantee.

**Four. Keep the purchase and device backstop running.**

The boring one that's still worth it: keep purchase approvals and the device-layer limits from the younger years quietly in place. **Require a password for every purchase**, remove stored cards where you can. This matters more than you'd think at this age — and I'll explain why when we get to scams.

**[ON SCREEN: one line — "These dashboards show 'who,' not 'what.' They start conversations. They don't replace them."]**

That's the lot. Four moves. Notice none of them is about reading their messages — because you can't, and chasing that is the wrong battle. The shift here is supervision *with* conversation. Which brings us to the part that actually does the heavy lifting.

---

## THE CONVERSATIONS THAT MATTER MOST HERE (≈4 min)

**[ON SCREEN: heading — "The words. This is the part free advice never gives you."]**

Everyone tells you to "have the conversation." Almost nobody tells you what to actually say so it doesn't land as a lecture and get you a shrug. So here are the few that matter most at fifteen and sixteen. Use your own words — these are scaffolding, not a script to read out loud.

And one rule that sits over all of them, from the research: **little and often, not one big talk.** CEOP's actual slogan is "talk little, talk often." The car is perfect — no eye contact, low stakes, a natural end when you arrive. A shared task. Never mid-argument.

**[ON SCREEN: "Conversation 1 — The cornerstone." with a small star/anchor icon]**

**First, and forever, the cornerstone.** This is the single highest-impact thing you will ever say to your child about their online life, and it leads every age band for a reason. It sounds like this:

> *"If anything online ever feels weird, or scary, or out of control — even if you'd broken one of our rules to get there — I want you to come straight to me, and you will not be in trouble. Helping you matters to me way more than any rule."*

**[B-ROLL: a parent and a near-grown teenager walking side by side, no eye contact, just talking — easy, unforced]**

I want you to really sit with why this works. The threats that hurt teenagers most online — and I'm going to name them in a minute — they all run on the same fuel: *shame and the fear of getting in trouble.* That's what keeps a teenager silent at the exact moment they most need an adult. The cornerstone line is the antidote. It pulls the fuel out of the fire before it starts. At fifteen and sixteen you can say it almost peer-to-peer: "you're nearly an adult, you make your own calls now — but that offer never expires."

The flip side is the *don'ts*, and they matter just as much. If your teenager comes to you with a problem, never open with *"why did you do that?"* — it shuts them down instantly. Ask *"what happened? Talk me through it."* Never say *"they were so stupid to share it"* about anyone, even someone on the news — your teen is listening for how you'd react if it were them. And never, ever say *"if anything happens I'll take your phone."* Say the opposite: *"if anything happens, telling me won't cost you your phone."* The fear of confiscation is one of the biggest reasons teenagers handle a crisis alone. Don't be that fear.

**[ON SCREEN: "Conversation 2 — Mistakes & repair."]**

**Second, the mistakes-and-repair talk.** This is the cornerstone's everyday cousin, and it's perfect for this age because they *will* mess something up — post the wrong thing, send the wrong thing, click the wrong thing. You're getting ahead of it:

> *"Everyone messes up online — posts something, sends something, clicks something. If it happens to you, my job isn't to lecture you, it's to help you sort it out. Deal?"*

That word "deal" matters. You're framing it as a pact between near-equals, not a rule from above. That's the coach posture in a single sentence.

**[ON SCREEN: "Conversation 3 — Scams, money & the muling red line."]**

**Third — and this one's newly important at fifteen and sixteen — money.** The scams aimed at this age are genuinely clever, and there's a specific trap that switches on around now. It sounds like this:

> *"There are some really convincing scams aimed at people your age — free V-Bucks, crypto 'flips', fake job DMs, 'your account's locked' messages. If something promises money or freebies for a click or a code, what's your gut say? Show me one if you get one, some are genuinely clever."*

And then the line specific to this band, said plainly:

> *"And never let anyone use your bank account for a fee — that's called money-muling. It's a crime, and it's your name on it."*

I'll explain that one properly in a moment. The reason you say "these scams are designed to fool adults too" rather than "how could you be so naive" is the same reason as everything else: you're removing the shame so they'll actually show you the dodgy message instead of hiding it.

**[B-ROLL: phone screen showing a too-good-to-be-true "easy money" DM, scrolling past]**

**[ON SCREEN: "Conversation 4 — The picture-pressure line."]**

**Fourth — and this one's squarely in scope now that relationships move online — the picture-pressure conversation.** At this age someone may be pressured for a nude — by a stranger, but just as often by someone they actually like. The most useful thing you can do here isn't a warning; it's handing them a ready-made excuse to say no without losing face. It sounds like this:

> *"If someone ever pressured you for a picture — even someone you liked — what do you think you'd do? You can always blame me: 'my mum checks my phone' is a totally fine excuse to use."*

That last line does the real work. It gives them a way out that doesn't cost them social standing — which at fifteen is often the actual barrier to saying no. This is the *proactive* version of the image-based threats I'll come to in a minute: the words that help them refuse in the first place, before there's ever anything to clean up.

**[ON SCREEN: "Conversation 5 — Does this app leave you feeling rubbish?"]**

**Fifth, the one about how it all makes them feel.** This matters more than it looks. Appearance and comparison pressure is one of the genuine harms at this age, and a teenager will almost never raise it unprompted. The opener is deliberately low-key:

> *"Do you ever notice certain accounts or apps leave you feeling rubbish about yourself? What do you do when that happens?"*

You're not telling them to delete anything. You're naming the pattern — feeds are built to hold attention, and some of what holds attention leaves you feeling worse — and giving them quiet permission to mute or unfollow without it being a big deal.

> **If your child is struggling:** Childline 0800 1111 · Shout (text) 85258 · Samaritans 116 123 · Papyrus HOPELINE247 0300 102 2470 · full list Bearings/emergency.

And there's one more worth weaving in *only* when a natural moment hands it to you — usually off the back of a TV storyline — about how unrealistic a lot of online material about sex and bodies actually is: *"that storyline got me thinking — a lot of what's online about sex and bodies is pretty unrealistic. Do you and your mates ever talk about how fake some of it is?"* That's the one you don't force. Let the moment hand it to you.

**[ON SCREEN: card — "The full wording for every one of these → /library/conversations"]**

If you want any of these written out in full — the cornerstone, mistakes-and-repair, scams and money, the picture-pressure line and the feelings one — they're all in the library at **Bearings/library/conversations**.

---

## THE TOP THREATS FOR THIS AGE — calmly, with what to do (≈4 min)

**[ON SCREEN: heading — "The risks that matter now. No alarm. Just what to do."]**

Okay. The threats. I'm going to name the ones that are most salient at fifteen and sixteen, and I'm going to do it calmly, because panic is genuinely counter-productive here — it's contagious, and a panicked parent is a parent a teenager stops talking to. For each one: what it is, briefly, and what you'd actually *do*. And I want to be clear about the boundary — if something is a live emergency, the move is always to signpost to the proper authorities. That's CEOP, the police, the helplines. We don't improvise crisis intervention.

**[ON SCREEN: "1 — Sextortion & image-based abuse"]**

**First, sextortion — and image-based abuse more broadly.** This was the headline risk in the thirteen-to-fourteen band, hitting boys hardest, and it absolutely continues here. Someone poses as a peer, gets flirty fast, persuades a young person to send a nude — then threatens to share it unless they pay. There's a newer wrinkle too: AI "nudify" tools can fake a nude from an ordinary photo.

Here's the playbook, and it's worth your teen knowing it *cold*, for themselves or a mate: **Stop. Don't pay. Don't delete anything. Screenshot the threats. Block them. And tell a trusted adult.** Then report to **CEOP** — that's ceop.police.uk/Safety-Centre — and for taking an image down, **Report Remove**, run by the IWF and Childline at childline.org.uk/remove, which works for under-eighteens including for AI-generated fakes. If there's immediate danger, that's 999. What matters more here than any setting is your calm, non-blaming reaction — it's what lets them come to you in the first place. It is *never* the victim's fault, and it can be sorted.

**[ON SCREEN: "The full playbook → /library/playbooks/sextortion"]**

The full step-by-step is in the library at **Bearings/library/playbooks/sextortion**.

**[ON SCREEN: "2 — Consensual-then-betrayed sharing & coercive control"]**

**Second, the relationship version of that.** At this age relationships move online, and an image shared willingly with a partner can later be forwarded after a breakup, or used to control someone. Same calm response: don't blame, screenshot any threats, use Report Remove, and reassure them. Worth knowing so you can say it honestly — UK police use something called **Outcome 21** specifically to avoid criminalising children in consensual-sharing cases. Your teen is not going to be treated as a criminal for being a victim. That reassurance is true, so use it.

**[B-ROLL: soft-focus shot of two phones on a table, screens dark — restraint, not melodrama]**

**[ON SCREEN: "3 — Misogyny, extremist content & the 'fixation with violence'"]**

**Third, the content-and-community risk — misogyny, extremist material, radicalisation.** I'll be measured here, because this is an area where over-reaction backfires badly. The modern picture isn't usually one clean ideology; the authorities describe young people, often boys, drawn toward mixed, nihilistic, violence-fixated corners of the internet. The most damaging thing a parent can do here is confront aggressively and cut off the relationship — isolation deepens it. So: keep talking, debate rather than shut down, and notice the genuine escalation signs versus an edgy phase. If you're genuinely worried, the route is **ACT Early** — that's the police service built for worried families, actearly.uk, 0800 011 3764. It's confidential, and for most cases it's about support, not prosecution. 999 only if there's an imminent threat.

**[ON SCREEN: "More on this → /library/playbooks"]**

The full version is in the library at **Bearings/library/playbooks**.

**[ON SCREEN: "4 — Scams & money-muling"]**

**Fourth, scams and money-muling.** Here's that money trap I promised. "Easy money for using your bank account" is mule recruitment — a criminal using your teen's account to launder money, and it's a crime in *your child's name*, with real consequences for their future. Prevention is the conversation we covered. If it's already happening, the routes are **Action Fraud** — 0300 123 2040 — and the bank.

**[ON SCREEN: "5 — AI companions & over-reliance"]**

**Fifth, AI companions and over-reliance.** AI companion apps can feel like a friend because they remember things — but they can't actually care, and they get things confidently wrong. The line to plant is gentle: *"great for ideas; not the place to go for anything that's really worrying you. That's what people are for."*

**[ON SCREEN: "6 — Sleep"]**

**And sixth, the quiet one that amplifies all the others — sleep.** Night-time scrolling genuinely wrecks sleep, and lost sleep makes every other problem worse — mood, anxiety, focus. The single most worthwhile habit, all the way through the teens, is the phone charging *outside the bedroom* overnight — and you do it too. Framed not as punishment, but as something the whole house does because the evidence on sleep is solid.

> **If your child is struggling:** Childline 0800 1111 · Shout (text) 85258 · Samaritans 116 123 · Papyrus HOPELINE247 0300 102 2470 · full list Bearings/emergency.

**[ON SCREEN: "If it's a live emergency → signpost. Always. /emergency · 999 · CEOP · Childline 0800 1111 · NSPCC 0808 800 5000"]**

---

## WHAT NOT TO PANIC ABOUT (≈1.5 min)

**[ON SCREEN: heading — "And now — the relief. What's actually fine."]**

I promised I'd be as clear about what's fine as what to change. So here's the relief list, because being against overwhelm cuts both ways.

**[B-ROLL: a teenager laughing at their phone with a sibling, both leaning in to show each other something — connection, not danger]**

**Wanting privacy is not a warning sign.** A fifteen-year-old who wants their messages to themselves is developing normally. Privacy and safety are not opposites.

**You do not need to read their messages — and you can't.** The family dashboards on Snapchat, Instagram and Discord show you *who*, not *what*. They are not message-readers, and that's by design. Chasing the content is the wrong battle, and trying to win it is how you lose the channel that actually keeps you informed.

**Most online relationships, group chats and gaming are just... their social life.** The noise of a teenager's online world is overwhelmingly ordinary friendship, jokes, and interests. Don't read threat into the volume.

**A lot of what scared you in the younger years is now better handled by them.** Their judgement is genuinely improving. You're allowed to trust the training you've done.

And **you don't have to do every setting on every app.** The four we covered are the ones that earn their place at this age. Volume isn't the goal. The right few things are.

---

## DO THIS WEEKEND — the close (≈1.5 min)

**[ON SCREEN: heading — "This weekend. Three things. That's it."]**

So let me leave you with something finishable. Not a project. Three things, this weekend.

**[ON SCREEN: checklist builds, one tick at a time]**

**One — say the cornerstone line.** In the car, on a walk, doing the washing up. Out loud, in your own words: *"If anything online ever feels wrong — even if you broke a rule getting there — come to me. You won't be in trouble. Helping you matters more than any rule."* It's the highest-leverage thirty seconds you'll spend all year.

**[B-ROLL: a parent and teen in a car, both facing forward, mid-conversation, relaxed]**

**Two — do one setting review *with* them, not at them.** Sit down together for ten minutes. On Snapchat, check *Contact Me* is set to Friends and Ghost Mode is on. If they're on Discord, set up Family Centre together. Frame it out loud as safety, not control — and let them show you how it works. That role-reversal, where they're the expert, is doing more good than the toggle itself.

**Three — agree the "what we'd do if…" plan.** Five minutes. *"If anything ever went wrong with an image or a message — a leak, a threat, a scam — here's what we'd do together: we don't panic, we don't delete, we screenshot, and we sort it out. As a team."* You're rehearsing calm before you ever need it.

**[ON SCREEN: final card — "Coach, don't seize control. Keep the relationship intact, and they keep coming back."]**

**[ON SCREEN: signpost card — "If your child is struggling: Childline 0800 1111 · Shout (text) 85258 · Samaritans 116 123 · Papyrus HOPELINE247 0300 102 2470 · full list Bearings/emergency"]**

That's it. Three things. And then the ongoing posture is just this: low-key, weekly, little-and-often check-ins beat dramatic spot-checks every time. When something does go wrong — and remember, for almost every teenager something eventually does — your job as the coach is not to grab the controls. It's to help them think it through, point them to the right route, and keep the relationship so intact that they come back to you the *next* time too.

You've got this. Be the calm. I'll see you in the next one.

**[ON SCREEN: Bearings · Age band 15–16 · "Coach, don't control" · [DATE]]**

---

*Sources behind this masterclass are UK authorities — Ofcom, NSPCC/Childline, CEOP/NCA, IWF, the Children's Commissioner, the Gambling Commission and gov.uk Prevent. Helpline numbers and reporting routes should be re-checked at [DATE]. Nothing here detects, monitors, or guarantees anything — this is guidance to help you have the right conversations and set the few settings that matter. For any live emergency, go to /emergency or call 999.*

---

## Band 17–18 — Launch Year: The Online-Safety Masterclass for Parents of 17–18-Year-Olds

## Band 17-18 — Launch Year: The Online-Safety Masterclass for Parents of 17–18-Year-Olds

*Age band 17–18 · "Launch / near-adult" · Posture: CONSULT · Target run-time ~15–20 min · Bearings · [DATE]*

> **Brand-voice note for delivery:** calm, warm, premium, first-person. Prevention not panic. We are *against overwhelm* — this is the right few things, not a long list. Be as clear about what's already fine as about what to change. No guarantees, no "this keeps them safe." Emergencies are signposted only.

---

## COLD OPEN — the hook *(approx. 0:00–1:45)*

[ON SCREEN] Soft title card, no alarm imagery: *"Launch Year."* Then under it, smaller: *"They're nearly an adult. So is their online life."*

[B-ROLL] A kitchen, early morning. A near-adult — UCAS-shaped chaos, a laptop, a phone, a coffee they made themselves — heading out the door. A parent watching from the hallway, not following.

Let me start somewhere ordinary.

There's a moment, somewhere around seventeen, where you realise you don't actually know their passcode anymore. And — this is the part that surprises people — *that's fine.* That's not a failure of parenting. That's the job working.

Because here's where we are. Your child is about to become, legally and practically, an adult online. In the next year or so they age out of the child-specific safety net — and I'll be specific about that in a minute, because it's one of the most useful things in this whole talk. The protections that have quietly had their back since they were thirteen start to switch off. Not because anything's gone wrong. Just because of a birthday.

[ON SCREEN] One calm line: *"At 18, the safety routes change. Most parents don't know this. By the end of this you will."*

So this isn't a talk about clamping down. At this age you couldn't if you tried, and you shouldn't want to. This is a talk about *handover done well* — making sure that when they walk into independent adult life, they walk in knowing the things a savvy adult knows. And that the door home stays open.

I'm going to keep this tight. The right few things, not a pile of them. Let's go.

---

## WHAT CHANGES AT THIS AGE — the posture *(approx. 1:45–4:30)*

[ON SCREEN] The posture slide, with the last word lighting up: *Co-use → Co-set → Coach → **Consult.***

If you've followed this from the younger years, you'll know the parenting posture has been sliding. At eleven and twelve you were *co-using* — sat beside them, setting things up together. At thirteen and fourteen — the big one, the threshold year — you moved to *co-setting* the rules. At fifteen and sixteen you became a *coach*: supervision with conversation, handing over day-to-day control with a backstop.

At seventeen and eighteen, you become a **consultant.**

[B-ROLL] A parent and near-adult on a sofa, the young person showing the parent something on their phone — the parent leaning in to *look*, not to take.

Here's what that actually means, in plain terms. **They lead. You advise.** Few imposed rules — most of those have quietly expired anyway. The "family agreement" you might have had pinned to the fridge becomes something much simpler: *a standing offer of help.* An open door. "Any time, no judgement."

And the discipline of this stage — genuinely the hardest bit — is **resisting the urge to take over.** When something goes wrong at this age, every instinct says *grab the phone, fix it myself, sort it.* Don't. If you take the controls now, you teach them that the way to handle a crisis at nineteen, at twenty-two, on their own in a flat somewhere, is to handle it alone — because the one person who'd have helped made it about *them.*

[ON SCREEN] *"You're a consultant now. They lead, you advise. Resist taking over."*

There's solid evidence underneath this, by the way — it's not just a nice idea. What a parent actually *knows* about their child's life comes far more from the child *choosing to tell them* than from any monitoring. That's a landmark finding in adolescent research, Kerr and Stattin. Warmth beats surveillance — not as sentiment, but because it's what works. And at seventeen, surveillance isn't even on the table. So warmth is all you've got. Good news: it's also the strongest thing you ever had.

---

## THE 3–4 SETTINGS THAT MATTER NOW *(approx. 4:30–8:30)*

[ON SCREEN] *"Mostly self-managed. Four things worth a Saturday."*

[B-ROLL] Two people at a laptop, side by side, doing something *together* on screen — not a parent peering over a shoulder.

Now — settings. At this age it's mostly self-managed, so we're not installing controls *on* them. We're doing four things *with* them, as one near-adult helping another get set up properly for independent life. Think of it as the digital equivalent of teaching them to check their bank balance.

[ON SCREEN] **Setting / action 1 — Account security: 2FA on everything that matters.**

First: account security. This is the unglamorous one that prevents the most pain. Turn on **two-factor authentication** on the accounts that matter — email first, because email is the master key that resets everything else, then banking, then the big social accounts. Unique passwords, not the same one everywhere; a password manager makes that painless. The **NCSC** — that's the National Cyber Security Centre, the UK's official authority on this — has plain, free guidance, and it's genuinely good. Frame it honestly: "this is the stuff I wish someone had set up with *me* at your age."

[ON SCREEN] **Setting / action 2 — The public footprint review.**

Second: review their public footprint *together.* Sit down and ask the genuinely useful question — "what would a university admissions tutor or an employer actually find if they searched your name?" Look at what's public versus private. Old accounts they've forgotten. Tagged photos. A username that made sense at fourteen. This isn't snooping — you do it *side by side, at their invitation.* It's a life skill, not an inspection.

[ON SCREEN] **Setting / action 3 — Know the ADULT reporting routes.**

Third — and this is the one nobody tells parents — **learn the adult reporting routes**, because the child ones are about to switch off. I'll come back to the specifics in the threats section, because this is the heart of the whole handover.

[ON SCREEN] **Setting / action 4 — Carry the basics forward (don't re-do them).**

And fourth, lighter: whatever device-layer or privacy basics are still running from younger years — location settings, contact controls — just confirm they're sane, then leave them. Don't re-engineer what's working. Remember, we're against overwhelm: the goal is the *right* few things.

[ON SCREEN] **Standing caveat:** *"Menus move. App makers rename and relocate settings constantly — if a path doesn't match your screen, search the setting's name in the app, or use the official help link. For account security, the trusted source is the NCSC: ncsc.gov.uk."*

One honest note that applies to all of this: settings menus *move.* App makers rename and relocate things all the time. So if what's on their screen doesn't match what you expected, search the setting's name in the app or go to the official help page. And these social dashboards — the family centres — they were never really for this age anyway. They show you *who*, not *what*, and they're not message-readers. At seventeen, they're beside the point.

---

## THE CONVERSATIONS THAT MATTER MOST *(approx. 8:30–12:30)*

[ON SCREEN] *"Talk little, talk often."* — small credit line: *CEOP*

[B-ROLL] A car, evening, two people in the front seats looking at the road — not at each other.

The conversations. This is the part free websites can't give you — they tell you to "have the conversation"; I'm going to give you roughly the words.

Two quick rules before the scripts, both evidence-based. **Little and often, not one big sit-down talk** — that's literally CEOP's slogan, "talk little, talk often." And **ask, don't tell.** The single most powerful swap in this entire field: when something's gone wrong, ask *"what happened? Talk me through it"* — never *"why did you do that?"* The word "why" sounds like a verdict, and it closes them down instantly. A car journey, by the way, with no eye contact, is the perfect place for any of these.

### Conversation 1 — The cornerstone *(the one that never expires)*

[ON SCREEN] The cornerstone line, held on screen longer than anything else in the film.

This is the most important sentence in the entire programme, at every age, and it leads every single band — including this one. It defeats the one thing that keeps a young person silent when they most need help: shame, and fear of being in trouble. Here's the line, tuned for a near-adult:

> *"You're nearly an adult now, and you handle almost all of this yourself — and you do it well. But that offer never expires. If anything online ever feels weird, scary, or out of control — even if you'd broken some rule to get there — you come straight to me, and you will not be in trouble. Helping you matters to me more than anything else. Always will."*

Say it once, lightly, and let it sit. You don't need to make it a moment. You just need them to *know* it's true — so that at two in the morning, in a panic, with something genuinely frightening on their screen, the thought *"I'll tell mum, I'll tell dad"* arrives before the thought *"I'll handle this alone."* That's the whole game.

### Conversation 2 — Scams and money, adult-grade

[B-ROLL] A phone showing a too-good-to-be-true DM; a hand hovering, then putting the phone down.

Second: scams — and at this age, grown-up scams, because they're about to have a real bank account, a first salary, maybe a student loan landing in one lump. Try:

> *"There are some genuinely clever scams aimed at people exactly your age now — fake job offers in your DMs, crypto 'flips,' 'your account's locked' messages, investment stuff that looks legit. These are designed to fool *adults.* If something promises money fast, or asks for a code, what's your gut say? Show me one if you ever get a good one."*

And the red line that matters most at this age — money-muling:

> *"Never, ever let anyone use your bank account to move money for a fee. That's money-muling. It's a crime, it's *your* name on it, and it can wreck your finances before they've even started. If anyone offers you that, the answer is no, and you tell me."*

Notice the framing — *"designed to fool adults too."* Never *"how could you be so naive?"* The first keeps them talking; the second guarantees they'll hide the next one.

### Conversation 3 — The footprint and reputation talk

Third, and this one's almost unique to this age:

> *"Quick one — what do you reckon a university or an employer would find if they Googled you? Not because I think there's anything bad. Just — it's worth a five-minute tidy before applications. Want to do it together?"*

Light. Practical. Forward-looking. It pairs directly with the footprint review we set up in the settings section — conversation plus action, which is always the combination that actually sticks.

[ON SCREEN] *"Cornerstone · Scams (adult-grade) · Footprint · plus Sextortion (adult routes) and Mistakes & repair."*

And keep two more in your back pocket: the sextortion conversation — which I'll cover in the next section because it needs the adult routes — and the *mistakes-and-repair* one, the simple "everyone messes up online; my job isn't to lecture you, it's to help you sort it." At this age that's less a speech and more just a posture you hold.

[ON SCREEN] *Word-for-word openers for all of these: Bearings/library/conversations.*

---

## THE TOP THREATS — calmly, with what to do *(approx. 12:30–16:30)*

[ON SCREEN] *"Four things to understand. Calmly."*

[B-ROLL] Steady, undramatic — a desk, daylight, ordinary life continuing around the screen.

Now the threats. I'm going to be calm about these on purpose, because calm is the *useful* response, and because most of what your near-adult does online is completely fine. There are four that are most relevant at this age. For each: what it is, what to do, and where to point. Nothing here is a live-emergency guide — if something is happening *right now*, that's a job for the official routes, and I'll name them.

### Threat 1 — Digital footprint and reputation

[ON SCREEN] **Threat: footprint / reputation.** *What to do: review together → tidy public-facing accounts.*

The most age-specific one, and the least frightening: the long tail of a permanent footprint, now that it actually has stakes — jobs, university, first impressions. What to do is exactly what we've already covered: review together, tighten what's public, retire the old account with the embarrassing handle. That's it. This is housekeeping, not danger.

[ON SCREEN] *More on this: Bearings/library/playbooks.*

### Threat 2 — Scams and financial fraud

[ON SCREEN] **Threat: scams & fraud.** *Signpost: Action Fraud — 0300 123 2040.*

Fraud is one of the online harms people are most likely to run into — for adults as much as teens; **Ofcom**'s research consistently puts scams near the top of what UK users actually encounter. We've done the conversation. If money is actually lost: the route is **Action Fraud** on **0300 123 2040**, and their bank straight away. Banks can often act fast on fraud if they're told quickly. Calm, prompt, no shame — that combination gets the best outcome.

[ON SCREEN] *More on this: Bearings/library/playbooks.*

### Threat 3 — Sextortion, via adult channels

[ON SCREEN] **Threat: sextortion.** *Stop · don't pay · don't delete · screenshot · tell · report.*

This one I'll slow down for, because the routes change at eighteen and this is the crux of the handover.

Financially-motivated sextortion — where someone poses as a peer, gets flirty fast, gets a nude sent, then threatens to share it unless they're paid — has, per **CEOP** and the **NCA**, hit teenage boys especially hard, and it doesn't politely stop on someone's eighteenth birthday. So your near-adult needs the response *memorised*, the way they know to dial 999:

> **Stop. Don't pay. Don't delete anything. Block them. Screenshot the threats. And tell someone.** It is never the victim's fault, and it can be sorted.

[ON SCREEN] **The route changes at 18:** *Under 18 → Report Remove (childline.org.uk/remove). At 18+ → StopNCII.org · Revenge Porn Helpline (revengepornhelpline.org.uk · 0345 6000 459).*

Here's the bit that's genuinely easy to miss. While they're under eighteen, the route to get an intimate image taken down is **Report Remove**, run by Childline and the IWF — that's at childline.org.uk/remove, and it works for AI-generated fakes too. But once they turn eighteen, that door closes. The adult equivalents are **StopNCII.org** — that's "Stop Non-Consensual Intimate Image" abuse — and the **Revenge Porn Helpline** (revengepornhelpline.org.uk · **0345 6000 459**). Same problem, different door. *Make sure they know which door is theirs.* That one piece of knowledge is, honestly, one of the most valuable things you can hand over this year.

And if there's coercion, blackmail, or an adult involved: **CEOP** at ceop.police.uk, and **999** if anyone is in immediate danger.

[ON SCREEN] *The full sextortion playbook: Bearings/library/playbooks/sextortion.*

### Threat 4 — Harmful online communities

[ON SCREEN] **Threat: harmful communities.** *Signpost: ACT Early — 0800 011 3764.*

The fourth: harmful online communities — content and groups that pull a young person toward extreme ideologies or, increasingly per the UK picture, a *fixation with violence* with no clear ideology at all. The right move here is the *opposite* of cutting them off — isolation deepens it. Keep the dialogue open, debate rather than shut down. If you're genuinely worried, the route is **ACT Early** — the police service built specifically for worried families, at actearly.uk or **0800 011 3764.** It's confidential, and for most cases it's about support, not prosecution.

[ON SCREEN] Quick signpost card, all together: *Action Fraud 0300 123 2040 · CEOP ceop.police.uk · Under 18: Report Remove childline.org.uk/remove · At 18+: StopNCII.org · Revenge Porn Helpline 0345 6000 459 · ACT Early 0800 011 3764 · 999 in immediate danger.*

And if any of this brings up a worry about how they're coping — low mood, sleep, the way a feed can leave you feeling — keep these in reach too: *If your child is struggling: Childline 0800 1111 · Shout (text) 85258 · Samaritans 116 123 · Papyrus HOPELINE247 0300 102 2470 · full list Bearings/emergency.*

---

## WHAT NOT TO PANIC ABOUT *(approx. 16:30–18:00)*

[ON SCREEN] *"What's already fine."*

[B-ROLL] Deliberately calm and warm — a young adult laughing at something on their phone; a parent half-smiling, not anxious.

Now let me be as clear about what's *fine* as I've been about what to change — because being against overwhelm cuts both ways.

**Don't panic that you no longer have their passcode.** At seventeen, that's correct. Access was never the protection — the relationship was.

**Don't panic about ordinary adult-level use.** Full-on, all-day, adult-pattern use of their phone is, at this age, just… life. The research is clear that *how* they use it matters far more than the raw hours — active and creative beats passive scrolling. A near-adult living a normal connected life is not a problem to be solved. But if you do notice the harder signs — low mood, withdrawal, sleep going badly, a feed that visibly leaves them feeling worse — that's worth gently naming, and there is somewhere to turn. *If your child is struggling: Childline 0800 1111 · Shout (text) 85258 · Samaritans 116 123 · Papyrus HOPELINE247 0300 102 2470 · full list Bearings/emergency.*

**Don't panic over an edgy phase.** A dark sense of humour, a provocative opinion, an argument online — that's adolescence finishing its work, not radicalisation. Save the ACT Early route for genuine, escalating concern, not for an edgy meme.

**And don't panic about the handover itself.** Ageing out of the child protections is not a cliff-edge you've failed to prevent. It's the system working exactly as designed. Your job was never to keep the scaffolding up forever. It was to make sure the building stands on its own. This year, it does.

[ON SCREEN] *"Access was never the protection. The relationship was."*

---

## DO-THIS-WEEKEND CLOSE *(approx. 18:00–19:30)*

[ON SCREEN] *"This weekend."* A short, finishable checklist appears one line at a time.

So — what do you actually *do* with all this? Here's the weekend version. Finishable. Not a project.

[ON SCREEN, building line by line]
- **One conversation.** Drop the cornerstone line — *"that offer never expires"* — into an ordinary moment. Car, kitchen, washing-up. Lightly.
- **One security pass.** Turn on **2FA** on their email and bank, together. Fifteen minutes. NCSC has the guide: ncsc.gov.uk.
- **One footprint check.** Google their name side by side. Tidy whatever makes them wince. Treat it like life admin, because it is.
- **One thing they keep forever.** Make sure they know the routes flip at eighteen — **Report Remove** now, **StopNCII** and the **Revenge Porn Helpline** (0345 6000 459) as an adult. Say it once. Let it land.

[B-ROLL] The opening shot again — the near-adult heading out the door. But this time the parent isn't anxious in the hallway. Just… watching them go. Steady.

That's it. Four small things, one weekend.

[ON SCREEN] Final card. *"You're not closing the door. You're showing them where the handle is — from the inside."*

You spent years building the channel. Co-using, co-setting, coaching. This year you get to do the quietest, most confident version of the job: consulting. They lead. You advise. And the door stays open — not because you're holding it, but because they *know* it's open. Any time. No judgement.

That's the whole thing. That's launch year, done well.

[ON SCREEN] *Bearings · [DATE]* · small print: *Information and conversation support, not a monitoring or safety guarantee. In an emergency, contact 999, or see the signposts at Bearings/emergency.*

---

*[Production note — guardrails honoured: no efficacy/safety guarantees; emergencies signposted only (Action Fraud 0300 123 2040, CEOP, StopNCII.org, Revenge Porn Helpline 0345 6000 459, ACT Early 0800 011 3764, Report Remove, distress signpost — Childline 0800 1111 / Shout 85258 / Samaritans 116 123 / Papyrus 0300 102 2470, 999); general facts attributed to UK authorities (Ofcom, CEOP/NCA, NCSC); "menus move" caveat included with official URL; library deep-links use approved slugs only (/library/conversations, /library/playbooks, /library/playbooks/sextortion); no child-identifiable data solicited; never framed as "coaching" a person; Bearings/[DATE] placeholders used. Re-verify all helpline numbers and URLs at publish and quarterly.]*

---
