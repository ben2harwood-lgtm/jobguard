# AI Safety Course - First Sale Decision Log

*Created 2026-06-27. Status: owner decision log for the founding pilot. Complete this before creating or sharing a payment link. This is not legal advice.*

## Decision — 2026-07-05 (owner, per blueprint `99` + memo `96` §11)

Recorded after the founder's 2026-07-04 confirmed decision set. These supersede the earlier drafts in the table below where they conflict.

- **Product name: Keepwise** (not Bearings). The "Bearings AI Safety Course" naming in the table below is retired.
- **GO — fully automated offering** per blueprint `99` (block-assembly plans, locked crisis signpost, no per-customer human labour, no LLM in delivery).
- **Pricing: System £49 one-off + £29/yr Stay Current renewal.** Founding pricing is **retired** — no £79 anchor, no fake discounts, no scarcity/founding copy anywhere (CPR-clean). The GBP 49 "founding parent pilot" price in the table is superseded by the standing £49 system price.
- **The AI course (AI Readiness Lab) folds into the £49 system as a module** once built. There is **no standalone £49 course SKU** beside the £49 system at pilot. The pricing page may only claim what ships today (plan, ~51-item library incl. AI guides, conversation scripts, Family Agreement builder, printables, first year of updates); the course module + new tools are scheduled in the build plan, not promised on the page.
- **Concierge (£650) retired** — per-customer labour by definition. Removed from nav, pricing and the /start recommendation. The `/concierge` route is now a brief honest notice ("not currently offered") linking to `/pricing`; the enquiry form is unreferenced (dormant socket).
- **Claims:** every "checked/reviewed by a real person" style claim is now false and removed. True claims only ("written, checked and dated by our editors" / "matched to your children's ages and apps in minutes" / "kept current all year"). Banned: human-review/real-person/"not a chatbot"/founding/scarcity claims and any promise of the course or tools before they ship.
- **Safeguarding review of the block library is gated before first sale** (the ai-safety-*.ts libs stay review-gated and unrouted).

## Decision Table

| Decision | Current status | Options / notes | Owner answer |
|---|---|---|---|
| Trading name | Needed | Example format: Ben Harwood trading as [NAME], or other lawful trading setup. |  |
| Public contact email | Needed | Use an address Ben is comfortable putting in buyer copy. |  |
| Address/contact address | Needed | GOV.UK source indicates distance sales need address/contact information. Decide what can lawfully and comfortably appear. |  |
| Product name | Drafted | Bearings AI Safety Course - Founding Parent Pilot. |  |
| Price | Drafted | GBP 49. |  |
| Delivery timing | Needed | Manual delivery within [TIMEFRAME]. |  |
| Digital content option | Needed | Option A: delay delivery. Option B: early digital delivery with explicit acknowledgement. |  |
| Refund window | Needed | Choose [NUMBER] days and align with cancellation approach. |  |
| Payment provider | Drafted | Stripe Payment Link, if it can collect/record required acknowledgements. |  |
| Required checkout acknowledgements | Drafted | See `86` and `87`; confirm exact implementation before payment link. |  |
| Optional marketing consent | Drafted | Separate and optional. |  |
| Privacy controller name | Needed | Must match trading setup. |  |
| Email provider / processors | Needed | List actual tools used for email, forms, storage, and payment. |  |
| Lead retention period | Needed | Choose a deletion/anonymisation period for non-buyers. |  |
| Buyer/admin retention period | Needed | Align with accounting/tax duties. |  |
| Feedback retention period | Needed | Keep no-child-detail product notes only. |  |
| ICO fee position | Needed | Complete ICO fee route/self-assessment; record paid/exempt and date. |  |
| Emergency signpost URL | Needed | Use the verified live URL from `84`. |  |
| Maximum pilot buyers | Drafted | 5 before paid professional review. |  |
| Allowed lead sources | Drafted | Warm parent, parent-group DM, LinkedIn, founder network; no school/PTA circulation before professional review. |  |

## Current Go/No-Go

Status: **No-go for payment link** until the needed owner answers above are completed.

The content and process drafts can continue to be edited, but the payment link should not be created or sent while any of these remain blank:

- trading/contact details;
- address/contact-address decision;
- digital content option;
- refund/cancellation wording;
- privacy controller/processors;
- ICO fee position;
- emergency signpost URL.

## After Ben Completes This

1. Fill placeholders in `86_AI_Safety_Course_Founding_Pilot_Terms_Privacy_Drafts.md`.
2. Update `87_AI_Safety_Course_Founding_Pilot_Payment_Setup_Draft.md` with the chosen checkout flow.
3. Update Email 1 in `79_AI_Safety_Course_Founding_Pilot_Email_Templates.md` with purchase-summary wording.
4. Run content lint and focused phrase scans.
5. Only then create the private payment link.
