# KW-018 builder receipt — candidate awaiting independent review

Author: actual managed Codex UUID `01a1b2c8-4e33-75d3-a105-8f339fb95a25` (CODEX_SESSION_ID / CODEX_THREAD_ID). Existing Gmail route `/Users/benharwood/.codex-ben2`, gpt-6.1-sol medium, no fallback or subagents. Exact leaf `KW-018`; admission claim `claim-2091-65f08bf85786408a9153916365168d9b`, inherited FULL_STEAM_ADMISSION/FULL_STEAM_ENTRY retained. Outer run/launch child_boundary read from the admitted claim; no nested admission or coordinator launch. Boundary prompt hash `c952abeb102e3ac5b8d727aac9a6418c5d156cfe62edfbaaa0343687f7833123`. Queue revision 40 independently records this actual managed start; author did not edit queue/handoff.

Canonical dirty `feat/milestone-2`, HEAD `f91b58b6ab8d7dc05e1c2b9a0517747c5ff60867`, retained. Issued working-tree source pin `fa52c45edea2e0fca34de507ef4599ea2eab7e1010a31dcb772d73655987084a`. No checkout/reset, commit/push, publication, provider/account operation, spending, messages, media generation, new guidance or approval. Writes are confined to the six issued paths, including this receipt.

Read current AGENTS, simplicity rule, BUILD_RULES, project spec, existing inventory, Keepwise runbook/handoff and selected queue cards/dependencies/contracts; inspected loader, registry, schema/health/log/publication body hash, render/assembly callers, existing tests and explicit origin statements. `lib/ai-safety-update-stream.ts` was read only; it is not imported or activated. Current rules: BUILD_RULES SHA-256 `87a5b4d2e40b13143b99f06ac8443eb9311327870c006e24313fc229cd917b12`; SIMPLICITY_RULE SHA-256 `6951013f7f7c750002f3096a4e9d1c7a467fabe0a4a6b26972169f2493ffeee6`.

## Result and reuse

The read-only adapter observes exact file identities, current file/body hashes, declared MDX dates, block versions, explicit sourceFile/origin dependencies and existing health/log eligibility. It reuses the content loader/registry and existing contentHash/health/publication verification. Numbered authored asset paths come from the existing inventory's §6 existing-material cells; no second asset list or ledger is introduced. The appendix documents semantics tied to the existing rows.

Pure functions return stable sorted direct dependents, stale/held/unknown/current flags, recheck requirements and candidate replacement assessment. Currentness requires genuine derivation pins plus explicit exact-byte source AND derivative reviews/publication eligibility. No hash grants suitability or professional approval. Duplicate/invalid identities or pins throw before a result is returned; absent sources hold. Multiple direct dependencies are handled without transitive expansion. Downloads return remoteRetractable=false and an advisory, never remote deletion or delivery.

All pre-existing assets are reused without regeneration. Three printable origins are explicitly evidenced by their generation/render comments (27→27 Markdown, 33→32 Markdown, 34→34 Markdown). Current source and asset bytes are separate observations, never retroactive historical pins. All real historical derivation pins remain null; reviews remain unknown. Scripts/course/checklist/pilot files with no evidenced origin retain path/hash and unknown historical currentness. Translations and recordings remain unverified. All ten marked-published blocks remain ineligible because the genuine publication log is missing; no names or check dates were invented.

The inventory prefix was reconstructed before §8 and SHA-256 verified equal to the issued original `a56ee11ae7d909bd6616ee123d283ef5bdfef267688df565131fb9b249bf3218`. All 125 MDX files retain corpus digest `28e544a0991d1016c8856aa604430c78af7efcce36c30d26b027d434c90a8f7b` (sorted relative POSIX path + NUL + SHA-256(file bytes) + LF).

## Actual checks

- Installed runner: `node -p 'require("vitest/package.json").version'` → `2.1.9`.
- `node node_modules/vitest/vitest.mjs run tests/content-versions.test.ts tests/derived-assets.test.ts --maxWorkers=1 --minWorkers=1 --pool=threads --poolOptions.threads.maxThreads=1 --poolOptions.threads.minThreads=1` → initially 11 passed / 4 failed: Vitest it.each spread array rows, fixed test parameter table to named objects. Rerun after that fix and UTF-8 byte-integrity check: **15/15 passed**, 2 files (12 pure-function cases, 3 real adapter cases), 229ms runner duration. Actual one worker/thread, max/min 1.
- After narrowing inventory discovery to existing-material cells, new exclusion assertion found APP_README was still included (2 passed / 1 failed). Restricted discovery to numbered authored Markdown/HTML paths in those cells. `node node_modules/vitest/vitest.mjs run tests/content-versions.test.ts --maxWorkers=1 --minWorkers=1 --pool=threads --poolOptions.threads.maxThreads=1 --poolOptions.threads.minThreads=1` → **3/3 passed**, 250ms. Pure module/tests unchanged since their passing run; no redundant rerun.
- `node node_modules/typescript/bin/tsc --noEmit --incremental false` → exit 0 before and after adapter discovery changes. No generated tsbuildinfo write.
- `git diff --check` → exit 0. Readback verified original inventory prefix hash and unchanged MDX corpus; exact final candidate hashes below. No full build/suite, database or provider checks run.

Behaviour tested: synthetic old/current versions and version-only revisions; exact pins and both source/derivative review states; today's source hash cannot fill unknown historical pin; revisions/withdrawals/deletions flag only direct affected assets; unrelated paths excluded; retries/input ordering stable and inputs unchanged; multiple sources; missing/rejected/unreviewed/unknown-pin/unrelated replacements; duplicate/invalid identities/hash/version; downloaded-copy non-retractability; real loader/registry mapping, declared dates, 51 source MDX/74 blocks, current bytes and missing-log eligibility.

## Complexity and remaining work

Two small modules separate repository IO from deterministic decisions. No graph/chain framework, CMS, ledger, database, route, service, dependency or configuration switch. Fresh observations reject stale cached loader/registry bodies rather than mislabel current hashes. Exact-path reads reject escapes/symlinks outside the project and non-UTF8 text rather than silently changing byte identity. No consumer integration is required for this bounded repository workflow; integrating a future caller needs its separately issued file scope.

Initial author inspection, non-blocking LATER / SIMPLICITY: `lib/derived-assets.ts` validateAssets pin validation currently constructs a temporary VersionEvidence to reuse validation. If validation grows, extract a shared hash/version validator instead; this would remove irrelevant evidence fields from pin validation and reduce future maintenance coupling. No correctness gate is deferred by this observation.

Not accepted, integrated, published or released. Different checker must review the exact scoped candidate and evidence; only coordinator writes queue/handoff and acceptance. Next action: independently review adapter source identity/origin mapping and pure flags at the manifest below. No author self-acceptance. U06/U10/N08/N09 full feature completion remains open: historical pins/actual source and derivative competence reviews, publication evidence and live/saved-plan correction propagation are absent. KW-019/020 owns matching households, preferences, dedupe and authorised notices. KW-045/046 retains actual translations/recordings/reviews/delivery. No public or in-product activation. Existing content, approval, release and first-sale gates remain.

Measured window: managed start recorded 2026-11-06T21:34:09.706066Z; receipt generated at 2026-11-06T21:39:33.492607+00:00. Independent checking and external wait not measured by this author; do not infer zero or acceptance.

## Frozen candidate hashes (receipt excluded to avoid self-reference)

Candidate manifest SHA-256: `e8e29f156bad3b7bb94b28c7481dce534e9d152ea2b07971dc7ca3c79bc1bded`.
Algorithm: SHA-256 of sorted `relativePath + NUL + SHA-256(fileBytes) + LF` for these five files.

```text
77607e2b86a06b2167f3a1bdcfcaecad9fd37dfcc36436a1651dbcd3acdf05bf  108_Content_Inventory_Map.md
9e07bdfdd16671e54531d2ca9457daa325fe8844f452924f574a00a512553ee8  lib/content-versions.ts
e0f55865a0fae09cfea5f1847c7982cd4f2a2ffc322df3d1e85d2706e1317381  lib/derived-assets.ts
6e639f03743e8c5e75b1f2ab86bac007fd6964c8a45fce4b0f9f8511467d2079  tests/content-versions.test.ts
83691e1b1593ae0984684cfabcd0e7be52397020e2edaa8c6e57996b8a093278  tests/derived-assets.test.ts
```

## Read-only reused source/current asset byte hashes

These are observed current bytes only, not historical derivation or approval evidence.

```text
7df2d9088c2c4b34a3e5b0fad873ecf08f0bc59fda68e263e63a0fdab450ea19  lib/content.ts
fb3b1959c23a14fd4d6615e388524de7491132e18d01a2d41067e6e80d00afa1  lib/blocks/registry.ts
bf61fabec36b9d1baaca836b71580f6a84b9d13ffe4ea2420a0b3871a71f543d  lib/blocks/render.ts
5161d31a937edb386d6cd8d92bc1d80cfa684bffc661a106a9f1039f207d69d1  lib/blocks/health.ts
58794ee1f3713129a9d77975ea71bd19d4b8c3591a30df30403f1b01ee16ac29  lib/blocks/publish.ts
88622cfcfef16fbddfa4302b7399be1bed12c35f23f41387cc8c6f0cc37574a4  lib/blocks/publish-log.ts
4b9ed9d9764c2c663be8f9f711a5d0c60cdcee2f702efb6bdf1a7b068740378d  lib/ai-safety-update-stream.ts
5c7a28bc5e641a2ba57bf1f1b8c6400326f6317159815e028f45c89399458a94  27_Platform_QuickRef_Cards_print.html
1c0344b127358f76b3005e8a84a5b6c2d149b599df51fee8bee16b4f12c8fef2  27_Platform_QuickRef_Cards.md
85aed008a97dd53d45a95fdbcd6b3156203c55d58b4e3c8417bd800c58f7fb65  33_Printable_AgeBand_Cards.html
3f0d840d053c39f8df1898ffcfc2111db1bbefadbf5c4c340329ca6bf9143d28  34_Threat_Playbook_Cards_print.html
5779332025c85e26ca2988e126925928f929c6ceb962bd7d64daac740e55db4d  34_Threat_Playbook_Cards.md
6992e8e250465acfdd56ed00ea5c77cbed3bc93c410276e1661ca0f054efc5b1  32_AgeBand_Cards_and_Weekend_Checklists.md
b08aa95cede91ce69b3d6b5064d6b35e9fcf8302705c6b9832662be7ba20f294  28_Platform_Video_Scripts.md
d31964dd5a8ece4aefd58d7945a05d47456726c824ba08724845460994a5f8b9  29_Masterclass_Scripts.md
b373a44dd3337b5267fcee6fba8eaea18790bf8c339f00f1c24646ba3bf0e9bf  51_AI_Readiness_Lab_Curriculum_Spec.md
68ec418980c163b17c90984e4e72c1d14fe12acbf9f7d8f955d097825644ed2a  52_AI_Readiness_Lab_Lesson_Plans.md
96636c1f88b93ed01ffbdf594c814995896134be6ab1f80f6357b6c73a5d7e2a  53_AI_Readiness_Lab_Parent_Workbook.md
2b1e957693b565d3e49c4ce31e30e1ab56f059a4d2c645875c2f5a9f3961ef02  55_AI_Readiness_Lab_Complete_Course_Pack.md
c012c6486e92893f0bfe50aa17f2e0ad3f5d0d6ede4e7bb9751e5342c78498c4  81_AI_Safety_Course_Founding_Pilot_Printable_Pack.html
```
