# KW-016 builder receipt — implementation, not acceptance

Author session: `01a1b2b1-7255-7963-b835-271976d98f79`.
Coordinator: `01a1b1d3-816e-7d01-9ef7-4971cb7dfb6e`.
Boundary start: 2026-11-06T21:08:55.144572Z. Implementation/check evidence captured through 2026-11-06T21:14:45Z (about six minutes wall time, overlapping reading/implementation/checks; not a claim of independently measured checking time). Independent checking and external wait time remain unknown.

Canonical dirty branch `feat/milestone-2`, HEAD `f91b58b6ab8d7dc05e1c2b9a0517747c5ff60867` retained. Issued working-tree source pin: `452a315c99ba77f5f57c829a7d2f98ff86403d26362c95e52a5d53455be4bbfa`.

## Boundary and instructions

Inherited `FULL_STEAM_ADMISSION` remained set to `/Users/benharwood/.local/share/full-steam/codex-queue/admission/claim-70789-0f39b39b000a4d4ebd047dd6ec6d3cc8.json`. Read once: exact task/leaf KW-016, gmail-codex route codex-a, exact project cwd/root/paths, child boundary and prompt SHA-256 `f15c812dbec48703866f56a97d21535d294b34d9d556d1c61bde0c2071a8180b`. This CLI used the actual outer run/launch claim; no nested admission, new helper, second claim, child coding session or subagent was started. Coordinator owns actor/headroom reconciliation and queue/handoff updates.

Read current AGENTS, runbook, handoff, selected queue card and supplied U02/U10 contracts, simplicity rule and BUILD_RULES; inspected affected source, callers, tests, dirty diff and initial file hashes. The issued five existing source hashes matched before editing.

- BUILD_RULES identity: `87a5b4d2e40b13143b99f06ac8443eb9311327870c006e24313fc229cd917b12`.
- SIMPLICITY_RULE identity: `6951013f7f7c750002f3096a4e9d1c7a467fabe0a4a6b26972169f2493ffeee6`.

## Implementation and credited reuse

- Added pure `blockHealth(currentBlock, latestLogRow, asOf, integrityProblems)` projection. Reports missing source/publisher/reviewer/publication date/review deadline, overdue or invalid deadline, reviewer-rule failures and log mismatches. No filesystem mutations. Missing sources are shown as editorial follow-up; existing selection contracts do not require a source file for freshly authored content.
- Existing local desk displays source references, version, per-block issues and verified eligibility/counts. It calls existing `verifyPublishLog` for whole-file integrity, rather than interpreting a log tail as successful verification. An unreadable JSON log is reported; production selection fails closed on parse errors. Existing strict registry validation still throws on structurally invalid blocks; this patch does not create a lenient parser or replacement desk.
- Existing `registry.selectableBlocks` now combines `schema.isSelectable`, latest publication event and existing whole-file/version/body log verification with the shared health projection. Logs and file hashes are checked on every selection despite a warm parse cache. Missing log excludes published content. No assembler rewrite or change was needed: existing default assembly already calls this selector, and its explicit pool remains the existing fixture seam. Protected `deliverPlan` remains the customer path and retains the pause guard.
- Parent proof is in the existing rendered footer section, used by `/library/start` through `doc.sections` and the real MDX renderer. It uses only stored AssemblyLog block identity, source-file reference, version, body hash and captured review deadline, plus receipt assembly identity/time. No lookup of current metadata or invented reviewer/date/competence/endorsement. It explains source references are not frozen source copies and the hash is before household substitutions. Metadata text is escaped for MDX.
- Removed the renderer's unsupported blanket review dateline. The renderer now generates its factual footer from the receipt instead of repeating the legacy fixed-footer block's blanket review/date claim. Actual content files, including that legacy footer, were not edited. Existing PlanDocument/AssemblyLog interfaces and saved formats remain unchanged; no ContentProof component was needed.
- Credited unchanged `planPublish`, `computePublish`, `enactPublish`, withdrawal helpers, `buildLogRow`, append-only publication log, `assertLocalAdmin` on every server action, `_resetBlockCache` after publish/withdraw/batch, and local/environment pause/resume enforcement. Their fixture lifecycle is exercised through real server actions, enactment, registry, delivery and rendering. No new mutation API.

Complexity rationale: one small pure projection shares the selection/desk decision; existing filesystem verification remains authoritative for whole-file bytes. A small receipt formatter and text escaping are needed because stored historical evidence must survive today's metadata changes and travel through executable MDX safely. No new storage format, CMS, pipeline, configuration switch or component layer was introduced. Tests are confined to the two registered new files and disposable synthetic fixtures.

Initial author inspection — LATER / SIMPLICITY: `app/admin/blocks/page.tsx`, the health row projection passes the whole log to `verifyPublishLog` for every block even though `latestByBlock` was already computed. Passing only each block's latest row, as the selector does, would avoid repeated whole-log scans while retaining all checks. This is a small future maintenance/performance simplification, not an acceptance blocker. No new simplicity observations on rechecks.

## Actual commands and results

Working directory for checks: `/Users/benharwood/Claude/Projects/AI Safety Build`. Installed Vitest is **2.1.9** (`node -p 'require("vitest/package.json").version'`). Installed `--help --poolOptions` confirmed support for the explicit thread/fork max/min options below. All test execution used one actual thread worker, with both thread/fork max/min fixed at one. No full suite, build, database or browser suite.

```text
CI=1 node node_modules/vitest/vitest.mjs run tests/blocks-health.test.ts tests/blocks-proof.test.ts --no-cache --pool=threads --poolOptions.threads.maxThreads=1 --poolOptions.threads.minThreads=1 --poolOptions.forks.maxForks=1 --poolOptions.forks.minForks=1
```

Exit 0: **31/31 passed**, two files, duration 372 ms, 2026-11-06 21:13:39 local/UTC. Includes pure health negative fixtures; actual guarded action publish/withdraw/correction v1→v2 and immutable rows; cache reset and warm-cache tampering/latest withdrawal exclusion; missing/unreadable log, body/version tamper, overdue review; every mutation refusing production; local pause/resume and environment pause; actual desk health output; receipt unknowns/historical fields; parent page section extraction through real MDX compilation/static rendering; malicious stored source reference treated as text; signpost first/once/hash. React's static server renderer warns about server-action functions on form `action` attributes; runtime action invocations are tested separately. Vite reports its existing CJS API deprecation warning.

```text
CI=1 node node_modules/vitest/vitest.mjs run tests/blocks-publish.test.ts tests/blocks-schema.test.ts tests/blocks-assemble.test.ts tests/blocks-render.test.ts tests/editorial-isolation.test.ts tests/guardrails-structure.test.ts tests/signpost-integrity.test.ts --no-cache --pool=threads --poolOptions.threads.maxThreads=1 --poolOptions.threads.minThreads=1 --poolOptions.forks.maxForks=1 --poolOptions.forks.minForks=1
```

Exit 1: **113 passed, 14 failed**, seven files, duration 509 ms, 2026-11-06 21:13:49 local/UTC.

- Passing whole files: blocks-publish 29, guardrails-structure 50, signpost-integrity 3, editorial-isolation 3.
- blocks-schema: 15 passed, 1 failed at line 135 because it requires all ten currently published blocks to remain selectable without any publish log.
- blocks-assemble: 7 passed, 10 failed at lines 65, 70, 81, 86, 101, 114, 134, 147, 189, 217; these expect actual unlogged content in newly assembled plans.
- blocks-render: 6 passed, 3 failed at lines 26 and 50 (actual unlogged content excluded) and line 61 (explicitly requires removed `editor-reviewed and dated` phrase).

These are unresolved legacy test contract conflicts, not a green regression claim. All existing tests remain read-only. No publish log exists at the actual project root, and no historical approval record was fabricated. New fixture tests demonstrate the positive logged publication path and negative enforcement. An asynchronous coordinator scope request reported this exact finding and requested registration for isolated logged fixtures/truthful receipt assertions in the three old test files. No answer/scope extension had arrived at receipt time. Do not weaken checks or mutate real content/logs to make those tests green.

```text
node node_modules/typescript/bin/tsc --noEmit --incremental false
git diff --check
```

Both exit 0. Passing checks were not rerun. No commit, push, reset, clean checkout, publication, deployment, provider operation, real data, email or spend.

## Candidate hashes

SHA-256 of each complete file. Manifest identity `1adedc0f5962897b624178644d09f37eddbb5dc14efef7f126c9bcbc2a60fe66` is SHA-256 of the following eight-entry path→hash object serialized as Python `json.dumps(hashes, sort_keys=True, separators=(',', ':')).encode()`; receipt excluded to avoid self-reference.

```text
bf61fabec36b9d1baaca836b71580f6a84b9d13ffe4ea2420a0b3871a71f543d lib/blocks/render.ts
30bf266c1ae3ee4f50eb5b9c44e47348499473699a3f3f0dce51756f77f37de7 app/admin/blocks/actions.ts (unchanged)
f770b86e98023acaf6cc014caa9b4e30d2541c8f7237052302174eecd0226e61 app/admin/blocks/page.tsx
f7e08e5ff5bd8a136c174c6b6b35e650ac58b331b48555d2760226074bd13ad1 lib/blocks/health.ts
fb3b1959c23a14fd4d6615e388524de7491132e18d01a2d41067e6e80d00afa1 lib/blocks/registry.ts
2eee69d601a699d13453598dacbd6d481517a1ce358a6fc0d6107bb34a19476c lib/blocks/assemble.ts (unchanged from issued dirty source)
38a984067823d42b97c62f2dfa2cfdb2402c5df1239e39bd9f94b24e76dc7635 tests/blocks-health.test.ts
d445d62ddd2cc184446d7beb87f5f8376fc25ecd7b5a32ad918ce3102a61afa0 tests/blocks-proof.test.ts
```

Read-only checks: the following legacy files were byte-compared against HEAD and remain identical, except guardrails-structure which retains its issued pre-existing dirty hash below.

```text
160e4e5a4ada2b2f1cbb7fa6669b069b6bcbc72e74218426c1747f3af840006c tests/blocks-publish.test.ts
f5c38ed2837e3685628b7366c7ad3929684868e4a96862fe312979813bcc07c4 tests/blocks-schema.test.ts
49446ebb3e98466b3f63dbfa50bd127da15289fefe450e18a6c0fe8f5de4b1b3 tests/blocks-assemble.test.ts
a6ef482ab3c28a80e06d6c2d98bbc34b9f2712605cbad1306da6194f36620fa8 tests/blocks-render.test.ts
1ed12368d417dec07e9bd96854eaa3d00d571bd29d41b275eaaeae6b9a0c77b4 tests/editorial-isolation.test.ts
59bf2eb536837d36ad0920250151793038ce8808ed760bc14a513d72ed65cffb tests/guardrails-structure.test.ts (issued dirty hash retained)
8f6801a80553b55c582a634dd8e4c789ac0f3fd2a9e7295b6e5d3e1e604496c0 tests/signpost-integrity.test.ts
1916cdbe6de1ad045e1fa89502965b3d4000a164d566a963e189bf5a06e7e27b lib/signpost.ts
```

## Handoff and limits

Implementation supplied for independent review; **not accepted, integrated, committed, pushed, published or released**. Only six implementation/test files plus this receipt were written. Other author retains billing/schema; queue/handoff untouched.

Coordinator next action: resolve/register the exact three legacy test file fixture/assertion scope above, obtain a different agent's review of this candidate manifest and negative/positive evidence, and record outcome/elapsed time/handoff. No author self-acceptance. The absent actual publication log currently means zero actual guidance blocks can be newly selected; content owners must establish genuine scoped publication/review evidence before activation. Existing source content is unchanged and not newly approved.

This receipt proves local mechanisms and the actual page→sections→MDX proof path with fixtures, not a hosted browser/account/provider journey. It does not prove correction propagation to saved customer plans or other devices (KW-008/009 remain later work). Reviewer competence is not available in the current stored receipt; no endorsement is claimed. Existing live views/content, review/A0/privacy/sale/release gates and public unmonetised emergency access remain governed separately. Emergency constant, pinned hash and protected test checks were preserved.
