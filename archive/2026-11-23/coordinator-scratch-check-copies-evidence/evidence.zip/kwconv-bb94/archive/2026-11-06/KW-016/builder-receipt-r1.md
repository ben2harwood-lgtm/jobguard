# KW-016 bounded repair R1 — ready for independent delta review

Author remains original UUID `01a1b2b1-7255-7963-b835-271976d98f79`. Coordinator owns acceptance, queue/handoff and browser verification. This receipt does not self-accept the change.

Fresh outer admission: `claim-91185-3a546e7837ab4807a0fa1f21226f01e0`, 2026-11-06T21:26:42.166982Z, exact KW-016 leaf and saved UUID/cwd/root through the existing Gmail local codex-a route. Boundary prompt hash `a37642c276460214fabeb6b0debbc4dcdbe59e68debfcc00dcd74673dbd7042f`. Inherited admission variable retained; no nested admission, second claim, helper coding process, subagent or fallback. Actual whole-machine/actor admission remains coordinator-owned.

Current instruction identities matched the retained rules:

- BUILD_RULES: `87a5b4d2e40b13143b99f06ac8443eb9311327870c006e24313fc229cd917b12`.
- SIMPLICITY_RULE: `6951013f7f7c750002f3096a4e9d1c7a467fabe0a4a6b26972169f2493ffeee6`.

Read current selected queue card, repair registration and handoff, affected code/tests/callers and retained original receipt. Scope is the same-author repair issued following `/root/transition_check`'s independent initial source review. Canonical dirty `feat/milestone-2`, HEAD `f91b58b6ab8d7dc05e1c2b9a0517747c5ff60867` retained. Issued repair source pin: `13bdecb1b9a287bd87d1d88a0e74c5b8b119cdfd2fd52858f73effeedb8e399a`.

## Repair

Only production edit: `lib/blocks/health.ts`.

A small private helper checks exact `YYYY-MM-DD` syntax, finite UTC date and round-trip ISO equality. JavaScript's normalization of impossible days now fails that equality check. Health reports invalid publication dates and invalid review deadlines separately, and selection requires both dates to be valid. Missing dates retain their existing missing-field messages. Deadline expiry still uses the existing `23:59:59Z` inclusive boundary; one millisecond later is overdue. No publication date ordering rule, schema, publish contract, stored format or interface was changed.

Other health issues do not automatically block selection: a freshly authored block with no source file/references still reports the source gap while remaining selectable if the existing metadata/log requirements pass.

Added otherwise-eligible matching-log date cases in `tests/blocks-health.test.ts`:

- Impossible day/month and exact-form failures: `2027-02-31`, non-leap `2027-02-29`, non-leap century `2100-02-29`, `2028-02-30`, `2027-04-31`, `2027-13-01`, `2027-01-00`, `2027-2-28`.
- Every invalid date is tested independently as review deadline and publication date, with no log mismatch; as-of March 2 reproduces the reported February normalization boundary.
- Valid non-leap February, leap February, leap century, month end and year end: `2027-02-28`, `2028-02-29`, `2000-02-29`, `2027-04-30`, `2027-12-31`. Each is selectable at the exact deadline and excluded one millisecond later.
- Explicit source-gap policy regression.

## Legacy assertions preserved with isolated logs

Only the three newly approved legacy files were changed. All fixture files/logs are under uniquely created temporary roots. The real block corpus and actual project log were not written; actual `block_publish_log.jsonl` remains absent.

- `blocks-schema`: real corpus schema/type/lint/spread/reserved-signpost assertions remain. Selection tests use eight synthetic published blocks plus draft/withdrawn blocks, real `buildLogRow`/file hashes and the actual production registry. Original exact published count, stale count, draft/withdrawn and future exclusion assertions remain; exact selected IDs and successful whole-file verification strengthen the positive path. Added missing-log exclusion while published files still exist.
- `blocks-assemble`: all 17 original tests and their positive behavior, scoring/map agreement, age/platform, fallback, paired conversation, interpolation, privacy, deterministic output and signpost assertions remain unchanged. Fixture setup reads selection metadata from the source corpus, retaining IDs, triggers, age bands, domains, weights and pairs; replaces guidance bodies, source references and publisher/checker identities with explicitly synthetic data; writes only temporary files and their correctly hashed publication rows. The production selector is neither mocked nor rewritten, and default assembly traverses it. The pre-existing concern-unit tests retain their explicit pool seam unchanged; no new bypass was added. Added positive whole-file log verification and actual missing fixture-log exclusion with emergency retention.
- `blocks-render`: all nine original behavior tests remain, including complete section order, emergency once/first, exposure/low-confidence explanation, checklist derivation, no raw placeholders, lint, quiet-household omissions and checklist parsing. Uses the same inline temporary synthetic fixture strategy, through real `examplePlanDocument`/default assembly/selection. Only the unsupported blanket `editor-reviewed and dated` assertion was replaced: the footer must contain each captured block's ID, version, source reference, body hash and review deadline, assembly date and explicit reviewer/competence unknowns; the unsupported blanket phrase must be absent. Existing `not monitoring, not a guarantee` assertion remains. Added verified positive fixture-log and missing-log exclusion checks.

No fixture helper file was introduced. The small inline fixture setup is duplicated in assemble/render because the authorized scope excludes a shared helper file; it reuses gray-matter and production `buildLogRow`/`verifyPublishLog` instead of another parser/hash/log implementation. Synthetic prose avoids adapting or approving actual guidance while retaining every selection assertion. This is test isolation complexity only; production change remains one explicit date helper and two eligibility booleans. No new simplicity observation on this delta recheck; the original initial-review observation remains in the preserved first receipt.

## Actual checks

Explicit cwd: `/Users/benharwood/Claude/Projects/AI Safety Build`. Existing installed Vitest 2.1.9, one actual thread worker; max/min both one for threads and forks. Only the affected health file and exactly three authorized legacy files ran. No prior proof/publish/guard/signpost/isolation rerun, full suite/build, database or browser suite.

```text
CI=1 node node_modules/vitest/vitest.mjs run tests/blocks-health.test.ts tests/blocks-schema.test.ts tests/blocks-assemble.test.ts tests/blocks-render.test.ts --no-cache --pool=threads --poolOptions.threads.maxThreads=1 --poolOptions.threads.minThreads=1 --poolOptions.forks.maxForks=1 --poolOptions.forks.minForks=1
```

Exit 0, **87/87 passed, 4/4 files**, start 2026-11-06 21:29:06 UTC, duration 380 ms:

- blocks-health 40;
- blocks-schema 17;
- blocks-assemble 19;
- blocks-render 11.

The pre-existing CJS Vite warning and React static-render warning about server-action form props remain; actual fixture action functions are separately exercised by the retained health suite. No real publication/withdrawal/correction action was performed; health action tests remain confined to their disposable synthetic root.

```text
node node_modules/typescript/bin/tsc --noEmit --incremental false
git diff --check
```

Both exit 0. No failed repair check and no passing check rerun. Evidence captured through 2026-11-06T21:29:34.790873Z, about three minutes wall time from admitted start; independent review/browser time remains unknown.

## Exact hashes

Repair manifest SHA-256 `343b4ab0cbe39d2a44cc092382cd0be00684aca98b83ba0c740972f37845cfd0`: SHA-256 of the following five-entry path→hash object serialized using Python `json.dumps(hashes, sort_keys=True, separators=(',', ':')).encode()`. This new receipt is excluded to avoid self-reference.

```text
5161d31a937edb386d6cd8d92bc1d80cfa684bffc661a106a9f1039f207d69d1 lib/blocks/health.ts
91544b1e938f83809574def6f9badc46456be9a27f769576940c24167e205900 tests/blocks-health.test.ts
02152709dee621d1389254fafbe3c2d7a5b0e434aa14b26ff42e4bfe939063f0 tests/blocks-schema.test.ts
b6290b8dd8461645b1a0e1631c8cc5f99cfc0ee86d36634e0d7adc0964b3f98c tests/blocks-assemble.test.ts
3e5e2c88b0ee62442be1a0f1d90ee9eb671de7c2ef1538e1ff74845e295de1b7 tests/blocks-render.test.ts
```

Other original scoped source remained byte-identical to the issued repair hashes:

```text
bf61fabec36b9d1baaca836b71580f6a84b9d13ffe4ea2420a0b3871a71f543d lib/blocks/render.ts
30bf266c1ae3ee4f50eb5b9c44e47348499473699a3f3f0dce51756f77f37de7 app/admin/blocks/actions.ts
f770b86e98023acaf6cc014caa9b4e30d2541c8f7237052302174eecd0226e61 app/admin/blocks/page.tsx
fb3b1959c23a14fd4d6615e388524de7491132e18d01a2d41067e6e80d00afa1 lib/blocks/registry.ts
2eee69d601a699d13453598dacbd6d481517a1ce358a6fc0d6107bb34a19476c lib/blocks/assemble.ts
d445d62ddd2cc184446d7beb87f5f8376fc25ecd7b5a32ad918ce3102a61afa0 tests/blocks-proof.test.ts
a1097ecba78099e59970253454241ff1d309e24e2d659b1637ad12391db9f45d archive/2026-11-06/KW-016/builder-receipt.md
```

Original receipt and coordinator candidate archives preserved; this repair writes only the five authorized code/test paths and this new R1 receipt. Emergency/signpost constants and protected tests/actions were not edited. Other author's changes retained. No queue/handoff, commit, push, checkout/reset, provider/account/email/charge/spend, real-data, publication or deployment operation.

## Handoff

Ready for the independent checker's delta review of this five-file repair plus preserved original candidate. Coordinator then owns actual parent/desk/emergency browser verification and acceptance recording. Local mechanism evidence only: genuine publication evidence, reviewer competence, saved-plan correction propagation and provider/launch/privacy/sale/release gates remain open. The absence of the real publication log still excludes actual guidance; fixture logs do not confer approval on it.
