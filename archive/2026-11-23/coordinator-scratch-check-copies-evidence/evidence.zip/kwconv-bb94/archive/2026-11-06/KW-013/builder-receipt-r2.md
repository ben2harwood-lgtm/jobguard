# KW-013 bounded focus repair — author receipt r2

Recorded UTC: 2026-11-06T21:24:20.056036+00:00
Exact leaf KW-013; original author session `01a1b2a4-48b9-7422-a0a6-c9c726f06ad4` retained. Status: repair authored and targeted checks passed; actual mounted geometry retest and independent delta acceptance remain pending. No self-acceptance or queue/handoff write.

## Evidence and authority retained

Read browser-focus-finding.json and visually inspected browser-desktop-result.png and browser-mobile-result.png. Desktop screenshot leaves the result heading above the visible content, while mobile clips its first line. Read current Quiz source, shared heading refs, reducer, five existing component tests, sticky-header source/CSS read-only and independent-review.json. Prior independent source pass and actual two-household browser flows/back/edit/reset/email-unavailability passes remain credited; they do not clear this focus finding.

Checked unchanged AGENTS/runbook/current rule identities against retained full prior reading. BUILD_RULES SHA-256 `87a5b4d2e40b13143b99f06ac8443eb9311327870c006e24313fc229cd917b12`; SIMPLICITY_RULE SHA-256 `6951013f7f7c750002f3096a4e9d1c7a467fabe0a4a6b26972169f2493ffeee6`. No new simplicity review observations on this delta.

Actual inherited outer claim observed: `claim-88940-cdba42fbb6cd48a3b43558ef3a29d66c`, leaf `KW-013`, saved session `01a1b2a4-48b9-7422-a0a6-c9c726f06ad4`. Ordinary own scoped commands used the admitted session; no nested admission probe/new claim/helper/subagent, account fallback or changes to admission variables.

## Exact delta

Only components/Quiz.tsx changed, plus this new receipt. Within Quiz's existing shared heading effect:

- Focus uses `focus({ preventScroll: true })` so browser default scrolling cannot position the heading behind the sticky header.
- Immediately calls `scrollIntoView({ block: "center", behavior: "instant" })` on that same heading. No timer, animation, CSS/header change, platform branch or guessed pixel offset.
- Effect depends on the reducer state instead of only step. All state transitions use the same heading focus/scroll behaviour, including reset when step is already zero. Initial mount remains exempt as before. Questions, results and incomplete-result fallback already share the same ref.

Before hash (independently source-reviewed r1): `4133511d18d2b524532d9f43761064235364d430bbc5a058c0f18c8d31af30a9`.
After hash (repair candidate): `cf0c92fccd97c226407448a4bc11f58b366e2d5d391ea4122f75242e229a4aa7`.
Verified replacing exactly this effect with its prior text reproduces the exact r1 hash; no additional source delta. Verified all other five independent reviewed source/test hashes unchanged. Original receipts byte-identical: builder-receipt.md `70a1bf1f25eb8531359842018421ac986e7ae854d911031175c39399619b9f87`, builder-receipt-r1.md `c3e086d3206f4303f1de609eedf4256db20f72be98ae508a84665248dce5f2bf`.

Complexity rationale: two standard DOM calls in the existing effect and one dependency change; no new abstraction, configuration, dependency or framework. Keeps shared behaviour for all existing transitions.

## Actual checks

- `CI=1 node node_modules/vitest/vitest.mjs run tests/quiz-component.test.tsx --maxWorkers=1 --minWorkers=1`: exit 0, five tests passed, one worker. Existing Vitest CJS Node API deprecation warning only. No tests changed and no fake geometry tests added.
- `node node_modules/typescript/bin/tsc --noEmit --incremental false`: exit 0, no diagnostics. No unrelated author's source edited.
- Exact delta reconstruction and unchanged reviewed-file/prior-receipt SHA-256 assertions: passed.
- No rerun of the 34 unaffected passing reducer/API/threshold tests, heavy/full build/suite, database/provider or browser suite.

## Required next verification and limits

Coordinator/root retests actual mounted Next browser at desktop and 375 CSS px: immediately following keyboard question/result/back/edit/reset/fallback transitions, focused H2 top must be at or below actual header bottom, and full H2 bottom at or above neither viewport edge (bottom <= viewport height), without manual scroll. This receipt reports implementation and component/TypeScript evidence only; it does not claim measured post-repair browser geometry.

Eight questions/weights, reducer/API, local anonymous/no analytics flow, action/offer copy and explicit email-unavailable behaviour unchanged. No external email/provider/database operation, spending, publication, deployment, commit or push. Actual controlled delivery remains KW-049/G-services; broader integration, content/safeguarding/terms/billing/release gates remain open. Different checker must review the exact new Quiz hash and root records its actual browser result before acceptance.
