# KW-005 builder checkpoint · 6 November 2026

Status: scoped local implementation checkpoint, NOT independently reviewed/accepted and NOT live payment/SQL acceptance. Author is this bounded worker. Canonical feat/milestone-2 HEAD f91b58b6ab8d7dc05e1c2b9a0517747c5ff60867 retained. No commits, queue/handoff edits, services, provider calls, emails, charges, dependencies, publication or deployment. Existing dirty files retained; disjoint KW-030 files appeared during this worker and were not edited. Approximate observed implementation interval 17:19–17:25 UTC; not coordinator accounting or external wait evidence.

## Implemented behavior

- Removed the direct configured Payment Link redirect; public checkout and webhook endpoints explicitly return unavailable (503). Authenticated checkout POST requires trusted Origin and a tier-only bounded form. Missing identity returns 401. Legacy Payment Link/public price env values cannot bypass auth or change the recorded offer.
- One exported £49 System / £29 annual updates offer, GBP, with first-year updates and permanent non-refunded base access. Tax treatment, renewal method and cancellation terms are explicitly pending review. Existing commercial surfaces outside the allowed files were not rewritten or certified. Deliverable/terms completeness across receipts, account and school materials remains U11 integration work.
- Testable checkout handoff obtains the verified adult's app ID, queries its linked auth_subject, uses service-only intent RPC, checks provider-adapter session intent/package/amount/currency and HTTPS Stripe checkout origin, and durably binds the session before returning its URL. Provider creation must use intent UUID as idempotency key; only a trusted server adapter may implement it. Browser email/metadata are never identity authority.
- Version-1 minimal signed adapter envelope: HMAC-SHA256 over delivery timestamp and exact bounded raw bytes; five-minute signature window; event occurrence time may be delayed. Retries are re-signed. Reject unknown fields, unsigned identity, malformed IDs, wrong amount/package/currency, invalid/future timestamps and forgery before persistence. Storage errors return generic retryable 503. No raw body, email, token or provider error is stored/logged.
- Additive SQL/RPC checkpoint uses existing purchases/subscriptions as access authority. billing_intents binds adult/auth subject, checkout and payment; billing_events holds event ID/hash/kind/times only. User-row locking serializes different intents for an adult; unique event IDs and digest comparison handle retry/replay conflict. Writes and event receipt share one transaction. No public/anon/authenticated table access or RPC execution; service role only, no SECURITY DEFINER elevation.
- Refund is a terminal tombstone even before success; late success never restores a refunded purchase. Failure/abandonment do not grant access and may have no payment ID. Renewal grants updates only with paid base purchase required at intent creation. Base refund removes base authority; updates alone cannot grant library access. Cancel/reactivate record ordered renewal intention without extending paid periods or erasing paid-through updates/rules. Refund recomputes managed renewal period from non-refunded paid intents. Early/overlapping renewal and repurchase after base refund fail closed pending approved terms rather than inventing stacking/recovery policy.
- Financial authority: trusted adapter must verify capture/refund with actual provider objects. `paid.occurredAt` must be capture time, not delivery/event-publication time; the first capture establishes its one-year term. `refunded.occurredAt` is verified refund time. Receipt time never extends updates. Full refund/revocation mapping and partial refund handling require explicit provider/terms review; no arbitrary provider refund message can simply be forwarded as authority. Events record times; this is not a tax/revenue-recognition accounting system.

## Checks and exact limits

Installed runtime observed: node v24.17.0; Vitest 2.1.9. All Vitest commands used `--maxWorkers=1 --minWorkers=1 --pool=threads --poolOptions.threads.maxThreads=1 --poolOptions.threads.minThreads=1` through `node node_modules/vitest/vitest.mjs run`.

- Scoped tests: billing-fulfilment 16/16, billing-webhook 4/4, checkout final 8/8 (28 unique tests). Final checkout rerun covered added linked-subject/identity-confusion test. Earlier 27-test run passed before this one-test addition.
- Relevant existing auth-session 20/20, library-access 12/12, guardrails-structure 50/50 (82 tests). No protected test changed.
- `node node_modules/typescript/bin/tsc --noEmit --incremental false`: final pass. Initial run identified a widened fixture currency literal; corrected without changing production requirements.
- `git diff --check`: pass. No full build, full suite, browser or database run.
- Signature, rejected amounts/identity/package, public unavailability, bounded payloads, DB retry forwarding and checkout binding execute in actual installed runner with fixtures.
- Concurrency/duplicate/out-of-order lifecycle ingress tests demonstrate forwarding to the durable boundary ONLY. SQL tests are explicitly static design assertions. They DO NOT execute locks, transactions, replay resolution, refund projection or PostgreSQL constraints. No mock-to-live or SQL-semantics pass is claimed.

## Remaining integration/acceptance gates and exact next action

1. Independent checker reviews these exact hashes; author has not self-approved. Coordinator alone records review/acceptance and queue state.
2. On an authorised disposable PostgreSQL instance, apply schema.sql, kw002 then kw005; execute real concurrent cross-intent and duplicate/conflicting-event transactions, refund-before/after-success, failed/abandoned payment, late capture, renewal expiry/refund, cancel/reactivate tie/order, session/payment/subject mismatch, RLS/RPC permissions and rollback tests. No PostgreSQL execution evidence was available here. Static assertions are insufficient to accept this mechanism's SQL behavior.
3. Implement the authorised existing-provider server adapter and real sandbox journey: create/retrieve the correct checkout, verify immutable intent/package/captured amount/currency/transaction time, bind before redirect, verify native provider webhook signature and retrieve relevant provider objects, then map to the minimal envelope. This checkpoint's signed adapter format is NOT a Stripe webhook format or a native-provider signature verifier. Both production routes intentionally remain 503; setting a payment-link/key/secret cannot enable them. Wiring them requires a further exact scoped order after adapter/SQL/terms evidence, not an implicit runtime flag. No real payment or live checkout has been proved.
4. Confirm actual test-mode provider entitlement, refunds including partial/refused refunds, retries after provider/session creation interruption, cancellation and reactivation against approved renewal method; no real charge/new spend. Resolve how abandoned provider sessions are replaced without double-charge before activation. Current pending intent is reused and has no automatic reset.
5. Complete approved tax, renewal, cancellation/refund terms and precise commercial deliverables on all surfaces; G-A/G-B0 before first sale, G-SERVICES/real browser/provider journey and other product release gates remain. No gate is satisfied by this receipt.

## Complexity rationale

Two small supporting tables are needed because existing purchases/subscriptions cannot bind pre-payment auth subjects or remember rejected/replayed events and refund-before-success tombstones. They are transaction/audit inputs, not a replacement entitlement system. SQL user locks, terminal refunds, unique session/payment/event/period keys and service-only RPCs preserve identity, financial and replay controls that an in-memory dedupe map or unsigned metadata shortcut would lose. The deliberately missing provider adapter avoids a speculative billing framework or unverified Stripe implementation.

LATER / SIMPLICITY (builder suggestion, nonblocking; independent initial review still required): lib/pricing.ts and lib/checkout.ts could use a tier-keyed offer record for labels and explanatory copy when launch terms are approved, reducing repeated wording across future receipts/account integration. Keep independent SQL price checks as financial defense, not a simplification target.

## Exact SHA-256 of scoped implementation/test files

- `lib/checkout.ts`: `70194ff112e2daaeccff3f3bd6f78c5bc581d3ee34500e69dfe175002e2bb595`
- `lib/pricing.ts`: `7e04f1bceb58f3667c4fc0f71e9b65dc603add3cf11f5964b742bc44c15cf320`
- `lib/billing/fulfilment.ts`: `d7887ead4fe3be261714577d8bee0c05a9c71f1357b0a3f303917db6534309a2`
- `app/api/billing/webhook/route.ts`: `b96968015ab78335307d7bca9b685c70d35a5f8132adcbd51edd1a747f46d86f`
- `supabase/migrations/kw005_billing_events.sql`: `c572f277ffa9cf12a1145f7712539e34c93c925c31bb2ecc1e51b06e9b388b1a`
- `tests/billing-fulfilment.test.ts`: `d871789b9b221a4b42913639e2e252eb021ef21a401211217150149c5af8605e`
- `tests/billing-webhook.test.ts`: `f2ef9292284cffe42d23b34b8610cadf1f15d2b5ea663f7684bd6c73e4e16df9`
- `tests/checkout.test.ts`: `69bf46e9b3f202fff527943a568fc6fba35591c8bca6b63fdbd935ff8dfbf5d3`
- `app/checkout/[tier]/page.tsx`: `512a16dd983dc42b6e9a59d068cfaf8170c8ba7a3e00bdc5fd2afe1ae47da02a`
- `app/api/billing/checkout/route.ts`: `73ea4b8a1bbe31f439d323ac5025fb36dc89bb395c30e17358e17e92ef40376f`
