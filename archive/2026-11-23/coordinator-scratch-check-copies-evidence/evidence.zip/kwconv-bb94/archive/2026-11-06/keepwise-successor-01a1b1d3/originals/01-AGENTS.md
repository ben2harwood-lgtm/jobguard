# Standing rule for every Codex session on this Mac

Keep it simple (Ben, 25 Oct 2026, card simplicity-check-before-launch): before you build, repair or change code, read and follow
/Users/benharwood/Claude/Projects/Next Gen Learning Platform/docs/workflow/SIMPLICITY_RULE.md
If you write, dispatch or resume a build or repair for another session (including `codex exec resume` drivers and hand-written
.job lines), put that file's full text in its prompt. When you check code, record a worthwhile simplification only on the
initial review, as LATER / SIMPLICITY with the location, the simpler approach and the maintenance benefit; it never blocks.
This sits below each repository's own AGENTS.md and CANON and changes no gate, round cap or scope.

# Exception: Cue and Workings builds skip the general queue's admission (Ben, 2 Nov 2026, card cue-queue-check-2026-11-02: "Yes, skip it")

Applies only to a Cue (CUE-E*) or Workings (WPB-*) build in the Next Gen Learning Platform repo: do not run `build-policy.py run`,
`check` or `launch` for it, and do not treat their HOLD or a missing row in that queue as a blocker. Its launcher applies the builder
limit. This exception changes nothing else: round caps, independent reviews, tests, side branches, lane registration, commit hooks,
write roots, made-up data only, and Cue staying off for children all stand. Every other project keeps the rules below.

# Current build coordination rules

Before coordinating, dispatching, resuming, or checking a build, read
/Users/benharwood/.local/share/full-steam/BUILD_RULES.md and the applicable repository AGENTS.md/CANON.
Use /Users/benharwood/.local/share/full-steam/build-policy.py prompt to refresh the issued prompt with the current rules and the full simplicity text; this includes hand-written .job files and resume drivers.
Use its `run <exact task label> <command...>` admission for local drivers before setup or mutation. The eight-role global coding ceiling is eight, with exactly two each for Gmail local CLI, Yahoo WEB APP WORK TAB, Astra web and Claude builders; no role borrowing. Yahoo CLI is prohibited; unverified external transport remains HOLD. Gmail coding uses existing ~/.codex-ben2 gpt-6.1-sol medium, exact same-leaf saved UUID/cwd/roots, no paid/account/session fallback; planning, coordination, Claude checks, CI and test runs are excluded. Bind explicit profile/account/model and exact saved session/cwd/roots through runtime-bindings.json and current queue schema v3. Publish actual coding-worker observations through the existing sole coordinator queue; include coding admission claims by exact label or ID. This staged generation remains held until independently reviewed and coherently installed with the sole coordinator publisher transition.
The shared rule is read at execution time. Do not copy stale model/account, generic review, round-cap, or capacity rules from historical orders. Do not create another coordinator/timer or enable dormant auto-helper live switches through this alignment.

# Managed child consumption and unsupported surfaces

Managed coding wrappers must send the actual final Codex argv through
`build-policy.py launch <exact issued leaf> -- <installed codex> exec ... <literal prompt>`.
Refresh via `build-policy.py prompt` first. The boundary checks the current full rule bytes and
source hashes, admitted role/claim, leaf, exact saved session and cwd before child execution;
its claim record and existing command log bind the prompt hash. A worker ACK alone is insufficient.
Do not reuse a checker claim for coding or start a fresh helper on a saved worker claim.
Manual .job files through admission support one literal managed wrapper command only; other
shell shapes hold for coordinator reconstruction, even when they mention the helper.

Native app/tool children, external cloud/ChatGPT/manual execution do not acquire mechanical
coverage from these instructions. The sole coordinator must obtain actual current-rule and
candidate consumption evidence, reconcile every coding actor against the global eight coding slots,
and hold results/new work without it. Prepared cloud configuration is not actual fresh-task
execution evidence; review the published environment's supported UI/runtime separately.
Yahoo CLI auth metadata is provenance only; Yahoo Work requires actual observed proper web account/session/source/execution and shared atomic admission capability. Astra and Claude coding require existing verified subscriptions/chat identities and exact executable adapter bindings; missing capability stays plans-only. Independent Claude reviewers are not builders. No friendly-name promotion or invented actors. JobGuard build-ahead/routine own-plan setup follows the 27Oct scoped approval, with current-main CI, fixed dependency merge order and C282 actual independent merges preserved; genuinely reserved gates and Workings C250 do not change. Legacy/mixed generation observations never authorize R2; unsupported remote execution remains HOLD. Product CANON, Workings C250, AAC policies, independent
review/acceptance and all existing resource, STOP, schedule and release gates still apply.

The inherited Vitest 2 environment sets max 2/min 1 threads and forks, permitting stricter max 1.
Verify installed runner support; Vitest 4 and unknown runners require their explicit maxWorkers
option and evidence. This environment is not a universal test concurrency guarantee.
