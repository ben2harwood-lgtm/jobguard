# KW-030 builder receipt — 6 November 2026

Built locally; **not independently reviewed, accepted, integrated or released**. Coordinator: `01a1b1d3-816e-7d01-9ef7-4971cb7dfb6e`. Builder scope is exactly the four authorised paths. No queue/handoff edits, subagents, runtime/dependency changes, provider calls, services, commits, push or publication.

Baseline: intentionally dirty `feat/milestone-2`, HEAD `f91b58b6ab8d7dc05e1c2b9a0517747c5ff60867`. Initial library page matched issued SHA-256 `130737c040a62682eda10f3a5aed30f5228ffec8fb0e39aa44a128b1033aa9ca`; component/test absent. Current rules and simplicity file read from their prescribed paths; runbook, handoff, selected queue/dependency records and KW-002 catalogue-search scope inspected. Existing managed-launch/admission evidence remains coordinator-owned; this receipt does not establish a fresh admission or runtime acceptance.

## Behaviour

- Replaced only the platform section with a client explorer supplied by accepted `getPlatformCatalogue()` **after** the existing library guard. Age navigation, playbooks/modules and original first-phone/other navigation remain.
- Searches title, summary, slug and metadata tags of exactly 19 guides. Case-insensitive whitespace-separated terms intersect with guide-age, purpose/topic and control-topic filters. All filter options derive from guide metadata; control options use a small explicit subset of existing topic names. Reset clears every field using the same model as filtering.
- Query exists only in React memory. No form submission, URL update, analytics event, network call, logging or persistence. Type-only client import avoids importing the server catalogue loader into the client runtime. No household/external search.
- Native labelled search/selects, fieldset/legend, button, details/summary and polite result status; fluid grid, wrapping cards and 44px input/button minimum height. Browser behaviour remains unverified.
- Results compare editorial age/topic coverage only. Source-declared last-updated dates and attributions remain visible with explicit current-verification, review and test limitations. Minimum ages, ratings and contact/privacy/commercial/family-control facts remain unknown. Shared guide tags never imply equivalent platforms or tested provider controls.
- Missing-app path offers reset/shorter search, existing first-phone/conversation links and categories to check against current publisher evidence, without assigning facts or a rating. Existing Roblox/Fortnite/Minecraft/Steam/consoles and ChatGPT/Gemini/My AI coverage reused. Universal games/AI-companion coverage remains unsupported; e.g. Character.AI has no named catalogue entry and returns a gap. Guide body mentions do not become structured coverage/facts.

## Validation

Installed runtime observed: Node v24.17.0, Vitest **2.1.9**; existing Next 14/React 18/TypeScript packages reused. Installed runner exposes thread/fork options.

```sh
CI=1 node node_modules/vitest/vitest.mjs run tests/platform-explorer.test.tsx tests/catalogue.test.ts tests/library-access.test.ts --no-cache --maxWorkers=1 --minWorkers=1 --poolOptions.threads.maxThreads=1 --poolOptions.threads.minThreads=1 --poolOptions.forks.maxForks=1 --poolOptions.forks.minForks=1
node node_modules/typescript/bin/tsc --noEmit --incremental false
```

Both exit 0: **39/39 tests across three files**, TypeScript passes. New TSX tests are included by the existing real Vitest configuration. They exercise actual catalogue combinations, native change/reset handlers feeding the filter model, React server-rendered results/semantics, unsupported searches, missing dates/attributions, unknowns and navigation/guard ordering. A final added guard-presence assertion was verified by rerunning only `tests/platform-explorer.test.tsx` with the same worker flags: **14/14**, exit 0. Counts overlap. Existing Vite CJS deprecation warning only. Scoped tracked diff whitespace check passes.

No full build, browser, database or provider tests run. Server rendering and direct React-element handler tests do not prove browser focus, keyboard interaction, hydration or mobile presentation. Coordinator/checker must verify those and independently review the exact hashes below. Actual PostgreSQL/provider operation remains unestablished. KW-002/B0 search scope review, reviewed current facts/content and all existing sale/release gates remain unresolved; no activation clearance claimed.

## Complexity and preservation

One pure filter and a controlled view share behaviour between the small useState wrapper and server-rendering tests. This is the only added separation: it permits meaningful behavioural tests without a new DOM/browser dependency. The six control-topic names classify editorial metadata only; no new platform registry, ranking, comparison engine, guide content or packages introduced.

Initial review only — **LATER / SIMPLICITY**: `components/PlatformExplorer.tsx`, `GuideCard`: a single local labelled-fact list could render the two age/rating rows together with the four comparison rows, reducing two presentation paths to maintain when evidence fields change. Nonblocking; no unrelated refactor performed. This builder observation is not independent approval.

Original protected APP_README.md, app/globals.css, tests/library-access.test.ts, app/library/first-phone/page.tsx and components/FirstPhoneWalkthrough.tsx still match recorded baseline hashes. The original first-phone card remains in the intentionally changed library page. Accepted catalogue and catalogue-test hashes also remain unchanged. Other worker paths were not edited.

## Exact SHA-256 hashes

| File | SHA-256 |
|---|---|
| app/library/page.tsx | `4b0768a8dbf116e4659cd284f8cb22263130fa80c07144978fc8440a0f7dea4b` |
| components/PlatformExplorer.tsx | `fac372b38b2ddc998862508b8e36a15357e983294537c6d3b6d0f0c50f5e78ed` |
| tests/platform-explorer.test.tsx | `110bf45b54c84594968f2087654a10264ac9e277af55f59a251d8d2d7fe7a66f` |
| lib/catalogue.ts (read-only accepted dependency) | `8c5afe9e4f620a11706d78dd83c844a7622aebb549f1c928c3f32a828a7f0af4` |
| tests/catalogue.test.ts (read-only accepted dependency) | `2a0f8e64bf1553b61fa745c4ffda8d2c803aceb1d6748ae03741bfe68538e92a` |

Receipt self-hash is intentionally external to its own contents. Next action: coordinator obtains independent scoped review and browser keyboard/mobile evidence, then records the decision and elapsed observations in the existing queue/handoff.
