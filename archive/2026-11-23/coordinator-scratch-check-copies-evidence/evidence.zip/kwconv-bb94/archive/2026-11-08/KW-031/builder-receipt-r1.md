# KW-031 repair 1 builder receipt

Author evidence for the synthetic KW-031a substep. Independent delta review and coordinator acceptance are pending. The literal guidance checkpoint, KW-031b/c and N05 remain open.

The inherited Gmail local boundary resumed `KW-031` on the original UUID `01a1bb76-357c-7e81-81f2-09c818c5a44b` under claim `claim-18002-0073817050da47bc9d76b97080418556`. The boundary recorded the project cwd as the sole saved root, zero added directories and prompt SHA-256 `b2ca452c2480f630e589d00b8f703bdacedb919797fd7a10f5583562ee57ab3a`. Queue revision 60 and the active lease agreed with the resumed identity. HEAD remained `f91b58b6ab8d7dc05e1c2b9a0517747c5ff60867`.

The two P2 findings in `independent-review.json` (SHA-256 `53ed2fdb635c305ab59a66bb14eb337f987a731a0ac24a3cdbfff1270183b5e8`) were against manifest `390792b7de0a061d25faebde6931239c0d87422d554010659bfaf8785be21a37`. The live candidate matched the reviewed source hashes before repair.

The repair rejects non-string facts before membership and matching, requires nonblank strings that match exactly across both scopes, and guards the date parser against non-string input. A row without option scope cannot enter a category and purpose comparison. A row with valid category and purpose but missing evidence scope remains in comparison as unconfirmed. The fixtures, component, result vocabulary, approved scope and editorial gates are preserved. Only chooser source, its focused tests and this receipt were edited. The original receipt still hashes to `98b10278c84a2e36b0758f7759868685e87008cedb6af8d482e5c512ad677644`. This repair adds no ingestion layer and makes no real product or provider checks.

## Verification

- `CI=1 node node_modules/vitest/vitest.mjs run tests/before-you-buy.test.tsx --no-cache --pool=threads --poolOptions.threads.minThreads=1 --poolOptions.threads.maxThreads=1` on Vitest 2.1.9. With the regression cases added and the original chooser still in place, 8 failed and 27 passed (exit 1). Failures reproduced the upfront array false match, null and undefined evidence scope exceptions, missing option scope exception, shared numeric, whitespace and array scope false matches, and a symbol date exception. After the repair, all 35 passed (exit 0). Both runs printed the existing Vite CJS API deprecation warning.
- `node node_modules/typescript/bin/tsc --noEmit --incremental false` exited 0.
- For each changed source path, `git diff --no-index --check <(unzip -p archive/2026-11-08/KW-031/candidate-source.zip "$file") "$file"` printed no whitespace diagnostics. The first loop stopped on the first path because no-index returned 1 for differing files. The follow-up loop checked both paths and observed 1 for each changed file with no diagnostics.

## Candidate SHA-256

| Path | SHA-256 |
| --- | --- |
| `lib/catalogue/chooser.ts` | `49ef6037afad6efdfb44afd4c13ea2cf9e665fefaf08ca100ebd4a3114621871` |
| `tests/before-you-buy.test.tsx` | `18f75a52fe7046221be98b9459a382ba5350d3fc4b8579db3240c2e14879fe1f` |
| `components/BeforeYouBuy.tsx` (unchanged) | `d54a5c8a485a2e0c86c98c369fe14d5b020a909e8941dc59381e7dd5f1ca241c` |

SHA-256 of the sorted compact JSON path-to-file-hash map is `30d36d0824a89c4544926f76cd2fa951b15e218bbcec419f8c1fdb763d72df14`. The next step is independent review of the repair against this candidate.
