# KW-031 builder receipt

Author evidence for the synthetic KW-031a substep. The exact candidate is ready for independent review before coordinator acceptance. The literal guidance-adaptation checkpoint, KW-031b/c and N05 remain open.

## Managed execution

- Leaf `KW-031`, queue revision 57 at readback. Actual session UUID `01a1bb76-357c-7e81-81f2-09c818c5a44b` and claim `claim-6547-91ce1c8eca6c4634ac889df050cd4db5` matched the inherited environment, managed log and queue attempt. The outer boundary recorded fresh Gmail local `gmail-codex` (`codex-a` / `~/.codex-ben2`), `gpt-6.1-sol` medium, the project cwd and zero added directories.
- Child prompt SHA-256 `61022d6bf73472159e8ced1c3841385135adaf1ebb4ae43f75129072d0dbf9cb`. Source pin `working-tree-sha256:15e495aa4112aa39dc0c0dee1bdda622037d1d3eb979b6083d6ab509fbe319f1`. HEAD before and after implementation `f91b58b6ab8d7dc05e1c2b9a0517747c5ff60867`. The three pinned reuse inputs matched their registered hashes.
- Read AGENTS.md, the live shared rules and simplicity rule, the runbook, current handoff and KW-031/N05 card and dependency context. Read the actual `/root/transition_check` final answer at coordinator transcript item 451, preserved in the approval audit transcript for `01a1bb6f-cc28-7fb3-a370-8c1dd1aa34ca`. That review cleared fixture-only issuance.
- Used the inherited claim. No nested admission, fallback, other workers or subagents. Only the registered candidate paths and this receipt were edited in the project. No queue/handoff writes, commits, push, deployment, provider/account operation, spend, sharing or publication.

## Exact candidate SHA-256

| Path | SHA-256 |
| --- | --- |
| `lib/catalogue/chooser.ts` | `73898aa1b32d40fc096023104bcee5c79a6a4547d2e96b89c5f1db9ce3863483` |
| `components/BeforeYouBuy.tsx` | `d54a5c8a485a2e0c86c98c369fe14d5b020a909e8941dc59381e7dd5f1ca241c` |
| `tests/before-you-buy.test.tsx` | `ab4df46423c7f8363778ecc4de357e1235263f807d5fb6a686277b4163313e6b` |

The receipt is the author manifest, separate from the three implementation/test bytes it identifies.

## Checks

- `node node_modules/vitest/vitest.mjs --version` returned 2.1.9. The installed CLI help exposed both thread options below.
- `CI=1 node node_modules/vitest/vitest.mjs run tests/before-you-buy.test.tsx tests/catalogue.test.ts --no-cache --pool=threads --poolOptions.threads.minThreads=1 --poolOptions.threads.maxThreads=1` exited 0 on the initial run. 38/38 passed, with 25 chooser and 13 catalogue tests. Vite printed its existing CJS API deprecation warning.
- `node node_modules/typescript/bin/tsc --noEmit --incremental false` exited 0 on the initial run. Neither validation check required a rerun.
- A before/after porcelain status comparison before writing the receipt showed only the three expected candidate additions. The status diff exited 1 for those expected additions. A discovery command found that the new `lib/catalogue/` directory did not yet exist. The final status comparison also saw `browser-chooser.png` and `browser-evidence.json` appear concurrently in the archive. These are external to this builder’s writes and checks.

## Boundaries and review caveats

- Eight labelled synthetic fixtures exercise two contrasting requirement sets in each of four categories. The native selectors use local React state and an explicit fixed demo as-of date. The only budgets are illustrative ordinal bands and required recurrence status. Each comparison uses deterministic fixture ID order.
- The material complexity is the separation of configuration identity, a validity window, and per-criterion findings. One evidence bundle must match the full category, purpose, edition, OS, account and region. A bundle with an invalid scope or window supplies zero eligible facts. Field findings retain known mismatches and evidence gaps separately, including when both occur in the same comparison. Each fixture represents one atomic configuration and uses explicit conflict/unknown/unsupported states. No evidence ingestion or reconciliation process is included.
- The catalogue's source-stated and unknown types describe a different evidence boundary. The chooser consumes no catalogue facts, guide metadata or vendor leads. The existing catalogue regression tests passed. The component has no customer route or browser integration. Composition evidence is React static rendering plus native change handler checks, with no browser/device or live-provider result.

## Outstanding real input matrix

For every supported row, first obtain dated, attributable evidence for the exact UK variant/edition, target device and OS version, adult device ecosystem/OS, account roles and eligibility, region, purpose and applicable configuration. Record each mandatory prerequisite and whether it is met, unmet or unknown in the scenario. Verify the configured communication modes and audiences, including open chat where relevant, and the named control's presence, default, setup and observed effect separately. Evidence must cover the total required upfront UK acquisition band and whether any plan, subscription, hardware or other recurring cost is required for that purpose. Separate optional extras and retain unresolved costs as unknown. Record the evidence snapshot, observation and review dates and the validity or recheck condition. Obtain an editorially reviewed explanation of trade-offs and a current official public setup link and next step for each included scope.

| Category | Existing research leads | Scope-specific inputs still needed in addition to the common matrix |
| --- | --- | --- |
| First phone | iPhone with Screen Time; compatible Android phone with Family Link | Identify exact iPhone and Android models and OS combinations. Establish family organiser/guardian and supervised child-account eligibility by region, applicable parent-device combinations, required service for the selected communication mode, and actual communication limits and controls on each configuration. |
| Smartwatch | Apple Watch SE with cellular and Family Setup; Garmin Bounce 2 | Establish exact watch and organiser device/software combinations, account and companion app eligibility, UK provider, plan and coverage for the chosen independent-use scenario, and communication and control behaviour in that setup. |
| Console | Nintendo Switch; Xbox console with Xbox Family Settings | Identify exact console generation/software, game or service and family/account context. Verify console versus account or game scope for voice/chat, schedules, content and spend, including any required online service. |
| App | Roblox; Minecraft Bedrock or Java with Microsoft family settings | Identify exact app/device version and Roblox parent-mode, linked-account and age-check requirements. Scope Minecraft Bedrock and Java separately and establish device, account, multiplayer/server and chat conditions. Verify actual control outcomes and any mandatory purchase or subscription by purpose. |

All eight vendor sources remain leads. The coordinator's next action is independent review of the exact three candidate hashes. Translating reviewed guidance, resolving any category with fewer than two supported comparable choices, and supplying reviewed setup steps remain separate from this synthetic substep.
