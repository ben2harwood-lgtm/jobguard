# KW-031 UK comparison evidence

Observed 8 November 2026. Internal evidence for N05. Each row scopes a possible configuration. Prices are one seller's snapshot for the named item. Separate costs apply where listed. Account, device and network prerequisites are household-specific. Recheck volatile facts before use. No hands-on device or account verification was performed.

## First phones for supported native calls and texts

### Apple iPhone 17e, 256 GB, UK SIM-free, iOS 27 Family Sharing configuration

- Apple UK listed the 256 GB variant at £699. Its March launch price was £599. Use the dated current-store observation. Native mobile calling and texting require a suitable SIM/eSIM service and coverage. Cost depends on the household's plan.
- A child Apple Account in Family Sharing lets a parent manage Screen Time on a compatible Apple device. The scoped configuration uses supported, updated devices running iOS 27 for the current controls, with iCloud Contacts and the appropriate contacts-only and contact-editing settings. Screen Time can schedule downtime and limit apps. Contact limits apply in Phone, Messages, FaceTime and other supported Apple-documented contexts. Third-party channels and emergency calling need their own consideration.
- Setup sources are Apple's parental controls and Communication Limits instructions.
- Sources: https://www.apple.com/uk/shop/buy-iphone/iphone-17e | https://www.apple.com/uk/newsroom/2026/03/apple-introduces-iphone-17e/ | https://support.apple.com/en-gb/105121 | https://support.apple.com/en-gb/108806 | https://support.apple.com/guide/iphone/choose-communicate-times-iph4df1c0dad/ios

### Google Pixel 10a, 128 GB Obsidian, UK unlocked, Android 16 with Family Link

- Argos listed £399 for the SIM-free 128 GB Obsidian variant. Google documents that variant. A compatible mobile service and coverage are separate for native calling and texting.
- A personal supervised child Google Account and parent Google Account are required. Family Link's general management supports both adult Android and iOS. Google's approved contacts setup specifically documents an Android adult device. Treat iOS-only adult setup for this contact requirement as unconfirmed. The scoped native controls apply to Google Dialer and Google Messages on a supported child Android phone (Android 14+). Google documents exceptions for third-party apps, forwarded group calls with an added participant, voicemail and emergency services. Daily screen limits are available.
- Setup sources are Family Link's contacts and general prerequisites instructions.
- Sources: https://www.argos.co.uk/brand/google-pixel/ | https://store.google.com/gb/product/pixel_10a_specs?hl=en-GB | https://support.google.com/families/answer/7101025?hl=en | https://support.google.com/families/answer/15843584?hl=en | https://support.google.com/families/answer/7103340?hl=en

## Watches for supported contact while away from the adult's phone

### Apple Watch SE 3, 40 mm GPS + Cellular, Apple Watch For Your Kids in the UK

- Apple UK lists GPS + Cellular from £289. The £219 GPS price is a different configuration. A compatible family watch plan and coverage are required for standalone cellular calling and messaging. Apple lists EE and BetterRoaming under the UK family-setup heading. BetterRoaming advertised a £8.99 monthly option when observed. Its annual promotional rate and household coverage should be checked directly if relevant. Standard paired-watch network support is a separate list.
- Adult iPhone 11 or later, parent/guardian or organiser in Family Sharing, separate Apple Accounts, adult two-factor authentication and enabled iCloud Contacts for shared contacts. Model-specific OS documentation currently differs between older setup and current tech-spec material. Scope this candidate to an adult iPhone with iOS 27 and current compatible watch software. Exact older supported combinations remain unconfirmed here.
- Apple documents shared contacts with Screen Time restrictions and Schooltime. This is a specific managed watch communication configuration and Schooltime limits certain features. Treat a strict all-channel approved-contacts or hard time-cap requirement as unconfirmed unless separately evidenced.
- Setup source is Apple's family watch guide.
- Sources: https://www.apple.com/uk/shop/buy-watch/apple-watch-se?part=Z0YQ | https://support.apple.com/en-gb/109036 | https://support.apple.com/en-gb/125094 | https://support.apple.com/en-gb/109015 | https://support.apple.com/en-gb/guide/watch/apd54d0a51fb/watchos | https://www.apple.com/uk/watch/cellular/ | https://www.betterroaming.com/watches/apple-watch-family-united-kingdom/

### Garmin Bounce 2, turquoise SKU 010-03399-02, Garmin Jr., UK

- Currys direct listings surfaced both £259.99 and £199 promotional pricing for turquoise. Current single price and availability are unconfirmed. Garmin documents a required active Garmin LTE subscription and LTE coverage for away-from-phone messaging. Current UK tariff amount and address-level coverage remain unconfirmed.
- Adult pairs the watch using Garmin Jr. and a Garmin Connect account. The app is available for iPhone and Android. Confirm app compatibility on the actual adult device. Garmin describes approved Garmin Jr. contacts and family group messages for its messaging path. Contacts use the supported Garmin ecosystem. School mode and sleep do-not-disturb are available. A hard daily device-use cap and ordinary calls to arbitrary phone numbers are unconfirmed.
- Setup source is Garmin's Bounce 2 pairing guide.
- Sources: https://www.garmin.com/en-GB/p/pn/010-03399-02/ | https://www.currys.co.uk/smart-tech/smart-watches-and-fitness/smart-watches/kids-smart-watches?productsPerPage=3 | https://www8.garmin.com/manuals/webhelp/GUID-ED045F09-4EC3-41F5-AAAC-42B3A3836894/EN-GB/Bounce_2_OM_EN-US.pdf | https://apps.apple.com/gb/app/garmin-jr/id1122225740 | https://play.google.com/store/apps/details?id=com.garmin.android.apps.vivokid | https://www.garmin.com/en-GB/connectivity/smartwatches/bounce-2/coverage/

## Consoles for two people playing together on the same console

Compare the UK Bedrock release of Minecraft as a shared example. A compatible display and controls for both players are assumed when describing play. Assess incremental upfront cost only after accounting for anything the household must acquire. Keep online multiplayer subscriptions outside this same-console purpose.

### Nintendo Switch OLED, 64 GB White, original Switch family

- Nintendo UK listed Minecraft for original Switch at £19.99 and documents one-to-four players on a single system. Confirm game availability and the exact controllers and display needed for this title before quoting a full setup cost. Current standalone console price and stock remain unconfirmed. The original £309.99 launch listing and current out-of-stock bundles are separate observations.
- Nintendo's adult app supports iOS and Android and can set play time limits with an optional suspend-software setting. Console restrictions generally apply to all users of that system. Nintendo eShop restrictions are separately managed through Nintendo Account. In-game communication restrictions are scoped and game-dependent. Do not infer a cross-service communication shutoff or a per-child console-wide cap.
- Setup source is Nintendo's original Switch parental controls guide.
- Sources: https://www.nintendo.com/en-gb/Hardware/Nintendo-Switch-Family/Nintendo-Switch-OLED-Model/Nintendo-Switch-OLED-Model-2000984.html | https://www.nintendo.com/en-gb/Games/Nintendo-Switch-games/Minecraft-1386505.html | https://www.nintendo.com/en-gb/Games/Nintendo-eShop/Best-sellers/Nintendo-eShop-charts-1396788.html | https://www.nintendo.com/en-gb/News/2021/September/Pre-order-Nintendo-Switch-OLED-Model-now-on-Nintendo-Store--2040089.html | https://www.nintendo.com/en-gb/Support/Parental-Controls/How-to-Set-Up-Adjust-or-Remove-Parental-Controls-on-Nintendo-Switch-1494771.html | https://www.nintendo.com/en-gb/Support/Parental-Controls/Can-I-Set-Parental-Controls-for-Each-Player-on-Nintendo-Switch-1498001.html | https://www.nintendo.com/en-gb/Support/Parental-Controls/What-Can-I-Block-With-Parental-Controls-on-Nintendo-Switch-1500177.html

### Xbox Series S, 512 GB White, digital-only

- AO's Xbox Series S category showed £429 for the White 512 GB unit. Microsoft's Minecraft listing documents same-console split screen for two to four players on Series X|S. Confirm the current standalone digital game price, second controller and full setup cost. Online console multiplayer is listed separately with a Game Pass requirement for this title.
- The Xbox Family Settings app supports adult iOS and Android. Console limits require a signed-in child account in the Microsoft family group using its Xbox profile. Screen time, spending approval, multiplayer and communication settings are documented. Their scope is the supported account or service. A global shutoff across every game or outside channel remains unconfirmed.
- Setup source is Xbox Family Settings.
- Sources: https://www.xbox.com/en-GB/consoles/xbox-series-s | https://ao.com/l/consoles-xbox-2154-xbox_series_s/1-6-20-219/107-290-291/ | https://ao.com/product/ep210058-xbox-game-console-white-104388-291.aspx | https://www.xbox.com/en-GB/games/store/minecraft/9MVXMVT8ZKWC/0010/9QJ0XHPXR66C | https://www.xbox.com/en-GB/apps/family-settings-app

## Apps for joining known players online from iPhone

Scope to compatible already-owned iPhones, separate players with the necessary accounts and internet access. App prices below are per download as listed, before any additional equipment, data service or optional purchases.

### Roblox on iPhone, UK App Store

- UK App Store lists the download as free with in-app purchases and iOS 14+ on the observed listing. Play depends on the experience and applicable Roblox account, age and join settings. For a shared free experience, optional purchases remain separate.
- Linked parent account with parent privileges and Roblox eligibility requirements. Roblox documents time limits and separate communication controls, including experience chat, friends chat and Quick Words. Age checks, age band, experience rules and regional rollout affect the options. Trusted friends do not establish an approved-only player list or universal communications off. Verify the exact UK child account/experience and accessible chat surfaces before asserting either.
- Setup source is Roblox Parental Controls Overview.
- Sources: https://apps.apple.com/gb/app/roblox/id431946152 | https://en.help.roblox.com/hc/en-us/articles/30428310121620-Parental-Controls-Overview | https://en.help.roblox.com/hc/en-us/articles/203314220-How-to-follow-or-join-another-player-in-experiences | https://en.help.roblox.com/hc/en-us/articles/37725513985812-Unlocking-trusted-friends

### Minecraft Bedrock on iPhone, UK App Store

- UK App Store lists £6.99 with in-app purchases and iOS 14+ on the observed listing. The compared use is joining a friend's online world while both are online, with the Microsoft accounts, friend relationship and child multiplayer permissions Minecraft documents. A paid Realm is a separate hosting option.
- A parent can manage documented Minecraft social settings for the child Microsoft account through Xbox Family Settings on supported adult iOS or Android. Microsoft's console app screen-time controls do not establish Minecraft time limits on iPhone. A separate iPhone Screen Time configuration is possible and needs its own evidence scope. Microsoft and game communication controls apply to supported surfaces and settings, with public servers and other channels outside this comparison.
- Setup sources are Minecraft's child social settings and friend-world instructions.
- Sources: https://apps.apple.com/gb/app/minecraft-dream-it-build-it/id479516143 | https://help.minecraft.net/hc/en-us/articles/24122512131213 | https://help.minecraft.net/hc/en-us/articles/35189478489485 | https://help.minecraft.net/hc/en-us/articles/19615552270221-Accounts-Required-to-Play-Minecraft | https://www.xbox.com/en-GB/apps/family-settings-app

## Readiness for the chooser

These are eight sourced configurations, with a shared purpose inside each category. The descriptions above are factual research for review. Before a real result can match, prove all required criteria for one configuration, including the household's device/account prerequisites, total incremental cost and exact controls. A product that supports one communication channel or Schooltime may have other capabilities or gaps. Preserve separate unknowns for mixed price observations, third-party communication, unresolved tariffs or device/account conditions.

Resolve the evidence gaps against the chosen scopes, agree actual budget bands and editorial decision language, then review the exact catalogue content under the applicable project gates. Avoid a uniform expiry period and recheck source-dependent claims before use. This research does not update the customer catalogue, recommendation logic or fixture coverage.
