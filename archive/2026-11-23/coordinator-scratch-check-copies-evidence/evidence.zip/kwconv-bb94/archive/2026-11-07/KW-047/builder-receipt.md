# KW-047 builder receipt — 7 November 2026

Author evidence only. Candidate ready for an independent check; no acceptance, integration or release claim.

- Actual UUID: `01a1b528-91cd-7f52-90d9-c1f68d2ba4ed` (both session and thread environment).
- Actual outer claim: `claim-45573-c9e0a4d046be4346890b280421ff84b7`; exact leaf `KW-047`, Gmail local CLI, `gpt-6.1-sol` medium. Read the inherited claim and its child boundary; no nested admission, fallback or worker.
- Outer launch prompt SHA-256: `a287e4bb306d5d3a3d52a642afbda3cc34c703be0171e9b6d67b7fe3c8e0ccb9`. Current build and simplicity rule bytes matched the issued hashes.
- CWD and sole workspace root: `/Users/benharwood/Claude/Projects/AI Safety Build`. HEAD remained `f91b58b6ab8d7dc05e1c2b9a0517747c5ff60867`. The four registered input file hashes matched before work. Only the six candidate files below and this receipt were written; existing unregistered and dirty files were left in place.

## Candidate SHA-256

```text
38638388a191ea19f17906a3401b2d6edf345c2ded9bb300ed5ebe9ddb785a99  components/GuidanceAudio.tsx
a5e4f4417ca23e33a811aa58b96115515594648e5c093aa6831ac4f254e4b354  lib/media-manifest.ts
79edeccdd25257ff4bee9253d279a4b5aa9793996a0599b4ef104930e3247b69  app/library/downloads/page.tsx
d2ebbd022b15b38e1f3cd119d2fe0b0355a968415ca3d95809c561eae512b19e  tests/media-manifest.test.ts
51f745cdf8c81a7399a795f4e08b780bfdf16ef41d7074dc709132ad2e080b1b  tests/guidance-audio.test.tsx
0adb3563e2f16da9d8091cff0791ddaec4c106409c92ef08e89294e3df6fec07  tests/fixtures/guidance-audio-preview.tsx
```

## Checks and limits

- `rg` across app, components, lib, tests and public found no existing equivalent audio player or offline pack; no local recording files surfaced. Reused the existing library gate and route layout, KW-018 exact review/currentness, KW-044 source locale and repository content hashing. The existing content loader is MDX guidance, not approved audio evidence.
- `node_modules/.bin/vitest --version` and `node_modules/.bin/vitest run --help`: Vitest 2.1.9 supports explicit worker bounds. All runs set `CI=1` and `--no-cache --minWorkers=1 --maxWorkers=1`. The Vite CJS deprecation warning was non-fatal.
- Initial `CI=1 node_modules/.bin/vitest run --no-cache --minWorkers=1 --maxWorkers=1 tests/media-manifest.test.ts tests/guidance-audio.test.tsx tests/derived-assets.test.ts tests/locales.test.tsx tests/library-access.test.ts`: **77 passed** across five files.
- Initial `node_modules/.bin/tsc --noEmit --incremental false`: **exit 2**, TS2322 at lines 48 and 49 of the UI test. The mock setters used narrow boolean/string parameter types where generic React dispatch expects unknown. Fixed by narrowing inside the mock callbacks.
- After adding retarget and authorized rendering coverage and returning keyboard focus to the player after retry: `CI=1 node_modules/.bin/vitest run --no-cache --minWorkers=1 --maxWorkers=1 tests/media-manifest.test.ts tests/guidance-audio.test.tsx` **38 passed**; TypeScript passed. Repeated only those checks after adding the source version/date to both saved filenames: **38 passed**, TypeScript **exit 0**. The unchanged dependency and guard suites contributed 42 passing tests in the initial run (80 unique tests across final changed tests and unchanged suites).
- The browser steps below are prepared, unexecuted worker instructions for the independent checker. No browser server, Next dev server, full build, full suite or background process was started. No commit, push, deploy, provider/account operation, spend, sharing, publication, queue or handoff write.

The only new evidence format is the tuple in the projector: asset identity/version, audience, locale, type, exact source ID/hash/version and date, review date, audio digest and transcript text. It pairs the recording and transcript in the existing review check; it does not establish factual transcript accuracy or create approval. WAV only, up to 256 KiB; UTF-8 plain text up to 16 KiB. Base64 is a deliberate small-payload tradeoff. There is no file lookup, cache, remote URL or user-specific input. The two saves carry the same version/date and artifact suffix. Withdrawn or stale records expose only a recheck/replacement state; previously saved files cannot be recalled.

## Coordinator browser check

Run from the repository root with installed esbuild. The first bundle projects the synthetic row in Node and writes the projected result into the temporary HTML. The browser bundle mounts the actual player; it never runs the projector. The HTML and script stay in a temporary directory and the server binds only to loopback.

```sh
KW047_PREVIEW="$(mktemp -d /tmp/kw047-preview.XXXXXX)"
node_modules/.bin/esbuild --bundle --platform=node --loader=ts --sourcefile=project-fixture.ts --outfile="$KW047_PREVIEW/project.cjs" <<'TS'
import { createHash } from "node:crypto";
import { projectMedia } from "./lib/media-manifest";
import { syntheticMedia } from "./tests/fixtures/guidance-audio-preview";
const result = projectMedia(syntheticMedia(bytes => createHash("sha256").update(bytes).digest("hex")));
if (result.state !== "available") throw new Error("Synthetic audio did not pass projection");
const json = JSON.stringify(result).replace(/</g, "\\u003c");
process.stdout.write(`<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Synthetic audio fixture</title><div id="preview"></div><script id="media" type="application/json">${json}</script><script defer src="preview.js"></script></html>`);
TS
node "$KW047_PREVIEW/project.cjs" > "$KW047_PREVIEW/index.html"
node_modules/.bin/esbuild --bundle --platform=browser --loader=ts --sourcefile=mount-fixture.ts --outfile="$KW047_PREVIEW/preview.js" <<'TS'
import { mountGuidancePreview } from "./tests/fixtures/guidance-audio-preview";
mountGuidancePreview();
TS
rm "$KW047_PREVIEW/project.cjs"
python3 -m http.server 8047 --bind 127.0.0.1 --directory "$KW047_PREVIEW"
```

1. Open `http://127.0.0.1:8047/`. Check the synthetic label and descriptive transcript. Confirm silence on load; use native Play and Pause, then choose 0.75× and 1.5× with the labelled speed select. Check that the element's `playbackRate` changes and that controls are keyboard reachable at a narrow viewport.
2. To trigger a real decode failure, run this in the browser console: `const player = document.querySelector("audio"); player.src = "data:audio/wav;base64,AAAA"; player.load(); void player.play().catch(() => {});` Confirm the error message and that the transcript remains visible. Use **Retry audio**, confirm focus returns to the player, press Play, and confirm the tone plays at the chosen rate.
3. Use both save links. Stop the foreground server with Ctrl-C, then open the saved WAV and TXT directly from the downloads folder. Verify the tone plays and the TXT matches the displayed description; the two files share the version/date and artifact suffix. Delete the temporary preview and synthetic downloads after checking.

## Remaining gates

Independent review of the exact six files and browser/offline verification are pending. KW-046 still needs an agreed real generic media set, approved source scripts and actual recordings, matching transcripts/captions, exact source/version records, and genuine independent editorial/listening review and publication eligibility (G-MEDIA/G-REVIEW). The product catalogue has no approved entries. Real language choice and reviewed translations remain with KW-045.
