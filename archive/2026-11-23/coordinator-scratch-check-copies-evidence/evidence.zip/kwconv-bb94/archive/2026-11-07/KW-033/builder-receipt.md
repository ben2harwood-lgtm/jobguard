# KW-033a builder receipt

7 November 2026. Checkpoint a implemented and locally checked. This is author evidence for independent review of the exact candidate before coordinator acceptance.

## Managed execution

- Actual session UUID `01a1b522-8d21-7ea0-b363-6bb824935c3d` from `CODEX_SESSION_ID` and `CODEX_THREAD_ID`, matching the coordinator’s active lease.
- Inherited claim `claim-28741-8e36d75724744513884a047d4e144b74`. Its recorded child boundary binds the fresh exact leaf `KW-033`, local Gmail role `gmail-codex`, route `codex-a` under `/Users/benharwood/.codex-ben2`, and the registered `gpt-6.1-sol` medium claim. CWD and sole root are `/Users/benharwood/Claude/Projects/AI Safety Build`, with no added directories.
- Boundary prompt SHA-256 `e5fe00a9cad8e57925cb72e732ce354903bf7c53fe892c2cd157ea8acdc7c884`. BUILD_RULES and SIMPLICITY_RULE SHA-256 matched the boundary’s `87a5b4d2e40b13143b99f06ac8443eb9311327870c006e24313fc229cd917b12` and `6951013f7f7c750002f3096a4e9d1c7a467fabe0a4a6b26972169f2493ffeee6` respectively. The inherited boundary was read directly.
- HEAD before and after `f91b58b6ab8d7dc05e1c2b9a0517747c5ff60867`. Registered source pin `working-tree-sha256:91f21337eacb12e73bd90d0b9b2be7c548099e95041ddbbc94f8b86e2d125fe5`. The route and four pinned source dependencies matched their individual starting hashes.

## Candidate hashes

| Path | SHA-256 |
| --- | --- |
| `app/library/platforms/[slug]/page.tsx` | `f2e0fb501b45f366156ac80117dd919e257a209eadbc26f2ffb0b9bdab551c69` |
| `tests/troubleshooting.test.tsx` | `d431b845e49dd84313adaa10a71970e1403b0134a03372ed1ed9194cd51d0159` |

The route retains guard → guide lookup → notFound and passes the original document and labels to ContentArticle. For the two supported slugs, a native disclosure sits above the existing article. Four labelled outcomes give distinct next steps. The only platform-specific logic selects the help URL and the version/account wording. This uses two code files with no additional component, data registry, client state, telemetry, form, content rewrite or CSS file. The plain outbound links suppress referrer information.

## Checks and limits

- `./node_modules/.bin/vitest --version` reported 2.1.9. Its `--help --poolOptions` confirmed explicit thread limits.
- `CI=1 ./node_modules/.bin/vitest run --no-cache --pool=threads --poolOptions.threads.maxThreads=1 --poolOptions.threads.minThreads=1 tests/troubleshooting.test.tsx tests/library-access.test.ts` exited 0 on the first run. All 17 tests passed across two files, with the existing Vite CJS deprecation warning. The new tests exercise the actual route with the real catalogue lookup behind a spy, mocked guard/notFound and a stubbed article. They check the native markup, four outcomes, both exact URLs, original article props, another existing guide, and denial/missing-guide order. The existing authorization tests were left as supplied.
- `npm run typecheck -- --incremental false` exited 0 on the first run. `git diff --check -- 'app/library/platforms/[slug]/page.tsx'` exited 0. The post-check hashes of the loader, ContentArticle and both guide files matched the source pins.
- `sysctl -n vm.loadavg` was denied by the sandbox. `uptime` returned load averages of 15.03, 10.22 and 6.61. Only the short targeted one-thread test and TypeScript checks ran. No heavy build or browser suite ran.
- Public support lookup returned Google’s article directly. Apple direct retrieval returned HTTP 429, and search returned the exact Apple UK support article. The coordinator supplied both URLs as verified help sources. This lookup and the tests provide no device, account or control verification.
- Scope was limited to the two guide IDs and checkpoint a. No actual device or keyboard-browser run, recording, provider account operation, commit, publication, queue/handoff edit, independent review or acceptance was performed by this session.

## Outstanding evidence for KW-033b and KW-046

Use demonstration accounts and synthetic screens. Each row needs the exact device family/model, OS build and app version where applicable, demo account role/type, region, actual test date, exact written guide revision, control and observed result, supporting help URL, and recording or precise gap. Record confirmed steps, changed paths and unavailable controls separately. The matrix below is work to verify.

| Guide and proposed demo coverage | Observations to capture | Recording gap |
| --- | --- | --- |
| Apple Screen Time on iPhone and iPad | Record parent and child device versions. Check Family Sharing, Screen Time passcode, Downtime, App Limits, Communication Limits and Safety, content/privacy and location restrictions, and Ask to Buy. Include a differing supported version, an unavailable control and any account/region boundary declared in scope. | Match the Apple segment of `28_Platform_Video_Scripts.md` to the observed steps and exact written guide. Record approved configurations with captions and transcript. |
| Google Family Link for supervised Android and Chromebook | Record parent app version and supervised Android/ChromeOS versions. Check daily limits and schedules, Downtime and School time, app management, filters, approved contacts and purchase approval per device. Record any unsupported control, supervised vs school-managed account boundary, region boundary and layout mismatch in the declared scope. | Match the Family Link segment of `28_Platform_Video_Scripts.md` to the observed steps and exact written guide. Separate device-specific steps in the captioned recording and transcript. |
| Both guarded guide routes | Check keyboard focus, activation, link traversal and reading order in an authorised browser session. Confirm each outcome gives a clear next step when a demo screen differs. | Include a cue to the written fallback in the recordings. Link each recording to the exact tested guide revision and configuration. |
| Broader U05 launch set | Agree the remaining guide/control and configuration inventory. Mark unsupported and untested combinations, and recheck any changed guide or interface before retaining current-verification wording. | Inventory exact script/guide pairs, caption and transcript status, and missing or outdated recordings for KW-046. |

Next action is independent review of the two candidate hashes above. Physical-device evidence, declared launch coverage and recordings remain outstanding.
