# KW-044 builder receipt — 7 November 2026

Author evidence only. Candidate implemented and locally checked; independent review of the exact candidate and coordinator acceptance are pending.

- Managed Gmail local session: `01a1b522-528c-7e70-82a7-e87d4173f6e3` (both `CODEX_SESSION_ID` and `CODEX_THREAD_ID`, corroborated by queue revision 45).
- Outer claim: `claim-28369-1f697c5775ff42df9634e164d4429f1c`; exact leaf `KW-044`, `gmail-codex` / `codex-a`, GPT-6.1-sol medium. The supplied claim's child boundary binds fresh launch, exact workspace cwd, no added directories and prompt SHA-256 `6de092522048bd0c1fc6a6ba600c9db614ad031b3051ecf0dddb79186c804410`. No nested admission, alternate route or extra worker was used.
- Branch `feat/milestone-2`, HEAD before and after `f91b58b6ab8d7dc05e1c2b9a0517747c5ff60867`. Issued source pin `working-tree-sha256:266cd5e99446ea0925c39862611f6e017f60c7f2d7c92a699d361535d64e1586`. The three registered dependency hashes matched before and after. Existing dirty files were left in place. No queue, handoff, content or route edits.
- Claim reserved at 08:31:27 UTC; first targeted verification finished around 08:33:47 UTC. Roughly two minutes of author reading and implementation followed by under three seconds of parallel local checks; independent checking time and external waits are unmeasured.

| Candidate path | SHA-256 |
| --- | --- |
| `lib/locales.ts` | `b2c7b2736b0658aa1d41f5f324c7e062454415d5b576e8d6cceec9fd915af8b5` |
| `components/LanguageChoice.tsx` | `2ef3c8e4b07bdb1438a552b20bb389e624944fc7d8042840dbb9de399455fce5` |
| `tests/locales.test.tsx` | `3cff95d9861d9203d111c7799559171f3221fec9a436f46a9401a5414dcb05b4` |

The resolver reads the supplied current MDX using the same gray-matter body convention as the existing loader. It hashes the complete current UTF-8 source and delegates exact source and derivative review, publication eligibility and pin currentness to KW-018's `assetCurrentness`. The fixture artifact's canonical JSON tuple binds the exact rendered text to its asset identity and version, requested locale, and source identity, hash and version. Reassigning the evidence to another source or locale cannot reuse the original review hash. This is byte binding against caller-supplied evidence; the resolver does not authenticate editorial records, establish reviewer competence, or load or publish a translation.

The chooser invokes the resolver for both options on the server. Native radios and existing Tailwind peer selectors switch between the two vetted panels without a route, client state or persistence. This adds one binding format and a dependency on the existing utilities for panel visibility. The test locale `und-x-fixture` and its content are synthetic; the positive-path review/publication fields are made-up test inputs. Available source text is shown on translation fallback; missing source gets an explicit notice. No real language selection, content quota, translation, provider/account operation, spend, sharing or publication occurred.

Checks from the workspace:

- `node_modules/.bin/vitest --version` and `node_modules/.bin/vitest --help --poolOptions`: installed Vitest 2.1.9, explicit one-thread controls confirmed.
- `CI=1 node_modules/.bin/vitest run --no-cache --pool=threads --poolOptions.threads.maxThreads=1 --poolOptions.threads.minThreads=1 tests/locales.test.tsx tests/derived-assets.test.ts tests/content-versions.test.ts`: 33/33 passed (18 new, 15 existing). Existing Vite CJS API deprecation warning.
- `npm run typecheck -- --incremental false`: passed with no incremental cache write.
- Inline Node/PostCSS check: `postcss([tailwind('./tailwind.config.ts')]).process('@tailwind utilities;', { from: undefined })`; assertions for both named checked radio sibling selectors and `.hidden { display: none }` passed in memory.
- `git diff --no-index --check /dev/null <candidate-path>` produced no whitespace diagnostics for each candidate. Exit 1 reflects the new files differing from the empty comparison; an initial shell loop stopped at that status and the remaining paths were checked separately. A read-only exploratory listing also found no top-level full-steam admission directory; the supplied claim path was present and used as evidence. No behavioral, CSS, or type check failed.

The next action is independent review of these hashes before coordinator acceptance. The checks exercise React composition and generated CSS, with no browser, assistive technology or print run. KW-045 still owns actual demand-based language and content selection, competent exact-version review, navigation and print evidence, and the G-LANGUAGES / G-REVIEW gates.
