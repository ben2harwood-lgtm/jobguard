# Sample Household Online-Safety Report

**Worked example — fictional household. Use as the production model and as a marketing sample.**
*Prepared for a parent of a 13–14-year-old · Sample reference SR-001 · Based on current UK guidance, June 2026*

> This is an educational readiness report. It helps you see where your household has the most room to reduce online exposure and what to do first. It is **not** a safeguarding assessment, a prediction of harm, or a guarantee of safety, and it does not monitor your child. If something is happening **right now**, go straight to the **Emergency signpost** (section 8).

---

## 1. Your summary

Your household is in reasonably good shape on the basics — your daughter's accounts are mostly private and you've had some safety conversations already, which puts you ahead of many families. The clearest opportunity is around **two newer risks you flagged as "not yet discussed": sextortion and fake AI-generated images.** These are exactly the areas where a short, calm conversation now makes the biggest difference, because they target this age group and move fast. There's also a quick technical win available in **device settings** that will take you about ten minutes. Nothing here suggests anything is wrong — this is about closing a few gaps before they matter.

---

## 2. Your top three priority actions

**1. Have the "if you're ever threatened, I will help" conversation — this week.**
*Why:* Financially-motivated sextortion overwhelmingly targets teenagers, and the single thing that protects a child is knowing they can come to you without being in trouble. Your answers suggest this hasn't been discussed yet.
*Do this:* Say, in your own words: *"If anyone online ever pressures you for a photo, or threatens to share one unless you pay — stop talking to them, don't pay, don't delete anything, and tell me. You will not be in trouble, and I will help you sort it."* That's the whole conversation.
*Time:* 5 minutes. (Full script in your Plan if you'd like a longer version.)

**2. Talk about fake/AI "nudify" images — and that making them is a crime.**
*Why:* Apps can now turn an ordinary clothed photo into a fake nude. Teens can be targeted without ever sending anything, and creating such an image of a classmate is a criminal offence. Naming it removes its power and tells your daughter you're someone she can report this to.
*Do this:* Explain that any photo can be altered, that it's never the victim's fault, and that if it ever happens to her or a friend, there's a route to get images removed (Report Remove — in section 8).
*Time:* 5 minutes.

**3. Check and lock the device settings — ten-minute job.**
*Why:* You weren't sure who set up the privacy settings, and the phone is used in the bedroom overnight. Tightening defaults is the cheapest exposure reduction available.
*Do this:* Together, check the three things in section 6, and agree the phone charges outside the bedroom overnight.
*Time:* 10 minutes.

---

## 3. Your household exposure map

| Domain | Exposure | Confidence | Note |
|---|---|---|---|
| Device & settings | **Higher** | Medium | Own phone, used in bedroom overnight, settings not confirmed |
| Contact & platform | **Moderate** | High | Snapchat + WhatsApp + some gaming chat; accounts mostly private |
| Image & location | **Moderate** | Medium | Location not shared publicly; image-permanence understanding unclear |
| Threat awareness | **Higher** | High | Sextortion, AI images, scams not yet discussed |
| AI exposure | **Moderate** | Low | Uses AI for schoolwork; companion-app use unknown ("Don't know") |
| Family readiness | **Lower** | High | Informal rules, good parent–child trust, child likely to disclose |

*Low confidence on AI exposure means we couldn't assess it well — finding out which AI apps she uses is one of your "this month" actions.*

---

## 4. Platform-specific notes (only the platforms she uses)

**Snapchat** — highest-priority platform for this age group. Turn off **"Quick Add"** (stops strangers being suggested), check **Location/Snap Map is set to "Ghost Mode"**, and make sure the contact list is friends-only. *How-to:* Snapchat Family Centre / privacy settings.

**WhatsApp** — set **"Who can see my profile photo / last seen / groups"** to *My Contacts*, and turn on **two-step verification**. Talk about not joining group chats with people she doesn't know.

**Gaming chat** — agree that people met in games stay in games: no moving to other apps, no sharing socials. "Move to another app" is the key warning sign to name.

---

## 5. The conversation to have this week

You only need one this week — the sextortion conversation in action #1. Keep it short, calm, and end on *"you can always come to me."* Don't try to cover everything at once; a single clear message lands better than a lecture. The Plan spaces the rest out over the coming weeks.

---

## 6. Settings & account checks (your checklist)

- [ ] Snapchat: Quick Add **off**, Snap Map **Ghost Mode**, friends-only.
- [ ] WhatsApp: profile/last-seen to *My Contacts*, two-step verification **on**.
- [ ] Phone: screen-time/content settings reviewed together; phone charges **outside the bedroom** overnight.
- [ ] Check (together, not secretly) which AI apps are installed.

---

## 7. Family-agreement recommendations (age 13–14)

Suggested, to adapt together — agreements work better than rules imposed top-down:

1. Phones charge downstairs overnight.
2. People met in games/online stay online — no moving to private apps, no meeting up.
3. "Tell me anything, no judgement" — she won't lose her phone for being honest about something scary.
4. New apps get a quick chat before download.

*(Editable family-agreement template is included with your Plan.)*

---

## 8. Emergency signpost — who to contact right now

*If a child is in immediate danger, call **999**.* This page is included in every report. Full version: `03_Emergency_Signpost_Screen.md`.

| If… | Contact |
|---|---|
| Immediate danger / risk to life | **999** |
| Sextortion or blackmail in progress | Stop, don't pay, don't delete · tell a trusted adult · **CEOP** (ceop.police.uk/ceop-reporting) · 101, or 999 if at immediate risk |
| A nude image of an under-18 (real or fake) shared or threatened | **Report Remove** — childline.org.uk/remove |
| Suspected grooming / an adult contacting a child sexually | **CEOP** (ceop.police.uk/ceop-reporting) |
| Scam or money lost | **Action Fraud** 0300 123 2040 / reportfraud.police.uk · contact the bank |
| Your child is distressed or at risk of self-harm | **Childline** 0800 1111 · **Shout** text SHOUT to 85258 · 999 if life at risk |
| Worried about a child generally | **NSPCC** 0808 800 5000 |

---

## 9. What not to panic about

- **AI for schoolwork is fine.** Using ChatGPT-style tools for homework help is normal and low-risk — that's not the AI risk to worry about (companion/"friend" apps are).
- **Your daughter is likely to tell you.** Your answers suggest strong trust at home. That is the single biggest protective factor there is — more than any setting.
- **You're not behind.** You'd already had several safety conversations before this report. This is fine-tuning, not catching up.

---

## 10. What to revisit next month

These are the medium-priority gaps — worth doing, just not this week:

- Confirm which AI apps she uses, and try them yourself (action from the AI domain).
- Have the **scams** conversation (fake tickets, jobs that ask for money upfront, "money-mule" account use).
- Have the **AI-companion** conversation (an AI is not a real friend or a therapist; for anything serious, talk to a person or a helpline).
- Move the informal family rules to a short written family agreement.

---

## 11. Keep going with the Family Safety Plan

Your report surfaced **four medium-priority actions** above. The **AI Safety Planner (Family Safety Plan)** walks you through them one at a time — a single short action every couple of weeks, ready-made conversation scripts, an editable family agreement, and a monthly briefing on what's actually changed in the risks facing teenagers (so you hear it from us, calmly, rather than from a scary headline). It's automated, low-cost, and you can cancel anytime.

*£7/month or £70/year. It is education, planning and signposting — not monitoring, not crisis help, and not a replacement for the professionals in section 8.*

---

*This report is based on current public guidance from UK authorities including Ofcom, the NSPCC, CEOP/National Crime Agency, and the Internet Watch Foundation. It reflects your answers and current guidance as of June 2026; online risks change, which is what the monthly briefing is for.*
