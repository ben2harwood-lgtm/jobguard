# 106 — Naming Decision: Brainstorm, Screening & Recommendation

**Date:** 5 July 2026
**Status:** Decision document — supersedes the naming portions of 103 (§1 "Keepwise decided") pending Ben's sign-off
**Inputs:** Five independent lens reports (wise-family, orientation, calm-competence, descriptive-hybrid, coinage-wildcard), each with its own WebSearch + live-site collision screening; contradictions between lenses resolved with direct registrar (whois) lookups run on 5 July 2026.
**Scope:** Product name for the £49 one-off (+£29/yr) automated household system. Calm, premium, evidence-led. Not monitoring software; no safety guarantees; the claims lint applies to the name itself.

---

## 0. The headline, before anything else

**Keepwise is not ownable and should be retired.** This is not a taste judgement — it is registrar fact, confirmed independently by three of the five lenses and re-verified today:

- `keepwise.co.uk` — **registered by a third party on 31 May 2026** and serving a live site (HTTP 200). Two lenses identified the occupant as connected to **keepwise.partners**, an active US accounting firm with explicitly political/religious branding ("compete with the woke tech giants — and build Christendom"). Whatever the occupant, the exact-match .co.uk is gone.
- `keepwise.com` — **registered since 2005** (whois-confirmed today; one lens reported it free — that report was wrong).
- **keepwise.ai** — live AI workflow-kits product. Same string, software space.
- The name sits **one keystroke from a wall of live "-wise" brands** in exactly our category: Kinwise, Staywise, Parentwise, Screenwise, Cyberwise, Nestwise, Hearthwise, SafeWise. A name that forces "no, the one with KEEP" at the school gate has already lost the school-gate test.

What Keepwise actually won in the 4-way brand-world test was the **calm-competent "-wise" tone**, not that specific string. The tone is portable. The string is spoken for.

---

## 1. Does the name need "online safety" in it?

**No — and it must not. Ownable name + plain descriptor tagline.** But the counter-case deserves a fair hearing first.

### The honest case FOR a descriptive name
1. **SEO / discoverability.** A worried parent Googles "online safety kids UK", not an invented word. A descriptive name matches search intent cold.
2. **Zero explanation cost.** "Online Safety Plan UK" tells the other parent what it is with no tagline needed.
3. **Trust-by-transparency.** In a fear category, plain words can read as more honest than a clever coinage.

### Why it loses anyway
1. **The descriptive real estate is already occupied — by charities and government.** Verified live: UK Safer Internet Centre, Internet Matters, UKCIS, Childnet, SWGfL, IWF, SafeWise, Safer Schools UK. A £49 commercial product wearing the same generic words competes on their turf, gets mistaken for a free charity resource, and never outranks them.
2. **Descriptive marks are legally weak.** UKIPO refuses or heavily restricts descriptive marks absent acquired distinctiveness. You would spend money building equity you cannot defend. Invented/arbitrary marks register cleanly and are enforceable.
3. **It breaks our own claims philosophy.** The build has a strict claims lint that bans "keeps kids safe". "Safety" *in the name* is the same implied promise, baked in permanently, unremovable by any disclaimer — the SafeKid pattern we explicitly reject. Keeping "safety" out of the name is the only *consistent* position.
4. **It fails the stretch requirement.** AI-readiness is already on the roadmap and does not fit under "online safety". A descriptive name dates the moment the roadmap moves.

### How the category leaders resolve exactly this tension (verified)
- **Bark** — arbitrary word → "Parental controls for families."
- **Qustodio** — invented word → "Parental control and digital wellbeing software."
- **Aura** — arbitrary word → "All-in-one family digital safety platform."

The **name** carries tone, equity, trademark and stretch. The **descriptor** carries SEO and meaning, and can be rewritten freely as scope grows. The descriptor *may* contain the words "online safety" — naming the category is description, not a guarantee, and it sits in editable copy the lint can police. The name cannot be edited later; the descriptor can.

---

## 2. Ben's three: Get Wise / Stay Wise / Be Wise

Each screened explicitly. All three fail.

| Name | Verdict | Why |
|---|---|---|
| **Stay Wise** | **DEAD — catastrophic collision.** | `staywise.co.uk` is the **National Fire Chiefs Council's child-safety education platform** (fire/police/RNLI curriculum resources, ages 3–18). Same country, same audience, same mission-adjacent space, exact domain. Unusable — even as a tagline endline it invites confusion with a live UK child-safety brand. |
| **Get Wise** | **DEAD.** | `getwise.org` (education) and `getwise.uk` (digital agency) both live. Beyond collisions: a generic imperative idiom — unownable as a bare phrase at UKIPO, and "get wise, parents" reads faintly confrontational/promotional, off the calm-premium tone. |
| **Be Wise** | **DEAD/weak.** | Bewise was a well-known defunct UK discount-clothing chain (folded into Store Twenty One) — residual recognition in exactly our buyer demographic. Also the vaguest and most preachy of the three, and unownable as an idiom. |

**Broader finding:** the "-wise" vein is the most collision-dense root in the entire category. Eleven "-wise" names were screened across the lenses; every good one is taken by a live UK operator in an adjacent lane (see kill list, §8). Even the two coinages that initially screened clear — Tendwise and Steadwise — turn out compromised at the registrar: `tendwise.com` registered since 2005 and **`tendwise.co.uk` registered on 10 June 2026** (three weeks ago); `steadwise.com` resolves and a Steadwise Solutions Ltd exists. **Recommendation: retire the "-wise" family entirely.** Its tested equity is tone, and tone travels.

---

## 3. The scored shortlist

Top 8 across all five lenses, scored 1–5 on the quality bar. Keepwise scored on the same matrix, as required — it does not win.

| # | Name | School-gate | Ownability | Claims-safe | Tone | Stretch | **Total /25** | Collision verdict | Domain position (registrar-checked 5 Jul 2026 where noted) |
|---|---|---|---|---|---|---|---|---|---|
| 1 | **Bearings** | 4 | 4 | 5 | 4 | 5 | **22** | **CLEAR in-category** — only industrial bearings + a dormant "Bearing Software Ltd"; no parenting/safety/education product anywhere | `bearings.co.uk` held since 2004 (industrial/generic). **`getbearings.co.uk` — UNREGISTERED, free to register today (whois-confirmed).** `getbearings.com` — HugeDomains for-sale page (acquirable, typically £1.5–3k). |
| 2 | **Steady** | 5 | 3 | 5 | 5 | 4 | **22** | **CLEAR in-category** — no parenting/safety product; German membership platform "Steady" exists in a different class | `steady.co.uk` registered Apr 2024, parked for sale (acquirable, not free). Dictionary word → TM needs stylisation/class care. `getsteady.co.uk` fallback. |
| 3 | **Soonly** | 4 | 5 | 5 | 3 | 5 | **22** | **CLEAR** — no app/company/TM collision found | **`soonly.co.uk` — UNREGISTERED (whois-confirmed).** Invented word, strongest TM position on the board. *But note: it already lost the 4-way brand-world test on tone/meaning — that is real evidence against it.* |
| 4 | **Keepden** | 4 | 4 | 5 | 4 | 4 | **21** | **CLEAR** — zero product/company/TM collisions in any search | **`keepden.co.uk` — UNREGISTERED (whois-confirmed).** `keepden.com` registered 22 Jan 2026 (generic placeholder page — no brand; possibly acquirable). "Den" = warm, unmistakably British family word. |
| 5 | **Threshold** | 3 | 3 | 5 | 4 | 4 | **19** | **CLEAR** — no parenting/safety product collision | Common English word: no exact domain, generic-mark risk at UKIPO. `thresholdapp.co.uk` / `getthreshold.co.uk` route. |
| 6 | **Setout** | 4 | 3 | 5 | 3 | 4 | **19** | **MINOR** — `setoutapp.com` is a live architecture site-work app (different buyer/class) | `trysetout.com` and `getsetout.com` reported available. Echoes the tested "Soonly" start-small territory with more grip. |
| 7 | **Tendwise** | 4 | 2 | 5 | 3 | 4 | **18** | **CLEAR in-category**, but sits in the saturated "-wise" field | **Registrar check overturns the lens claim of "both free": `tendwise.com` registered since 2005; `tendwise.co.uk` registered 10 Jun 2026.** "Tend" also tilts nursery for a 5–18 product. Out. |
| 8 | **Keepwise** (incumbent) | 3 | 1 | 4 | 4 | 4 | **16** | **FATAL on ownability** — keepwise.co.uk live third party (May 2026); keepwise.com held since 2005; keepwise.ai live; keepwise.partners active with politically charged branding | No clean domain exists. One keystroke from Kinwise/Staywise/Parentwise. "Keep" also carries a faint surveillance shade ("keeping tabs") — the monitoring frame we reject. |

**Scoring notes, honestly held:**
- The three-way tie at 22 is real, and the matrix alone does not pick a winner. The narrative does:
- **Bearings** leads on grounds the matrix cannot capture: it is a **pre-tested brand world** (it ran in the 4-way and built genuine equity), the orientation metaphor **is the product's actual job** ("a lost parent gets their bearings" — know what to check, set and say), a **full designed front-end already exists** in `brand-mockups/` (switching cost is unusually low), and its exact-match lockup `getbearings.co.uk` is free to register *today*.
- **Steady** is the warmest and most sayable name on the board and the strongest challenger — but its ownability is the weakest of the top four (dictionary word, domain is a purchase, TM needs care).
- **Soonly** scores well but already lost a live brand-world test to the "-wise" world; re-crowning a tested loser needs positive evidence we do not have.
- **Keepden** is the clean-sheet wildcard: zero collisions, free .co.uk, coined and registrable — but it is untested and "keep" + "den" wants a say-it-aloud check (does it read cosy-household or containment?).
- **Keepwise loses.** Its 4 on tone is genuine — the test proved the *world* works. Its 1 on ownability is disqualifying, and no amount of tone survives "our .co.uk belongs to a politically branded accounting firm".

### Top-name tagline pairings
- **Bearings** — *the household plan for your kids' online life.*
- **Steady** — *the calm household plan for your kids online.*
- **Keepden** — *one calm plan for your family's digital life.*
- **Soonly** — *turn the worry into a plan for your kids' online life.*
- **Threshold** — *know what to check, set and say, at every age.*
- **Setout** — *the calm first step for your kids' online life.*

---

## 4. Recommendation

**Lead: Bearings.** Pre-tested, genuinely clear in its category, claims-safe by construction, stretches effortlessly to AI-readiness and whole-household scope, brand system already half-built, and `getbearings.co.uk` is registrable this afternoon for the price of a sandwich. Its known weaknesses — slight abstractness, industrial homonym, bare `bearings.co.uk` unavailable — are all manageable with the descriptor and a `getbearings` lockup.

**Challengers for the head-to-head: Steady** (warmer, more sayable; budget for the domain purchase) **and Keepden** (cleanest ownership on the board; needs the say-it-aloud test).

**Retire:** Keepwise and the entire "-wise" construction. Do not carry "Stay Wise" even as an endline — StayWise is a live UK child-safety education brand.

Run the three-way test in §6. If forced to one word today: **Bearings**.

---

## 5. The tagline system

Pattern: **[Name] — [plain descriptor that does all the explaining].** The descriptor is where "online safety" is allowed to live — it names the category without promising an outcome, and it is editable copy under claims-lint control. Three candidate descriptors, usable with any name choice:

1. **"— the household plan for your kids' online life."** *(Primary. Category + audience + scope in nine words; "plan" not "protection".)*
2. **"— know what to check, set and say, from 5 to 18."** *(The emotional job verbatim; strongest at the anxious moment of purchase; carries the age range.)*
3. **"— online safety for your family, turned into one calm plan. Kept current."** *(SEO workhorse: contains the search phrase "online safety" while framing the product as a plan, not a shield; "kept current" sells the £29/yr.)*

Rule of thumb: descriptor 1 on the mark/logo lockup, descriptor 2 on the landing-page hero, descriptor 3 in metadata and ads.

---

## 6. The decision frame

### The cheap 48-hour test (do this before anything irreversible)
1. **School-gate test, live:** say **Bearings, Steady, Keepden** aloud to five real parents. Script: "Have you got ___?" / "I used ___ to sort the kids' phones." Watch for: mishearing, spelling requests, smirks, "the what?". One evening at pickup plus two texts.
2. **UKIPO register search, properly:** exact and near-match word marks in **classes 9 (software), 41 (education), 42 (SaaS), 45** (note: class 45 covers "safety" services — search it, do not file the word "safety"). Free at gov.uk; an hour's work. The lens screenings surface products and companies, **not pending trademark applications** — this step is not optional.
3. **Buy the domains BEFORE announcing anything.** Register `getbearings.co.uk` and `keepden.co.uk` *today* regardless (≈£10 each — cheap insurance either way; tendwise.co.uk being sniped on 10 June is a live demonstration of why). Get a HugeDomains quote for `getbearings.com` and the steady.co.uk asking price before falling in love. Whois "available" ≠ always buyable; confirm at checkout.

### The deadline anchor
The name must be locked by **Gate B0 submission** — it goes on legal documents as the trading name. Until then, **block authoring uses the brand token**, so M1 and all content work proceed name-agnostic. There is no reason to rush past the 48-hour test, and no reason to slip past B0.

### What changing costs — today vs after launch
| | **Today (pre-B0)** | **After launch** |
|---|---|---|
| Code/content | Find-and-replace one brand token | Same, plus cached/printed copies in the wild |
| Brand assets | Reconcile `brand-mockups/` copy (already a known task) | Full redesign + reprint of all printables customers hold |
| Domain/SEO | Register the right domain once | Domain migration, redirects, SEO equity reset, email deliverability re-warm |
| Legal | One name on B0 docs | Re-papering, TM refile, terms updates, customer notification |
| Trust | Zero customers affected | Paying subscribers asking "who are you now?" — the one cost a trust brand can't refund |

Renaming today is roughly a day of work. Renaming after launch is a quarter's distraction and a trust dent. That asymmetry is the whole argument for spending 48 careful hours now.

---

## 7. Reconciliation note (why some lens claims are overridden)

Where lenses disagreed, registrar lookups (5 Jul 2026) are authoritative:
- `keepwise.com`: one lens said free → **wrong**; registered since 2005.
- `tendwise.co.uk`/`.com`: one lens said both free → **wrong**; .com held since 2005, .co.uk registered 10 Jun 2026.
- `getbearings.com`: one lens said available → **overstated**; it is a HugeDomains for-sale asset (acquirable, not registrable). `getbearings.co.uk` however is genuinely unregistered.
- `keepden.com`: one lens said unregistered → **wrong**; registered 22 Jan 2026 (placeholder page). `keepden.co.uk` genuinely unregistered.
- `soonly.co.uk`: confirmed genuinely unregistered.

**Standing caveat:** everything here is search- and registrar-based, not a legal clearance. Before B0, commission (or run carefully) a UKIPO/EUIPO search in classes 9/41/42/45 on the winner, and complete domain purchases before any public use.

---

## 8. Kill list — screened DEAD; do not re-propose

**The "-wise" family (the vein is mined out):**
- **Staywise** — NFCC child-safety education platform, staywise.co.uk; exact space, exact audience.
- **Getwise** — getwise.org (education) + getwise.uk (agency) live.
- **Bewise** — defunct UK clothing chain; residual recognition; weak sound.
- **Kinwise** — live UK estate-planning platform ("Plan clearly. Protect wisely.") AND a live parenting app at kinwise.com.
- **Parentwise** — 4+ live UK/global operators.
- **Homewise** — 50-year UK retirement-property firm owns homewise.co.uk; plus US mortgage brand.
- **Housewise / Grow Wise** — live UK Ltds; Grow-wise is a child-development programme.
- **Streetwise** — multiple live UK youth charities; idiom means the opposite of home/calm.
- **Screenwise** — screenwiseapp.com (parental-controls guides) + Google Screenwise. Double collision.
- **Cyberwise** — cyberwise.org: digital literacy + AI safety + parenting. Direct competitor.
- **Netwise** — multiple active UK IT Ltds + former US TM.
- **Nestwise** — live "money app for busy moms".
- **Hearthwise** — live family-organiser app (hearthwise.xyz).
- **Everwise** — active UK Ltd + US L&D platform.
- **Wisehouse** — live consultancy + international college; clumsy to say.
- **Steadwise** — steadwise.com resolves + Steadwise Solutions Ltd (2023); .com gone.
- **Tendwise** — tendwise.com held since 2005; tendwise.co.uk registered 10 Jun 2026.
- **Keepwise** — see §0.

**Everything else screened dead:**
- **Roost** — roost.tools, live global online-safety nonprofit. Direct category collision.
- **Rello** — live AI family app.
- **Levelhead** (re-entrant) — registered US game TM + mindfulness app + UK Ltds.
- **Lodestar / Lodestone** — live US family-portal app; TM-crowded.
- **Waymark** — multiple UK software cos incl. a compliance firm.
- **Northmark** — live London digital agency.
- **Firmground** — Dutch accessibility software + US architecture firm.
- **Handrail** — .co.uk freshly taken; reads mobility-aid.
- **Kinhold** — live family-hub app (kinhold.app).
- **Goodnest** — NZ home-services app + US baby-care brand.
- **Truehold** — funded US real-estate company.
- **SafeHouse / any "Safe-" pattern** — violates our own claims lint in the name; plus anti-trafficking org collision.
- **NetNest** — reads as a Net Nanny cousin; dated.
- **Homescreen** — ubiquitous generic UI term; unsearchable, unregistrable.
- **Onhand** — live UK volunteering app. **Inhand** — live IoT firm holds inhand.co.uk.
- **Allsquare** — live golf platform. **Homefront** — military connotation + US franchise co.
- **Calmhouse** — therapy register we deliberately avoid. **Wardley** — owned by "Wardley Mapping" mindshare.
- **Grow Wise AI / GrowWise** — live UK Ltds, child-development programme.

---

## 9. The bench — viable but not shortlisted (keep on file)

- **Setfair** — the best metaphor in the whole exercise ("set fair" = barometer reading for settled fine weather ahead; calm, British, evidence-led, zero guarantee overtones). Ships with a taken .com, an Inmarsat maritime history and UK Ltd clutter. If Bearings/Steady/Keepden all fail the parent test, clear this one properly.
- **Northlight** — CLEAR, premium, steady-mood; weaker on the specific "I'm lost" job. `northlightapp.co.uk` open.
- **Foothold** — lovely first-step metaphor; Foothold Technology (health software) makes the software-class TM contested.
- **Grounded** — strong double meaning for parents; plain-word domain problem; game of same name (different category).
- **Wingspan** — the confident letting-go register nobody else in the category uses; board-game association; descriptor-dependent.
- **Homestead** — warm, whole-household; faded US website-builder heritage; verify UKIPO.
- **Steadings** — distinctive, evocative, CLEAR; fails the say-it-first-time spelling test.
- **Waypoint** — safe but badly crowded across software generally.
- **Keeplane** — CLEAR, keeps "keep"; faint traffic-lane misread; .com parked-buyable.
- **Wellset / Aptwise** — on-brief meanings, minor collisions, cooler tone; backups only.

---

## Addendum B — round 2: guard/family/online roots (2026-07-05)

**Brief:** Ben asked for candidates built from **online, guard, family** plus the adjacent fields **home, net, nest, hearth, haven, watch, keep (as noun — castle keep)**. Screened on the §3 rubric; kill list (§8) respected — Netnest and Homefront were requested and are already dead there; not re-proposed. Whois lookups run 5 Jul 2026 via Nominet/Verisign from this machine; web screening same day.

### B1. The guard field — analysed honestly, then closed

The question was whether "guard" in a *name* (a) makes the protection promise the copy may never make, (b) sounds like the surveillance category we define against, (c) is crowded out anyway. The answer is yes, yes, and yes — any one alone would kill the field.

**(a) Claims.** The claims lint bans "protects your child" in editable copy. "Guard" *is* that claim, compressed into the one asset that can never be edited or disclaimed. It is the §1.3 SafeKid pattern with a sword instead of a padlock. A guard-name commits us to the exact promise the product philosophy refuses to make.

**(b) Surveillance house-style — worse than suspected.** "-Guard" is not merely adjacent to monitoring software; it is its *naming convention*, verified live:
- **HomeGuard** (Veridium Software) — stealth activity monitor: keystroke logging including passwords and chat, screenshots as often as every 2 seconds, "impossible to bypass". The literal opposite of this product.
- **KidGuard / KidsGuard Pro** (kidguard.us, ClevGuard) — phone spyware: reads children's texts, records their calls, "listens to the phone's surroundings"; criticised in the New York Times for marketing to spouses who want to spy on partners.
- **NetGuard** — live, popular open-source Android firewall (netguard.me).
- **Guardio** — Tel Aviv browser-security firm, ~$100M ARR, $80M raise Nov 2025. Owns the "guard-" sound in consumer security marketing.
- **FamilyGuard** — an SC Johnson **disinfectant spray** line ("kills 99.9% of germs"). A household-CPG giant owns the family+guard collocation.
- iGuard: not individually verified (biometric/access-control uses circulate); immaterial — the field is already gone.

**(c) Two UK-specific aggravators.** First, **"safeguarding" is the statutory term for child protection in UK schools** — a guard-name reads institutional (DBS forms, safeguarding leads), borrowing an official register we have no right to and inviting exactly the wrong comparison. Second, **"the Home Guard" is Dad's Army** — in the UK, "Homeguard" carries an affectionate but fatal note of amateur, bumbling defence.

**Best guard-family survivors, still scored in case a softened form lived:**

| Name | Why it was the best case | Why it still dies | Score /25 |
|---|---|---|---|
| **Guardrail** | The softest guard: passive infrastructure, not a watcher; catches the worst rather than promising to prevent it. Genuinely the right *metaphor* — which is why we already use it internally. | `guardrail.co.uk` registered 2008. And "guardrails" is the single most saturated word in AI tooling — guardrailsai.com, guardrail.ai, guardrail.tech, guardrails.ai, guardrails.chat, AWS Bedrock Guardrails, F5 AI Guardrails, all live. Our own roadmap stretches *into* AI-readiness; the name would collide head-on with where we are going. UK ear also says "crash barrier". | **12** (3/1/3/3/2) — DEAD |
| **Fireguard** | The most domestic guard-word there is: the physical mesh a parent puts in front of the hearth. Passive, parent-installed, watches nobody. | Still a protection artefact in the name; fire-safety companies own the word commercially; reads as a physical product. | ~13 — DEAD |
| **Homeguard** | Home + guard is the brief, verbatim. | Dad's Army + a live stealth keylogger of the same name. Dead twice over. | — DEAD |

**Field verdict: the guard/shield/protect semantic field is closed.** Not on taste — on claims consistency, category positioning, and verified crowding, independently. The guardrail *metaphor* stays in internal vocabulary and copy explanation, where the lint can police it; it cannot be the mark.

### B2. Root-by-root sweep — 19 candidates

**Roots dead by construction (no candidates generated):**
- **Online** — descriptive root; fails §1 wholesale. "Online" belongs in the descriptor, never the mark.
- **Net** — condemned by precedent: Netwise and NetNest already killed (§8, "Net Nanny cousin; dated"); NetGuard live. The Net- prefix time-stamps a brand to ~1998.
- **Watch** — positioning-dead regardless of collisions: "watch" is the monitoring frame we define against, and **Home Watch is literally what several UK police forces call Neighbourhood Watch**. Housewatch/Homewatch would name us after curtain-twitching. No.

**The sweep:**

| Candidate | Root | Quick verdict |
|---|---|---|
| Guardrail / Fireguard / Homeguard | guard | DEAD — see B1 |
| **Keepside** | keep | **CLEAR — scored below** |
| The Keep | keep | DEAD as a bare mark — Google Keep owns the word in software; generic English noun, unownable at UKIPO; film/novel baggage |
| Keephold | keep | DEAD — `keephold.co.uk`/`.com` both registered 2009; tautological (keep = hold); reads containment |
| HomeKeep | keep/home | DEAD — `homekeep.co.uk` registered 6 Nov 2025; one letter from Housekeep (below) → guaranteed school-gate confusion with a cleaning brand |
| Housekeep | keep/home | DEAD — housekeep.com is a major live UK home-cleaning platform (est. 2014, "London's best cleaners", 4.9★) |
| Homehold | home | DEAD — the best coinage of the home root, but homehold.org is a live UK lease-extension firm (ALEP member, Trustpilot presence) and `homehold.co.uk` was registered 8 Dec 2025 |
| **Homeport** | home | MINOR — scored below |
| Homefront | home | Already killed (§8) — not re-proposed |
| Homewatch / Housewatch | home/watch | DEAD — Neighbourhood Watch adjacency; monitoring frame (see above) |
| **Hearthside** | hearth | Scored below — dies on narrative |
| Havenly | haven | DEAD — verified: havenly.com is the largest US online interior-design service (~1M designs, acquired The Inside) |
| Haven (field) | haven | DEAD as a field — **Haven Holidays** owns "Haven" in the UK parent demographic outright; and "haven" is a safe-place promise, claims-adjacent in the name |
| **Nestside** | nest | MINOR — scored below |
| Netnest | net/nest | Already killed (§8) — not re-proposed |
| **Familyhold** | family | CLEAR — scored below |
| Famside | family | DEAD on tone — "fam" is youth slang; a premium calm brand for parents cannot lead with it |
| Family Compass | family | DEAD — descriptive two-worder (§1) + family-compass.org is a Dallas child-abuse-prevention nonprofit (est. 1992) + familycompass.com live health services + a parenting book of the same name |
| Stronghold | keep-adjacent | DEAD — too martial for calm-premium, and in the UK **Stronghold is a Zoetis prescription flea/worm spot-on** every cat-owning parent has heard of at the vet; plus the Stronghold castle-game franchise |
| Firmhold | keep-adjacent | DEAD on tone — "firm hold" is a hairspray descriptor; school-gate smirk guaranteed |

*Pattern worth noting: `homekeep.co.uk` (Nov 2025), `homehold.co.uk` (Dec 2025), `familyhold.com` (Nov 2025) were all registered within the last eight months — the home/keep/hold namespace is being actively speculated, same lesson as tendwise.co.uk in §6.3. Whatever survives this round should be registered immediately.*

### B3. The scored top 6 (same rubric as §3)

| # | Name | School-gate | Ownability | Claims-safe | Tone | Stretch | **Total /25** | Collision verdict | Domain position (whois 5 Jul 2026) |
|---|---|---|---|---|---|---|---|---|---|
| 1 | **Keepside** | 4 | 4 | 5 | 4 | 4 | **21** | **CLEAR** — no company, app or product found anywhere; only false-positive "keep sidebar open" noise | **`keepside.co.uk` — UNREGISTERED (whois-confirmed).** `keepside.com` registered 2019 but is a bare GoDaddy for-sale parking page (verified live) — no occupant, acquirable. Same shape as the Bearings position. |
| 2 | **Homeport** | 4 | 2 | 5 | 4 | 4 | **19** | **MINOR** — Garmin HomePort (marine route-planning software, widely known to boaters), a Capterra-listed HomePort, several UK "Homeport Ltd"s (mostly dissolved) | `homeport.co.uk` registered Oct 1999. Lovely metaphor (the port you return to — orientation without armour), but the string is generically trafficked and the exact domain is 27 years gone. |
| 3 | **Nestside** | 4 | 3 | 5 | 3 | 3 | **18** | **MINOR** — only Nestside Property Ltd (small UK real-estate co, Dec 2024); but Google Nest shadows the entire Nest- prefix in home tech, and §8's dead Nestwise shows the vein is trafficked | **`nestside.co.uk` — UNREGISTERED (whois-confirmed).** `nestside.com` registered 2017. |
| 4 | **Familyhold** | 3 | 4 | 4 | 3 | 4 | **18** | **CLEAR** — no product or company found | **`familyhold.co.uk` and `familyhold.uk` — UNREGISTERED (whois-confirmed).** `familyhold.com` registered 4 Nov 2025 (GoDaddy, recent speculation). Four syllables, earnest but heavy; "hold" carries a faint restraint shade. |
| 5 | **Hearthside** | 4 | 2 | 5 | 4 | 3 | **18** | **DEAD on narrative** — Hearthside Food Solutions is the largest US contract food manufacturer, and it filed Chapter 11 in Nov 2024 **following child-labour investigations at its facilities**. A child-safety brand cannot share a first page of Google with that headline. Hearthwise already dead (§8); Hearth Display is a live family-organiser device | `hearthside.co.uk` registered Aug 2003. |
| 6 | **Guardrail** | 3 | 1 | 3 | 3 | 2 | **12** | **DEAD** — see B1; the AI-tooling collision lands exactly where the roadmap stretches | `guardrail.co.uk` registered Jun 2008. |

**Scoring notes:**
- **Keepside is the one genuine find of the round.** It keeps the castle-keep equity (the strong safe place — the household metaphor, exactly as briefed) *without* the mined-out "-wise" suffix, and adds the fireside/hearthside warmth register through "-side" without borrowing anyone's collision. Zero collisions found, free .co.uk today, parked-buyable .com. Its 21 exactly ties Keepden — unsurprisingly, since they are the same idea wearing different second halves: **keep + den** (animal warmth) vs **keep + side** (fireside warmth, "by your side"). They should not both be carried; they split one territory.
- **Nestside** loses to its own root: "nest" tilts infant/nursery for a product that runs to 18 — the same flaw that helped sink Tendwise — and Google Nest looms over any home-tech-adjacent Nest- brand.
- **Familyhold** is ownable but nobody would love saying it.

### B4. Kill-list additions (append to §8)

- **The guard field wholesale** — Homeguard (Veridium stealth keylogger + Dad's Army), KidGuard/KidsGuard (phone spyware, NYT-criticised), NetGuard (live Android firewall), Guardio (live, $100M ARR), FamilyGuard (SC Johnson disinfectant), Safeguard (claims lint + "safeguarding" statutory register). Field closed on claims + category + crowding, independently.
- **Guardrail** — guardrail.co.uk (2008) + saturated AI-tooling namespace exactly where our roadmap goes; keep as internal vocabulary only.
- **Fireguard** — domestic but still a protection claim; fire-safety category owns it.
- **Housekeep** — live UK cleaning platform (housekeep.com). **HomeKeep** — one letter from it; .co.uk taken Nov 2025.
- **Homehold** — live UK leasehold firm (homehold.org); .co.uk taken Dec 2025.
- **The Keep / Keep (bare)** — Google Keep; generic noun, unownable.
- **Keephold** — both domains 2009; tautology; containment shade.
- **Hearthside** — child-labour bankruptcy headline adjacency; .co.uk 2003.
- **Havenly** — live US interior-design major. **Haven (field)** — Haven Holidays owns it in-demographic; safe-place promise in the name.
- **Family Compass** — descriptive + live child-abuse-prevention nonprofit + live health service.
- **Famside** — youth-slang register. **Firmhold** — hairspray. **Stronghold** — martial + Zoetis flea treatment + game franchise.
- **Housewatch / Homewatch / any watch- construction** — Neighbourhood Watch adjacency; monitoring frame in the name.
- **Online- and Net- roots** — descriptive (§1) and dated respectively; no exceptions found.

### B5. Does round 2 change the shortlist?

**No — honestly, no.** Nothing from these roots reaches the 22 of Bearings or Steady, and the round's best find, **Keepside (21), exactly ties Keepden** because it is the same castle-keep idea in warmer clothing. The leaders stand: **Bearings 22, Steady 22**, with the keep-territory wildcard now a **choice of skin — Keepden or Keepside — not an addition**. If the keep metaphor goes into the §6 say-it-aloud test, take whichever of the two survives being said to five parents ("Have you got Keepside?" vs "Have you got Keepden?") and drop the other; carrying both splits one idea.

Two actions regardless of the winner: **register `keepside.co.uk` now** (≈£10, same insurance logic as §6.3 — the surrounding namespace is being speculated monthly), and add Homeport, Nestside and Familyhold to the §9 bench, not the shortlist.

And the requested roots have now been swept properly: **online, net and watch are dead by construction; guard is dead three independent ways; haven and hearth die on collisions; home dies on Homehold/Housekeep occupancy; family produces only worthy-but-unloved compounds. The keep root is the only one that paid — and we already knew that, because Keepden was on the board. Round 2's real contribution is closing doors with evidence rather than taste, and one better door into the keep.**

---

*Prepared by Fable from five parallel screening lenses plus direct registrar verification. Verdicts are evidence-led but not legal advice; §6 step 2 is the gate before commitment. Addendum B (round 2) added 5 Jul 2026: guard/family/online roots swept; whois via Nominet/Verisign same day.*
