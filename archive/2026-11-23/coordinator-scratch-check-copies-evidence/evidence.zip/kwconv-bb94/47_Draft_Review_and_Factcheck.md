# 47 — Draft Review & Fact-Check Worklist

Adversarial safeguarding + accuracy review of the Phase-2 draft library (files 40–45), 2026-06-21. Totals across all files below. Work through the 🔴 items first (guardrail), then the fact-check list (every stat/date/number/price/phone number to confirm against the live source), then polish.

**Guardrail fixes:** All 8 guardrail fixes were auto-applied to the drafts.

**Totals:** 🔴 high 7 · 🟡 fact-check 45 · ⚪ polish 6


## 40_Platform_Guides_Wave2_DRAFT.md

- 🔴 **HIGH** — In an incident ('If something goes wrong') section, this is bespoke 'do this in a crisis' instruction (use report tools, block the player) that goes beyond stay-calm-plus-official-routes signposting.
  - quote: `- **Use the in-game report tools** (Java's player reporting; report and block on any platform) and **block** the player.`
  - fix: Move in-app block/report guidance out of the incident/crisis signpost block into the everyday-settings body, and keep the 'If something goes wrong' section to stay-calm plus the official routes (999/CEOP/Report Remove/NSPCC/Childline) only.

- 🔴 **HIGH** — Appears inside the 'If something goes wrong' incident section as a bespoke action step, going beyond signpost-only crisis advice (stay-calm + official routes).
  - quote: `Use the in-platform **block and report** tools on Steam as well.`
  - fix: Remove this line from the incident signpost block (block/report is already covered in the everyday Chat/friends section); keep the crisis section to the official routes only.

- 🔴 **HIGH** — Adds a non-standard incident route (direct-to-IWF reporting) to the crisis signpost block beyond the agreed official set (999/CEOP/Report Remove via Childline+IWF/NSPCC 0808 800 5000/Childline 0800 1111). For an under-18 image the agreed route is Report Remove; signposting parents to report images directly is bespoke incident steering.
  - quote: `You can also report illegal images to the **Internet Watch Foundation (IWF)**: iwf.org.uk.`
  - fix: Drop the standalone IWF reporting line from the incident block; Report Remove (Childline + IWF) is already the agreed route for under-18 images.

- 🔴 **HIGH** — In the Pinterest/BeReal 'If something goes wrong' section, this adds a bespoke action step (use in-app block/report) within the crisis signpost block rather than keeping it signpost-only.
  - quote: `Use the in-app **block and report** tools too, but the lines above are the ones that matter most.`
  - fix: Move the block/report mention to the everyday settings body and keep the incident section limited to stay-calm plus the official routes.

- 🟡 **MED** — Specific legal/date claim stated as fact in body prose without a [verify] marker or inline citation. Elsewhere the same fact is given a date '25 July 2025' (Reddit section), so the document is internally inconsistent on the date and neither version is marked for fact-check at the point of the claim.
  - quote: `the Online Safety Act's age-assurance duties came fully into force in July 2025`
  - fix: Add a [verify] marker and reconcile the date with the Reddit section, e.g. 'the Online Safety Act's age-assurance/child-protection duties came into force on 25 July 2025 [verify date and exact duty]'.

- 🟡 **MED** — Specific date and legal-status claim stated as fact without a [verify] marker (the [PV] tag is on the following sentence about Reddit's own rollout, not on this dated legal claim). Conflicts with the 'July 2025' phrasing used in the broadband section.
  - quote: `Online Safety Act child-protection duties have been live since 25 July 2025`
  - fix: Tag the dated legal claim itself, e.g. '...live since 25 July 2025 [verify exact date and which duties commenced]' and align with the broadband-section wording.

- 🟡 **MED** — Two specific statistics. They carry a [V] tag but no inline source is attached at the point of claim and the precise figures ('four in five', 'roughly half', age bands 13–17 / 7–17) need matching to the exact Ofcom wording to confirm they are not misattributed.
  - quote: `around four in five online teenagers aged 13–17 use generative AI tools, and Snapchat's My AI alone reaches roughly half of online 7–17-year-olds`
  - fix: Keep the [V] but attach the specific Ofcom report and year inline (as done for the NSPCC stat), and confirm the exact figures and age bands match the source before publishing.

- 🟡 **MED** — Rounded restatement ('Half', 'a third') of the 52%/31% figures cited later. The rounding is a paraphrase of the source; ensure it does not overstate. Stated as fact with only a parenthetical source and no [verify] on the rounding.
  - quote: `Half of children use AI; only around a third of parents realise their child does (NSPCC, 2025).`
  - fix: Use the precise figures from the source (52% / 31%) or mark the rounded version [verify]; keep the NSPCC 2025 citation.

- 🟡 **MED** — Specific numeric figures for the Pinterest shareable-link expiry. It is marked [verify], which satisfies the rule, but flagging so the exact numbers get fact-checked as they read as precise fact.
  - quote: `reported as **3 days or 5 new followers** `[verify]``
  - fix: Retain [verify] and confirm the exact expiry window/follower count against Pinterest's current help page; soften to 'reportedly expires after a short window' if it cannot be verified.

- 🟡 **MED** — Specific platform-default claim stated as fact. It carries [V] so the rule is met, but flag to confirm the default has not changed, since Twitch defaults shift.
  - quote: `**Thumbnail blurring for Sexual Themes is on by default for all users.** `[V]``
  - fix: Keep [V] and re-confirm against the live Twitch Content Classification Labels help page before publishing.

- 🟡 **MED** — Specific date and policy claim. It carries [V], so the rule is technically met, but the date is precise and the policy recent/volatile; flag to ensure the date and scope are confirmed.
  - quote: `from **late November 2025**, Character.AI **stopped allowing under-18s to have open-ended conversations**`
  - fix: Keep [V] but re-verify the exact effective date and scope against Character.AI's official notice; the later [PV] note already hints this may evolve.

- 🟡 **MED** — Legal claim (statutory duty) stated as fact. The sentence does include a bracketed [verify exact wording and current edition] shortly after, which covers it, but the duty assertion itself is presented firmly; confirm KCSIE wording supports 'legal duty'.
  - quote: `UK schools have a legal duty to provide **"appropriate filtering and monitoring"**`
  - fix: Ensure the [verify] explicitly covers the 'legal duty' characterisation, e.g. '[verify that KCSIE/standards phrase this as a statutory duty and the current edition]'.

- ⚪ **LOW** — Superlative safety framing ('the safest way ... safe'). It is hedged with 'generally considered', which softens it, but the phrase still leans toward an efficacy/safety claim about a feature keeping play safe.
  - quote: `Realms is generally considered the safest way for children to play together online because it is a closed group you control.`
  - fix: Reframe as a relative, non-safety statement, e.g. 'Realms is a closed, invite-only group you control, which is why many parents prefer it for younger children' — drop 'safest'.

- ⚪ **LOW** — Borderline efficacy framing. It is properly negated ('not a guarantee' appears in the same paragraph and 'reduce the chance' is hedged), so this is acceptable, but flagging to confirm 'reduce the chance of stumbling onto adult sites' is not read as an implied protection promise.
  - quote: `Filters reduce the chance of stumbling onto adult sites; they are not a substitute for the device layer`
  - fix: Optional: tighten to 'Filters lower the chance of accidentally reaching adult sites' to keep it clearly probabilistic; no change strictly required given the surrounding negation.

## 41_Threat_Playbooks_Wave2_DRAFT.md

- 🔴 **HIGH** — This is bespoke incident-handling advice in the deepfake/CSAM strand, which is meant to be signpost-only. Telling a parent specifically what evidence to keep/not keep around a child sexual abuse image goes beyond stay-calm + the official routes (999/CEOP/Report Remove/NSPCC/Childline). Evidence-handling around CSAM is exactly the kind of bespoke step that should be left to the authorities the playbook signposts.
  - quote: `Keep evidence of the surrounding messages** (who sent what, where), but don't save or share the image itself.`
  - fix: Remove the bespoke evidence-handling instructions. Replace with a signpost-only line, e.g. 'Don't make, save or forward the image. The routes below are run by the people whose job this is - follow their guidance,' then route directly to 999/CEOP/Report Remove/NSPCC/Childline.

- 🔴 **HIGH** — Bespoke 'do this in a crisis' instruction inside the signpost-only CSAM strand. Although well-intentioned and legally cautious, it is a specific behavioural step the playbook gives itself rather than deferring to the official routes, which the file's own framing says it will not do ('We do not give bespoke incident-handling steps').
  - quote: `Don't make or forward it, and don't ask the child to send it to you.** Sharing it on — even to show an adult — can itself be an offence.`
  - fix: Fold this into the signpost framing rather than as a parent action step, e.g. note that Report Remove and CEOP guidance covers what to do, and that an under-18 can report an image of themselves - rather than issuing direct do/don't instructions to the parent.

- 🔴 **HIGH** — Bespoke crisis-handling instruction in the swatting 'if it happens' section. The playbook explicitly says it 'does not give incident-handling steps,' but this tells the parent specifically what to say and do during a live armed-police response - a scripted crisis step beyond stay-calm + official routes.
  - quote: `If officers do attend, stay calm, follow their instructions, and tell them you believe it may be a hoax (a "swatting" call). Do not improvise beyond that.`
  - fix: Reduce to stay-calm + signpost only, e.g. 'If you believe a hoax call may bring an emergency response to your home, call 999.' Remove the scripted instructions about what to tell attending officers and 'do not improvise beyond that.'

- 🟡 **MED** — A factual statistic-style claim ('large majority of teens') stated in the body. It carries a trailing [verify] note, so it is marked - but the qualitative claim itself reads as fact within the sentence. Flagging so the magnitude is checked against the named source before publishing.
  - quote: `Ofcom's media-literacy research finds the large majority of teens have used a generative-AI tool, with ChatGPT and similar among the most-used.`
  - fix: Already carries a [verify] marker - ensure the 'large majority' wording is confirmed against the exact Ofcom figure, or soften to 'most' only if the source supports it.

- 🟡 **MED** — A specific legal commencement date stated as fact. There is a trailing [verify] note on the deepfake-offence point, but the 25 July 2025 OSA date itself is asserted without an inline [verify]/source marker on that clause.
  - quote: `Online Safety Act child-protection duties have been live since 25 July 2025`
  - fix: Add an explicit [verify] marker (or cite the source) directly to the '25 July 2025' OSA date. This date recurs in the Parasocial playbook ('live since 25 July 2025') - verify and apply consistently.

- 🟡 **MED** — Same specific OSA commencement date asserted as fact in the Parasocial playbook. The clause carries a [V ... OSA timeline as per library legal backdrop] marker but the precise date should be independently verified rather than assumed correct across playbooks.
  - quote: `the Online Safety Act's child-safety duties (live since 25 July 2025)`
  - fix: Confirm 25 July 2025 against gov.uk/Ofcom OSA implementation timeline and ensure the [V] marker actually points to a verified source for the date.

- 🟡 **MED** — Three specific statistics (30%, 23%, 4.4x) and two different age bands (11-17 vs 11-16) stated as fact. There is a [V - Gambling Commission] marker plus a [verify] on the multiplier, but the precise figures and the differing age bands should each be fact-checked against the named source before publishing.
  - quote: `Gambling among 11–17s rose to **30% in 2025**, and **23% of 11–16s have paid to open loot boxes** — a behaviour associated with roughly **4.4× higher odds** of problem gambling.`
  - fix: Keep markers; ensure each figure and each age band (11-17 vs 11-16) is checked against the latest Gambling Commission 'Young People and Gambling' report and dated/attributed inline.

- 🟡 **MED** — Specific factual/dated claim about a CMA enforcement action. Carries a [V - CMA, Nov 2025] marker so it is flagged - noting it for fact-check since regulator-action claims stated as fact need a citable source confirmed at publish.
  - quote: `in late 2025 the CMA opened a consumer-protection drive into online pricing tactics including drip pricing and pressure selling.`
  - fix: Already marked [V - CMA, Nov 2025]; confirm against the specific CMA press release/page and cite it inline before publishing.

- 🟡 **MED** — A specific helpline phone number stated as fact without an inline [verify] marker or cited source on that number. Phone numbers are explicitly in scope for accuracy red-flags.
  - quote: `**National Gambling Helpline 0808 8020 133** (24/7; supports under-18s and worried parents), via **GambleAware**.`
  - fix: Add a [verify] marker to the 0808 8020 133 number (and confirm at publish), consistent with how other numbers in the library are link/number-checked.

- 🟡 **MED** — Specific helpline number stated as fact. It carries a [V] marker at the end of the surrounding sentence in one place, but the number itself should be explicitly verified; ensure every occurrence (it appears more than once) is checked.
  - quote: `**Action Fraud 0300 123 2040**`
  - fix: Confirm 0300 123 2040 against actionfraud.police.uk and ensure each occurrence is covered by a [verify]/[V] marker tied to the number.

- 🟡 **MED** — A specific statistic (41%, users 13+, four-week period) for misinformation exposure. It is inside a [verify] note, so it is flagged - noting it so the figure and its scope are checked against the named Ofcom Online Nation source rather than carried over from elsewhere in the library unverified.
  - quote: `currently cited elsewhere in this library as 41% of users 13+ in a four-week period`
  - fix: Keep the [verify]; confirm the 41% figure, the '13+' population and the 'four-week period' framing against the current Ofcom Online Nation report and date it.

- 🟡 **MED** — Multiple specific percentages and age bands stated as fact. Carries a [PV ... verify exact figures] marker so it is flagged - noting for fact-check that each figure and band be confirmed against the named Ofcom 2025 report before publishing.
  - quote: `roughly **half of children** said they watched vloggers or YouTube influencers — more common among **8–11s (around 47%)** and **12–15s (around 49%)** than among 5–7s (around 34%).`
  - fix: Keep the [PV]/verify markers; confirm the 47%/49%/34% figures, age bands and report title/year against the live Ofcom source and state the year inline.

- 🟡 **MED** — Specific statistic (43% / two in five) attributed to Internet Matters but the figure itself should be fact-checked. It carries a [PV ... verify the exact stat and date] marker, so it is flagged - noting it for confirmation against the live source.
  - quote: `Around **two in five parents (43%)** are concerned about children spending money online on games and apps`
  - fix: Keep the [PV]/verify marker; confirm 43% against the named Internet Matters research and date/attribute it inline.

- 🟡 **MED** — Specific legal/regulatory claim about FCA financial-promotion wording stated as fact. It carries a [V - FCA; verify exact wording and date] marker so it is flagged - noting for fact-check that the exact mandated wording and the regime's scope be confirmed against live FCA pages.
  - quote: `Promotions must carry the standard warning that you could **lose all the money you put in**.`
  - fix: Keep the [V]/verify marker; confirm the exact FCA-mandated risk-warning wording and the October 2023 commencement date against the live FCA cryptoasset financial-promotions pages.

- 🟡 **MED** — Specific regulatory commencement date (October 2023) stated as fact. Carries a [V ... verify exact wording and date] marker - flagging so the date is confirmed against the live FCA source.
  - quote: `Since the Financial Conduct Authority's cryptoasset financial-promotions regime took effect (October 2023)`
  - fix: Keep the [V]/verify marker and confirm the October 2023 date against the FCA's published commencement of the cryptoasset financial-promotions regime.

- ⚪ **LOW** — Bespoke evidence-preservation instruction in the doxxing/swatting 'if it happens - signpost only' section, which states it 'does not give incident-handling steps; it points you to those who do.' This is a specific do-this step beyond signposting.
  - quote: `**screenshot before blocking**, and don't delete the messages or posts.`
  - fix: Either drop the evidence instruction or move it out of the signpost-only block; if retained, frame it generically per the official guidance rather than as a Bearings instruction. (Note: similar 'screenshot first' lines appear in other playbooks - apply consistently.)

## 42_Incident_Disclosure_Scripts_DRAFT.md

- 🟡 **MED** — Specific phone numbers (Childline 0800 1111, Samaritans 116 123) and the URL childline.org.uk are stated as fact without a [verify] marker or inline source citation in this line. The Samaritans 116 123 number in particular appears here with no [verify] anywhere. These are among the approved official routes, but the reviewer brief requires every phone number stated as fact to carry a [verify] marker or cited source.
  - quote: `**Childline** (under-19s): **0800 1111** · childline.org.uk. **Samaritans** (anyone, 24/7): **116 123**. **Call 999 if their life is at risk.**`
  - fix: Add a [verify] marker to the Childline number/URL and the Samaritans number (e.g. '0800 1111 [verify]', '116 123 [verify]'), or cross-reference the Sources block, so they are flagged for fact-check on launch and quarterly like every other figure/link.

- 🟡 **MED** — The 999 / 101 routing distinction is stated as fact without a [verify] marker or source. This is the same kind of specific, fact-checkable claim (which number for which situation) that the file marks elsewhere; here it is unmarked.
  - quote: `**Immediate danger or risk to life — call 999.** Urgent but not life-threatening — **101**.`
  - fix: Add a [verify] marker (or a one-line police.uk source reference) to the 999/101 routing line so it is fact-checked alongside the other numbers.

- 🟡 **MED** — The NSPCC Helpline number 0808 800 5000 is stated as fact here without a [verify] marker inline. (It is repeated in the Sources line at 118, also without [verify].) Phone numbers stated as fact should carry a verify marker per the brief.
  - quote: `**NSPCC Helpline** — worried and not sure where to start: **0808 800 5000**.`
  - fix: Append [verify] to the 0808 800 5000 number both here and in the Sources block so the helpline number is fact-checked on launch and quarterly.

- 🟡 **MED** — The 101 route is presented as fact without a [verify] marker or source. Same fact-checkable routing claim as elsewhere; unmarked here.
  - quote: `**101** if urgent but not life-threatening`
  - fix: Add a [verify] marker or police.uk source reference to the 101 routing claim.

- 🟡 **MED** — The '13+' eligibility age for Report Harmful Content is a specific factual/eligibility claim. The URL carries a [verify] but the age threshold '13+' is the kind of precise claim that should itself be explicitly verified (RHC's stated minimum age must match).
  - quote: `**Report Harmful Content** (for users 13+) at reportharmfulcontent.com`
  - fix: Ensure the [verify] explicitly covers the '13+' age threshold (e.g. 'for users 13+ [verify age threshold]'), so the eligibility figure is fact-checked, not just the URL.

- 🟡 **MED** — Samaritans 116 123 and Shout's '85258' shortcode / 'text SHOUT to 85258' instruction are stated as fact in the Sources block with no [verify] marker. Shortcodes and crisis-line numbers must be fact-checked; this line is unmarked.
  - quote: `**Samaritans** 116 123 · **Shout** text SHOUT to 85258 — distress and crisis support.`
  - fix: Append [verify] to the Samaritans number and the Shout shortcode (e.g. 'Samaritans 116 123 [verify] · Shout text SHOUT to 85258 [verify]').

## 43_AgeUp_Cards_DRAFT.md

- 🟡 **MED** — A factual claim attributed to CEOP/NCA (sextortion is 'significant and growing' and 'hitting teenage boys particularly hard') stated as fact without a [verify] marker or a specific cited source/date. The attribution is named but the quantitative/trend assertion needs fact-checking against a current CEOP/NCA source.
  - quote: `CEOP/NCA highlights financially-motivated sextortion as a significant and growing risk, hitting teenage boys particularly hard.`
  - fix: Add a [verify] marker and cite the specific CEOP/NCA alert or report: e.g. 'CEOP/NCA highlights financially-motivated sextortion as a significant and growing risk, hitting teenage boys particularly hard [verify against current CEOP/NCA alert and date].'

- 🟡 **MED** — Phone numbers and URLs (999, ceop.police.uk, childline.org.uk/remove, 0808 800 5000, 0800 1111) are stated as fact in body text without inline [verify] markers. The content is signpost-only and correct in framing, but the specific numbers/paths should carry a fact-check marker per the draft's own stated standard ('every figure and link is marked for fact-check').
  - quote: `the routes are **999** in immediate danger, **CEOP** (ceop.police.uk) for online sexual pressure or grooming, **Report Remove via Childline** (childline.org.uk/remove) for a nude image of an under-18 `
  - fix: Add a [verify all numbers/URLs] marker to this signpost block, e.g. append '[verify all phone numbers and URLs against official sources before publishing]' so the helpline numbers and web addresses get checked.

- 🟡 **MED** — A legal/factual claim about the minimum age for social platforms stated as fact without a [verify] marker or cited source. While widely true (COPPA/13+ self-set minimums), it should be flagged for fact-check as a factual assertion.
  - quote: `Thirteen is the minimum age for most mainstream social platforms`
  - fix: Add a [verify] marker or cite the basis, e.g. 'Thirteen is the minimum age for most mainstream social platforms [verify].'

- 🟡 **MED** — A factual/legal claim that child-specific reporting routes hand over to adult ones at 18, stated as fact without a [verify] marker or cited source.
  - quote: `**18** (when child-specific reporting routes hand over to adult ones)`
  - fix: Add a [verify] marker, e.g. '18 (when child-specific reporting routes hand over to adult ones) [verify].'

- 🟡 **MED** — A specific dated factual claim (Roblox changed controls 'substantially in 2026'). Although followed by '[verify]' at the end of the sentence, the dated assertion itself is stated as fact; ensure the [verify] explicitly covers the date and the 'substantially' characterisation.
  - quote: `Roblox changed its controls substantially in 2026`
  - fix: Make the verify cover the dated claim explicitly, e.g. 'Roblox changed its controls in 2026 [verify the date and what changed]' rather than asserting 'substantially'.

- ⚪ **LOW** — Efficacy-adjacent framing implying a conversation reliably does the most protective work. It is hedged and figurative rather than a hard guarantee, but borders on an unqualified efficacy claim about an approach.
  - quote: `the line that does the heaviest lifting through the teen years`
  - fix: Soften to avoid implied efficacy, e.g. 'the line many parents find matters most through the teen years' or 'the line we put the most weight on through the teen years.'

## 44_Proportion_Guide_DRAFT.md

- 🟡 **MED** — Specific statistics (56%, 83%) and a future-dated source (May 2026) stated as fact. The May 2026 date is plausible-but-cited; the figures themselves carry no [verify] marker on the numbers.
  - quote: `Smartphone ownership rises sharply from **56% of 10-year-olds to 83% of 11-year-olds** — the year most children start Year 7 (Ofcom, *Children and Parents: Media Use and Attitudes*, May 2026).`
  - fix: Add a [verify] marker to the 56%/83% figures, e.g. 'rises from 56% of 10-year-olds to 83% of 11-year-olds [verify both figures against the 2026 report]'.

- 🟡 **MED** — Specific statistics (77%, 60%) stated as fact with a citation but no [verify] marker. Should be flagged for fact-check.
  - quote: `among **8–12s** who use these apps, around **60%** are signed up with their own profile despite being under the minimum age (Ofcom, *Media Use and Attitudes*, May 2025).`
  - fix: Add [verify] to the 77% and 60% own-profile figures so they are checked against the cited May 2025 report.

- 🟡 **MED** — Specific statistic (96%) stated as fact without a [verify] marker.
  - quote: `**Teenagers:** social media use is close to universal — roughly **96% of 13–17s** use it (Ofcom, May 2025).`
  - fix: Add [verify] to the 96% figure.

- 🟡 **MED** — Specific statistics (65%, 34%) stated as fact without a [verify] marker.
  - quote: `about **two-thirds (65%)** of 8–17 social-media users say they mainly read, watch, follow or "like" content, against around a third (34%) who post, share or comment (Ofcom, May 2025).`
  - fix: Add [verify] to the 65%/34% watching-vs-posting figures.

- 🟡 **MED** — Specific statistics (56%, 66%) stated as fact without a [verify] marker.
  - quote: `AI tools are now mainstream among children: around **56% of 8–17s** use them, rising to **66% of 16–17s** (Ofcom, May 2026).`
  - fix: Add [verify] to the 56%/66% AI-use figures.

- 🟡 **MED** — Specific statistic (11%) stated as fact without a [verify] marker.
  - quote: `about **11% of 8–17s** said they had used AI "as someone to talk to or 'as a friend'" (Ofcom, May 2026).`
  - fix: Add [verify] to the 11% figure.

- 🟡 **MED** — Specific statistic (77%) stated as fact without a [verify] marker.
  - quote: `Internet Matters reported that **77% of 9–17s** had experienced some form of harm online over the year (*Children's Wellbeing in a Digital World Index*, 2025).`
  - fix: Add [verify] to the 77% harm figure.

- 🟡 **MED** — Multiple specific statistics (41%, 27%, 22%, 19%) stated as fact without [verify] markers.
  - quote: `The most common were **false information (around 41%)**, being **contacted by strangers (around 27%)**, seeing **violent content (around 22%)**, and getting **bullying or abusive messages from people `
  - fix: Add [verify] to the 41%/27%/22%/19% breakdown figures.

- 🟡 **MED** — Legal claim about UK law status and a commencement date. It carries a [verify] marker, but the assertion that it is 'law-in-principle' is stated quite definitively; ensure the legal characterisation itself (not just the date) is fact-checked.
  - quote: `A widely discussed restriction on under-16s using social media is **law-in-principle but not yet in force** in the UK, expected around Spring 2027 [verify commencement before relying on it].`
  - fix: Broaden the marker to cover the legal status as well as the date, e.g. '[verify both the legal status and any commencement date before relying on it]', and cite the specific Act/regulation.

- 🟡 **MED** — Specific publication date (21 May 2026) stated as fact in the Sources list without a [verify] marker.
  - quote: `Ofcom, *Children and Parents: Media Use and Attitudes Report 2026* (published 21 May 2026)`
  - fix: Add [verify] to the '21 May 2026' publication date, or confirm against Ofcom's published report.

- 🟡 **MED** — Specific publication date (7 May 2025) stated as fact in the Sources list without a [verify] marker.
  - quote: `Ofcom, *Children and Parents: Media Use and Attitudes Report 2025* (published 7 May 2025)`
  - fix: Add [verify] to the '7 May 2025' publication date, or confirm against the live source.

- ⚪ **LOW** — This one is already marked [verify] — included only to note it is handled correctly. No fix needed; not a true issue. (Listing for transparency.)
  - quote: `around three-quarters of 8–9s use a tablet [verify exact figure against the 2026 report].`
  - fix: No change needed — this figure is correctly marked for verification.

## 45_Room_by_Room_Setup_DRAFT.md

- 🟡 **MED** — Legal/factual claim that provider filters were 'strengthened as a default' under the broadband filtering commitments. The clause about exact product names and on-by-default status carries a [verify], but the historical claim that filters were strengthened as a default is stated as fact without its own marker or cited source.
  - quote: `These are **on or off at the account level** and were strengthened as a default across major providers under the broadband filtering commitments.`
  - fix: Add a [verify] marker or cite the gov.uk broadband filtering commitments page directly to this claim, e.g. '...under the broadband filtering commitments [verify — gov.uk filtering commitments].'

- 🟡 **MED** — Factual/legal claim that PEGI is 'the UK's games age-rating system', stated as fact. PEGI is the relevant system, but this specific assertion has no [verify] on this sentence itself (the [verify] appears two bullets later on a different claim) and no inline source.
  - quote: `This filters by PEGI rating, the UK's games age-rating system.`
  - fix: Move/add a [verify] to this sentence, e.g. 'This filters by PEGI rating, the UK's games age-rating system [verify — VSC/PEGI as UK statutory system].'

- 🟡 **MED** — Specific factual claim about the YouTube Kids age threshold ('under-13s') stated as fact. The [verify] at the end of the sentence applies to the Platform Settings Library cross-reference; the age figure itself should be explicitly flagged.
  - quote: `**YouTube Kids** for under-13s`
  - fix: Attach a [verify] to the age figure, e.g. 'YouTube Kids (for younger children) [verify exact age threshold]'.

- ⚪ **LOW** — Borderline tone — 'quietly connects to the internet all day' earlier plus this framing leans slightly toward an anxiety hook, though it stays mostly calm. Minor risk of implying the default state is unsafe.
  - quote: `so the shared infrastructure is set the way you'd choose rather than the way it came out of the box`
  - fix: Keep it factual and neutral, e.g. 'so the shared devices are configured deliberately rather than left on their out-of-the-box defaults.'