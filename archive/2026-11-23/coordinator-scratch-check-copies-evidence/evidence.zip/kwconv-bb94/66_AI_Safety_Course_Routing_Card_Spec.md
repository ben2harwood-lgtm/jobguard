# AI Safety Course - Routing Card Spec

*Created 2026-06-27. Status: Phase 3 draft for the route-only printable card described in `62_AI_Safety_Course_Phase3_Tools_Spec.md`. This card is not release-ready until all route names, URLs, phone numbers, eligibility rules, jurisdiction notes, and image-risk wording have been re-checked and cleared by human safeguarding/legal review.*

## Purpose

The routing card gives parents a short route-only reference for live concerns. It is designed to sit outside the course flow: if something is already happening, the course/tool stops and the parent uses the card or emergency signpost. [RTE-001, RTE-007]

The card does not ask for facts, diagnose a situation, classify a message, judge an image, decide whether something is a crime, or give bespoke live-incident advice. [GRM-002, VBT-004, RTE-007, GAP-013]

## Card Boundary

- Signpost only.
- No free text.
- No upload.
- No request to paste messages or describe images.
- No advice to investigate, negotiate, confront, or collect more material.
- No "save it", "screenshot it", "copy it", "download it", or "forward it" instruction for suspected nude or sexual images of under-18s.
- No claim that the route list is complete or legally definitive.
- No route is considered launch-ready until immediately re-checked. [RTE-008, GAP-011, GAP-016]

## Required Front-Of-Card Wording

> If something is already happening, stop the course and use the right route. This card is a signpost, not advice on a live case.

Under-18 image-risk wording:

> For suspected nude or sexual images of under-18s: do not save, screenshot, copy, download, forward, or ask anyone to resend. Use the relevant route instead.

[SMI-002, SMI-006, GRM-004, RTE-007, GAP-015]

## Route Categories

| Route ID | Concern type | Card wording | Claim IDs | Review |
|---|---|---|---|---|
| ROUTE-001 | Immediate danger or crime in progress | If there is immediate danger or a crime in progress, use 999. Non-emergency police contact is 101. | RTE-001 | Safeguarding review |
| ROUTE-002 | Online sexual abuse, grooming, or online sexual communication with a child | Use CEOP for online sexual abuse, grooming, or online sexual communication with a child. CEOP is not the route for every online harm. | RTE-002 | Safeguarding review |
| ROUTE-003 | Nude images of under-18s shared online | Use the under-18 Report Remove route where eligible. Re-check eligibility, now-18+ routes, and IWF/Childline wording before publication. | RTE-003 | Legal and safeguarding review |
| ROUTE-004 | A child wants confidential support | Childline is the route for a child who wants confidential support. | RTE-004 | Safeguarding review |
| ROUTE-005 | Adult worried about a child | NSPCC helpline is the route for an adult worried about a child. | RTE-004 | Safeguarding review |
| ROUTE-006 | Fraud or cyber-crime | Report Fraud is the route in England, Wales, and Northern Ireland; Police Scotland 101 is the route in Scotland unless there is immediate danger. | RTE-005 | Safeguarding/source review |
| ROUTE-007 | School-linked or peer-community safeguarding concern | Use the school's Designated Safeguarding Lead or equivalent safeguarding route for school-linked or peer-community concerns. | RTE-006 | Safeguarding review |
| ROUTE-008 | Harmful content, wellbeing concern, threats, or coercion | Stop the interaction and use qualified support or emergency routes depending urgency and facts. | HCM-003, HCM-005, RTE-007 | Safeguarding review |

## Back-Of-Card Notes

Include these short notes only after review:

- Reassure first; avoid blame.
- Do not ask a child to resend suspected nude or sexual images.
- Do not use AI to judge a real message, image, or live concern.
- For non-image material only, a parent may note what can safely be noted without copying illegal or harmful material; this wording requires review before publication. [GAP-015]
- If unsure and the concern is serious, use a qualified route rather than the course.

## Printable Layout

Recommended printable format:

- A5 one-page PDF.
- Front: immediate route categories.
- Back: calm response and boundaries.
- No forms or blank incident-detail fields.
- Last checked date.
- Review owner.
- "Route details checked on..." line.

## Data Fields

Each route entry should include:

| Field | Required? | Notes |
|---|---|---|
| route_id | Yes | Stable route ID. |
| concern_type | Yes | Parent-facing category. |
| card_wording | Yes | Short wording after review. |
| claim_ids | Yes | Claim IDs from the Claim Register. |
| source_ids | Yes before publication | Official source IDs. |
| review_status | Yes | Draft, needs legal review, needs safeguarding review, approved, retired. |
| last_checked | Yes before publication | Date route details were checked. |
| reviewer | Yes before publication | Human reviewer or owner. |
| print_ready | Yes | Must be false until all review and date checks are complete. |

## Acceptance Criteria

- Card has no incident-detail fields.
- Card has no AI judgement, classification, or triage engine.
- Card includes the under-18 image no-save/no-screenshot/no-copy/no-download/no-forward carve-out.
- Card entries cannot be marked print-ready while review status is draft or needs review.
- All route entries have Claim IDs and require source IDs before publication.
- Any route with under-18 image wording requires legal and safeguarding review.
- Route details are re-checked immediately before sale and whenever Stay Current changes a route.

## Implementation Recommendation

Start with static draft data only. Do not expose a printable route-card page until every route entry has:

- `review_status: "approved"`;
- `print_ready: true`;
- source IDs;
- date checked;
- reviewer;
- a pre-launch route verification note.

Until then, `/emergency` remains the only public live-concern route surface.
