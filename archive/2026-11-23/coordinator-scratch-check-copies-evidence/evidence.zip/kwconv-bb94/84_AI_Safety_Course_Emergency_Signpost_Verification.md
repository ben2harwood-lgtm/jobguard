# AI Safety Course - Emergency Signpost Verification

*Created 2026-06-27. Status: line-by-line route check of `app/emergency/page.tsx` after the Claude pilot review blocker. This is source verification and wording cleanup only. It is not legal advice, safeguarding advice, clinical advice, or launch approval.*

## Scope

Checked:

- `app/emergency/page.tsx`
- official-source rows in `68_AI_Safety_Course_Source_Recheck_Log.md`
- the Claude blocker in `83_AI_Safety_Course_Claude_Pilot_Review_Findings.md`

Not checked:

- paid legal duties for handling unsolicited suspected under-18 sexual material;
- safeguarding duties for the founder if a parent discloses a live risk;
- full terms/privacy/consumer-law pages;
- every possible Scotland, Wales, and Northern Ireland local variation beyond the route notes already recorded.

## Route Check

| Page section | Current route in app | Verification result | Patch made |
|---|---|---|---|
| Immediate danger | 999 | GOV.UK police route rechecked in `68` as emergency / immediate danger route. | No wording change needed. |
| Sextortion or blackmail | CEOP, 101, 999 if immediate risk | CEOP scope rechecked in `68`; police route rechecked in `68`. | Replaced old "do not delete anything / evidence" wording with under-18 image carve-out: do not save, screenshot, copy, download, forward, or ask a child to resend. |
| Under-18 nude or sexual image | Childline Report Remove + IWF | Childline/IWF route rechecked in `68`; AI-generated lookalike images included on the Childline route. | Removed unverified adult route note from this child-focused card. |
| Suspected grooming | CEOP, 999/101 if immediate or urgent danger | CEOP route and "not for every online harm" scope rechecked in `68`. | Switched CEOP links to the checked `ceop-reporting` URL. |
| Scam, fraud, or money lost | Report Fraud, Scotland 101, bank | Report Fraud route and Scotland caveat rechecked in `68`. | No wording change needed. |
| Harmful content or abuse on a platform | Platform first, then Report Harmful Content | Report Harmful Content checked 2026-06-27; it cannot take sexual-image reports involving under-18s. | Added line that it is not the route for sexual images of under-18s. |
| Distress or self-harm risk | Childline, Shout, Samaritans, Papyrus, 999 if life at risk | Childline/NSPCC source rows already in `68`; Shout, Samaritans, and Papyrus added to `68` on 2026-06-27. | Replaced old Papyrus number with 0300 102 2470 and added text HOPE to 88247. |
| School-linked concern | School DSL, local authority children's services, CEOP/police where relevant | KCSIE route rechecked in `68` for England; local variation still needs human review before wider use. | No wording change needed. |
| Adult worried about a child | NSPCC Helpline | NSPCC helpline rechecked in `68`; hours can change. | No wording change needed. |

## Remaining Gate

The emergency signpost blocker from `83` is patched for the small founding pilot only if:

- the live page uses the patched `app/emergency/page.tsx`;
- `78_AI_Safety_Course_Founding_Pilot_Execution_Checklist.md` keeps the pre-sale signpost verification step;
- any route change found before first sale pauses the pilot;
- paid legal/safeguarding review still checks the route handling before broader release.

Do not convert this verification into a claim that the product is safeguarding reviewed, legally reviewed, approved, compliant, or safe.
