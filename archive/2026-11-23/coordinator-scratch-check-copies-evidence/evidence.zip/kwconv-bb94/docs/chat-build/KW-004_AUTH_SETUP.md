# KW-004 — adult sign-in integration

**31 October 2026 · local implementation; provider/browser activation unverified.**
The queue records independent acceptance and exact source/test hashes. No email
has been requested from a real provider, and no real account was created by this
job. Missing configuration produces a clear unavailable state and denies access.

## What the implementation reuses

The existing `@supabase/supabase-js` installation provides email OTP requests,
one-use token verification, authoritative `getUser(jwt)` and local-session
revocation. `lib/db.ts` remains the service-role database access point. Existing
`users`, `purchases`, `subscriptions` and KW-002's unique `auth_subject` mapping
remain authoritative. No replacement authentication stack or dependency was
added. `lib/guard.ts` and the library access predicates are unchanged.

The adult can reach `/sign-in` through the global **Your account** link or the
locked library's sign-in link. The page uses a normal HTML form, email
autocomplete, explicit labels and adult self-attestation, without collecting a
birth date. An authenticated adult sees a POST-only sign-out action there.
Authentication does not create a purchase or grant paid access.

## Request and identity boundaries

1. `POST /auth/request` requires the exact configured application Origin,
   a small URL-encoded form, an adult email and adult self-attestation. It
   requests a Supabase link with a random 10-minute browser nonce. Provider
   acknowledgement is displayed as a request, never as proof of inbox delivery.
2. `GET /auth/callback` checks that nonce before contacting the provider. The
   callback supports `token_hash` with `type=email`; tokens in URL fragments or
   arbitrary callback types are not accepted. Missing/wrong-browser cookies
   cannot consume the token, including ordinary email scanners without that
   browser cookie. The provider must still reject expired/reused tokens.
3. The callback verifies the provider user with `getUser(jwt)`, requires its
   confirmed email and refuses anonymous users. It links only by the verified
   auth subject. A collision with an older email-only app row is held for
   deliberate account linkage; it is never silently claimed by matching email.
   New app rows explicitly start with `is_admin=false` and no marketing consent.
4. The access token is stored only in a host-only HttpOnly, SameSite=Lax cookie;
   Secure is required in production/HTTPS. Its browser lifetime is the shorter
   of the provider token expiry and one hour. No refresh token is persisted.
   Re-sign-in is required after expiry. The decoded expiry can deny a request;
   decoded identity/role claims can never grant one.
5. Every authenticated read verifies the token with the provider and finds the
   matching app subject. Admin status comes only from the app database. Paid
   and current access come only from matching existing System purchase and
   subscription rows. An auth request does not mutate the cached service-role
   client's session: each verification flow uses a fresh anon-key auth client.
6. Missing, expired, invalid, unlinked and unavailable outcomes remain distinct
   internally and all deny access. Public errors contain no submitted email,
   provider message, database detail or token. Library preview never creates a
   verified adult; protected mutations must use `getCurrentUser()`/the verified
   session independently of the existing preview-only view helper (KW-006).
7. All auth handlers and the page are dynamic. Provider identity fetches use
   `cache: no-store`; session reads call Next's `noStore()` and use cookies
   before database reads. No cross-request user/session cache was introduced.
   Independent purchase/subscription reads run together.
8. Return destinations are allowlisted local library/start/checkout paths;
   query strings and fragments are stripped. The configured application origin
   is used, never a caller-controlled Host header. Auth responses are private,
   no-store and `Referrer-Policy: no-referrer`; callback secrets are not rendered
   into a page, copied to the destination or put in application logs.
9. `POST /auth/sign-out` requires the same Origin, attempts local provider
   revocation and clears both browser cookies even on provider failure. It does
   not claim to sign out other devices. Provider access-token expiry/revocation
   behaviour must be checked in the controlled provider rehearsal.

**Deliberate limits:** the email link must open in the browser that requested it
within ten minutes. Another browser/device needs its own request. There is no
refresh-token rotation mechanism, recovery workflow or automatic legacy-email
account merge in this slice. Provider delivery/rate limits remain active; no
custom bypass or paid mail service is introduced. Billing event reconciliation,
refunds, cancellation and paid-through renewal behaviour remain KW-005/006;
the current access read uses the existing active-subscription rule. Lapsed
updates do not by themselves remove a valid System purchase.

## Configuration needed for a controlled provider rehearsal

All of these were absent from the standard Next environment load during this
session. Their values were neither inspected nor printed.

| Setting | Required purpose |
|---|---|
| `SUPABASE_URL` | Existing authorised Supabase project's API URL. HTTPS in production. |
| `SUPABASE_ANON_KEY` (or the existing `NEXT_PUBLIC_SUPABASE_ANON_KEY`) | Public/anon key used by fresh server auth clients. Never substitute the service-role key here. |
| `SUPABASE_SERVICE_ROLE_KEY` | Existing server-only database client. Must never be exposed to browser code or public variables. |
| `APP_URL` (or existing `NEXT_PUBLIC_APP_URL`) | Explicit canonical origin, with no path/query/credentials. Production requires HTTPS; localhost HTTP is development-only. |

First validate/apply the KW-002 migration on an authorised disposable database;
it was not executed during KW-002. Set the Supabase Site URL and permitted
redirect configuration to the intended application and callback. Verify the
query-bearing `/auth/callback?state=…&next=…` RedirectTo round-trips intact;
do not broaden the allowed host list to make a misconfigured callback work.

Configure the relevant email magic-link template to use the server token-hash
callback. The request always supplies a RedirectTo containing its state/query:

```html
<a href="{{ .RedirectTo }}&token_hash={{ .TokenHash }}&type=email">Sign in to Keepwise</a>
```

Keep the provider's email confirmation and rate limits enabled. Confirm that
the allowed existing email facility can deliver to controlled test addresses
without a new paid commitment. Do not use a default implicit-flow template that
puts tokens only in URL fragments: that does not complete this server flow.

## Verification evidence and remaining real-flow check

`tests/auth-session.test.ts` exercises absent/expired/forged sessions, verified
identity binding, metadata rejection, account collision/race handling,
matching paid/current rows, provider/database failure and return/cookie policy.
`tests/auth-routes.test.ts` exercises bounded requests, Origin rejection,
nonce-before-provider ordering, callback/expiry failures, safe cookie/redirect
handling and sign-out cleanup. These use isolated fixtures, not real email,
provider verification or browser delivery evidence.

The controlled G-SERVICES rehearsal still needs an authorised test environment
and actual test accounts: request and receive a link; sign in in the same
browser; reopen a protected page; verify the unpaid boundary; check purchase
access after the later test checkout integration; expire the token; sign out;
try link reuse, another browser, a wrong nonce and an email-collision fixture.
Check rendered mobile labels/keyboard navigation and make sure no callbacks
are captured by deployment access logs or third-party analytics. These checks
remain recorded rather than being represented by an API 200 or unit pass.

## Source/API references and implementation review

The installed SDK source and type declarations were inspected for
`signInWithOtp`, `verifyOtp`, `getUser(jwt)` and `auth.admin.signOut(jwt, scope)`.
The coordinator also verified the official guides:

- <https://supabase.com/docs/guides/auth/auth-email-passwordless>
- <https://supabase.com/docs/reference/javascript/auth-getuser>
- <https://supabase.com/docs/reference/javascript/auth-admin-signout>
- <https://supabase.com/docs/guides/auth/auth-email-templates>

The React best-practices check covered server-only auth state, no mutable shared
request session, parallel independent reads, labelled native forms, passwordless
email autocomplete, explicit button types, no unnecessary client bundle or
effects, and reuse of the existing header/footer/styles. No global styling or
protected pre-existing first-phone change was altered.
