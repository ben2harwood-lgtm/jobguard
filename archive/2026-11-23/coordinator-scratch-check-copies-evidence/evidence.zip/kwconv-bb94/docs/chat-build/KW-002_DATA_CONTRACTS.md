# KW-002 — shared core contracts and scope delta

**31 October 2026 · implementation scope, not launch clearance.** Source checked
against `feat/milestone-2` at `f91b58b6ab8d7dc05e1c2b9a0517747c5ff60867`.
This note records the addition to the existing model; `KEEPWISE_QUEUE.json`
records its author, independent acceptance and actual verification evidence.

## Reused entities and the missing fields

| Existing source | Retained responsibility | Minimal addition |
|---|---|---|
| `users` | Existing adult app identity and admin flag | Nullable unique `auth_subject`, linked only after the server verifies the Supabase session; no email-only or caller-id authentication. Existing users remain unlinked until a deliberate authenticated linkage. |
| `purchases`, `subscriptions` | Paid System access, included updates, renewal state | No new billing/entitlement table. Typed projections use the current columns. The active purchase tier is `system`; legacy `concierge` rows do not grant a new product. Verified provider reconciliation and one shared offer record remain KW-005. |
| `questionnaires` | The adult's structured diagnostic | Nullable contract marker, household reference and coarse multi-band array. New writes use version 1 and a strict enum parser derived from `questionnaireQuestions`. |
| `plans` | Stored generated plan and delivery time | Nullable contract marker, household/version, save request UUID, content hash and the existing assembler's receipt. New automated plans use `delivered`; there is no per-customer approval queue. |
| `feedback` | Structured response to a plan | Reused; the new write type fixes `notes` to null. Outcome semantics remain KW-014. |
| `lib/access.ts`, `lib/guard.ts`, `lib/db.ts` | Default-deny server access and service-role persistence | Unchanged. Auth/session wiring is KW-004; ownership/entitlement enforcement is KW-006. |
| `lib/blocks/deliver.ts`, `AssemblyLog` in `lib/blocks/assemble.ts` | Protected deterministic delivery, engine/block/source versions and signpost receipt | Reused, not bypassed. KW-008 must expose/persist the actual receipt through the protected delivery entrypoint; it must not directly assemble a customer plan to avoid the pause/signpost checks. |

`households` is the only new table: a random id, adult owner and creation time.
It contains no child profile, household name, school identifier or free-text
field. The core permits an adult to own more than one household; future
membership is separate and remains KW-025. No sharing is activated here.

## Data and integrity boundaries

- `parseStructuredDiagnostic()` accepts only the current structured question
  keys and enum choices. It rejects the historical `priority_note`, new/unknown
  keys, nested values, child/school identifiers and identity/ownership fields.
  Errors contain no submitted text. Missing non-age answers may represent a
  partial draft; KW-007 owns completeness, mutually exclusive choices and the
  safe per-band adapter. Age bands are required and returned in canonical order.
- `age_bands` uses existing hyphenated library/database slugs; `answers_jsonb`
  uses the existing engine labels with `age_band` as an array. This is household
  band coverage, never a persistent Child A/Child B profile. KW-007 must adapt
  each band for engine predicates that currently expect a single age string.
- The nullable `contract_version` leaves historical rows unchanged. Version-1
  diagnostics require a household and keep `free_text`/`child_age_band` null.
  Raw answers never belong in URLs, event props, payment metadata or email.
- The service chooses `user_id` and `household_id` from verified identity and
  an ownership query. Composite database references reject a user/household
  mismatch and a plan referring to another household's questionnaire. The
  existing questionnaire-delete action still clears only `questionnaire_id`;
  the companion composite reference is deferred so that purge can complete.
- The original RLS posture remains: anon/authenticated database roles have no
  household policies. The service role bypasses RLS, so these constraints are
  additional integrity protection, not a replacement for per-request guards.
- A version-1 saved plan has generated content, its SHA-256, delivery time and
  the exact existing `AssemblyLog` (engine version, assembly time, signpost hash,
  block versions/hashes/sources/review dates, enumerated options/interpolation).
  Database checks enforce presence/basic shape; the server must compute/check
  the hashes and validate the receipt. The SQL does not claim to prove content
  review, every JSON enum or cryptographic integrity by itself.
- Household/request and household/version unique indexes provide collision
  detection. KW-008 must allocate versions transactionally, handle retries and
  conflicts, and reject reuse of a request id with different content. A new
  version cannot silently rewrite an adult's saved agreement. Current guidance
  corrections and withdrawn content still need the customer-render safeguards.
- `purchases.updates_until` and the verified paid subscription period are the
  existing currentness inputs. Expiring updates does not itself remove a paid
  System purchase or the adult's rules. Refunds, cancellation/end-of-period,
  reactivation and event ordering are KW-005/006, tested there rather than
  inferred from display prices. The retained offer is £49 one-off with the
  first year included and £29 annual renewal; charge/terms configuration is
  unverified here. No schema comment is treated as an authoritative price.
- Historical free-text, Concierge and manual-review columns/statuses are not
  dropped or rewritten. New write types exclude them. This does not assert
  that every legacy page/API has already been rewired; the queued integrations
  must use these contracts. No model generation or manual customer fulfilment
  is introduced.

Assembly receipts and saved diagnostics are adult-linked personal records.
Their purge, correction, export and deletion behaviour needs the KW-024/B0
review, including where audit answer options outlive the questionnaire row.
This migration does not run a retention job or promise a working deletion flow.

## Scope reassessment against the old no-sharing/search memo

`103_M0_OSA_Scope_Memo_and_M0_Decisions.md` describes a single adult recipient,
no sharing, no child-facing surface and no search over user content. Its
historical out-of-scope analysis is not carried forward as approval for the
expanded feature set. The user has authorised local reversible implementation;
the following exact changed operations are carried into the scope/B0 review.
This is a record of changed design assumptions, not a new legal determination.

| Proposed operation | Bounded design now recorded | Required scope/activation evidence |
|---|---|---|
| Shared caregivers, two homes, temporary carers (KW-025–028) | Authenticated adults; explicit roles/grants; selected structured rules; no open messaging or free-text incident exchange. A separate household is private by default; temporary grants expire. | Reassess the old “no second party” assumption for the actual sharing design and data lifecycle. Scoped access tests and B0/privacy clearance before activation; no inherited blanket exemption. |
| Catalogue search/comparison (KW-029–033) | Search one editor-maintained catalogue; raw queries are transient; no search over households, user posts or multiple external sites. Unknown coverage is explicit. | Record the actual search operation in the B0 scope evidence. Reviewed current catalogue facts remain required; this note does not approve later content. |
| School administration and policy publishing (KW-038–041) | Verified school publishing authority; a separate school administration domain; generic household sponsorship. School-specific sources stay public/local/printed, with no synced household-school association. | Reassess publishing and recipient exposure using the implemented approval/moderation and ownership design. B0/privacy and explicit publication authority remain required. |
| Supervised activities/practice (KW-035/037) | Generic bounded exercises, no child accounts, uploads, disclosures or open-ended AI. Software fixtures stay isolated from held customer routes. | Actual child-access assessment and applicable G-CHILD-ACCESS/G-LAB/G-A content clearance before activation. Preserving adult account ownership alone does not settle child access. |

G-A0 remains applicable before bulk adaptation/fresh guidance; G-A and G-B0
still block first sale; G-B1 applies to real digest/sequence activation; G-B2
applies only to a later DNS flag-on. Provider/browser proof is still G-SERVICES.
No gate is marked passed by this note. Existing ai-safety route/import guards
and source review holds remain unchanged.

## Applying and reversing the additive migration

Apply `supabase/schema.sql` followed by
`supabase/migrations/kw002_core_contracts.sql` once on an authorised disposable
database first. This file is a versioned migration, not a repeatable bootstrap.
The transaction ensures a failed statement rolls back the entire addition.
No database was provisioned or changed by preparing these files. Availability
checks found no local PostgreSQL/Docker runtime; static SQL checks are not a
substitute for a database execution test.

Before provider activation, verify: existing fixtures remain readable; a valid
diagnostic/plan saves; cross-owner tuples, duplicate request/version and missing
receipt fields fail; direct authenticated/anonymous roles cannot access the new
table; questionnaire purge nulls its plan reference; owner deletion cascades;
rollback returns the fixture schema. These are controlled integration checks,
not instructions to touch real accounts.

For rollback, first stop version-1 writers and check whether any new records
exist. Export/retain them under the agreed policy before an authorised rollback
on a populated database: dropping the added columns/table removes that new data.
On an empty disposable fixture, execute the following in one transaction:

```sql
begin;
alter table plans drop constraint plans_questionnaire_owner_fk;
alter table plans drop constraint plans_household_owner_fk;
alter table plans drop constraint plans_core_v1_check;
drop index plans_household_request_key;
drop index plans_household_version_key;
alter table plans drop column household_id, drop column contract_version,
  drop column plan_version, drop column idempotency_key, drop column content_hash,
  drop column assembly_log_jsonb, drop column created_at;
alter table questionnaires drop constraint questionnaires_household_owner_fk;
alter table questionnaires drop constraint questionnaires_core_v1_check;
drop index questionnaires_household_idx;
drop index questionnaires_id_household_owner_key;
alter table questionnaires drop column household_id, drop column contract_version,
  drop column age_bands;
drop table households;
drop index users_auth_subject_key;
alter table users drop column auth_subject;
commit;
```

No rollback touches existing purchased/access rows, questionnaire answers,
rendered plan content, feedback or the six preserved user-modified files.
