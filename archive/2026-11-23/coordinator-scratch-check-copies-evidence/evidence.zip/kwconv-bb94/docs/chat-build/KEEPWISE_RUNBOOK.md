# Keepwise chat build runbook

**31 October 2026. Canonical execution instructions beside the existing project.**

The programme contains 50 stable jobs, covering the remaining work for all 12 upgrades, 12 additions and existing promised courses, setup, printables and transition tools. The implementation audit already established substantial reusable software and content. Execute the remaining differences; a job is not permission to recreate a working component.

## The three files

| File | Responsibility |
|---|---|
| KEEPWISE_RUNBOOK.md | Stable operating rules, scope, evidence baseline and resume protocol. |
| KEEPWISE_QUEUE.json | Authoritative job cards, dependencies, state, gates, ownership, attempts and acceptance evidence. |
| KEEPWISE_HANDOFF.md | Short current summary generated from the queue, with next ready jobs and exact resume instruction. |

Canonical directory: /Users/benharwood/Claude/Projects/AI Safety Build/docs/chat-build

The Page and exported archive are readable snapshots. Read the current project files before acting; do not advance progress from a stale exported queue. The JSON queue is authoritative if the handoff revision differs. Rebuild the handoff from it, preserving any genuinely newer source evidence.

## Start and resume

1. Read this runbook and the current handoff. Parse the queue header, state summary, active jobs, gates relevant to the next work and only the selected job cards and their relevant feature_contracts entries. Those full U/N acceptance contracts remain binding; short card checklists do not erase them. Do not load all 50 briefs and the entire master specification into every context.
2. Read applicable AGENTS.md instructions, then inspect actual Git HEAD, branch, status and diffs for the selected files. The initial baseline below is a reference, not an instruction to reset the project.
3. Reconcile active/checking entries after an interruption. Determine whether their processes still run, what files changed and which checks actually completed. A stale status does not prove the work is absent or the old agent still owns a live session.
4. Choose at most two jobs whose dependencies are accepted, whose next checkpoint gates are satisfied, and whose write paths/locks do not overlap. Prefer the next pair in the handoff; choose another ready job when a named external blocker prevents useful progress.
5. Read each job's named existing inputs. Verify and credit any capability already present. Narrow or finish the job through verification when its intended result already works; do not force a rewrite to fill a job slot.
6. Record the job owner, start reference, exact current write paths and lock names before edits. Implement the smallest checkpoint, run relevant checks, and obtain independent review.
7. Update queue state and handoff after acceptance, a material block, interruption or the end of a session. Continue with the next ready work while the active chat has capacity. End with completed IDs, evidence, blockers and next IDs.

A simple request of **Continue Keepwise** in this thread means resume this queue. A genuinely new chat should receive the resume instruction at the end of this file and needs the same authorised device/project access.

## What autonomy means here

One coordinator can direct two implementation agents and one independent checker inside the active chat. Responsibilities may change between jobs, but no author approves their own change. This fits four concurrent agent slots including the coordinator.

The user does not need to paste 50 prompts. A job is a coherent result with bounded lettered checkpoints, not a promise about a platform message count. Several independent jobs can finish in one active response; a larger permission or asset job may need several checkpointed exchanges. Aim for one focused implementation/check cycle per small job and split a larger change into its named substeps without changing the stable job ID.

Checkpoint after every accepted result and plan a fresh chat after roughly 8–10 accepted jobs, or earlier when the selected context becomes unwieldy. The trigger is context quality, not a rigid quota. Save before switching.

This setup does not keep an ended chat executing, schedule a wake-up, create a new conversation or transfer hidden model memory. The durable files carry the exact state. The user opens a new chat and pastes one resume instruction; the next agent reads the project files to recover it.

## Assignment and collision rules

Only the coordinator writes the queue and handoff. Immediately before a write, reread queue_revision and reconcile any mismatch. Increment the revision, write a temporary queue, validate it, atomically replace the queue, and regenerate the handoff with the same revision. If interrupted between the replacements, the queue wins and the handoff is regenerated.

Before assigning a job, record a lease in its owner/started_from fields and active_sessions: job ID, active chat/session identity, actual agent identity, exact paths, locks, start time and next checkpoint. Before ending, release completed leases and record incomplete leases honestly. Do not expire and steal a lease just because a clock has elapsed; reconcile running sessions and source state first.

Schema, identity/access, assembly, shared content inventory, global styling and final integration have exclusive named locks. A lock covers a semantic shared contract even if two agents propose different filenames. Two migrations may be independent, but changing the shared schema contract still requires coordinator scheduling. Use uniquely named additive migrations; do not have two agents rewrite schema.sql. Proposed filenames in the queue are reservations, not claims that those files exist or that they must be created. Reuse an equivalent existing implementation first.

Treat the write scopes as maximum candidate areas. Before editing a broad content or UI directory, narrow it to an exact file list for that checkpoint. Any extra shared file requires the coordinator to update the scope and resolve overlap. The checker can inspect shared files read-only while other jobs work, but must identify the exact reviewed diff/hash.

All agents currently share files. Parallel reads, analysis and disjoint code work are safe; concurrent edits to a shared file are not. If the remote device is accessible only through the coordinator, builders receive the exact relevant source and return disjoint patches; the coordinator applies them serially and the checker reads the result independently. Previous subagent remote process calls stalled, so do not repeat that pattern by default.

Do not create a clean worktree from HEAD and assume it contains the current project: six existing changed/untracked files are part of the initial product. If isolated checkouts are useful later, include and record the complete agreed working snapshot without discarding the user's work. No push/PR is required merely to start; no remote was configured at the inspected baseline.

## Acceptance and review

The five states are queued, active, checking, accepted and blocked.

A job becomes accepted only when its scoped acceptance criteria pass and a different agent checks the result. Record the author, checker, reviewed commit or patch/content hash, relevant commands and outputs, any browser/provider evidence, and the remaining activation gates. Record verified existing functionality as reuse evidence. A checker who fixes code becomes an author of that fix; another independent agent checks it.

If a check fails, return the job to active with the specific finding. If an outside input is unavailable, save the completed checkpoint and mark blocked with the exact missing input, owner if known and next action. Continue independent ready work. Unblock using actual evidence; never replace a missing human approval with an agent's confidence.

Use the existing tests and targeted behavioural checks. Add tests when a changed contract or consequential failure path needs evidence; do not generate tests that merely mirror a small reversible copy change. Broaden the suite when shared behaviour changed or at integration gates. No repeated full source audit or full regression for every tiny edit.

An accepted mechanism is not automatically a shipped feature. For example, a fixture-driven locale resolver can complete KW-044 while actual reviewed language delivery remains open in KW-045. A player can complete KW-047 while actual audio/video assets remain open in KW-046. The final 24-feature acceptance checks both the mechanism and required real content, review and operations.

Keep completion and activation separate. Local reversible work is authorised by the build intent. Produce the concrete reviewable result before raising any genuinely required external decision. Sending messages/invitations, publishing publicly, charging real money or buying resources requires the relevant actual authorisation; routine implementation does not require repeated permission questions.

## Bounded content and provider jobs

Content/practice/language/media jobs maintain an explicit batch_cursor with the current item, remaining list and completed evidence. An empty uninitialised list does not mean completion.

KW-015 handles one named coverage family per checkpoint. Keep an explicit remaining-family list in its evidence; do not invent a target block count. A0 applies before bulk adaptation/fresh authoring; the existing pack permits limited inventory/verbatim slicing while the verdict is pending.

KW-035, KW-037, KW-045 and KW-046 cannot complete on draft data alone. Their actual review/asset requirements are explicit. Search the existing authorised assets and approvals first. If reviewer availability, language choice or production resources are genuinely missing, prepare the exact packet or choice, save the work and continue independent software jobs. Do not purchase or contact reviewers automatically.

A0 also applies to any later checkpoint that performs the same kind of bulk adaptation/fresh authoring; its scope is not restricted to a job number. Actual new/adapted ladder, catalogue, course and practice guidance is linked to the review inventory. A gate passes only for the named content/version scope, not automatically for later material.

KW-004/005/013 can complete scoped implementation with honest configured-provider limitations. KW-049 requires the real permitted browser/provider journey. Run the early core sign-in → provider test purchase → diagnostic → save → reopen probe at KW-009, as soon as authorised service access permits. Record missing external access in early_core_probe and retry when it becomes available; do not wait for every advanced feature to finish. Fix code failures before accepting the slice. KW-049 remains the later comprehensive rehearsal. A and B0 still block any first sale, including a core-only release before KW-050.

Do not treat a static preview, successful unit test, mocked webhook or API 200 with no delivery as production acceptance.

The source's ai-safety modules are explicitly review-held and guarded against production imports/routes. KW-034 uses generic UI plus isolated fixtures. Actual routing in KW-035 and course/activity activation wait for the relevant clearance; do not weaken existing guard tests just to make the new route pass.

## Scope and decisions retained

- Existing automated product: deterministic assembly from reviewed blocks, no runtime LLM, no manual per-customer fulfilment.
- Existing recorded offer: £49 one-off with the first year of updates included; £29 annual renewal. Actual checkout configuration still needs verification.
- Keep the local editorial desk, existing schema entities and established access helpers. No replacement CMS, authentication stack or database by default.
- Adult accounts and structured household choices. No child names, dates of birth, uploads, monitoring or free-text disclosures. Unrestricted custom agreement wording stays local/print-only unless the data decision explicitly changes.
- School administration remains separate from household ownership. School codes grant generic sponsorship without promising named household-seat management under a no-association model. School-specific rule-card sources remain public/local/printed as recorded in the design.
- Generic content/audio may be downloaded for offline use. Private household and temporary-carer endpoints must not enter a general offline cache.
- Preserve emergency signposting, hash/version safeguards and cautious claims. No invented guarantees, professional endorsements or reviewer identities.
- Reuse current tools, subscriptions and authorised allowances; zero new upfront spend. Do not dispatch the project to another coding product.
- Existing project review gates are recorded with their scope; current expanded-feature intent is carried into the scope reassessment. Do not mistake an old feature absence for a reason to ignore the requested addition, or infer a new approval from an old draft.

## Initial evidence baseline

Project: /Users/benharwood/Claude/Projects/AI Safety Build

Device: Bens-MacBook-Pro-2.local  
Branch: feat/milestone-2  
HEAD: f91b58b6ab8d7dc05e1c2b9a0517747c5ff60867

The inspection found the existing quiz/scoring, deterministic assembly/render/delivery engine, guarded local editorial desk, 19 platform guides within 51 MDX documents, 74 blocks (10 marked published and 64 draft), editable agreement/printing, and an 18-task first-phone walkthrough. The existing feedback table and feedback_submit event are reusable. The source also contains substantial authored course/script material and eight review-held scenario objects.

The main remaining integration gaps are real adult identity and entitlement fulfilment, structured diagnostic-to-engine wiring, saved/reopened customer plans, shared household state, truthful email fulfilment, and the additional permissions/school/catalogue/media flows. These findings and file evidence are in the [implementation audit and build plan](https://chatgpt.com/space/page_5270b28ae8008191a417234cf1a215ad).

The last inspected working tree passed 377 tests across 13 files using CI=1 node node_modules/vitest/vitest.mjs run --no-cache. That is existing unit/content/structural evidence, not a hosted/browser end-to-end pass.

Pre-existing modifications: APP_README.md; app/globals.css; app/library/page.tsx; tests/library-access.test.ts. Pre-existing untracked work: app/library/first-phone/page.tsx and components/FirstPhoneWalkthrough.tsx. The queue records hashes for all six. Preserve them; the planning setup changes only docs/chat-build.

New evidence while making this execution plan: 108_Content_Inventory_Map.md already exists and has stale 45/12/33 block counts. KW-003 refreshes it instead of creating a competing ledger. The source's 100_Automated_Build_Plan.md and 105_Gate_A0_Submission_Pack.md explicitly distinguish A0 before bulk authoring, A/B0 before first sale, B1 for digest/sequence and B2 for DNS flag-on. Those are project gates, not a new legal conclusion by this plan.

## Sequence and parallel work

Start KW-002 shared contracts alongside KW-003 inventory. KW-034 generic trainer fixtures is a ready substitute if one lane is blocked.

Then run KW-004 identity and KW-007 diagnostic adapter in parallel. Follow identity through KW-005 billing and KW-006 guards. After their common dependencies, KW-008 save/reopen and KW-009 customer UI connect the core journey. Catalogue work KW-029–033 can take a free lane once the inventory is ready. Family work builds on plan/progress and permissions; school work builds on accepted adult access. Locale/player mechanisms can proceed while actual translations or recordings wait on assets/review.

Job numbers are stable references, not a forced serial order: KW-019 deliberately depends on the catalogue in KW-029. Always use the dependency graph. Do not launch all 50 jobs at once.

## Timing and re-estimation

The 50 jobs are work packages and context boundaries, not 50 human developer days. The prior audit's conditional allowances remain approximately 3–7 focused agent delivery days for the core and 2–4 working weeks total for expanded software, with two builders and an independent checker. They are provisional, unmeasured allowances, not a release-date promise.

Record implementation/checking time, rework and external waits separately. Re-estimate after 3–5 representative accepted implementation jobs and after the real core journey. Complete-feature release timing remains dependent on actual content coverage, competent review, language selection, media assets and provider/test access. Do not convert unknown waiting time to zero.

## New chat resume instruction

Continue Keepwise from /Users/benharwood/Claude/Projects/AI Safety Build/docs/chat-build/KEEPWISE_RUNBOOK.md, /Users/benharwood/Claude/Projects/AI Safety Build/docs/chat-build/KEEPWISE_QUEUE.json and /Users/benharwood/Claude/Projects/AI Safety Build/docs/chat-build/KEEPWISE_HANDOFF.md on Bens-MacBook-Pro-2.local. Read the current queue revision and source state, preserve existing changes, reconcile unfinished jobs, and run the next ready nonoverlapping jobs in this chat using up to two builders and an independent checker. Reuse existing work, save progress after each accepted job, and prepare a handoff before context runs out. Do not restart the audit or dispatch to another coding product.

