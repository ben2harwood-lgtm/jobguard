# Keepwise: Ben's switch-on steps

Written 13 Nov 2026 by the Claude coordinator. Everything here is only yours to do: it is money, a public claim, a
sign-in or a launch. The site is built and checked on this Mac with made-up data (launch branch `launch/skeleton`).
Do them in this order. Each step says what it unlocks.

## Short list: what is left for you, in order (15 Nov)

Send each answer to the Keepwise coordinator chat. Words in quotes are ready to send as they are; change them if you want something else.

1. ~~Trade mark search~~ done 16 Nov by the coordinator through TMview (UK data included): no UK mark for Keepwise in any class; one EU mark for baby monitors and similar devices (class 9, 2021) that has no UK effect. Note: `full-steam/coordinator/keepwise-trademark-search-2026-11-16.md`. Optional: file your own UK application (IPO fee). Then buy the web addresses (classes 9, 41, 42) and buy keepwise.uk and getkeepwise.co.uk. Then send: "Domain bought".
2. Set up the support email on the new domain and give the ICO number, or register at ico.org.uk. Then send: "Support email is ___, ICO number is ___".
3. ~~Commercial terms~~ Access for a year, renew by buying again: decided 15 Nov and built. Price £79 confirmed 15 Nov.
4. Terms, privacy and refund pages. Send: "D2 terms approved", or say what to change.
5. July rule. Send: "July rule lifted for the skeleton", or name who reads.
6. Create Stripe test mode and put the three test values into the hosting settings (step 5 below). Then send: "Test keys are in".
7. After the hosted test rehearsal passes, send: "Go live".

## Before anything goes live

1. **Name: Keepwise (decided 14 Nov).** Yours to do: the official trade mark search for Keepwise at
   trademarks.ipo.gov.uk (classes 9, 41 and 42), then buy keepwise.uk and getkeepwise.co.uk.
   Unlocks: the site address.
2. **Seller details.** Seller confirmed 15 Nov: FRM SYSTEMS LTD (company 17364736, England and Wales), 27 Ambleside
   Gardens, Wembley, HA9 8TL. These go into the hosting settings `NEXT_PUBLIC_LEGAL_NAME` and `NEXT_PUBLIC_LEGAL_ADDRESS`
   at switch-on; no code change. Still yours: a support email address (on the new domain, so after step 1) and the ICO
   registration number (the public register shows nothing for FRM SYSTEMS, so give the number or register at ico.org.uk,
   which has a yearly fee). 15 Nov: not ICO-registered yet, so leave `NEXT_PUBLIC_ICO_NUMBER` blank and claim no registration anywhere. VAT: not registered, so leave `NEXT_PUBLIC_VAT_LINE` unset (no VAT line, no "prices include VAT"). Setting the seller name, address and support email clears the technical seller-readiness
   gate. Live sales still require approval of the terms, privacy and refund wording, resolution of the July safeguarding
   and privacy rule, a clean hosted provider rehearsal, and Ben's explicit go-live authorization.
3. **Approve the words.** Read and approve, or change:
   - ~~the facts sheet~~ approved 15 Nov (`Next Gen Learning Platform/drafts/keepwise-facts-sheet-for-approval-2026-11-13.md`);
   - the terms, privacy and refund pages (`KW-D2_TERMS_PRIVACY_REFUND_DRAFT.md`).
   **Commercial terms.** Decided 15 Nov: access lasts a year; renewal is one more one-off payment, open from 30 days
   before the end, running on from the end date (built: KW-A8D, setting `MEMBERSHIP_ACCESS_DAYS=365`). Price: £79,
   confirmed by Ben 15 Nov.
4. **The July rule.** July's plan said no sale before a safeguarding read and a privacy read. You have not lifted it in
   words. Either say "lifted for the skeleton" or name who reads.

## Switch-on (these start paid services)

5. **Payment account (Stripe), test mode first.** Create the test-mode GBP price using the agreed terms from step 3
   and the webhook endpoint `<site address>/api/billing/webhook`, then give the lane the three test values
   (secret key, webhook secret, price id)
   through the hosting settings, never in chat. Then the lane runs the same rehearsal against the Stripe sandbox; only
   fakes have been tested so far. Card payments only.
   In Stripe settings, turn on its own emails for successful payments and refunds: those are the purchase and refund
   emails at launch (no code). Refund requests arrive by email from the account page; refund them in the Stripe dashboard.
6. **Sign-in and data service (Supabase).** Create the project, run the six SQL files in order (setup notes section 1),
   paste the sign-in email link from section 2 into both email templates, allow the return address from section 3.
7. **Email sender.** The sign-in service's own sender only reaches your team, two emails an hour. Real parents need a
   separate sender (a new paid service): pick one and connect it.
8. **Hosting.** Put the site on a host with the settings from setup notes section 4. Leave `LAUNCH_ALL` and
   `LIBRARY_PREVIEW` unset, `MEMBERSHIP_ACCESS_DAYS=365`, and `BILLING_MODE=test` until step 9.
9. **Go live.** Complete the decisions and approvals above and pass a hosted test-mode rehearsal with the actual
   providers. After Ben explicitly authorizes live sales, swap the three Stripe values for live ones, set
   `BILLING_MODE=live`, and buy one membership yourself with a real card, then refund it.

## Known gaps to review before launch (all on the stage-end list)

- A refunded parent cannot buy again and sees no contact address until step 2 sets one.
- The plan page still shows the buy link to refunded or pending parents (checkout then explains; nobody is charged twice).
- Parents who ticked July set-up steps must tick them again.
