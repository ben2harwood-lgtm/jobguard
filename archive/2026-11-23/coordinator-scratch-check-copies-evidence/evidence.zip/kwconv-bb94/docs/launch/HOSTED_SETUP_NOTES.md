# KW-A8: what the hosted service needs at switch-on

Facts for the lane to turn into Ben's steps. Nothing here has been done on a hosted service. Proven on this Mac only, against
real PostgreSQL 18.6 and a stand-in for the hosted sign-in and data service (`scripts/local-stack/`, `npm run test:db`).
"Provider docs" means the hosted service's own documentation, read on 11 Nov 2026 and not yet tried.

## 1. SQL files, in this order, once each
1. `supabase/schema.sql`
2. `supabase/migrations/kw002_core_contracts.sql`
3. `supabase/migrations/kw005_billing_events.sql`
4. `supabase/migrations/kwa8_intent_amount.sql` (KW-A8)
5. `supabase/migrations/kwa8b_billing_mode.sql` (KW-A8B)
6. `supabase/migrations/kwa8d_membership_renewal.sql` (KW-A8D: abandoned renewals can be retired; renewal before the end)

- Files 2 to 6 cannot be run twice; a second run stops with an error and changes nothing.
- Files 3 to 5 name the hosted service's roles `anon`, `authenticated` and `service_role`. They exist on the hosted service.
  Plain PostgreSQL does not have them (the local stack creates them first).
- File 4 removes the July rule that fixed the amounts at 4900 and 2900 pence. `kw005_create_intent` now takes the amount from
  the app as a fourth argument, and the database only checks it is between 100 and 100000 pence. The price lives in
  `lib/pricing.ts` and nowhere else; a price change needs no database change. Later events are still compared with the
  amount stored on the purchase's own row.
- The same list, for code: `SQL_FILES` in `scripts/local-stack/config.mjs`.

## 2. The email link the callback needs
The app asks for a link with a return address of `<APP_URL>/auth/callback?state=<64 hex characters>&next=<path>`.
The email must link to that address with two things added, exactly:

```html
<a href="{{ .RedirectTo }}&token_hash={{ .TokenHash }}&type=email">Sign in</a>
```

- The callback accepts only `type=email` with `token_hash`, and only in the browser that asked (it checks a cookie against
  `state` before it contacts the provider). The provider's default link (`{{ .ConfirmationURL }}`) does not work with this app.
- Put the same link in the "Magic link" template and in the "Confirm sign up" template. As far as I know the provider sends
  a first-time address the confirm-sign-up email, not the magic-link one. The provider docs do not say; a hosted run must show it.
- The link text should use the product name from the name setting (`NEXT_PUBLIC_BRAND_NAME`), not a typed name.
- The link works for ten minutes in practice: the provider's default is one hour (provider docs), the app's browser cookie
  lasts ten minutes. One request per address per 60 seconds by default (provider docs).

## 3. Return addresses to allow
- Site URL: the app's address, the same value as `APP_URL`.
- Allowed return address: `<APP_URL>/auth/callback`, and it must be accepted with `?state=…&next=…` attached. Provider docs
  describe patterns (`*`, `**`) and do not say whether the part after `?` is ignored, so by the documented rules the entry
  that covers it is `<APP_URL>/auth/callback**`. Only a hosted run can prove which form is needed.
- If the return address is not accepted, the link is built from the Site URL instead, has no `state`, and the callback refuses it.

## 4. Every setting the app reads
| Setting | What it is for |
|---|---|
| `SUPABASE_URL` | Address of the hosted sign-in and data service. Must be https in production. |
| `SUPABASE_ANON_KEY` (or `NEXT_PUBLIC_SUPABASE_ANON_KEY`) | Public key, used for sign-in requests and to check a session. Never the service key. |
| `SUPABASE_SERVICE_ROLE_KEY` | Server-only key for the database and for sign-out. Never in a `NEXT_PUBLIC_` setting. |
| `APP_URL` (or `NEXT_PUBLIC_APP_URL`) | The app's own address: origin only, https in production. Used to build links and to check form posts. |
| `NEXT_PUBLIC_BRAND_NAME`, `NEXT_PUBLIC_BRAND_DESCRIPTOR`, `NEXT_PUBLIC_SUPPORT_EMAIL`, `NEXT_PUBLIC_CURRENCY_STAMP` | Name, strapline, support address and date stamp shown on pages. |
| `NEXT_PUBLIC_LEGAL_NAME` | Seller name; missing details keep legal pages in draft and checkout closed. |
| `NEXT_PUBLIC_LEGAL_ADDRESS` | Seller contact address. |
| `NEXT_PUBLIC_ICO_NUMBER` | ICO registration, if applicable. |
| `NEXT_PUBLIC_VAT_LINE` | Optional VAT wording; omitted when empty. |
| `NEXT_PUBLIC_HOSTING_PROVIDER` | Privacy notice hosting name; defaults to our hosting provider. |
| `NEXT_PUBLIC_DATA_PROVIDER` | Privacy notice database/sign-in name; defaults to our database and sign-in provider. |
| `NEXT_PUBLIC_EMAIL_SENDER` | Privacy notice sender name; defaults to our email sender. |
| `NEXT_PUBLIC_PLAUSIBLE_DOMAIN` | Page-count analytics; disabled while /api/events is outside the launch list. |
| `LAUNCH_ALL` | `1` switches the off-list pages back on. Leave unset. |
| `LIBRARY_PREVIEW` | `1` opens the members' pages without payment, outside production and on Vercel preview builds. Leave unset. |
| `BILLING_MODE` | `off` (also the default when unset), `test`, or `live`. The only payment mode setting; production alone does not disable it. See section 8 and the separate KW-D2P sale gate. |
| `STRIPE_SECRET_KEY` | Server-only provider API key from the selected mode: `sk_test_…` for test; `sk_live_…` or `rk_live_…` for live. |
| `STRIPE_WEBHOOK_SECRET` | Server-only `whsec_…` signing secret for this endpoint in the selected mode. |
| `STRIPE_PRICE_SYSTEM` | `price_…` ID of the one-off GBP household membership price in the selected mode, matching `lib/pricing.ts`. |
| `STRIPE_PRICE_MEMBERSHIP` | Dormant July renewal price; leave unset for launch. While it is unset and `MEMBERSHIP_ACCESS_DAYS` is set, a renewal uses `STRIPE_PRICE_SYSTEM`. |
| `MEMBERSHIP_ACCESS_DAYS` | KW-A8D. Unset (the default): membership access never ends and there is nothing to renew. A whole number from 1 to 9999: access ends that many days after payment, the end date shows to members, and from 30 days before the end a member can renew with one more one-off payment that runs on from the later of the payment day or the current end. Any other value counts as unset. Applies to existing purchases from their payment time. **Launch value: `365`** (Ben, 15 Nov: a year). Set it before the build, as the page filter reads it. |
| `PLAN_GENERATION_PAUSED`, `ADMIN_LOCAL` | July admin and plan tools, not on the launch list. Leave unset. |

Without the first four, sign-in shows "not available at the moment" and every member page stays locked.

## 5. Sign-in settings on the hosted service
- Email sign-in on, with email confirmation on. The app refuses a user whose email is not confirmed.
- The provider's built-in email sender delivers only to the project team's own addresses, at 2 messages an hour, and is
  "not meant for production use" (provider docs). Real customers need a separate email sender connected to it. That is a
  new outside service and a decision for Ben.
- Session length: the app keeps a signed-in session for at most one hour and does not renew it. The adult asks for a new link.

## 6. Only a hosted run can prove
1. The six SQL files apply on the hosted PostgreSQL version (proven here on 18.6 only).
2. The server key can read and write `users`, `purchases` and `subscriptions`. `schema.sql` gives no explicit access; it
   relies on the hosted default for new tables. If a read fails with "permission denied", this is the missing line:
   `grant select, insert, update on users, purchases, subscriptions to service_role;`
3. The hosted data API sees `kw005_create_intent` with its four arguments straight after file 4 is applied.
4. The return address survives the allow list and the email template with `state` and `next` intact (section 3).
5. Which template a first-time address receives (section 2).
6. Real delivery: the email arrives, is not marked as junk, and the link opens in the same browser. A mail app that opens
   links in its own built-in browser will fail by design ("open it in this browser").
7. Sign-out ends the session at the provider, and an hour-old session is refused.
8. On the production build, a member page reflects a new purchase or refund on the next reload (seen here in development mode only).
9. Speed and limits: every page a signed-in adult opens asks the provider to confirm the session and reads two tables.
10. The paid unlock itself: KW-A8B enables explicitly configured hosted modes, but fixtures and the local database cannot prove hosted checkout or fulfilment. Section 8 lists the remaining rehearsal gates.

## 7. Price changes and recovery
- KW-A8B compares paid/refunded events with the amount and price on their own bound intent, so an old-price payment still unlocks and an old-price full refund still locks access after today's price changes.
- A new checkout always uses `lib/pricing.ts` and the matching configured provider price ID. The old row is never repriced or deleted.
- Before replacing an old-price unpaid opportunity, the app requires an existing local session binding and retrieves its current provider session and terms using GET only, then requires `expired` + `unpaid` and either no payment intent or a canceled payment intent with zero received. An open session, a payment still able to collect, or late-paid state holds replacement. The original event can then reconcile payment.
- Ordinary current-price checkout creation retries may repeat the original request with the original intent UUID as idempotency key, only within 23 hours and with the same recorded request context, and bind before redirect. Old-price terminal verification never creates or replays a provider session and never re-binds one. An old-price intent without a local session binding is held for manual reconciliation before any provider request, even with current request context; it cannot retire or allocate a replacement.
- The additive migration retains retired intents, their session binding and all event records. A partial unique index allows only one actionable base intent per adult; user-row locks serialize allocation, retirement and financial reconciliation. Refunded accounts still cannot buy again.
- The database stores an opaque request digest on new runtime intents before provider creation. It never interprets payment modes. Legacy unbound intents without this context, expired idempotency retention, ambiguous network results and mismatching mode/origin remain held for reconciliation; no second opportunity is created on that evidence.

## 8. Payments — settings and outstanding hosted steps

Nothing in KW-A8B calls a real payment provider, configures real credentials, publishes or deploys. The code and fixtures do not authorize sale. The combined checkout needs the exact **KW-D2P page and server sale gate**, coordinated and independently reviewed before acceptance/integration. If that leaf has landed, the coordinator must re-pin this base before its files are touched. No placeholder sale gate is provided here.

In the provider account, Ben will need:
- One product for household membership and one **one-off GBP price**, with its amount equal to `lib/pricing.ts`. No recurring price, discount, tax or shipping additions are supported by this adapter.
- One webhook endpoint at `<APP_URL>/api/billing/webhook`, configured for these handled events: `checkout.session.completed`, `checkout.session.async_payment_succeeded`, `checkout.session.async_payment_failed`, `checkout.session.expired`, `charge.refunded`, `refund.created`, `refund.updated`. Unsupported events are held with 503. A partial or pending refund is also held; only verified full refunds lock access through this path.
- Checkout sessions ask for card payments only (KW-A9), so delayed bank-style payments cannot start whatever the account allows. The two `async_payment` events stay handled for any older session. The checkout route also refuses on the server when seller details are missing (`canSell()`).
- The server API key, the price ID, and this endpoint's signing secret from the **same selected mode**. Test and live use distinct objects and secrets. Stripe's [published Refund object](https://docs.stripe.com/api/refunds/object) has no `livemode`: its absence is accepted on refund notifications, fetched Refunds and listed Refunds; an explicit contradictory field is rejected. The signed outer event and linked Charge, PaymentIntent and Checkout Session must still match the configured mode, with all ID, status, amount and currency bindings intact. A restricted live key must permit the session creation and all price/session/line-item/payment/charge/refund retrieval operations; a hosted rehearsal must establish its actual permissions.

Settings to enter in the host's server environment (never public/browser variables): `BILLING_MODE`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_PRICE_SYSTEM`, plus the sign-in/database settings and `APP_URL` from section 4. Empty, invalid or mismatched billing settings mean off: no continue button, checkout 503 and webhook 503. Legacy `STRIPE_PAYMENT_LINK_*` and `NEXT_PUBLIC_PRICE_*` settings do not enable payment or set charged amounts.

Rehearsal and switch-on order:
1. Keep `BILLING_MODE=off`. Apply the six SQL files in order, confirm the new RPCs appear in the hosted data API, and verify that only the service role can call them. Retain the protected SQL and local helper's production block.
2. Resolve KW-D2P and all founder/release gates. Use an **isolated test data and auth environment** for the separately authorized hosted test rehearsal. Never copy synthetic accounts, purchases or entitlements into the environment serving real customers. In that isolated environment, select `BILLING_MODE=test` and the matching test key, price and endpoint secret. Production builds must display “Test mode. No real money is taken.” Use only the provider's test payment fixtures.
3. Prove sign-in return to `/checkout/system`, checkout handoff, raw signature verification, event retries, delayed payment and full refund. The return address is `/library?checkout=returned`; that marker changes locked-view wording only. Membership opens only after the paid event is stored, never because of the return marker.
4. Before changing modes or origins, close/reconcile outstanding opportunities and drain pending deliveries in their original mode. A bound opposite-mode ID is refused, and an unbound recorded context cannot be replayed in another mode/origin. Legacy ambiguous unbound rows need deliberate provider reconciliation; this piece does not invent a recovery or migration policy for them.
5. Only after Ben authorizes live sale, keep billing off while replacing **all** settings with the matching live account values, then select `BILLING_MODE=live`. Confirm the page's price, one-off terms, refund line, NSPCC/CEOP links, terms/privacy and the KW-D2P sale gate. An authorized real purchase and full refund remain launch gates.

Only a real hosted rehearsal can establish the deployed provider API version/object shapes, restricted-key permissions, endpoint accessibility (including launch middleware), delivery/signature retries, success return in the signed-in browser, hosted RPC permissions and schema-cache refresh, production reload after paid/refund, operational limits, and real payment/refund handling. Fixtures cannot establish these. Do not switch mode while unresolved old-mode events remain; their authentic mode mismatch deliberately holds reconciliation.


Combined browser acceptance waits for KW-D2P and A3/A4 integration: a checkout return marker alone must leave access locked; a verified synthetic payment must unlock only the exact signed-in adult. First Phone choices stay browser-local. In a fresh browser that adult can restore the same plan from their downloaded choices file through the existing import; an unrelated adult in their own fresh browser must start without those choices or the other adult's member access. The choices file is transferable, not account-bound. No cross-browser server sync is part of this leaf. Run this acceptance only with isolated synthetic data/auth, separate from customers.

## 14 November full local candidate: additional holds

`LOCAL_BILLING` is a development-only loopback stand-in switch; leave it unset on every hosted environment. `.env.example` keeps `BILLING_MODE=off` and all live provider/seller values unset. Local start prints made-up seller settings solely to exercise the existing `canSell` gate. The account refund POST checks same-origin, freshly authenticated adult identity, and owned billing intent; it never accepts a browser user ID. Synthetic pending markers are local rehearsal evidence, not a hosted refund ledger.

Account/receipt/export pages render per request, with account export explicitly private/no-store. Receipt uses the bound original purchase amount and date, including refunds of old-price purchases. Account data export is intentionally scoped to account email and purchases, not a claim to export all legacy diagnostics/audit data.

Production remains held on annual access expiry and manual renewal semantics, safe erasure preserving financial/audit records, actual provider refund-request persistence and reconciliation, approved seller/retention/processor details, email delivery, all existing release/content gates and the previously listed hosted rehearsal. See the exact source-contract blockers in `LOCAL_RUN.md`. No schema, migrations, grants, RLS, access policy, production environment or provider account was changed by KW-FULL-LOCAL-A.

### Failed Checkout payment recovery hold (KW-FULL-LOCAL-LAUNCH-CATCHUP repair 1)

A complete unpaid Checkout Session with a nonterminal failed PaymentIntent (`requires_payment_method`) remains held for separately verified recovery. This adapter makes no cancel/expire mutation and allocates no replacement intent from that state. Stripe does not support direct cancellation of this Checkout-created payment in that state, and only open Checkout Sessions can be expired. An already-canceled payment is terminal proof only with the original exact session/payment binding, unpaid status, zero received, matching mode, amount and currency. Expired unpaid sessions with no payment remain subject to the existing checks. No live recovery or provider rehearsal has been performed or enabled.
