# Keepwise launch skeleton: rules for every builder and reviewer

Ben, 11 Nov 2026: "Keep Wise, we can launch skeletons first, MVP first." Target: ready for Ben Wed 18 Nov, on sale Fri 20 Nov.
The skeleton is one household membership whose promise is first-phone set-up: offer page, a few questions, an instant plan,
the set-up walkthrough, a printable pack with the family agreement, email-link sign-in and a paid unlock.

1. **Build only your piece.** Everything else in `KEEPWISE_FULL_PLATFORM_BUILD_PLAN_2026-11-10.md` waits until after launch.
   Smallest clear solution; reuse the July code; no new frameworks or dependencies unless your brief names one.
2. **Fully automatic.** Nobody at Keepwise checks, reviews or answers any family's plan. No AI writes advice when a parent
   uses the site: everything shown is pre-written, dated and sourced.
3. **Data.** Ask for age band, devices and apps only. No child names, birthdays, schools, screenshots or free text about a
   child. A family's answers and plan stay in the parent's own browser. Our servers hold only the adult's account and purchase.
4. **Words.** Never "safe", "protected", "verified", "certified", "reviewed for you", "checked by a person", "editor-reviewed",
   a guarantee, or help with an incident. A ticked step says "Marked complete by you". No scores, streaks, badges, fake
   discounts, testimonials or countdowns. Do not mention the under-16 social media ban.
5. **Something happening now.** Point to official help only (999, CEOP, NSPCC, Childline). `/emergency` stays free.
   `lib/signpost.ts` is hash-pinned: do not edit it.
6. **Only what works today is on show.** A page outside the launch list (`lib/launch.ts`, made by KW-A1) is switched off,
   not removed. If your piece adds a page a customer should reach, add it to that list.
7. **Name and price are settings.** Customer-facing text uses `brand.name` from `lib/brand.ts` and the price from
   `lib/pricing.ts`. Never type "Keepwise" or a price into a page. (The name will change: keepwise.co.uk is someone else's.)
8. **Dated and sourced.** Every set-up instruction carries its source link and a "last checked" date.
9. **Nothing goes live.** No real payment provider, no real email, no deploy, no real family data. Made-up data only.
10. **Phone first.** Every screen must work at 375px wide with no sideways scrolling.
11. **Checks.** `npm run content-lint`, `npx tsc --noEmit` and `npx vitest run --maxWorkers=2` must pass. Browser tests
    headless only. Do not weaken or delete a test to get a pass; if an old test asserts the July offer you are replacing,
    update it to the new truth and say so in your report.
12. **Git.** Work only in your own worktree and branch. Commit only files you changed (never `node_modules`). Never touch
    the main folder, `feat/milestone-2`, `save/*` or another piece's branch. Never delete files: switch things off instead.
