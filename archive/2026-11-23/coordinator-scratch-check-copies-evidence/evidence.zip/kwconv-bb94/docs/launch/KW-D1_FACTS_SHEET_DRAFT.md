# DRAFT. Keepwise facts sheet for the launch skeleton (KW-D1)

**DRAFT, 11 Nov 2026. Not approved. Nothing here may be posted, advertised or published until Ben approves it.**
It replaces the Keepwise section of `Next Gen Learning Platform/drafts/engine-approval-pack-2026-10-31.md`, which still
says £99, three working days and "checked by the founder". Until Ben approves this, the growth engine posts nothing about
Keepwise. The name is Keepwise (Ben, 14 Nov).

**Voice:** calm and practical, like a parent who has done the homework. Never scare parents and never shame them.

## Facts

- **What it is:** one household membership. A parent answers a few questions and at once gets a first-phone plan: what
  to set up, what to check and what to agree, in order, before handing the phone over.
- **What a member gets today:** the plan; step-by-step set-up for iPhone and Android, each step linked to Apple's or
  Google's own instructions and ending with a check the parent runs; a printable pack with a dated checklist, a family
  agreement, conversation openers and a 30-day re-check date. Anything added during the year is included.
- **Price:** £79 for a year, for the whole household. It does not renew by itself. 14-day refund.
- **Delivery:** straight away, on screen. No person at Keepwise reads or checks a family's plan.
- **Data:** asks for age band, devices and apps only. No child names, no school, no screenshots. The answers and the plan
  stay on the parent's own device.
- **Free:** the questions and the plan.
- **What it isn't:** monitoring software, emergency help, or a guarantee.

## Headlines

1. Giving a phone this Christmas? Know what to set, check and say before they unwrap it. *(approved 31 Oct, unchanged)*
2. First phone at 11? Four questions, then a plan for your family. *(was "a five-question check before you buy")*
3. The settings to change before your child unwraps their first phone. *(the 31 Oct version said "The 10 settings";
   use a number only if it matches the steps actually in the walkthrough)*

Dropped: "A phone plan written for your family and checked by a person" (no person checks plans) and "Phone set-up
evening" (no event exists).

## Phrases that may be used

- "prevention planning, not emergency help"
- "no child names, no school, no screenshots"
- "your answers stay on your own device"
- "each step links to Apple's or Google's own instructions"
- "dated and sourced"
- "it does not renew by itself"

**Buttons:** "Get the membership, £79" and "Answer the questions first, free".

**For anyone with a worry right now:** "If something is happening right now, the NSPCC helpline (0808 800 5000) and CEOP
can help today."

## Never say

Keeps your child safe, protects your child, guaranteed, verified, certified, expert-approved, reviewed for you, checked by
a person, checked by the founder, anything that suggests monitoring, "most parents get this wrong", "first 30 families",
"founding price", "within 3 working days", any countdown or limited-places claim, and anything about the under-16 social
media ban. Do not list a course, an app guide or any feature until it works on the site.

## For Ben to settle

1. The name (three options come separately by Fri 13 Nov).
2. The price: £79 is a starting guess from the 10 Nov plan, not a tested price.
3. The 14-day refund and "does not renew by itself" (they must match the terms in KW-D2).
