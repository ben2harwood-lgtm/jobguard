# KW-A0: the July work, saved (11 Nov 2026)

**What was saved.** Every changed or new file in the main folder on 11 Nov 2026 (73 paths, 303 files): sign-in, the
billing hand-off, the first-phone walkthrough, downloads, the 50-job build list and its archives. It is commit `e03004f`.
Branch `save/kw-a0-july-work-2026-11-11` holds it and never moves. Branch `launch/skeleton` starts from the same commit
and is where checked launch pieces land. The main folder itself was not touched; every saved file was compared with the
folder byte for byte. Ignored files (zips, `.env`, `node_modules`, `.next`) are not in the copy.

**What passes** (run on the saved copy, 11 Nov 2026, 2 workers):
- Wording check (`npm run content-lint`): 0 violations across 108 files.
- Type check (`tsc --noEmit`): clean.
- Tests (`vitest run`): 809 of 809 pass, 35 files.

**What is not proven** (nothing fails, but these have never been run for real):
- Sign-in has never sent a link through a real email service or been used in a browser.
- Purchase handling has passing tests but has never run against a real database (old job KW-005).
- The plan engine only uses published pieces of guidance and 10 of 74 are published, so it cannot yet make a first-phone plan.
- The walkthrough steps have not been checked on real phones (old job KW-033).
- The offer shown is still the July one (£49 plus £29 a year, three tiers, "editor-reviewed").
