# Three name options to replace "Keepwise"

**For Ben. First screen done 11 Nov 2026. Not legal clearance. Nothing has been bought or registered. You pick.**

Why it has to change: keepwise.co.uk is someone else's live UK site, also called Keepwise.

| | Name | Web address | Why it fits | Main risk |
|---|---|---|---|---|
| 1 | **Keepden** | keepden.co.uk and keepden.uk both show as not registered | Your own July shortlist name (21 out of 25). An invented word: no company, app or trade mark found using it | It starts with "Keep", like Keepwise. keepden.com is taken (registered Jan 2026, no real site on it) |
| 2 | **Well Begun** | wellbegun.uk shows as not registered. wellbegun.co.uk and .com have been held since 2010 with no live site, and run out in Jan 2027 | "Well begun is half done" is the first-phone promise, and it stretches to every later course | A well-known phrase is hard to protect and hard to be found for in search. An old clothing and retail trade mark exists; its owner was dissolved in 2022 |
| 3 | **Back for Tea** | backfortea.co.uk and backfortea.uk both show as not registered | What a parent says as a child heads out: freedom with one agreed rule | It sounds like a café until it is explained. backfortea.com is a stranger's blog |

**My lean: Keepden.** It is the only invented word of the three, so it is the easiest to own and to be found for, and
both UK addresses are clear.

**Reserves:** Hobside (a similar mark, HUBSIDE, is registered in the software and education classes), Coats On (an active
clothing company has the name), Kinstead (three unrelated active companies share it).

**Bearings** (July's alternative) is out as things stand: a live UK site called "Bearings funding finder" opened at
getbearings.co.uk in October 2026. It is in a different field, so reopening it is your call.

## What you do (about 15 minutes)

1. **Pick one** and tell the Keepwise launch lane the name. It goes into the site as one setting.
2. **Run the official trade mark search yourself.** Go to trademarks.ipo.gov.uk, search the word, and look for anything
   in classes 9, 41 or 42 (software, education, online services). The site asks you to prove you are human, which I cannot
   do. A European stand-in search found nothing in those classes for any of the three.
3. **Buy the web address** from any registrar. Buying is yours to do. Do it soon: several names from the July list were
   taken in September and October.

## What "shows as not registered" means

The UK registry answered "this domain name has not been registered" on 11 Nov 2026 (checked twice, once by the researcher
and once by the lane). It is only certain when you reach the registrar's checkout.

## What was not checked

Google Play, social media names, small local businesses that do not show up in search, and trade mark applications too
new to appear. Full evidence with links, and one line on every rejected name:
`docs/launch/research/name-research-2026-11-11.md`.
