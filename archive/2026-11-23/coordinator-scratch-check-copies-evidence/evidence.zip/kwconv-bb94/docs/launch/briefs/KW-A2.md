# KW-A2: a few questions, then an instant first-phone plan

Read `docs/launch/LAUNCH_RULES.md` first. Your worktree is on branch `build/kw-a2`, cut from `launch/skeleton` after KW-A1
landed, so `lib/offer.ts`, `components/BuyBox.tsx` and the launch list (`lib/launch.ts`) are there.

## Goal
A parent answers four questions on their phone and at once sees an ordered plan called "Before you hand it over". It is
free to see. Nothing they answer leaves their browser.

## The facts you may use
`docs/launch/research/first-phone-facts-2026-11-11.md` was checked against Apple's and Google's live help pages on
11 Nov 2026. It is the only source for any statement about a phone, a setting or an app's age rule.
- Use a fact only if its `Status` is CONFIRMED. For anything UNVERIFIED, show the maker's own help link and no instruction
  of ours.
- Do not add a fact from memory, from the July walkthrough or from `content/platforms`. If the plan needs a fact the file
  lacks, leave that line out and list it in your report.

## Build
1. **One fact file.** `lib/first-phone/facts.ts`: typed, plain data transcribed from the research file.
   - `pairings`: for each of parent phone (iphone, android, none) × child phone (iphone, android): what the parent can do,
     what they cannot, and where the settings are changed from.
   - `steps`: the ordered set-up steps for each child phone (B1 to B7 in the research file, plus the three non-technical
     July steps: real date of birth, check apps together before installing, where the phone charges overnight). Each has
     `id`, `title`, `whatItIsFor`, `how`, `limit`, `check`, `help` (the maker's page for "my screen looks different"),
     `minutes`, `source` (https link) and `lastChecked`. KW-A3 will show `how`, `limit` and `check`; you fill them in now.
   - `apps`: for each app in Part C: name, the maker's stated minimum age, any stated condition, the maker's parent page,
     `source`, `lastChecked`.
   Keep every sentence short and plain. Paraphrase; do not copy the makers' text.
2. **One pure function.** `lib/first-phone/plan.ts`: `buildFirstPhonePlan(choices)` returns the plan as data: the
   pairing note first, then the ordered steps for the child's phone, then one line per chosen app, then the two later
   stages ("Agree together", "30-day re-check") as headings. No network, no storage, no clock other than a passed-in date.
   - Choices are `ageBand` (`5-10`, `11-12`, `13-14`, `15-16`, `17-18`), `childPhone` (`iphone`, `android`),
     `parentPhone` (`iphone`, `android`, `none`) and `apps` (ids from the fact file, possibly empty). Anything else is rejected.
   - App line wording states facts only, for example: "WhatsApp's terms say 13 or over. Your age band is 11 to 12." Never
     a verdict, a tick, a cross, "ready" or "not ready".
3. **`/start` (free).** Replace the July safety check on this page with the four questions, one screen each, big tap
   targets, back button, progress as "Question 2 of 4". Labels: "10 or under", "11 to 12", "13 to 14", "15 to 16",
   "17 to 18"; "iPhone" / "Android (Samsung, Pixel and most others)"; "iPhone" / "Android" / "I don't have a smartphone";
   the app list with "None yet or not sure". Leave `components/StartSafetyCheck.tsx` in place, unused.
4. **`/plan` (free).** Shows the plan from the saved choices; with none saved it sends the parent to `/start`.
   - The pairing note comes first, in its own box, so a limit is seen before anything else.
   - Each step shows its title, what it is for and the time. The `how`, `limit` and `check` are for members: a visitor
     sees the buy box (`components/BuyBox.tsx`) with the line "The membership opens each step with how to do it, a check
     that it worked, your family agreement and the printable pack." A member (use `canAccessLibrary()` from
     `lib/guard.ts` on the server) sees a button to `/library/first-phone` instead.
   - Under the plan: "Sources last checked {date}", with the source links.
   - Three small buttons: "Download my answers", "Load my answers", "Clear my answers from this device". The file is JSON
     holding the four choices only; loading validates it with the same rules as the function and rejects anything else.
5. **On the device only.** Choices are kept in `localStorage` under `first-phone:choices:v1`. `/start` and `/plan` make no
   request that carries an answer: no `fetch`, no `track()`, no form post, no query string. Say on the page: "Your answers
   stay on this device. We never receive them."
6. **Launch list.** Add `/plan`.
7. **Tests** (vitest, existing style):
   - the plan for every pairing and age band, and with no apps, some apps and all apps;
   - every fact has an https `source` on the maker's own domain and a `lastChecked` date;
   - every sentence the function can produce passes the wording rules (run them through `lib/content-lint.mjs` if it
     exposes a function; otherwise assert the banned words in rule 4 are absent);
   - bad choices and a tampered answers file are rejected, including any extra key or free text;
   - the source of `app/start`, `app/plan` and `lib/first-phone` does not import `lib/events`, `lib/db` or call `fetch`.
8. The three checks in rule 11 pass. Walk `/start` to `/plan` yourself at 375px wide (`npx next dev -p 3101`).

## Out of scope
The member walkthrough screens (KW-A3), the agreement and pack (KW-A4), sign-in and unlock (KW-A8), the July plan engine
in `lib/blocks` and `lib/household` (leave it alone; it needs published guidance the skeleton does not have).

## When you finish
Commit on `build/kw-a2`. Report: what you changed, the exact check results, every fact you left out and why, anything
UNVERIFIED you had to work around, and any old test you updated and why.

## Added 11 Nov after the facts came back (read with the fact file)
- **Old and new names on iPhone.** Apple's controls have new names on version 27 (Screen Time Schedule, Time Allowances,
  Settings > Family > [child's name]) and the old ones before it (Downtime, App Limits). Do not add a question about
  software versions. Each iPhone step shows the version 27 names and route first, then one line "On older iPhone
  software:" with the earlier names from the fact file.
- **Android parent, iPhone child.** Say at the top of the plan, in the pairing box, exactly what the fact file confirms:
  Apple's instructions only cover a parent using their own iPhone, iPad or Mac; the route Apple documents otherwise is
  setting Screen Time on the child's iPhone itself, locked with a passcode; a child under 13 needs a Child Account in a
  family group. Where the file says UNVERIFIED (for example whether an adult with no Apple device can run the family
  group), say "Apple's pages do not say" and link Apple's page. Never guess.
- **A parent with no smartphone, or an Android child on Android 17.** Use the confirmed on-device route (parental
  controls in the child's phone Settings, locked by a PIN) from the fact file.
- **iPhone parent, Android child.** State the confirmed limit about approving paid content, and the confirmed minimum
  iPhone software for the Family Link app.
- **Apps.** Use the stated ages and conditions exactly as confirmed. Where the UK position is UNVERIFIED (for example
  Discord beyond "at least 13", WhatsApp's parent-managed accounts), say only what is confirmed and link the maker's page.
