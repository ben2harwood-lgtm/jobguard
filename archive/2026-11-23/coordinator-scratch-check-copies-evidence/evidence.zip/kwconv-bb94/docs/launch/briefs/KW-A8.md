# KW-A8: email-link sign-in and a paid unlock, proven with made-up events

Read `docs/launch/LAUNCH_RULES.md` first. Your worktree is on branch `build/kw-a8`, cut from `launch/skeleton`. It has its
own `node_modules` (run `npm ci` first); you may add exactly one dev dependency, `embedded-postgres` (real PostgreSQL that
runs from `node_modules`, no install on the Mac).

## Goal
On this Mac, with made-up data: a parent signs in by an emailed link, a made-up "paid" event unlocks the membership for
that account, and a made-up "refunded" event locks it again. The database is real PostgreSQL running the real schema and
functions. No real email is sent and no payment provider is contacted. The same app code must run against the hosted
service at switch-on with only settings changed.

## What exists (July, accepted, never run for real)
- Sign-in: `app/sign-in`, `app/auth/{request,callback,sign-out}`, `lib/auth/{session,policy}.ts`,
  `docs/chat-build/KW-004_AUTH_SETUP.md`. It talks to a hosted sign-in service through `@supabase/supabase-js` at
  `SUPABASE_URL` (a `http://localhost` address is allowed outside production). The callback expects the emailed link to
  carry `state`, `next`, `token_hash` and `type=email`.
- Purchases: `lib/billing/fulfilment.ts`, `lib/checkout.ts`, `app/api/billing/*`, and the database side in
  `supabase/schema.sql`, `supabase/migrations/kw002_core_contracts.sql`, `supabase/migrations/kw005_billing_events.sql`
  (`kw005_create_intent`, `kw005_bind_session`, `kw005_apply_event`).
- Access: `lib/access.ts`, `lib/guard.ts`: a signed-in adult with a `paid` purchase row gets in; default is no.
Do not redesign any of this. Change it only where this brief says or where a real run proves it wrong; report each such fix.

## Build
1. **Local test stack**, in `scripts/local-stack/`, for development only (every script exits at once if
   `NODE_ENV=production`):
   - `start.mjs` starts PostgreSQL through `embedded-postgres` with its data under `.local-stack/` (add that folder to
     `.gitignore`), applies `supabase/schema.sql` and then the two migrations in order, and starts a small stand-in for the
     hosted service on `http://127.0.0.1:54321`.
   - The stand-in answers only what the app calls. Sign-in: the requests `supabase-js` makes for `signInWithOtp`,
     `verifyOtp` (`token_hash`, `type: "email"`), `getUser(jwt)` and `auth.admin.signOut`. Tokens are one-use and expire.
     Data: the table reads and inserts on `users`, `purchases`, `subscriptions`, `billing_intents` and the three
     `kw005_*` functions, each run as SQL on the real database so the real constraints and functions decide the result.
     Unknown requests get a clear 501 so a gap is loud.
   - The "email" is never sent. The stand-in writes the link to `.local-stack/outbox/` and lists it at
     `http://127.0.0.1:54321/outbox`. The link is built the way the hosted email template must build it: the app's
     callback address with `token_hash` and `type=email` added.
   - It prints the lines to put in `.env.local` (made-up local keys, `APP_URL=http://localhost:3101`).
2. **Made-up events**, command line only: `node scripts/local-stack/billing-event.mjs paid <email>` and
   `... refunded <email>`. Each builds a made-up event with made-up ids and applies it through the same three database
   functions the real purchase path uses. It contacts nothing outside the Mac. Do not add any web route, button or
   setting that can grant paid access.
3. **Small app changes.**
   - `safeReturnPath` also allows `/plan`.
   - `components/LibraryLocked.tsx`: signed out shows a sign-in link and the buy box (`components/BuyBox.tsx` from KW-A1);
     signed in without a paid purchase shows "Signed in as {email}. This account has no membership yet." and the buy box;
     never show member content.
   - Anything on these screens that names the product uses `brand.name`.
4. **Tests.**
   - Keep the fast suite free of the database: `npx vitest run` must still pass without `embedded-postgres` loaded.
   - Add `npm run test:db` (a separate vitest config, one worker) that starts the local stack and proves, through the
     app's own functions (`resolveAdultSession`, `ensureAdultIdentity`, the checkout and event functions):
     a new adult has no access; a paid event gives access; the same paid event again changes nothing; a refunded event
     removes access; an event for another account does not unlock this one; an event with the wrong amount is refused.
   - Sign-in round trip against the stand-in: request a link, read it from the outbox, open the callback with the
     browser cookie, and the session is authenticated; the same link a second time fails; the link without the browser
     cookie fails; an expired link fails.
5. **Two short notes** in `docs/launch/`:
   - `LOCAL_RUN.md`: the exact by-hand run, start to finish, in under fifteen lines.
   - `HOSTED_SETUP_NOTES.md`: what the hosted service needs at switch-on, as facts for the lane to turn into Ben's steps:
     the SQL files in order, the exact email link template the callback needs, every setting name the app reads and what
     each is for, the return addresses to allow, and anything you found that only a real hosted run can prove.
6. Run it by hand as far as you can: stack up, `npx next dev -p 3101`, sign in through the outbox, `paid`, reload
   `/library` (open), `refunded`, reload (locked). Put what you saw in your report. Stop everything you started.
7. The three checks in rule 11 pass, and `npm run test:db` passes.

## Out of scope
Switching on real payments or real email (a later piece adds the live setting, off by default). Changing the price, the
offer wording or the pages (KW-A1). The questions, plan, walkthrough and pack.

## When you finish
Commit on `build/kw-a8` (never commit `node_modules` or `.local-stack`). Report: what you changed, exact check results,
what you saw in the by-hand run, every July bug a real run exposed and how you fixed it, and what remains unproven until
a hosted run.
