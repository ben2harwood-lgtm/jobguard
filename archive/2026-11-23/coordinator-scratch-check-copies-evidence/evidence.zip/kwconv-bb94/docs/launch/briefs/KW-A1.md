# KW-A1: the membership offer page

Read `docs/launch/LAUNCH_RULES.md` first. Your worktree is on branch `build/kw-a1`, cut from `launch/skeleton`.

## Goal
The home page and the pricing page sell one thing: a household membership whose promise is first-phone set-up. They list
only what works in the skeleton. Everything that is not part of the skeleton is switched off.

## Start from
- The single buy box built on 9 Nov: `git show codex/kw-f1:components/BuyBox.tsx`, `codex/kw-f1:lib/offer.ts`,
  `codex/kw-f1:tests/founding-offer.test.tsx`. Re-apply that shape here. Its wording is dead (£99, founder check, three
  working days, first 30 families, 30 November): none of it may survive.
- `app/page.tsx`, `app/pricing/page.tsx`, `app/checkout/[tier]/page.tsx`, `components/SiteHeader.tsx`,
  `components/SiteFooter.tsx`, `lib/pricing.ts`, `lib/checkout.ts`, `lib/brand.ts`.

## Done when
1. **One offer, in one file.** `lib/offer.ts` holds every customer-facing offer string. Draft wording (Ben approves it later;
   keep it exactly unless it breaks a rule):
   - Headline: "Giving a phone this Christmas? Know what to set, check and say before they unwrap it."
   - What it is: "One household membership. Answer a few questions and get your first-phone plan straight away: what to
     set up, what to check and what to agree, in order, before you hand the phone over."
   - What you get today (exactly these three, nothing else):
     1. "A first-phone plan made from your answers, on screen at once."
     2. "Step-by-step set-up for iPhone and Android. Each step links to Apple's or Google's own instructions and ends
        with a check you run yourself."
     3. "A printable pack: your dated checklist, a family agreement, conversation openers and a 30-day re-check date."
   - Also included: "Anything we add during your year is included."
   - Price line: "{price} for a year, for the whole household. It does not renew by itself." ({price} from the setting.)
   - Refund line: "14-day refund if it isn't for you."
   - Data line: "We ask for age band, devices and apps only. No child names, no school, no screenshots. Your answers and
     your plan stay on your own device."
   - Not line: "It isn't monitoring software, emergency help, or a guarantee."
   - Boundary: "Prevention planning, not emergency help", followed by links to NSPCC (`https://www.nspcc.org.uk/`) and
     CEOP (`https://www.ceop.police.uk/ceop-reporting/`) and to `/emergency`. This sits directly beside every buy button.
   - Buy button: "Get the membership, {price}" to `/checkout/system`.
   - Second button: "Answer the questions first, free" to `/start`.
2. **Price is one setting.** `lib/pricing.ts`: the membership is 7900 pence for 12 months. Set the renewal amount to the
   same 7900 so "optional renewal at the stated price" is true. Nothing else in the app may hold the price. Keep the tier
   ids (`system`, `stay-current`) so the billing code and its tests keep working; update fixtures that hard-code 4900/2900.
3. **Home page (`/`)** is a short offer page built from `lib/offer.ts`: headline and what it is with the buy box; the
   three things you get today; three plain steps (answer the questions, get your plan, set up and print); the data line and
   the not line; the price with the buy box again. Remove the July sample report (it shows Snapchat, Instagram and
   blackmail advice the skeleton does not contain), the "editor-reviewed" claims, the three tiers and concierge.
4. **Pricing page (`/pricing`)** shows exactly one offer box (`data-offer`), one buy button, the price, the three things,
   the refund line and the boundary line. No second tier, no add-ons.
5. **Checkout hand-off (`/checkout/system`)** is labelled "Household membership", shows the price from the setting, and
   keeps its honest "not open yet" state when no payment set-up exists. `/checkout/stay-current` is not linked anywhere.
6. **Launch list.** Add `lib/launch.ts` exporting the list of path prefixes that are part of the skeleton, and a root
   `middleware.ts` that answers 404 for any other page unless `LAUNCH_ALL=1` is set. The list at this piece: `/`,
   `/pricing`, `/start`, `/checkout/system`, `/sign-in`, `/auth`, `/api/billing`, `/emergency`, `/terms`, `/privacy`,
   `/library` (hub only), `/library/first-phone`, `/library/family-agreement`. Static files and Next's own paths must keep
   working. Do not remove any switched-off page or its tests.
7. **Header and footer** link only to pages on the launch list: home, pricing, your account (`/sign-in`), emergency, and
   the primary button "Start" to `/start`.
8. **Name is one setting.** No file under `app/` or `components/` that is on the launch list contains the literal word
   "Keepwise"; they use `brand.name`. Add a test that fails if one does.
9. **Tests.** Replace the founding-offer test with a membership-offer test: pricing shows one offer and one buy button to
   `/checkout/system`; home and pricing carry the headline, the price from the setting, the boundary line and both
   links; none of the dead wording or banned words (rule 4) appears; a switched-off path is refused and a listed one is
   served by the launch-list function.
10. The three checks in rule 11 pass. Look at `/`, `/pricing` and `/checkout/system` yourself at 375px wide with
    `npm run dev` (port 3101) and fix anything that overflows.

## Out of scope
The questions and plan (KW-A2), the walkthrough and pack (KW-A3, KW-A4), sign-in and unlock (KW-A8), terms and privacy
wording (KW-D2). Leave `/start` as it is; KW-A2 rebuilds it.

## When you finish
Commit on `build/kw-a1` with a conventional subject, the piece id and how you tested. Report: what you changed, the exact
check results, anything you could not do, and any old test you updated and why.
