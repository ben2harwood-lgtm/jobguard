# KW-D2P: terms and privacy pages from the draft, and a phone-width menu

Read `docs/launch/LAUNCH_RULES.md` first. Your worktree is on branch `build/kw-d2p`, cut from `launch/skeleton`.
`node_modules` is its own folder: run `npm ci` first.

## Why
Two independent checks found the same gaps on pages a customer can reach:
- `/terms` still says "You pay for the Household System once. Stay Current renews each year" and `/privacy` still says
  "guidance our editors have reviewed". Both are false for the membership now on offer.
- At phone width the header shows only the "Start" button, so a parent on a phone cannot reach Pricing, Your account or
  Emergency from the top of the page.

## Build
1. **Seller details as settings.** New `lib/legal.ts` reading `NEXT_PUBLIC_LEGAL_NAME`, `NEXT_PUBLIC_LEGAL_ADDRESS`,
   `NEXT_PUBLIC_ICO_NUMBER` and `NEXT_PUBLIC_VAT_LINE` (optional), plus `brand.supportEmail` from `lib/brand.ts`. Export
   `legalReady()`: true only when the name, address and a support email that is not the placeholder are set. Add the four
   names to `.env.example` and to the settings table in `docs/launch/HOSTED_SETUP_NOTES.md`.
2. **`/terms`.** Replace the page body with the twelve numbered sections under "Terms, in plain English" in
   `docs/launch/KW-D2_TERMS_PRIVACY_REFUND_DRAFT.md`, word for word, with these substitutions: `[NAME]` is `brand.name`;
   the price comes from `lib/pricing.ts`; `[LEGAL NAME]`, `[ADDRESS]`, `[VAT LINE]` come from `lib/legal.ts`; `[EMAIL]` is
   `brand.supportEmail`. The refund paragraph is the one under "Refund wording". Drop the bracketed note in section 12.
3. **`/privacy`.** The same for the sections under "Privacy notice, in plain English". For the bracketed provider names,
   add settings `NEXT_PUBLIC_HOSTING_PROVIDER`, `NEXT_PUBLIC_DATA_PROVIDER` and `NEXT_PUBLIC_EMAIL_SENDER`; when one is
   unset, write "our hosting provider", "our database and sign-in provider" and "our email sender". Leave out the
   "[TO CONFIRM AT BUILD]" paragraph about counting visits: `/api/events` is switched off, so no visits are counted, and
   the page must say nothing about it. Keep the retention periods as drafted and drop the bracketed "Confirm" notes.
4. **Draft banner.** While `legalReady()` is false, both pages show one clear line at the top, "Draft. These terms are
   not yet in force.", and any missing detail renders as "to be confirmed". When it is true the banner goes. The
   checkout hand-off page must not offer a way to pay while `legalReady()` is false: export a single
   `canSell()` from `lib/legal.ts` for the payment piece to use, and add a test for it. Do not change
   `lib/billing/*` or `lib/checkout.ts` here.
5. **Footer line.** In `components/SiteFooter.tsx` replace the default note with: "{brand.name} is planning help for
   parents. It is not monitoring software, emergency help or a guarantee, and it is not a substitute for the police,
   social services, a school's safeguarding lead, or legal or medical advice."
6. **Phone-width menu.** At 720px and below the header shows the name and a "Menu" button; pressing it shows Home,
   Pricing, Your account, Emergency and Start as a simple list (a `<details>` element or a small client component; works
   with the keyboard; no new dependency). Above 720px the header is unchanged.
7. **No visit counting at launch.** `components/Analytics.tsx` (rendered by `app/layout.tsx`) posts a "visit" to
   `/api/events` and keeps a random number in the browser's session storage. `/api/events` is switched off, so every
   first page view logs a 404, and the privacy notice says nothing is counted. Make the component do nothing at all (no
   storage, no request, no script) unless `/api/events` is on the launch list in `lib/launch.ts`; leave the component and
   the route in place. Add a test.
8. **Tests.** `/terms` and `/privacy` render the draft text with the settings substituted; none of the July wording
   ("Household System", "Stay Current", "editors have reviewed", "Concierge") remains on either page; the banner shows
   when details are missing and is gone when they are set; `canSell()` follows `legalReady()`; the header renders all
   five links inside the phone menu; the banned-word test in `tests/membership-offer.test.tsx` also covers `/terms` and
   `/privacy`.
9. The three checks in rule 11 pass. Look at `/terms`, `/privacy` and the menu yourself at 375px (`npx next dev -p 3101`).

## Out of scope
Changing the meaning of the draft wording (it is Ben's to approve), cookie banners, the offer pages, sign-in, payments.

## When you finish
Commit on `build/kw-d2p`. Report: what you changed, exact check results, what you saw at 375px, and any old test you
updated and why.
