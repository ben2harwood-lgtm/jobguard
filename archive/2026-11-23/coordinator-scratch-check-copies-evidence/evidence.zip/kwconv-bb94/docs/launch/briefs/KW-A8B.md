# KW-A8B: one payment setting (off, test, live), built dark

Read `docs/launch/LAUNCH_RULES.md` first. Your worktree is on branch `build/kw-a8b`, cut from `launch/skeleton` after
KW-A8 landed (sign-in, the local stack, `npm run test:db`, and `supabase/migrations/kwa8_intent_amount.sql` are there).
Run `npm ci` first; this worktree has its own `node_modules`.

## Why
The July payment code works only in the payment provider's test mode and switches itself off when `NODE_ENV=production`
(`lib/billing/fulfilment.ts` lines 70, 88, 100, 127, 149, 196 to 213, 278; `kw005_bind_session` in
`supabase/migrations/kw005_billing_events.sql` line 90). So on a hosted build nobody can pay, not even in a rehearsal.
Ben must be able to open payments by changing settings in the hosting account, with no code change, in two moves: a
rehearsal in test mode on the hosted address, then live.

## Goal
One setting, `BILLING_MODE`, with three values. Default is off. Nothing in this piece contacts the payment provider:
it is built and proven with fixtures and the local database only.

## Build
1. **The setting.** `BILLING_MODE` unset or `off`: checkout shows the honest "not open yet" page and the webhook answers
   503, as today. `test`: needs an `sk_test_` key; every provider object must say `livemode: false`; session ids are
   `cs_test_`. `live`: needs an `sk_live_` key (or a restricted `rk_live_` key); every object must say `livemode: true`;
   session ids are `cs_live_`. A key that does not match the mode, a missing webhook secret or a missing price id means
   off. `NODE_ENV=production` no longer blocks payments by itself; only the setting does. Keep one place that reads the
   mode; every existing test-mode check becomes a check against the mode.
2. **Never mixed.** In `test` a live object or id is refused; in `live` a test object or id is refused. A webhook event
   whose `livemode` does not match the mode is refused before anything is written.
3. **Database.** A new migration (do not rewrite earlier ones; add it to `SQL_FILES` in `scripts/local-stack/config.mjs`)
   lets `kw005_bind_session` accept `cs_live_` ids as well as `cs_test_`. Nothing else in the database learns about modes.
4. **A price change must strand nobody.** `parseBillingEvent` and `boundIntent` in `lib/billing/fulfilment.ts` (and the
   unpaid intent checks in `nativeCheckoutSession` and `prepareCheckout`) compare an amount with today's price. Compare
   with the amount stored on that purchase's own intent row instead. After a price change: a refund of an old-price
   purchase still locks the account; a "paid" event that arrives for a checkout started at the old price is still
   accepted and unlocks (the customer was charged that amount); and an adult who holds an unpaid intent at the old price
   can start again at today's price instead of meeting `intent_recovery_required` (the independent check of KW-A8 found
   all three cases). A new purchase is always made at today's price from `lib/pricing.ts`. Add one line on this to
   section 7 of `docs/launch/HOSTED_SETUP_NOTES.md`.
5. **The checkout page** (`app/checkout/[tier]/page.tsx`). Off: unchanged. Test: a clear line "Test mode. No real money
   is taken." and the continue button. Live: the price, "It does not renew by itself", the refund line from
   `lib/offer.ts`, the boundary line with the NSPCC and CEOP links (`components/BuyBox.tsx` has it), links to `/terms`
   and `/privacy` with "By continuing you agree to the terms", and the continue button. A signed-out adult is sent to
   sign in first and comes back here.
6. **After paying.** The provider returns the buyer to `/library`. If the paid event has not arrived yet, the locked
   view for a signed-in adult who has just returned from checkout says "We are confirming your payment. This page
   opens as soon as it is confirmed; reload in a moment." (use a return marker in the address, not a guess). Never show
   member content before the paid event is stored.
7. **Tests.** Fixtures only. Off, test and live each behave as in items 1 and 2, including with `NODE_ENV=production`;
   mismatched key, object or id is refused in both directions; the webhook signature check is unchanged; the refund of
   an old-price purchase locks the account (`npm run test:db`, with the price changed between purchase and refund); a
   `cs_live_` id binds and a malformed id does not.
8. **Notes.** Add a "Payments" section to `docs/launch/HOSTED_SETUP_NOTES.md`: exactly what must exist in the payment
   provider's account (one product, one one-off price in pounds, one webhook address and the event types the code
   handles), every setting name and where its value comes from, the order for a test-mode rehearsal and then live, and
   what only a real rehearsal can prove. Update the settings table.
9. The three checks in rule 11 pass and `npm run test:db` passes.

## Out of scope
Renewals and the second tier (leave `stay-current` code alone and unlinked), a self-service refund button, letting a
refunded account buy again, tax handling, any real provider call.

## When you finish
Commit on `build/kw-a8b` (never `node_modules` or `.local-stack`). Report: what you changed, exact check results, a
table of every place a mode decision is made, anything in the July code you had to change beyond this brief and why,
and what remains unproven until Ben's rehearsal.
