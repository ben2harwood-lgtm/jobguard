# KW-A3 and KW-A4 (slim): the member set-up steps and the printable pack

Read `docs/launch/LAUNCH_RULES.md` first. Your worktree is on branch `build/kw-a3a4`, cut from `launch/skeleton` after
KW-A1 and KW-A2 landed. `lib/first-phone/facts.ts` and `lib/first-phone/plan.ts` (KW-A2) hold every fact and the plan;
the parent's four choices are in `localStorage` under `first-phone:choices:v1`.

## Goal
A member follows the set-up for their two phones one step at a time, runs a check after each, and prints one pack to
keep: the dated checklist, a family agreement, conversation openers and a 30-day re-check date.

## KW-A3: set-up steps (`/library/first-phone`, members only)
1. Rebuild `components/FirstPhoneWalkthrough.tsx` to show the steps from `buildFirstPhonePlan(choices)` instead of its own
   hard-coded list. Keep its three stages ("Set up today", "Agree together", "After three days") and the wording of the
   two conversation stages exactly as they are.
2. With no saved choices, ask the parent to answer the questions first (link to `/start`). The pairing note from the plan
   sits at the top, before any step.
3. Every set-up step shows, in this order: what it is for; how to do it; the link "Open Apple's instructions" or "Open
   Google's instructions" (the step's `source`); "What this cannot do" (`limit`); and "Check it worked" (`check`). A step
   with no confirmed `how` shows the maker's link alone. Add nothing that is not in `facts.ts`.
4. Each step has a link "My screen looks different" that opens the step's `help` page (the maker's own). Never offer
   steps of our own as an alternative.
5. Ticking a step stores the date. A ticked step reads "Marked complete by you on 14 November 2026". Replace the July line
   "Checked and completed … next review due …" with "Marked complete by you on {date}. Re-check on {date + 30 days}." Keep
   the sentence that this is not a certification or a guarantee. Show progress as "3 of 9 marked complete"; remove the
   percentage.
6. Under the steps: "Sources last checked {date}".
7. Progress stays in `localStorage` only (keep the existing key so nobody loses July ticks; migrate old data forward).

## KW-A4: the printable pack (`/library/first-phone/pack`, members only)
One page, built in the browser from the saved choices and ticks, that prints cleanly on A4 (print stylesheet: no header,
footer or buttons; black on white; no page break inside a section). It holds, in order:
1. **Your first-phone checklist.** Every step for the family's pairing, its tick state and date ("Marked complete by you
   on …" or an empty box), and the pairing note.
2. **Our family agreement.** Pre-filled, with tick boxes the parent can untick before printing, and signature lines for
   the child and the adults. Use exactly these lines.
   The child's side:
   - "If something on my phone worries or upsets me, I will tell you."
   - "We check new apps together before they go on."
   - "Downloads, spending and payment links are ask-first."
   - "If someone pressures me to keep a secret or move to a private chat, I will pause and tell you."
   - "My phone charges outside my bedroom overnight."
   - One line per chosen app: "{App}: we set it up together and look at its privacy settings together."
   The adults' side:
   - "You will not be in trouble for telling us about a problem, even if a rule was broken."
   - "We will explain every setting we turn on and why."
   - "Our phones charge outside bedrooms overnight too."
   - "We will look at this agreement again together on {re-check date}."
3. **Conversation openers.** The titles from the walkthrough's "Agree together" and "After three days" stages.
4. **30-day re-check.** The date, and: "On this date, run each step's check again. Settings can change after a software
   update."
5. **If something is happening now.** The block from `lib/signpost.ts`, unedited, after calling `verifySignpost()`.
A "Print or save as PDF" button calls the browser's print. Nothing typed or ticked on this page is sent or stored
anywhere except the tick state already in `localStorage`.

## Member home and launch list
- `/library` for a member shows three cards only: "Your plan" (`/plan`), "Set-up steps" (`/library/first-phone`) and
  "Your printable pack" (`/library/first-phone/pack`). Leave the July hub code in place behind the launch list.
- Launch list: add `/library/first-phone/pack`; remove `/library/family-agreement` (the July AI agreement is not part of
  the skeleton; its page and tests stay).

## Tests
- For each pairing the walkthrough renders every plan step with its source link, limit and check, and the help link.
- A ticked step renders "Marked complete by you on" with its date; the percentage is gone.
- The pack renders all five sections for a sample family; the agreement lines match this brief word for word; the
  signpost block equals `SIGNPOST` and `verifySignpost()` is called.
- Both pages redirect a non-member (reuse the existing guard and its test style).
- Neither page's source imports `lib/events` or `lib/db` or calls `fetch`.
- The three checks in rule 11 pass. Walk the steps and print-preview the pack yourself at 375px wide.

## Out of scope
New facts (only `facts.ts`), the course, the July library, sign-in and payments, terms and privacy.

## When you finish
Commit on `build/kw-a3a4`. Report: what you changed, exact check results, what you saw in the by-hand run, and any old
test you updated and why.
