# DRAFT. Terms, privacy and refund wording for the launch skeleton (KW-D2)

**DRAFT, 11 Nov 2026. Not approved, not legal advice, not published.** Written for a yearly household membership, starting
from `86_AI_Safety_Course_Founding_Pilot_Terms_Privacy_Drafts.md`. Square brackets are blanks only Ben can fill. Whether a
solicitor reads this before the first sale is Ben's call; the July rule said one should.

## Blanks for Ben

| Blank | What is needed |
|---|---|
| [NAME] | The product name: Keepwise (Ben, 14 Nov), filled in from the brand setting |
| [LEGAL NAME] | The company or person that sells it |
| [ADDRESS] | A contact address (the law requires one for online sales) |
| [EMAIL] | A support address on the new web address |
| [ICO NUMBER] | The seller's data protection registration with the ICO, if it has one. If not, registering is a short online form with a yearly fee, and it is Ben's to do |
| [VAT LINE] | "Prices include VAT" if the seller is VAT registered; otherwise leave the line out |

## Refund wording (shown beside the price and in the terms)

> **14-day refund.** You get access straight away. If it isn't for you, email [EMAIL] within 14 days of paying and we
> will refund you in full, whether or not you have used it. A refund closes the membership.

Choice made here: the refund applies even after the parent has used the site. That is more generous than the law
requires and avoids the tick-box about losing cancellation rights that instant digital access otherwise needs. Until
the self-service refund button is built (after launch), a refund is one email to Ben and one click in the payment
provider.

## Terms, in plain English

**1. Who we are.** [NAME] is provided by [LEGAL NAME], [ADDRESS]. Contact: [EMAIL].

**2. What you are buying.** One membership for your household. Today it gives you: a first-phone plan made from your
answers; step-by-step set-up for iPhone and Android with links to Apple's and Google's own instructions; and a printable
pack with a checklist, a family agreement, conversation openers and a re-check date. Anything we add in the 12 months
after you pay is included.

**3. Who it is for.** Adults aged 18 or over who are parents or carers. Nothing on [NAME] is for a child to use, and no
child account is created.

**4. Price and payment.** £79, paid once. [VAT LINE] Payment is taken by Stripe; we never see or hold your card details.

**5. How long it lasts.** Your membership runs for 12 months from the day you pay. It does not renew by itself and we
will not charge you again. If you want another year you can choose to renew at the price shown then.

**6. Refunds.** As above: 14 days, in full, for any reason.

**7. What [NAME] is not.** It is not monitoring software, not emergency help, not legal, medical or safeguarding advice,
and not a guarantee about any child, phone or app. Phones and apps change. Each instruction shows the date it was last
checked and links to the maker's own page; where the two differ, follow the maker's page.

**8. If something is happening now.** Do not wait for us. If a child is in immediate danger call 999. For other urgent
worries use the free page at /emergency, which points to the NSPCC, CEOP and Childline. We cannot advise on a live
situation.

**9. Your account.** You sign in with a link sent to your email address. The membership is for your household; please
do not share your sign-in outside it.

**10. Your answers.** The answers you give and your plan are kept in your browser on your own device, not on our servers.
If you clear your browser's data they are gone, so download or print your plan if you want to keep it.

**11. Changes.** We may improve or correct the content. If we ever stop the service during your 12 months we will refund
the unused part.

**12. Your legal rights.** Nothing in these terms takes away rights you have under UK consumer law. These terms are
governed by the law of England and Wales. [Confirm if the seller is based elsewhere in the UK.]

## Privacy notice, in plain English

**Who is responsible.** [LEGAL NAME], [ADDRESS], [EMAIL]. ICO registration: [ICO NUMBER].

**What we hold about you (the adult).**
- Your email address, so you can sign in.
- Your purchase: the amount, the date, the payment provider's reference and whether it was refunded.
- That you ticked "I am an adult signing in to my own account".
- Ordinary technical records our hosting keeps for security, such as the time of a request.

**What we never ask for or hold.** A child's name, date of birth, school, photos, messages or account names. Your answers
to the questions (age band, phones and apps) and your plan stay in your browser on your device. We cannot see them.

**Cookies.** One cookie that keeps you signed in. No advertising or tracking cookies.
[TO CONFIRM AT BUILD: whether page visits are counted at launch, and if so say here that it is done without cookies and
without storing who you are.]

**Why we hold it and the legal basis.** To give you the membership you paid for (contract). To keep payment records the
tax rules require (legal obligation). To keep the site secure (legitimate interests). We send no marketing emails.

**Who else handles it for us.** Stripe (payments). [HOSTING PROVIDER] (runs the site). [DATABASE AND SIGN-IN PROVIDER]
(holds your account and sends the sign-in email, through [EMAIL SENDER]). Some of these companies process data outside
the UK under the standard safeguards. [Confirm each provider's name and location once Ben has chosen them.]

**How long we keep it.** Your account: until you ask us to delete it, or 24 months after your membership ends. Payment
records: six years, as tax rules require. [Confirm periods.]

**Your rights.** You can ask to see, correct or delete what we hold, and you can complain to the Information
Commissioner's Office (ico.org.uk) if you are unhappy with how we handle it. Email [EMAIL].

**Children.** [NAME] is for adults. We do not knowingly collect any child's personal data.

## Before this is published

1. Ben fills the blanks and approves the wording.
2. The site's `/terms` and `/privacy` pages are replaced with the approved text (a small build job once approved).
3. The pages still say "draft" until then, and the buy button stays on the honest "not open yet" page.
