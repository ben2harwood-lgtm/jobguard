# Full-local rehearsal on this Mac

Development only, using fictional household choices and adult addresses ending `@example.test`. Keep the app, database and stand-in on loopback. No real email, payment provider, family data, deployment or public sharing is part of this rehearsal. Production self-service refunds have not been added.

## Start

Use the existing installed dependencies. If dependencies are absent, stop and arrange the approved setup separately.

1. In terminal 1, run `APP_URL=http://localhost:3101 node scripts/local-stack/start.mjs`. This starts real local PostgreSQL on port 54329 and the stand-in on `127.0.0.1:54321`.
2. Copy **all** settings printed by the stack into `.env.local` (git ignored), including fictional seller settings, `LOCAL_BILLING=1` and `BILLING_MODE=off`. Keep every Stripe and email credential blank. Do not set `LAUNCH_ALL` or `LIBRARY_PREVIEW`. Only `@example.test` accounts can use the synthetic billing adapter. A production process refuses it even if the flag leaks into its environment.
3. In terminal 2, run `npx next dev --hostname 127.0.0.1 -p 3101`. Open `http://localhost:3101`. Restart the dev server after changing environment settings or if an edit does not appear.

For another port, match `APP_URL` and the dev-server port exactly: for example, `APP_URL=http://localhost:3103 node scripts/local-stack/start.mjs` and `npx next dev --hostname 127.0.0.1 -p 3103`. Add `--reset` to the stack command only when you intend to discard this disposable fictional database and outbox.

## Rehearse access, purchase and member content

1. While signed out, open `/library` and a member deep link such as `/library/platforms`. Confirm access is locked. `/checklist` and `/sample` are public; the sample uses fixed fictional choices through the existing pairing-aware First Phone assembler, without reading or overwriting browser answers.
2. Open `/checkout/system`, follow adult sign-in, enter `parent@example.test` and tick the consent box. In the same browser, open `http://127.0.0.1:54321/outbox` and follow the newest sign-in link. No email is sent. Before payment, `/library` remains locked.
3. Continue to test checkout. It binds one synthetic purchase and takes you to `/account`, without following a Stripe URL. Choose **Complete fictional payment**. Reload `/library` and confirm paid access opens through the existing database contract.
4. In `/account`, check the original amount, capture date and stored paid-through date. Print the rehearsal receipt and download the account/purchase export. Stored paid-through dates are bookkeeping. The separate membership end date is derived from captured payment times only when expiry is explicitly enabled; see below.
5. Follow the member-home links to `/library/courses`, `/library/tools`, `/library/practice`, `/library/platforms`, `/library/household` and `/library/whats-changing`. Expect 15 active courses with 45 lessons (the held course stays unavailable), 10 tools and 30 fictional conversations with 60 prewritten branches. The app index has one interactive search over exactly 50 guides: the unchanged 19 MDX guides plus 31 prepared additions. The hub's catalogue component provides one navigation link to that index.
6. Search for `Xbox`: the existing console guide and prepared Xbox guide both appear. Add guide-age coverage `5-10`: only the existing console guide remains; prepared additions do not invent age coverage. Reset to see 50 matches. Search for an unsupported name to see a coverage gap. Source consultation dates are separate from source update dates; unknown ratings, provider ages, review dates and device tests stay unknown. Queries stay in page memory.
7. Use fictional answers through `/start` and `/plan`, then open the First Phone walkthrough and printable pack. Exercise the member tools, conversation choices and household planning. Use the existing member export/import and clear controls with fictional data only. No held content is cleared by navigation, and member content/assets remain subject to access guards.
8. Download First Phone browser answers through `/plan` before clearing them. Account privacy controls clear only those answers and completion ticks; they do not delete other browser tools, account or financial data. Signing out clears this browser's session through the existing auth route. Confirm member access is locked again after sign-out.

## Rehearse a fictional refund

Sign back in to the paid fictional account. Within 14 days, choose **Request fictional full refund** in `/account`. Status becomes pending; a repeated request stays pending without a financial/grant write. Choose **Confirm fictional refund** to simulate provider completion through `kw005_apply_event`. Status becomes confirmed and `/library` closes. Repeated confirmations and late paid events must not regrant access. A refund is final for that address; use a fresh `@example.test` address for another purchase rehearsal.

A pending request survives stack restart in `.local-stack/outbox/refund-<intent>.json`; confirmed status comes from the database. Resetting the disposable stack removes its data. This two-step development adapter returns no real money. Production self-service provider refunds remain disabled.

## Stop and verification handoff

Stop terminals 1 and 2 with Ctrl+C. Check `lsof -i :3101 -i :54321 -i :54329` for remaining listeners; investigate any remaining process before another rehearsal.

Run checks only with valid shared host/resource observations and existing admission controls. The focused integration checks are:

```sh
npx vitest run tests/catalogue.test.ts tests/platform-explorer.test.tsx --maxWorkers=1 --minWorkers=1 --no-cache
npx tsc --noEmit --incremental false
```

The installed runner is Vitest 2; the explicit minimum and maximum keep this run to one worker. Typecheck disables incremental output so it writes no build metadata. The coordinator owns broader runtime verification, including `npm run content-lint`, member/account coverage, local database tests (`npm run test:db` with one worker), and loopback browser checks. These commands and rehearsal steps describe checks to perform, not evidence that they passed.

## Membership expiry and renewal catch-up

Ben decided the price and one-year buy-again terms on 15 November. The approved KW-A8D migration is included unchanged after `kwa8b_billing_mode.sql`; the stack applies it through the existing ordered migration loader. Existing fictional databases receive the additive migration on restart; no reset is required merely to add it.

`MEMBERSHIP_ACCESS_DAYS` stays opt-in and is absent from the stack's printed environment. For a separate fictional expiry rehearsal, explicitly set `MEMBERSHIP_ACCESS_DAYS=365` before starting the app (before building when using a build). Unset or invalid retains the existing non-expiring access. With the setting enabled, the verified server session derives access from the base purchase time and unrefunded renewal payment times; all library guards use that end. Renewal opens within 30 days of expiry or after expiry, at the same stated price. It never renews automatically. Stored intent period dates are bookkeeping, not this aggregate access end.

The offline `/api/billing/local` adapter continues to support **first purchase and full refund only**. `/checkout/stay-current` is admitted by middleware only while expiry is enabled, but offers no provider checkout while billing is off. Fictional renewal through the account controls is unavailable and unverified; do not enter provider credentials for this local task. Focused tests cover expiry, renewal allocation with fake rows, pending/refused checkout and terminal-payment handling. The combined real-PostgreSQL first-purchase/refund and renewal tests are prepared in `tests-db/local-stack.test.ts`; their execution requires the coordinator's heavy gate. No combined database or browser pass is claimed here.

## Contract and production blockers

- **Sale/provider activation:** this remains an unpublished local candidate. Provider billing, real email and release remain off; the existing tax/cancellation and release gates still apply. No new pricing or erasure policy is introduced.
- **Erasure and audit:** read `102_M0_Data_Inventory_and_Gate_B0_Scope.md` (financial retention and assembly-log de-linking), `docs/chat-build/KW-002_DATA_CONTRACTS.md`, queue KW-006/KW-024, and the actual `kw002`/`kw005` migrations. There is no installed account-erasure RPC preserving accounting records and separating editorial/personal audit data. Deleting `users` cascades purchases/billing intents and can conflict with event references. The account therefore offers a scoped export and existing support route, with no fake submitted deletion request or unsafe hard delete. Retention/processor identities and actual backup/de-linking policy remain required inputs.
- **Real provider refund:** no real provider mutation was added. The authenticated endpoint refuses unless the explicit development loopback stand-in is selected. Existing native webhooks continue to accept only verified full successful refunds; pending and partial native refunds remain held. Before provider activation, implement/verify a durable owned refund-request contract and provider idempotency/reconciliation under separate authorization.
- **Transactional email:** sign-in stays in the local outbox. Purchase/refund state is visible in the account; no payment/refund email delivery or delivery claim is added.
