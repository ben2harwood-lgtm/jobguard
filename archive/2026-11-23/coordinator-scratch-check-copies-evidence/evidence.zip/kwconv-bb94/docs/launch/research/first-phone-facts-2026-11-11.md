# First-phone facts, checked against Apple's and Google's live help pages

Checked: 2026-11-11. Every fact below was read from the live official page on that date (pages fetched directly; pages that
only load in a browser were read in a browser). Nothing here comes from memory. Wording is paraphrased; menu names are
given as the page prints them.

> **Lane spot-check, 11 Nov 2026 (19:45).** The launch lane re-read eight of the cited pages itself: Apple 108806;
> Apple guide pages k6zl0kw9zbgr, jrzvk3ml3unm, azgjjn208bw9, j103x81xtz4g, new8r0p02h10 and kmp239668ukx; Google
> 7101025 and 16766047. All of these matched this file: the version 27 redesign and the Settings > Family > [child]
> route; the 90-day device condition; managing on the device with a Screen Time passcode; Family Link for a parent's
> iPhone on iOS 16 or later; Android 17 on-device controls behind a PIN. The two renames ("formerly called Downtime",
> "previously called App Limits") are stated on kmp239668ukx only, not on the two pages cited in point 1 below.

## Read this first: three things the July walkthrough does not reflect

1. **Apple rebuilt its parental controls in iOS 27.** The names and the menu route changed. "Downtime" is now part of
   **Screen Time Schedule** and "App Limits" is now **Time Allowances** (Apple states both renames). The contact controls
   that the iOS 26 guide calls "Communication Limits" appear in the iOS 27 guide as **Allowed Contacts**, and there is a
   new **Ask to Browse**. A child's settings are now reached at **Settings > Family > [child's name]** on
   the parent's device. The new controls only appear once every device the family has used in the last 90 days is on
   version 27; otherwise the family stays on the previous (iOS 26) Screen Time, with the old names.
   Source: https://support.apple.com/en-gb/guide/child-safety/k6zl0kw9zbgr/web and
   https://support.apple.com/en-gb/guide/child-safety/jrzvk3ml3unm/web
2. **Apple has a dedicated guide for this job**, titled Apple Devices for Kids and Families:
   https://support.apple.com/en-gb/guide/child-safety/welcome/web
3. **Android 17 has parental controls built into the phone's Settings, locked by a PIN**, which need no parent app and no
   parent phone. Google's pages also say a child under 18 needs a parent's approval to stop Family Link supervision.
   Source: https://support.google.com/android/answer/16766047?hl=en-GB and
   https://support.google.com/families/answer/7106787?hl=en-GB

Conventions: `>` in a menu path means "then tap". Google's help pages print arrows as icons, so the `>` is mine; the
labels are theirs. Apple's support articles show a "Published Date"; Apple's guide pages and Google's help pages show no
date, so none is recorded for them.

---

## PART A. The four pairings, and child accounts

### Pairing 1: parent iPhone, child iPhone

**A1. Where the settings live and what the parent can do**
Source: https://support.apple.com/en-gb/108806 (Published Date: October 28, 2026) and
https://support.apple.com/en-gb/guide/child-safety/m03gpzj5tk26/web
Checked: 2026-11-11
Says: Once Family Sharing is set up and the child's own Child Account is in the family group, the family organiser or a
parent/guardian sets up and changes everything from their own iPhone, iPad or Mac at Settings > Family > [child's name].
The settings sync to the child's devices. From there the parent can: set a schedule and time allowances; choose apps and
people that are always allowed; approve downloads, purchases and new websites; allow or block named apps and websites;
set age ratings for content; choose who the child can call and message; turn on checks for sensitive images; lock it
all with a Screen Time passcode; see activity; pause the phone or allow unlimited use for a while. Requests from the
child arrive in Messages on the parent's device.
Limit: The new controls need version 27 on every family device. Not every control exists on every Apple device. Some
controls are on by default by age and region and cannot be removed. The pages checked give no list of things a parent
cannot see (for example message content); Apple simply does not describe any such viewing tool.
Status: CONFIRMED

### Pairing 2: parent Android, child iPhone

**A2. Apple only describes Apple devices on the parent's side**
Source: https://support.apple.com/en-gb/108806 ; https://support.apple.com/en-gb/102617 (Published Date: September 16,
2026) ; https://support.apple.com/en-gb/118308 (Published Date: October 01, 2026)
Checked: 2026-11-11
Says: Apple says parental controls are set up and managed from the parent's own iPhone, iPad or Mac. The steps for
creating a Child Account are given only for iPhone/iPad and for Mac. Apple's requirements page lists Family Sharing as
available on iPhone, iPad, Mac, PC and Apple TV. No page describes an Android app, an Android route, or a parent using
an Android phone.
Limit: Apple never says "you must own an Apple device" in so many words; it just documents no other way.
Status: CONFIRMED

**A3. The documented fallback is to set things on the child's iPhone itself, locked with a Screen Time passcode**
Source: https://support.apple.com/en-gb/108806 ; https://support.apple.com/en-gb/guide/child-safety/jrzvk3ml3unm/web ;
https://support.apple.com/en-gb/guide/iphone/iphbfa595995/ios ; https://support.apple.com/en-gb/guide/iphone/iph272b4c4bd/ios
Checked: 2026-11-11
Path (on the child's iPhone, iOS 27): Settings > Screen Time, then Screen Time Schedule, Time Allowances or Manage Screen
Time > Turn On App & Website Activity. Content: Settings > Screen Time > Content & Privacy Restrictions. Lock: Settings >
Screen Time > Passcode & Management > Lock Screen Time Settings, then enter a four-digit passcode twice.
Says: Apple recommends managing from the parent's device but states Screen Time can also be managed directly on the
child's device using a Screen Time passcode. The upgrade page says devices not on the newest controls can be managed
on the device itself with the passcode. When a passcode is set on the device itself, Apple advises adding a Screen Time Passcode
Recovery (an Apple Account that can reset the passcode).
Limit: If Family Sharing is managing the child's account, the passcode has to be set and reset on the parent's device,
not the child's. The iOS 27 on-device pages are written for an adult's own phone and send parents to the family guide.
Status: CONFIRMED

**A4. A child under 13 still needs a Child Account inside a Family Sharing group**
Source: https://support.apple.com/en-gb/126788 (Published Date: October 26, 2026) ; https://support.apple.com/en-gb/108380
(Published Date: October 14, 2026) ; https://support.apple.com/en-gb/guide/child-safety/grzxvj0yrbnm/web ;
https://support.apple.com/en-gb/guide/iphone/iphfd0b65920/26/ios/26
Checked: 2026-11-11
Says: In the UK a child under 13 cannot have an Apple Account without a parent's help and consent and must be in a
Family Sharing group. The organiser must be an adult and sets the group up from their own device. A new iPhone can be
set up without a second device (the Set Up Without Another Device option). If a child age range is chosen at set-up, age-appropriate
defaults are applied and the phone works straight away, but to download apps or change parental controls the parent has
to finish creating a Child Account and add it to a family group. That can be started on the child's iPhone at Settings >
Connect to Family.
Limit: The iOS 26 version of the guide says a phone for a child aged 12 or under needs to be connected to a parent or
guardian's device. The iOS 27 guide does not repeat or withdraw that sentence.
Status: CONFIRMED

**A5. Web routes Apple does document (they are narrow)**
Source: https://support.apple.com/en-gb/102473 (Published Date: September 16, 2026) ;
https://support.apple.com/en-gb/guide/iphone/iph6231f621a/ios
Checked: 2026-11-11
Says: A child's date of birth can be edited by signing in to the child's account at account.apple.com. A family member's
missing device can be located with Find Devices on iCloud.com.
Limit: I found no Apple page describing a website for Screen Time, Ask to Buy, or creating a Child Account.
Status: CONFIRMED

**A6. Approvals can be given in person on the child's iPhone**
Source: https://support.apple.com/en-gb/guide/child-safety/dq4vly6fq1je/web ; https://support.apple.com/en-gb/105055
(Published Date: September 15, 2026) ; https://support.apple.com/en-gb/127512 (Published Date: October 27, 2026)
Checked: 2026-11-11
Says: Requests normally go to the parent's iPhone, iPad, Mac or Apple Watch through Messages. A parent who is with the
child can instead approve on the child's phone: for an app, open it in the App Store, tap Approve and enter the parent's
Apple Account password; for a website or more time, enter the Screen Time passcode.
Limit: Turning Ask to Buy on is only described from the parent's iPhone, iPad or Mac, and it needs the family group.
Status: CONFIRMED

**A7. Can an adult who owns no Apple device be the family organiser or finish "Connect to Family"?**
Source: none found.
Checked: 2026-11-11
Says: Apple's pages do not answer this either way.
Status: UNVERIFIED (read: 108806, 108380, 102617, 105062, 118308, 125662, the whole Kids and Families guide, and the
iPhone User Guide family pages for iOS 26 and iOS 27)

**A8. Which child controls work on the child's iPhone alone in iOS 27, with no Family Sharing?**
Source: https://support.apple.com/en-gb/guide/iphone/iphbfa595995/ios ; https://support.apple.com/en-gb/guide/iphone/iph3ff83f3b1/ios
Checked: 2026-11-11
Says: The on-device pages cover schedule, time allowances, content restrictions and a passcode. They do not say whether
Ask to Buy, Ask to Browse or Allowed Contacts can be used without a family group; every Apple page for those three
starts from the parent's device and a family group.
Status: UNVERIFIED (not stated on any page read)

### Pairing 3: parent iPhone, child Android

**A9. The Family Link parent app is available for iPhone**
Source: https://support.google.com/families/answer/7101025?hl=en-GB ;
https://support.google.com/families/answer/9055704?hl=en-GB
Checked: 2026-11-11
Says: To manage a child's Google Account the parent needs an Android device, an iPhone or iPad, or a suitable Chromebook
to run the Family Link app; parents on iPhone or iPad get it from the App Store. The child's phone must be Android (or
a Chromebook or compatible Fitbit).
Status: CONFIRMED

**A10. What the iPhone app can do, and the one limit Google states**
Source: https://support.google.com/families/answer/7039872?hl=en-GB&co=GENIE.Platform%3DiOS ;
https://support.google.com/families/answer/7103413?hl=en-GB
Checked: 2026-11-11
Says: Google's steps for screen time, schedules, app blocking, Google Play, Chrome, Search and location are written for
"the Family Link app" without separating iPhone from Android, and some include an iPhone-specific note (for example
where Location settings sits). Purchase approvals have their own iPhone page: Family Link > select child > Controls >
Google Play > "Purchases & download approvals" > Require approval for.
Limit: On an iPhone the parent can only approve a pending request for paid content from the child's device. Requests
for free content can be approved in the app (Family Link > Notifications).
Status: CONFIRMED

**A11. Which iPhone software the parent needs**
Source: https://support.google.com/families/answer/7101025?hl=en-GB (says iOS 16+) ;
https://support.google.com/families/answer/9055704?hl=en-GB (says iOS 13+) ; https://families.google/familylink/faq/
(says iOS 11 and higher)
Checked: 2026-11-11
Says: Google's own pages give three different answers.
Status: UNVERIFIED (pages conflict; iOS 16 or later is the safe one to print)

**A12. Can the iPhone app manage the child's contacts, calls and texts?**
Source: https://support.google.com/families/answer/15843584?hl=en-GB (also read with the iPhone platform switch)
Checked: 2026-11-11
Says: Every step on the page is written for the parent's Android device. It does not say the iPhone app cannot do it,
and gives no iPhone steps.
Status: UNVERIFIED

**A13. Managing from a web browser**
Source: https://families.google/familylink/faq/ ; https://support.google.com/families/answer/7101025?hl=en-GB
Checked: 2026-11-11
Says: The FAQ says parents can manage nearly all of the child's account settings and features in a browser with no app
(familylink.google.com, also reached from g.co/YourFamily). The getting-started page is more cautious: only some
settings on the web, and the app is needed to find the child's device or to manage screen time and apps remotely.
Limit: The two pages pull in different directions; treat the app as the main route.
Status: CONFIRMED (both statements are on Google's pages today)

### Pairing 4: parent Android, child Android

**A14. Where the settings live and what the parent can do**
Source: https://support.google.com/families/answer/7101025?hl=en-GB ;
https://support.google.com/families/answer/7158477?hl=en-GB ; https://support.google.com/families/answer/9116646?hl=en-GB
Checked: 2026-11-11
Says: Everything is done in the Family Link app on the parent's phone (select the child at top left, then the Screen
time, Controls and Location tabs). The parent can change some account settings, approve or block apps, set app
permissions, set daily limits, downtime and school time, lock the phone, see its location, and filter Google Play,
Chrome and Search. When the child is signed in on their Android phone all of those apply. Purchase approvals can also
be set in the Google Play app (profile picture > Settings > Family > Manage family members > [name] > Purchase approvals).
Limit: iPhones, iPads and ordinary computers cannot be supervised. School (Workspace for Education) accounts cannot be
managed. Parent and child must live in the same country.
Status: CONFIRMED

**A15. What Google says a parent cannot do**
Source: https://support.google.com/families/answer/9055704?hl=en-GB
Checked: 2026-11-11
Says: Where supervision was added to a child's existing account, the parent cannot view the child's screen remotely, see
past searches, Chrome history or YouTube watch history, see or reset the password, read emails or messages, listen to
calls, or set a new screen lock on the child's phone.
Limit: That list is given for supervision added to an existing account. For an account the parent created for an
under-13, a separate page says the parent can reset the child's password
(https://support.google.com/families/answer/7103262?hl=en-GB).
Status: CONFIRMED

**A16. Android 17 on-device controls (works for either parent phone, or none)**
Source: https://support.google.com/android/answer/16766047?hl=en-GB
Checked: 2026-11-11
Path: on the child's phone, Settings > Parental controls > Set up parental controls PIN.
Says: On a phone with Android 17 or later a parent can set a PIN of at least four digits and then set, on the phone
itself: a daily limit, downtime, app limits, blocked apps, web content filters and app store filters. A recovery
account can be added to reset a forgotten PIN. Google presents Family Link as the fuller option (school time, location,
all the child's devices) and gives steps to switch.
Limit: Needs Android 17. Cannot be turned on if the phone has more than one profile. Forgetting the PIN with no recovery
account means a factory reset. Web filters only work in the Google app, Chrome and apps that have chosen to support
them. App store filters do not apply to apps already installed.
Status: CONFIRMED

### Child accounts for an under-13 in the UK

**A17. Apple: who creates it and what it is tied to**
Source: https://support.apple.com/en-gb/126788 (Published Date: October 26, 2026) ; https://support.apple.com/en-gb/102617
(Published Date: September 16, 2026) ; https://support.apple.com/en-gb/105062 (Published Date: September 15, 2026)
Checked: 2026-11-11
Says: In the UK a child under 13 needs a parent or guardian to create the account, with consent, and the account must
sit in a Family Sharing group. The family organiser or a parent/guardian in the group creates it. A Child Account is
required under 13 and available up to 18. The adult may be asked to confirm they are an adult: in the UK by a credit
card in their name, a passport, a driving licence, a PASS proof-of-age card, or a selfie; debit cards are not accepted.
In the UK the web content filter and Communication Safety are switched on automatically for children and teens.
Status: CONFIRMED

**A18. Apple: what is tied to age 13**
Source: https://support.apple.com/en-gb/105121 (Published Date: October 27, 2026) ;
https://support.apple.com/en-gb/guide/child-safety/kmp239668ukx/web ; https://support.apple.com/en-gb/102634 (Published
Date: September 14, 2026)
Checked: 2026-11-11
Says: Under 13: Ask to Buy and Ask to Browse are on by default, and contact management is on by default. From 13:
contact management becomes optional. Under 18: Limit Adult Websites, age-based content restrictions and Communication
Safety are on by default. A child under 13 can only leave a family group by being transferred to another one or by
having the account deleted. A 13 to 17 year old can be removed, or ask to leave, only after the organiser turns off
Screen Time and parental controls. Apple adds that in some places an account may have to stay in a family group until 18.
Limit: Apple has no single "what happens at 13" page; this is assembled from the pages above. Every one says ages vary
by country or region.
Status: CONFIRMED

**A19. Apple: date of birth**
Source: https://support.apple.com/en-gb/102617 ; https://support.apple.com/en-gb/102473 ;
https://support.apple.com/en-gb/124146 (Published Date: September 16, 2026)
Checked: 2026-11-11
Says: When creating the Child Account the parent enters the child's name and birthday, and Apple tells them to make
sure the date is correct. Apple says the date of birth drives Family Sharing and age-appropriate settings. If a child
has been using an account with the wrong (adult) birthday, the parent can correct it and convert it to a Child Account.
Changing a birthday to an age under 13 needs the account to be in a family group and the organiser to approve.
Status: CONFIRMED

**A20. Apple: age range instead of a birthday**
Source: https://support.apple.com/en-gb/guide/child-safety/el8j18q9miyv/web ; https://support.apple.com/en-gb/122770
(Published Date: September 16, 2026) ; https://support.apple.com/en-gb/108380
Checked: 2026-11-11
Path: Settings > Family > [child] > Apple Account & Password > Age Range for Apps > Share with Apps: Always, Ask First
or Don't Share. (The older support article gives it as Family > [child] > Age Range for Apps, or under Personal
Information.)
Says: Apps only ever receive an age range; the birthday stays private. The parent decides whether it is always shared,
shared on request, or never shared. Separately, a new iPhone can be set up by choosing a child or teen age range, which
applies default protections before any account exists.
Limit: Not available in every country, and only works with apps whose makers support it.
Status: CONFIRMED

**A21. Apple: is the UK a place where the age range is always shared with app makers?**
Source: https://support.apple.com/en-gb/122770
Checked: 2026-11-11
Says: The page says that in some places the age range is always shared, but does not name them on the page itself.
Status: UNVERIFIED

**A22. Google: who creates it and what it is tied to**
Source: https://support.google.com/accounts/answer/1350409?hl=en-GB ;
https://support.google.com/families/answer/7103338?hl=en-GB ; https://families.google/familylink/faq/
Checked: 2026-11-11
Says: 13 is the age for managing your own Google Account in every country not on Google's exceptions list, and the UK
is not on that list. Below that, a parent creates the account and manages it with Family Link. The parent signs in with
their own Google Account to give consent; one consent method uses a credit card, which may show a temporary hold but is
not charged. The parent must be 18 or over and live in the same country as the child. Google says there is no minimum
age for a child to have a Family Link account. Google allows about 15 minutes for set-up.
Status: CONFIRMED

**A23. Google: what changes at 13**
Source: https://support.google.com/families/answer/7106787?hl=en-GB ;
https://support.google.com/families/answer/9055704?hl=en-GB
Checked: 2026-11-11
Says: At 13 Google emails the parent and the child. If the child does nothing, supervision carries on unchanged. The
child can instead update the account and keep supervision in its over-13 form. A child under 18 needs a parent's
approval to stop supervision; a parent can stop it at any time once the child is 13. Both are told when it stops.
Limit: Google's pages do not fully agree. The create-an-account page says a child over 13 can stop supervision and
the phone is then temporarily locked. The dedicated page and the FAQ both say parent approval is needed under 18.
Contacts a parent created only inside Family Link can be lost when the child updates their account at 13 unless they
are synced to Google Contacts (https://support.google.com/families/answer/15843584?hl=en-GB).
Status: CONFIRMED

**A24. Google: date of birth and age range**
Source: https://support.google.com/families/answer/7103338?hl=en-GB ;
https://support.google.com/families/answer/7103262?hl=en-GB ; https://support.google.com/accounts/answer/1350409?hl=en-GB ;
https://support.google.com/families/answer/7103028?hl=en-GB
Checked: 2026-11-11
Path: birthday: Family Link > select child > Controls > Account settings > Birthday. Age range: Family Link > select
child > Google Play > Age sharing.
Says: The parent enters the child's birthday when creating the account and can correct it later. If Google learns
someone may be too young for their account, they get 14 days to fix it before the account is disabled. A parent can
choose whether Google shares the child's age range with apps that ask; the child is told when this is switched.
Limit: Google does not print an instruction to "use the real date" in so many words; it treats the birthday as the
basis for which rules apply.
Status: CONFIRMED

**A25. Google: is age-range sharing available in the UK?**
Source: https://support.google.com/families/answer/7103028?hl=en-GB
Checked: 2026-11-11
Says: The page only says the feature is not available in all regions.
Status: UNVERIFIED

---

## PART B. The set-up steps

iPhone paths below are the iOS 27 paths, done on the **parent's** iPhone unless stated. Android paths are in the
**Family Link app on the parent's phone** unless stated.

### B1. Family group and switching on parental controls

**B1-iPhone. Family Sharing, Child Account, Screen Time**
Source: https://support.apple.com/en-gb/108380 (Published Date: October 14, 2026) ; https://support.apple.com/en-gb/102617
(Published Date: September 16, 2026) ; https://support.apple.com/en-gb/108806 (Published Date: October 28, 2026) ;
https://support.apple.com/en-gb/guide/child-safety/kmp239668ukx/web
Checked: 2026-11-11
Path: (1) Settings > [your name] > Family > Continue. (2) Settings > Family > Add Member button > Create Child Account >
Continue, then enter the child's name and birthday. (3) Settings > Family > [child's name] > Screen Time and follow the
instructions; on iOS 27 this starts with Get Started and walks through content, contacts, schedule, school hours, time
allowances and a passcode.
Says: The family group is how a parent gets parental controls. The child must have their own account, not a shared one.
Limit: Up to five other family members. The organiser must be an adult. A person can be in only one family group. The
new controls need version 27 on all the family's devices. Some settings cannot be turned off, depending on age and region.
Check: Open Settings > Family on the parent's phone: the child's name should be listed, and tapping it shows their
status. Apple's passcode page says that if the child's name is missing there, the child is not signed in with their own
account or is not in the group.
Troubleshooting: https://support.apple.com/en-gb/guide/child-safety/jrzvk3ml3unm/web (which devices still need updating;
Settings > Family > View Family Devices). If the screen shows the old layout:
https://support.apple.com/en-gb/guide/iphone/ipha200da319/26/ios/26
Status: CONFIRMED

**B1-Android. Family Link supervision**
Source: https://support.google.com/families/answer/7103338?hl=en-GB ;
https://support.google.com/families/answer/9055704?hl=en-GB ; https://support.google.com/families/answer/7158477?hl=en-GB
Checked: 2026-11-11
Path: New account for an under-13: Family Link > select child's profile (top left) > Add child. Or on a brand-new
Android phone: at the Google sign-in step tap Create account (or More options > For my child), enter the child's
details, then sign in as the parent to give consent. Child already has an account: on the child's phone, Settings >
Google > All services > under "Kids & Family" tap Parental controls > Let's do this.
Says: Once the child is signed in on their Android phone, the parent's settings for Search, Play, Chrome, screen time,
location, app limits, app blocking and permissions all apply.
Limit: iPhones, iPads and non-Chromebook computers cannot be supervised. School accounts cannot be managed. For an
existing account the child must agree and the phone must be nearby. Only one child account per user profile; a second
profile on the phone without the child's account escapes the settings, so Google says to lock other profiles.
Check: Google gives an on-screen confirmation when set-up finishes. In Family Link, select the child > Controls >
Signed-in devices: the child's phone should be listed there.
Troubleshooting: "Troubleshoot" section of https://support.google.com/families/answer/7158477?hl=en-GB ; which devices
work: https://support.google.com/families/answer/9116646?hl=en-GB
Status: CONFIRMED

### B2. A passcode or lock so the child cannot change the settings

**B2-iPhone. Screen Time passcode**
Source: https://support.apple.com/en-gb/126533 (Published Date: October 28, 2026) ;
https://support.apple.com/en-gb/guide/child-safety/ty3v2rlzjie5/web ;
https://support.apple.com/en-gb/guide/child-safety/nzglr8yl0hwv/web
Checked: 2026-11-11
Path: Settings > Family > [child's name] > Passcode & Management > Lock Screen Time Settings, then enter a four-digit
passcode twice. To stop the child changing other things: Settings > Family > [child] > Content & Privacy Restrictions >
Allow Changes to Settings.
Says: The passcode must be entered before any Screen Time setting can be changed. It is separate from the code that
unlocks the phone. The child can still look at their settings but cannot change them. The parent is notified when the
passcode is used on the child's device, and can see when it was last used.
Limit: Apple's two support articles say that with Family Sharing the passcode must be set and reset on the parent's
device, not the child's. Its guide page says more loosely that it can be set from the parent's device or directly on
the child's. It is only four digits; Apple suggests avoiding birthdays and patterns like 1234.
Check: On the child's phone open Settings > Screen Time and try to change something: a passcode prompt should appear.
On the parent's phone, Passcode & Management shows a "Last used" time.
Troubleshooting: https://support.apple.com/en-gb/102677 (Published Date: October 27, 2026). Old layout (iOS 26: Settings >
Screen Time > [family member] > Manage Screen Time > Lock Screen Time Settings):
https://support.apple.com/en-gb/guide/iphone/iph272b4c4bd/26/ios/26
Status: CONFIRMED

**B2-Android. Parent password and parent access code**
Source: https://support.google.com/families/answer/7307262?hl=en-GB ;
https://support.google.com/families/answer/7103340?hl=en-GB ; https://support.google.com/families/answer/10436839?hl=en-GB
Checked: 2026-11-11
Path: Code: Family Link > select child's profile (top left) > Parent access code. Permissions lock: Family Link > select
child > Controls > Signed-in devices > [child's device] > App permissions > [permission] > Only parents.
Says: Family Link has no separate passcode to create. Changing limits, downtime or school time on the child's phone, or
stopping supervision, needs the parent to sign in or enter the parent access code. The code is shown only in the app or
on the web, never sent by email or text, and also works when the child's phone is offline.
Limit: A second user profile on the phone is not covered. "Only parents" does not undo permissions already granted.
On Android 17 the on-device alternative is a parental controls PIN (see A16).
Check: On the child's phone go to Settings > Digital Wellbeing & parental controls > Daily limit and try to edit it:
it should ask for the parent's sign-in or access code.
Troubleshooting: https://support.google.com/families/answer/7307262?hl=en-GB
Status: CONFIRMED

### B3. Approval before app downloads and purchases

**B3-iPhone. Ask to Buy**
Source: https://support.apple.com/en-gb/105055 (Published Date: September 15, 2026) ; https://support.apple.com/en-gb/105121
(Published Date: October 27, 2026) ; https://support.apple.com/en-gb/guide/child-safety/dq4vly6fq1je/web
Checked: 2026-11-11
Path: Settings > Family > [child's name] > Apps & Websites > Restrictions > Ask to Buy > turn on Require Purchase
Approval. (The guide's shorter version reads: [child's name] > Ask to Buy.)
Says: When the child tries to get an app (free ones included), make an in-app purchase or re-download a shared app, a
request goes to the parent, who approves or declines on their iPhone, iPad, Mac or Apple Watch, or in person on the
child's phone. Approved items download by themselves. A request not answered within 24 hours has to be sent again. It
is on by default for under-13s.
Limit: Apple says no request is sent when the child re-downloads their own earlier purchase or installs an update. The
parent must be in the child's contacts and able to receive iMessages. Apple lists it as working in the App Store
(including in-app purchases) and Apple's own apps such as Books; nothing else is listed. (Apple's two pages disagree on
redemption codes: one says no request, the troubleshooting page says a request is sent.)
Check: On the child's phone try to get a free app the child has never had. A request should arrive in Messages on the
parent's device. This is the behaviour the page describes.
Troubleshooting: https://support.apple.com/en-gb/118233 (Published Date: September 21, 2026) ;
https://support.apple.com/en-gb/125399 (Published Date: October 27, 2026)
Status: CONFIRMED

**B3-Android. Purchase and download approvals**
Source: https://support.google.com/families/answer/7039872?hl=en-GB&co=GENIE.Platform%3DAndroid ;
https://support.google.com/families/answer/7103028?hl=en-GB
Checked: 2026-11-11
Path: Family Link > select child > Controls > Google Play > "Purchases & download approvals" > Require approval for >
All content, Paid content only, In-app purchases only, or Never.
Says: With All content, a child under 18 needs approval for any download, including free ones. The child sees two
choices: ask in a message (the parent gets a notification and taps Approve or Deny) or ask in person (the parent types
their Google password on the child's phone). Pending requests: Family Link > Notifications.
Limit: Only covers purchases made through Google Play's own billing. Earlier downloads, updates, apps already approved
and anything shared through Family Library need no approval. No alert arrives if notifications are off for Family Link
or the Play Store. A parent using an iPhone can only approve paid requests on the child's phone. The page does not say
which option is the default for a new child account.
Check: On the child's phone try to download a free app never installed before. The two-option screen should appear;
choosing the message option should send a notification to the parent's phone.
Troubleshooting: "Troubleshoot problems" section of https://support.google.com/families/answer/7103028?hl=en-GB (no
separate page found)
Status: CONFIRMED

### B4. A quiet period at night and for homework

**B4-iPhone. Screen Time Schedule, Time Allowances, Always Allowed**
Source: https://support.apple.com/en-gb/guide/child-safety/azgjjn208bw9/web ;
https://support.apple.com/en-gb/guide/child-safety/j103x81xtz4g/web ;
https://support.apple.com/en-gb/guide/child-safety/kmp239668ukx/web ;
https://support.apple.com/en-gb/guide/child-safety/new8r0p02h10/web
Checked: 2026-11-11
Path: Schedule: Settings > Family > [child] > Screen Time Schedule > turn on Schedule > Add Schedule > choose days; Add
Time Window to add a named slot. Time limits: Settings > Family > [child] > Time Allowances > Add button. Exceptions:
Settings > Family > [child] > Always Allowed > Add Apps, Add People or Specific Contacts.
Says: A schedule sets which kinds of app are available at which times of day (built-in slots Before School, School,
After School; separate weekdays and weekends). Outside the available hours most apps and notifications are paused;
Apple says this is what used to be called Downtime. In guided set-up there is a "Pause During School Hours" switch that
pauses entertainment, games and social media in school time. Time Allowances (formerly App Limits) cap daily time for
Entertainment, Games and Social Media, with age-based suggestions. Always Allowed keeps chosen apps and people
reachable; FaceTime, Maps, Phone and Messages are always available by default. The child can ask for more time and the
parent can grant 15 minutes, an hour or the day. The parent can also pause the phone at once.
Limit: "Most" apps, not all, are paused. Needs version 27 across the family. On iOS 26 and earlier the names are
Downtime, App Limits and Always Allowed, and Apple notes that limits there can be ignored unless "Block at Downtime" is
turned on with a passcode.
Check: Set a schedule whose available hours end a few minutes from now. After that, most apps on the child's phone
should be paused, the Always Allowed ones should still open, and a request for more time from the child should arrive
in Messages on the parent's device.
Troubleshooting: no dedicated page found. Old layout: https://support.apple.com/en-gb/guide/iphone/iphb0c7313c9/26/ios/26
Status: CONFIRMED

**B4-Android. Downtime, School time, daily limit, app limits**
Source: https://support.google.com/families/answer/15938652?hl=en-GB ;
https://support.google.com/families/answer/7103340?hl=en-GB ; https://support.google.com/families/answer/15957417?hl=en-GB
Checked: 2026-11-11
Path: Family Link > select child > Screen time > Schedules > turn on Downtime or School time (then Weekly schedule for
days and times). Daily cap: Screen time > Time limits > turn on Daily limit > Weekly schedule. One app: Screen time >
Time limits > App limits > [app] > Set limit, or Unlimited time.
Says: Downtime and School time leave only chosen apps available at night or in lessons. When the phone is locked the
child cannot see notifications or open apps, apart from "Unlimited time" apps if the parent allowed them, and can
still answer calls and make an emergency call. In School time notifications are silent but the child can call and
text. In Downtime calls always work, but texting needs the messages app marked as unlimited. The parent can add bonus
time or lock the phone on the spot.
Limit: Android 7 or later. System apps cannot be limited. A daily limit applies to each device separately. Unlimited
apps are not available when the parent locks the phone by hand unless a setting is changed.
Check: Start Downtime for a few minutes from now (Screen time > Schedules > Downtime > Tonight). The phone should
lock at that time and only calls and the allowed apps should work. Google says the child is warned just before a
screen-time lock.
Troubleshooting: no dedicated page found; unlocking is at https://support.google.com/families/answer/7307262?hl=en-GB
Status: CONFIRMED

### B5. Content restrictions for apps, web and search

**B5-iPhone. Apps & Websites, Content & Privacy Restrictions**
Source: https://support.apple.com/en-gb/105121 (Published Date: October 27, 2026) ;
https://support.apple.com/en-gb/guide/child-safety/jymj24zqwaek/web ; https://support.apple.com/en-gb/127512 (Published
Date: October 27, 2026) ; https://support.apple.com/en-gb/guide/child-safety/ijpx5xj9vtx4/web
Checked: 2026-11-11
Path: Websites: Settings > Family > [child] > Apps & Websites > Restrictions > Filtering (under Websites) > Approved
Websites Only, Limit Adult Websites, or Unrestricted. Apps: Settings > Family > [child] > Apps & Websites > Restrictions
(age rating, installing and deleting, in-app purchases, Game Center); to block one app or site, add or select it under
Apps & Websites and tap Block App or Block Website. Films, music, books: Settings > Family > [child] > Content & Privacy
Restrictions > Content Restrictions. Siri and AI features: Content & Privacy Restrictions > Siri.
Says: "Approved Websites Only" is Ask to Browse: the child must ask before opening any new site, and approved sites
stay approved. Limit Adult Websites filters adult sites. Under-13s get Approved Websites Only by default; under-18s get
Limit Adult Websites. Age ratings limit the child to apps rated for their age, and the child can ask for an exception.
Limit: Ask to Browse works in Safari and other browser apps that support it, not every browser. A blocked app is hidden or
dimmed, not deleted. Apple describes no search-engine setting; its control is the website filter.
Check: On the child's phone open a website not visited before: it should ask for permission and a request should reach
the parent. Try to get an app above the age rating: the child should see a message that restrictions are on.
Troubleshooting: https://support.apple.com/en-gb/127512 ; https://support.apple.com/en-gb/125399
Status: CONFIRMED

**B5-iPhone (search). Google SafeSearch on an iPhone**
Source: https://support.google.com/websearch/answer/510?hl=en-GB ; https://families.google/familylink/faq/
Checked: 2026-11-11
Says: SafeSearch is Google's filter and affects Google Search only. It defaults to Filter when Google believes the user
is under 18. If the child signs in with a Google Account managed by Family Link, the parent's Search setting follows
them onto an iPhone, but Family Link's other controls do not.
Limit: Does nothing for other search engines or for websites themselves.
Status: CONFIRMED

**B5-Android. Google Play, Chrome, SafeSearch**
Source: https://support.google.com/families/answer/1075738?hl=en-GB ;
https://support.google.com/families/answer/7087030?hl=en-GB ; https://support.google.com/families/answer/7086922?hl=en-GB ;
https://support.google.com/websearch/answer/510?hl=en-GB
Checked: 2026-11-11
Path: Play: Family Link > select child > Controls > Google Play > choose the content type > choose the highest rating.
Chrome: Family Link > select child > Controls > Google Chrome and Web > Allow all sites, Try to block explicit sites, or
Only allow approved sites; named sites under Manage sites. Search: Family Link > select child > Controls > Google Search
> SafeSearch (Filter, Blur or Off).
Says: Play restrictions cap what can be downloaded or bought by maturity rating. Chrome can block explicit sites or
allow only an approved list, and the child can ask to visit a blocked site. Incognito is off for a supervised child.
SafeSearch is already on and locked for a supervised account; only the parent can change it.
Limit: Google's own words of caution: Play restrictions do not stop restricted content appearing in search results or
by direct link; apps installed earlier stay until blocked; no web filter is perfect; other browsers are not covered
unless blocked; SafeSearch is not enforced if the child is signed out or uses another search app. Google's FAQ says
Family Link offers filters but does not itself block inappropriate content.
Check: On the child's phone open Google's SafeSearch settings: a lock should show that someone else manages it. Open a
site on the blocked list in Chrome: the child should be offered a way to ask permission, and the request should appear
in Family Link.
Troubleshooting: "Fix possible content restrictions issues" in https://support.google.com/families/answer/1075738?hl=en-GB ;
https://support.google.com/websearch/answer/9448272?hl=en-GB
Status: CONFIRMED

### B6. Who the child can contact

**B6-iPhone. Allowed Contacts and Communication Safety**
Source: https://support.apple.com/en-gb/guide/child-safety/gkz40jx9zf5r/web ; https://support.apple.com/en-gb/105121 ;
https://support.apple.com/en-gb/105069 (Published Date: September 30, 2026)
Checked: 2026-11-11
Path: Settings > Family > [child] > Allowed Contacts > During Screen Time (Contacts Only, Contacts & Groups with at
Least One Contact, or Everyone), and When Device Paused or Unavailable. Turn on Manage [child's name] Contacts; leave
Allow Contact Editing off so the child must ask to add someone. Images: Settings > Family > [child] > Communication
Safety.
Says: The parent decides who the child can reach in Phone, Messages and FaceTime, can edit the child's contact list
from their own phone, and can require approval before the child talks to anyone new; a message from a new person stays
hidden until approved. Communication Safety blurs images and videos detected as nudity, gore or violence and offers the
child help.
Limit: Covers Apple's Phone, Messages and FaceTime only, not WhatsApp, games or other apps. The child has to accept the
parent's request to manage contacts. It relies on the child's contacts being stored in iCloud.
Check: Have someone not in the child's contacts send a message: the child should not see it until the parent approves,
and the request should reach the parent.
Troubleshooting: no dedicated page found. Old layout (Communication Limits):
https://support.apple.com/en-gb/guide/iphone/iph4df1c0dad/26/ios/26
Status: CONFIRMED

**B6-Android. Contacts, calls & text**
Source: https://support.google.com/families/answer/15843584?hl=en-GB ;
https://support.google.com/families/answer/7110462?hl=en-GB
Checked: 2026-11-11
Path: Family Link (the page says on the parent's Android device) > select child > Controls > Contacts, calls & text >
Get started or Add contacts; then Allowed calls & texts > Anyone, Contacts I add & limited groups, or Only contacts I add.
Says: The parent builds the child's contact list (up to 100) and can restrict calls and texts to it. The child can
request a new number and the parent approves or denies from a notification.
Limit: Child's phone needs Android 14 or later. Only ordinary phone calls and texts in Google's phone and messages
apps are covered. Google says plainly that WhatsApp and other chat apps are not limited by this; block those apps
instead. Anyone can still leave voicemail. Emergency calls are unaffected.
Check: With "Only contacts I add" on, have the child try to add a new number: a Family Link notification asking to
review the request should reach the parent.
Troubleshooting: the FAQ section of the same page
Status: CONFIRMED

### B7. Location sharing and per-app location

**B7-iPhone. Find My family sharing and Location Services**
Source: https://support.apple.com/en-gb/105107 (Published Date: September 16, 2026) ;
https://support.apple.com/en-gb/guide/iphone/iph6231f621a/ios ; https://support.apple.com/en-gb/102647 (Published Date:
October 24, 2026) ; https://support.apple.com/en-gb/guide/child-safety/nzglr8yl0hwv/web
Checked: 2026-11-11
Path: Family: Settings > Family > Location Sharing, choose who to share with, and optionally Automatically Share
Location. Per app (on the child's phone): Settings > Privacy & Security > Location Services > [app] > Never, Ask Next
Time Or When I Share, While Using the App, or Always; plus a Precise Location switch. To stop the child changing these:
Settings > Family > [child] > Content & Privacy Restrictions > Allow Changes to Settings (Location Services, Share My
Location).
Says: The organiser turns on family location sharing; each member then chooses whether to share. Shared locations show
in Find My and Messages. When automatic sharing is on for a child, only parents and guardians see the child's location.
A child with parental controls may be prevented from changing their own sharing.
Limit: Location Services must be on. If the child is not sharing, the family cannot see where they are, though they can
still make a missing phone play a sound, lock it or erase it.
Check: Open Find My on the parent's Apple device: the child should appear once sharing is on.
Troubleshooting: no dedicated family-location page found.
Status: CONFIRMED

**B7-iPhone (Android parent). Seeing an iPhone child's location from an Android phone**
Source: https://support.apple.com/en-gb/guide/iphone/iph6231f621a/ios
Checked: 2026-11-11
Says: The only non-app route Apple mentions is Find Devices on iCloud.com, described for finding a family member's
missing device. No page describes following a child's location from Android.
Status: UNVERIFIED

**B7-Android. Family Link location and app permissions**
Source: https://support.google.com/families/answer/7103413?hl=en-GB ;
https://support.google.com/families/answer/10436839?hl=en-GB ; https://support.google.com/android/answer/6179507?hl=en-GB
Checked: 2026-11-11
Path: Family Link > Location > Set up location > choose the child > Next > Turn on. Later: Location > select child >
More > Location settings > "See your child's location". Per-app permission from the parent's phone: Family Link >
select child > Controls > Signed-in devices > [device] > App permissions > Location. On the child's phone: Settings >
Location > App location permissions.
Says: The parent sees the child's Android phone on a map, can save family places such as home and school, and can get
arrive and leave alerts. The parent can switch any app's location permission on or off and can make permissions
parent-only.
Limit: Nothing shows if the phone is off, offline or unused for a while. Works best with mobile data. Only the
most-used device is shown if the child has several. Turning a permission off can stop an app working properly.
Check: After set-up, open the Location tab: the child's phone should appear (Google warns it can take a while).
Troubleshooting: "Troubleshoot" section of https://support.google.com/families/answer/7103413?hl=en-GB
Status: CONFIRMED

---

## PART C. Minimum ages and parent tools, from each maker's own pages

**C1. WhatsApp**
Source: https://www.whatsapp.com/legal/terms-of-service-uk (UK terms, effective August 17, 2026) ;
https://faq.whatsapp.com/695318248185629
Checked: 2026-11-11
Says: Minimum age 13 to use WhatsApp on your own. Under-18s are asked to read the terms with a parent. A younger child
may only use it through a parent-managed account, where that exists.
Parent tool: Parent-managed accounts, https://faq.whatsapp.com/899820539143195 (parent controls contacts and privacy;
only saved contacts can message or call by default; no Meta AI, Channels, Status, location sharing or disappearing
messages; the account moves to a normal one at 13).
Status: CONFIRMED

**C1b. Are WhatsApp parent-managed accounts available in the UK today?**
Source: https://faq.whatsapp.com/899820539143195
Checked: 2026-11-11
Says: Only that they are rolling out gradually and may not be available in every region.
Status: UNVERIFIED

**C2. YouTube**
Source: https://www.youtube.com/t/terms?gl=GB (UK terms, dated March 17, 2025)
Checked: 2026-11-11
Says: Minimum age 13. Children of any age may use YouTube and YouTube Kids if a parent or guardian enables it. Anyone
under 18 needs a parent's permission.
Parent tool: YouTube Family Centre and Family Link, https://support.google.com/families/answer/10495678?hl=en-GB ; teen
supervision, https://support.google.com/youtube/answer/15253498?hl=en-GB
Status: CONFIRMED

**C3. YouTube Kids and supervised child accounts**
Source: https://support.google.com/youtube/answer/10314940?hl=en-GB ;
https://support.google.com/youtubekids/answer/6130573?hl=en-GB ; https://support.google.com/youtubekids/answer/6172308?hl=en-GB
Checked: 2026-11-11
Says: A supervised child account is a parent-managed version of YouTube for under-13s, where the parent picks a content
level. Both it and the YouTube Kids app are listed as available in the United Kingdom. YouTube Kids settings sit behind
a parent lock in the app, in the parent's YouTube settings, or in Family Link > select child > Controls > YouTube.
Limit: Once a child is 13 and manages their own account these controls stop; Google points to Restricted Mode and teen
supervision instead.
Status: CONFIRMED

**C4. Roblox**
Source: https://en.help.roblox.com/hc/en-us/articles/115004647846-Roblox-Terms-of-Use (effective November 1, 2026)
Checked: 2026-11-11
Says: Accounts are open from age 5. Anyone under 18 must create the account together with a parent or guardian, who
accepts the terms for them. Some features must be switched on by a parent.
Parent tool: Parental Controls, https://en.help.roblox.com/hc/en-us/articles/30428310121620-Parental-Controls-Overview
(content, chat, spending, screen time, friends; by linking a parent account or using Parent mode on the child's device;
from 13 the child takes over screen time and blocking, and spending limits end).
Limit: The terms are worldwide; they give no separate UK age.
Status: CONFIRMED

**C5. Minecraft**
Source: https://www.minecraft.net/en-us/eula ; https://www.minecraft.net/en-us/article/parental-controls ;
https://support.microsoft.com/en-gb/accounts-billing/manage/list-of-countries-or-regions-that-have-statutory-age-limits-for-children
Checked: 2026-11-11
Says: No minimum age is stated. Minecraft needs a Microsoft (Xbox) account, and for a minor the parent is responsible
for creating that account and accepting the terms. Microsoft lists the United Kingdom at 13: below that a parent must
manage the account.
Parent tool: Xbox and Microsoft family settings (multiplayer, friends and chat are set by the parent), described at
https://www.minecraft.net/en-us/article/parental-controls and managed at account.xbox.com/settings and
account.microsoft.com/family
Status: CONFIRMED

**C5b. At what age does Minecraft treat a UK account as a child account?**
Source: https://www.minecraft.net/en-us/article/parental-controls
Checked: 2026-11-11
Says: The page says child accounts are those under 16 in the US and EU, and does not mention the UK.
Status: UNVERIFIED

**C6. Fortnite (Epic Games)**
Source: https://safety.epicgames.com/cabined-accounts ; https://legal.epicgames.com/epicgames/tos (last updated
September 10, 2026)
Checked: 2026-11-11
Says: No minimum age is stated. A player who says they are under 13, or under their country's age of digital consent
if that is higher, gets a restricted "Cabined Account" (no voice or free-text chat, no spending real money) until a
parent consents by email. A parent who accepts the terms for a minor is responsible for the account.
Parent tool: Epic Parental Controls, https://safety.epicgames.com/parental-controls (PIN-protected; chat limits, friend
requests, purchases; under-10s capped at friends-only chat; a daily spending cap for under-13s).
Limit: The page does not name the UK's digital-consent age. Epic says the purchase PIN does not cover payments made
through game platforms such as PlayStation, Xbox, Nintendo Switch or Steam, or spending of in-game currency.
Status: CONFIRMED

**C7. Snapchat**
Source: https://www.snap.com/terms (Snap Group Limited Terms of Service, effective September 21, 2026)
Checked: 2026-11-11
Says: Not for anyone under 13. The user must confirm they are old enough and may be asked to verify their age. Under-age
accounts are removed.
Parent tool: Family Centre, https://parents.snapchat.com/family-center (see the teen's friends and who they are chatting
with, not what is said; time spent; shared location; reporting).
Status: CONFIRMED

**C8. TikTok**
Source: https://www.tiktok.com/legal/page/global/uk-annex/en (UK annex, last updated July 2025) ;
https://www.tiktok.com/legal/page/eea/terms-of-service/en (last updated July 2026)
Checked: 2026-11-11
Says: Minimum age in the UK is 13. Some features need the user to be older; live streaming and virtual gifts need 18.
Parent tool: Family Pairing, https://support.tiktok.com/en/safety-hc/account-and-user-safety/family-pairing (daily
screen time, set to one hour by default for 13 to 17; scheduled time away; muted notifications overnight; keyword
filters; Restricted Mode). Teens can tighten but not loosen what the parent set.
Status: CONFIRMED

**C9. Instagram**
Source: https://help.instagram.com/581066165581870 (Terms of Use, effective 4 March 2026) ;
https://help.instagram.com/995996839195964
Checked: 2026-11-11
Says: Minimum age 13. Everyone aged 13 to 17 is placed in a Teen Account with protective defaults. Under-16s need a
parent's permission to loosen those; 16 and 17 year olds can change them unless a parent is supervising.
Parent tool: Supervision, https://help.instagram.com/472274307935829 and https://familycenter.meta.com/uk/our-products/instagram/
(teen 13 to 17, parent over 18, both must agree, one supervising parent per teen).
Status: CONFIRMED

**C10. Discord**
Source: https://discord.com/terms (effective September 29, 2025) ;
https://support.discord.com/hc/en-us/articles/360040724612 (updated 22 September 2026)
Checked: 2026-11-11
Says: Minimum age 13, or higher where a country requires it (up to 16 in some). A user below the age of majority needs
a parent or guardian to agree to the terms for them.
Parent tool: Family Center, https://discord.com/safety-family-center (activity feed, weekly email summary, some safety
and privacy settings).
Status: CONFIRMED

**C10b. Discord's exact figure for the UK**
Source: https://support.discord.com/hc/en-us/articles/360040724612
Checked: 2026-11-11
Says: The terms point to this page as the list of minimum ages by country, but the page no longer shows a country list.
Status: UNVERIFIED (13 is the floor; no UK line is published)

**C11. ChatGPT (OpenAI)**
Source: https://openai.com/en-GB/policies/eu-terms-of-use/ (applies to the EEA, Switzerland and UK; updated 16 January 2026)
Checked: 2026-11-11
Says: Minimum age 13, or the country's minimum for consent if higher. Under-18s must have a parent or guardian's
permission.
Parent tool: Parental controls, https://help.openai.com/en/articles/12315553 (page marked updated two days before this
check). Parent and teen accounts are linked by invitation. The parent manages some settings and schedules but cannot
read conversations. Either side can unlink.
Status: CONFIRMED

**C12. Google Gemini**
Source: https://support.google.com/gemini/answer/13278668?hl=en-GB ;
https://support.google.com/families/answer/16109150?hl=en-GB
Checked: 2026-11-11
Says: A user must be 13 (or the country's age) to use Gemini with a personal Google Account they manage themselves; the
UK is not on Google's list of higher ages. Google states that Gemini Apps are not available for supervised accounts in
the UK, the EEA and Switzerland. It follows that a UK child on a Family Link account cannot use it.
Parent tool: Family Link > select child > Controls > Gemini, where it is offered
(https://support.google.com/families/answer/16109150?hl=en-GB).
Status: CONFIRMED

**C13. Microsoft Copilot**
Source: https://support.microsoft.com/en-gb/privacy/microsoft-copilot/young-people ;
https://support.microsoft.com/en-gb/accounts-billing/manage/list-of-countries-or-regions-that-have-statutory-age-limits-for-children
Checked: 2026-11-11
Says: Minimum age 13, higher in some countries; Microsoft's country list puts the United Kingdom at 13. Under-18s get
extra protections.
Parent tool: Microsoft Family Safety, or the phone's own controls, to block Copilot, set hours and choose features;
some of this needs the child in the parent's Microsoft family group.
Limit: Microsoft says this page applies to the Copilot app as updated from 18 August 2026; a separate page covers the
older app with the same age rule.
Status: CONFIRMED

---

## The July walkthrough (`components/FirstPhoneWalkthrough.tsx`), statement by statement

Links
- `https://support.apple.com/en-gb/108806`: **still right.** Live, republished 28 October 2026, still the right entry page.
- `https://support.google.com/families/answer/7101025?hl=en-GB`: **still right.** Live, "Get started with Family Link".
- `https://support.google.com/websearch/answer/510?hl=en-GB`: **live, but shown in the wrong place.** It is shown for
  both phone types and covers Google Search only.

Statements
- "Set up Family Sharing and Screen Time": **still right** for a parent with an Apple device.
- "Lock Screen Time settings with a passcode your child does not know": **still right in substance; route out of date.**
- "review Downtime, App Limits, Ask to Buy and Content & Privacy Restrictions": **out of date on iOS 27.** Still right
  on iOS 26 and earlier.
- "Set up supervision with Google Family Link ... review app approvals, permissions, screen-time limits and Google Play
  content restrictions": **still right**, but incomplete.
- "Use the real date of birth ... protections depend on the age held by the account": **still right.**
- "Require approval before app downloads and spending ... or a PIN where the phone supports it": **still right**, vague.
- "Choose the essential contacts and apps that still need to work, then set the first version of downtime": **right in
  substance; the word is out of date on iPhone.**
- "turn on SafeSearch": **out of date / misleading.**
- "decide deliberately whether each app needs location access": **still right.**
- "Settings links checked 16 July 2026": **out of date.**
- Phone-type picker (child's phone only): **gap.** It never asks what phone the parent has.

## Wrong or out of date in the July walkthrough

1. **iPhone feature names.** On iOS 27 there is no "Downtime" or "App Limits" menu. They are now Screen Time Schedule
   and Time Allowances, reached at Settings > Family > [child]. Families still on iOS 26 see the old names, so the
   product needs both sets.
2. **The iPhone step assumes the parent has an iPhone.** Apple only documents Family Sharing, Child Accounts, Ask to Buy
   and the Screen Time passcode from the parent's own iPhone, iPad or Mac. For a parent with an Android phone the step
   as written cannot be followed.
3. **Where the passcode is set.** Apple's support articles say that with Family Sharing the Screen Time passcode must be
   set on the parent's device, at Passcode & Management > Lock Screen Time Settings, not on the child's phone.
4. **"Turn on SafeSearch."** For a Family Link child it is already on and locked. On an iPhone, Apple's website filter
   (Ask to Browse or Limit Adult Websites) is the built-in control and the walkthrough does not mention it.
5. **Missing iPhone controls.** Ask to Browse, Allowed Contacts and Communication Safety are not mentioned.
6. **Missing Android controls.** School time, Chrome site filtering, contact limits (Android 14 and later), the parent
   access code, and Android 17's built-in PIN-locked controls are not mentioned.
7. **Android wording.** "Connect the child account" hides the real first step for an under-13: the parent creates the
   child's Google Account and gives consent.
8. **"Settings links checked 16 July 2026."** Apple republished nearly every relevant page between 14 September and 28
   October 2026.
9. **No pairing question.** The tool asks only for the child's phone type.

## Could not verify

1. Whether an adult with no Apple device at all can be a Family Sharing organiser, or complete "Connect to Family" on
   the child's iPhone (A7).
2. Which child controls work on the child's iPhone alone under iOS 27, without a family group: in particular Ask to
   Buy, Ask to Browse and Allowed Contacts (A8).
3. Whether iOS 27 still requires a parent's Apple device to set up a phone for a child of 12 or under. The iOS 26 page
   says so; the iOS 27 page is silent (noted in A4).
4. Any way for an Android-owning parent to follow an iPhone child's location (B7).
5. The minimum iPhone software for the Family Link parent app: Google's pages say iOS 11, 13 and 16 in different
   places (A11).
6. Whether the Family Link iPhone app can manage the child's contacts, calls and texts (A12).
7. Whether Apple's Age Range for Apps is "always shared" in the UK (A21), and whether Google's age sharing is available
   in the UK (A25).
8. Whether WhatsApp parent-managed accounts are available in the UK today (C1b).
9. The age at which Minecraft treats a UK account as a child account (C5b).
10. Discord's published minimum age for the UK specifically (C10b).
11. The UK age of digital consent as Epic applies it to Fortnite: the page gives the rule but not the number (C6).
12. The default purchase-approval setting on a newly created Google child account: not stated (B3-Android).
13. Dedicated Apple troubleshooting pages for schedules, Allowed Contacts and family location sharing: none found.
14. Dedicated Google troubleshooting pages for purchase approvals and schedules: none found beyond sections inside the
    main articles.
15. Dates on Google help pages and Apple guide pages: none are shown, so "last updated" cannot be recorded for them.
16. Three places where Apple's own pages disagree and I could not tell which is right: whether redeeming a code
    triggers an Ask to Buy request; the exact Ask to Buy menu route (two versions printed); and whether, with Family
    Sharing, the Screen Time passcode may be set on the child's phone (two support articles say no, the guide implies yes).
