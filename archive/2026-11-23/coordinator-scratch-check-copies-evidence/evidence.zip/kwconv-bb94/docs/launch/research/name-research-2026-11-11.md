# Name research: first screen, 11 Nov 2026

This is a first screen of possible names to replace "Keepwise". It is not legal clearance. Nothing was registered, bought or
signed up for. Ben decides.

**Short version.** The three best options are **Well Begun**, **Back for Tea** and **Keepden**. The reserves are **Hobside**,
**Coats On** and **Kinstead**. "Bearings" (July's alternative) is dropped under the rules you set: someone now runs a live UK
site called Bearings at getbearings.co.uk. Most other July names have also gone since July.

## How the checks were done

All checks were run on 11 Nov 2026.

1. **Web search** for the name on its own and with "UK", "app" and "parents", plus a search of the UK App Store. The search
   tool leans towards US results, so a small UK business could be missed.
2. **Web addresses.** `whois` from the shell for `.co.uk`, `.com` and `.uk`, then an attempt to load each address. "Appears
   unregistered" means the registry returned no record. It does not mean you can have it: that is only known at checkout.
3. **Companies House** name search on find-and-update.company-information.service.gov.uk.
4. **UK trade marks. NOT DONE on the UK IPO's own site.** trademarks.ipo.gov.uk put up a "verify you are human" security
   check, which I did not try to get past. As a stand-in I used **TMview** (tmdn.org, the European trade mark offices' shared
   search, which carries UK IPO records), filtered to the UK office. TMview says of itself that it is not an official
   register. Treat check 4 as a stand-in until someone runs the real UK IPO search by hand.

Names were dropped at the first failed check, so dropped names did not always get all four.

## The three best options

### 1. Well Begun

- **Addresses I would use:** `wellbegun.uk` now, with `getwellbegun.co.uk` and `getwellbegun.com` as the matching pair.
- **Why it fits:** "Well begun is half done" is exactly the first-phone promise, it is plain and British, and it stretches to
  every later course ("a good start to the next thing").
- **Check 1, web:** searches for "Well Begun" alone, with UK/company/brand/app, with parents/parenting/children, and with
  app/software/membership/course found only the proverb
  ([Wikiquote](https://en.wikiquote.org/wiki/Beginning)) and one dissolved company. No product, app or parenting service.
  UK App Store: [0 results](https://itunes.apple.com/search?term=well%20begun&country=gb&entity=software&limit=8).
- **Check 2, addresses:** `wellbegun.uk` appears unregistered. `getwellbegun.co.uk`, `getwellbegun.com`,
  `wellbegunfamily.co.uk` and `wellbegunfamily.com` appear unregistered. `wellbegun.co.uk` is registered (27 Jan 2010, expires
  27 Jan 2027) and `wellbegun.com` is registered (19 Jan 2010, expires 19 Jan 2027). Neither shows a live site: the first
  redirects nowhere, the second returns a "not authorised" page.
- **Check 3, Companies House:** [search](https://find-and-update.company-information.service.gov.uk/search/companies?q=well+begun).
  One match, [WELL BEGUN LIMITED 07138702](https://find-and-update.company-information.service.gov.uk/company/07138702),
  an IT consultancy, **dissolved 10 Feb 2026**. No active company of this name.
- **Check 4, trade marks (TMview stand-in):**
  [UK search](https://www.tmdn.org/tmview/#/tmview/results?page=1&pageSize=30&criteria=C&offices=GB&basicSearch=well%20begun).
  One UK mark: WELL BEGUN, UK00003212646, registered, **classes 25 and 35** (clothing and retail), filed 14 Feb 2017, owner
  Faering Ltd ([official record, not opened by me](https://trademarks.ipo.gov.uk/ipo-tmcase/page/Results/1/UK00003212646)).
  Companies House shows Faering Ltd (09551300) dissolved on 1 Mar 2022. Nothing in classes 9, 41 or 42. No exact match at
  the EU, US or international offices.
- **Honest risks:** the plain `.co.uk` and `.com` belong to someone else, probably the old consultancy's owner, and may or
  may not lapse in January. A `.uk` address is less familiar to parents than `.co.uk`. The existing mark covers retail
  (class 35), which could matter if you ever sell printed goods. It is a well-known phrase, so it is harder to protect than
  an invented word and hard to rank for in search. It may faintly echo early-years schemes ("Sure Start", "Best Start").

### 2. Back for Tea

- **Addresses I would use:** `backfortea.co.uk` and `backfortea.uk`, with `getbackfortea.com` for the `.com`.
- **Why it fits:** it is what a British parent says when a child heads out, freedom with one plain agreed rule, which is the
  family agreement in three words and nothing to do with watching.
- **Check 1, web:** searches for "Back for Tea" alone, with UK/brand/company/app, with parents/family/children, and with
  app/podcast/book/shop returned only tea and recipe pages. No product, company or app of this name. UK App Store:
  [no app of this name](https://itunes.apple.com/search?term=back%20for%20tea&country=gb&entity=software&limit=8).
- **Check 2, addresses:** `backfortea.co.uk` and `backfortea.uk` appear unregistered (nothing loads).
  `getbackfortea.co.uk` and `getbackfortea.com` appear unregistered. `backfortea.com` is registered (20 Feb 2019) and is a
  live personal blog titled "Back in time for tea".
- **Check 3, Companies House:**
  [search](https://find-and-update.company-information.service.gov.uk/search/companies?q=back+for+tea). No company called
  Back for Tea. Nearest is BACK IN TIME FOR TEA LTD (12819057), dissolved 2 May 2023.
- **Check 4, trade marks (TMview stand-in):**
  [UK search](https://www.tmdn.org/tmview/#/tmview/results?page=1&pageSize=30&criteria=C&offices=GB&basicSearch=back%20for%20tea):
  0 results. "Back in time for tea": 0 results. No exact match at the EU, US or international offices.
- **Honest risks:** on its own it sounds like a café or a food blog, so it always needs a plain line under it. Search
  results for the phrase are all tea and recipes. The `.com` is a stranger's blog. The BBC ran a series called "Back in Time
  for Tea" (from memory, not checked today). It is nostalgic, which some parents may read as anti-phone. Three words, and
  "tea" means a different meal in different parts of the UK.

### 3. Keepden

- **Addresses I would use:** `keepden.co.uk` and `keepden.uk`, with `getkeepden.com` for the `.com`.
- **Why it fits:** your own July shortlist name (21 out of 25), warm and British ("den"), short, and nothing else found
  using it anywhere.
- **Check 1, web:** searches for "Keepden" alone, with app/company/parents, and with UK found nothing called Keepden. UK
  App Store: [no app of this name](https://itunes.apple.com/search?term=keepden&country=gb&entity=software&limit=8). Nearby
  "Keep" names in the family space did come up: [Keepers Child Safety](https://www.cbinsights.com/company/keepers-child-safety),
  a parental-control app, and Keepy, a family keepsake app.
- **Check 2, addresses:** `keepden.co.uk` and `keepden.uk` appear unregistered (nothing loads). `getkeepden.co.uk` and
  `getkeepden.com` appear unregistered. `keepden.com` is registered (22 Jan 2026) and shows a generic "service online" status
  page with no Keepden brand on it.
- **Check 3, Companies House:**
  [search](https://find-and-update.company-information.service.gov.uk/search/companies?q=keepden): no results.
- **Check 4, trade marks (TMview stand-in):**
  [UK search](https://www.tmdn.org/tmview/#/tmview/results?page=1&pageSize=30&criteria=C&offices=GB&basicSearch=keepden):
  0 results. A similar-spelling search found only "keephen" (class 25, clothing). Nothing at the EU, US or international
  offices.
- **Honest risks:** it starts with "Keep", like Keepwise, whose `.co.uk` owner runs
  [household money and life-admin tools](http://keepwise.co.uk/) (registered 31 May 2026). Your rule says the new name must
  not be confusable with them, and this is the closest of the six. "Keepers" is a monitoring app, the kind of product you
  define yourself against. Your July note said "keep" has a faint "keeping tabs" shade. The `.com` is held by an unknown
  party. It has not been said aloud to parents.

**Which way I lean:** Well Begun if you are content with a `.uk` or "get" address, otherwise Back for Tea, which has the
cleanest addresses of the three.

## Three reserves

### 4. Hobside

- **Addresses I would use:** `hobside.co.uk`, `hobside.com` and `hobside.uk`.
- **Why it fits:** a made-up, homely British word ("by the hob", the kitchen version of fireside) and the only name here
  where all three plain addresses appear unregistered.
- **Check 1, web:** searches for "Hobside" alone, with UK/app/company/parents/kitchen, and with app/parents/family found
  nothing of this name. UK App Store:
  [no app of this name](https://itunes.apple.com/search?term=hobside&country=gb&entity=software&limit=8).
- **Check 2, addresses:** all three appear unregistered; nothing loads.
- **Check 3, Companies House:**
  [search](https://find-and-update.company-information.service.gov.uk/search/companies?q=hobside): no results.
- **Check 4, trade marks (TMview stand-in):** no "Hobside" in the UK, EU, US or international records. But a
  [similar-spelling UK search](https://www.tmdn.org/tmview/#/tmview/results?page=1&pageSize=30&criteria=F&offices=GB&basicSearch=hobside)
  shows **HUBSIDE**, one letter different, registered in the UK in classes 9, 41 and 42 among others (UK00917890496,
  UK00918110983, UK00918110979; owners Hubside and Hubside.Store.Holding).
- **Honest risks:** Hubside is the main one. From memory it is a French phone and electronics brand, which I did not
  confirm today; if so it is a near-identical name in your exact classes and in phones. The name says little by itself and
  could be taken for a cooker shop. It could be misheard as "Hubside" or "Hopside".

### 5. Coats On

- **Addresses I would use:** `coatson.co.uk`, `coatson.com` and `coatson.uk`.
- **Why it fits:** "Coats on!" is the parent's call for getting ready before going out, which is the set-up idea, said in
  the parent's voice.
- **Check 1, web:** searches for "Coats On" alone and with UK/brand/app/parents found only clothing pages, with no product
  or app of this name. UK App Store:
  [no app of this name](https://itunes.apple.com/search?term=coats%20on&country=gb&entity=software&limit=8).
- **Check 2, addresses:** all three appear unregistered; nothing loads. `getcoatson.co.uk` and `getcoatson.com` also appear
  unregistered.
- **Check 3, Companies House:**
  [search](https://find-and-update.company-information.service.gov.uk/search/companies?q=coats+on).
  [COATS ON CLOTHING LTD 16169009](https://find-and-update.company-information.service.gov.uk/company/16169009) is active
  (internet clothing retail, York, formed 7 Jan 2025). COATS ON LTD (14411630) was dissolved on 16 Jan 2024.
- **Check 4, trade marks (TMview stand-in):**
  [UK search](https://www.tmdn.org/tmview/#/tmview/results?page=1&pageSize=30&criteria=C&offices=GB&basicSearch=coats%20on):
  no "Coats On" mark. The thread company J. & P. Coats holds "COATS DIGITAL" in classes 9, 35 and 42 (UK00003736278), and
  another firm holds "COATS" in class 9 (UK00003944105).
- **Honest risks:** it reads like a clothing shop, and an active clothing company has the name. Run together, "coatson"
  looks odd. It is playful, so it may feel less premium than you want. Coats is a large company with marks in class 9.

### 6. Kinstead

- **Addresses I would use:** `kinstead.uk`, with `kinsteadfamily.co.uk` and `kinsteadfamily.com` as the matching pair.
- **Why it fits:** your own July reserve, "the family homestead in one word", calm and clearly about the household.
- **Check 1, web:** searches for "Kinstead" alone, with UK/app/family/parents, and with app/software/brand/shop found
  nothing of this name. UK App Store:
  [0 results](https://itunes.apple.com/search?term=kinstead&country=gb&entity=software&limit=8).
- **Check 2, addresses:** `kinstead.uk` appears unregistered. `kinsteadfamily.co.uk`, `kinsteadfamily.com`,
  `kinsteadhq.co.uk` and `kinsteadhq.com` appear unregistered. `kinstead.co.uk` is registered (2 May 2025) and shows only a
  registrar holding page. `kinstead.com` is registered (7 Oct 2004) and is one family's personal site.
- **Check 3, Companies House:**
  [search](https://find-and-update.company-information.service.gov.uk/search/companies?q=kinstead). Three active companies:
  [KINSTEAD LTD 16420004](https://find-and-update.company-information.service.gov.uk/company/16420004) (internet retail,
  formed 30 Apr 2025), KINSTEAD FINANCIAL LTD 17304899 (mortgages and insurance, formed 27 Jun 2026) and THE KINSTEAD GROUP
  LTD 16626497 (consultancy, strike-off proposed). None is in parenting, education or software by its filed activity.
- **Check 4, trade marks (TMview stand-in):**
  [UK search](https://www.tmdn.org/tmview/#/tmview/results?page=1&pageSize=30&criteria=C&offices=GB&basicSearch=kinstead):
  0 results.
- **Honest risks:** the weakest of the six. Kinstead Ltd was formed two days before `kinstead.co.uk` was registered, so an
  online shop under this name may be coming. "Kin" names are crowded in family products (Kinside, Kinwise and Kinhold, from
  your July files). People may not know how to spell "stead".

## Rejected, one line each

**From your July files**

- **Bearings** — dropped under your rule: [getbearings.co.uk](https://getbearings.co.uk/) (registered 11 Oct 2026) is a live
  UK site, "Bearings funding finder", for North West businesses; also a UK application "Hidden Bearings Ltd" (UK00004464540,
  filed 23 Oct 2026) in classes 9, 41 and 42. It is a different field, and `bearingsfamily.co.uk`, `.com` and `.uk` appear
  unregistered, so this one is your call to reopen.
- **Steady** — "Steady" is a registered UK mark in classes 9 and 41 (UK00915720436, Steady Media GmbH, a membership
  platform); all three addresses registered.
- **Marlow** — "MARLOW" is a registered UK mark in class 42 (UK00004427741, filed Aug 2026); every address is registered,
  including `askmarlow.co.uk` (11 Oct 2026).
- **Fledge** — "Fledge" is a registered UK mark in classes 35, 41 and 42 (UK00004398715, Fledge Labs Ltd, an education
  company, filed Jun 2026).
- **Ballast** — "BALLAST" is a registered UK mark in classes 35 and 41 (UK00004378364, Ballast Ltd, filed Apr 2026).
- **Keepside** — two live UK sites now use it: [keepside.uk](https://keepside.uk/), a family memory bank in development,
  and [keepside.co.uk](http://keepside.co.uk/), "the mixtape you can hold" (registered Oct and Sep 2026).
- **Setfair** — a live iPhone app called Setfair ([getsetfair.com](https://getsetfair.com/), an AI calendar from a Portuguese
  company, on the UK App Store); it also rhymes with Betfair, which holds UK marks in classes 9 and 41.
- **Soonly** — [soonly.com](https://soonly.com/) is a live conversation-starter product called Soonly; `soonly.co.uk` was
  registered on 13 Sep 2026; it also lost your July brand test.
- **Kinside** — the same name was a US childcare marketplace, now part of UrbanSitter, which holds `kinside.com`
  ([Y Combinator listing](https://www.ycombinator.com/companies/kinside)); the UK addresses appear unregistered.
- **Keeplane** — nothing found against it and `keeplane.co.uk` appears unregistered, but it reads like the car feature
  "lane keeping" and shares "Keep" with Keepwise; weaker than Keepden.
- **Firstlight, Mainstay, Homeward, Threadwell** — `.co.uk` and `.com` both registered; address check only, not taken
  further.

**New ideas that failed**

- **Good Stead / Goodstead** — sounds identical to [Goodsted](https://www.goodsted.com/), a live UK software platform
  (Goodsted Community Ltd, active); [goodstead.app](https://goodstead.app/) is live property-inspection software; all three
  plain addresses registered.
- **Steady Course** — [STEADY COURSE LTD 05528807](https://find-and-update.company-information.service.gov.uk/company/05528807)
  is active and filed as an education business.
- **Level Best** — two apps called "Level Best" are on the UK App Store; "LEVEL BEST" is a registered UK mark in other
  classes (UK00002451000); Level Best Ltd is active (building).
- **Front Foot** — "FrontFoot" is a registered UK mark in classes 9 and 42 (UK00004417719, filed Jul 2026).
- **Setsteady** — mirror image of a live app called Steadyset (steadyset.app; `steadyset.co.uk` registered 11 Oct 2026).
- **Steadfold** — steadfold.com is a live web agency (registered Sep 2026).
- **Fairsteps** — FAIRSTEPS is a
  [University of Sheffield framework for GP surgeries](https://sites.google.com/sheffield.ac.uk/dera/current-workstreams/fairsteps),
  so it reads as public sector.
- **Kinsteady** — nothing found, but weak, and it contains the registered mark "Steady".
- **Sound Footing** — Sound Footings Ltd is active, and "Footing" was ruled out in your June review.
- **Home by Six** — [homebysix.co.uk](https://homebysix.co.uk/) is a live UK app for clinic owners (registered Oct 2026).
- **Mind How You Go** — mindhowyougo.co.uk is a live UK hypnotherapy practice.
- **Off You Go** — live sites on `offyougo.co.uk` and `offyougo.com`.
- **Know the Ropes** — theropes.co.uk is a live UK consultancy called The Ropes; trade mark check not run.
- **Even Keel, Fingerpost, Slipway, Housecraft, Plumbline, Trellis, Surefoot, Handover, Kit List, Fair Enough, Quiet Word,
  Same Page, Ground Rules, Good Order, Due Course, Dab Hand, Measure Twice** — `.co.uk` and `.com` both registered; address
  check only, not taken further.

## What changed since July

Several addresses your July files recorded as unregistered are now taken: `getbearings.co.uk` (11 Oct 2026),
`keepside.co.uk` (28 Sep 2026), `soonly.co.uk` (13 Sep 2026) and `askmarlow.co.uk` (11 Oct 2026). Fledge, Ballast and Marlow
all gained UK trade marks in 2026. Nearly every sensible two-word name I tried already has its `.com` registered. Names in
this space go quickly.

## Checks I could not complete

- **UK IPO trade mark search: NOT DONE.** The site's security check blocked it. TMview was used instead for every name.
- **Classes.** TMview searches covered all classes; I then looked for classes 9, 41 and 42 in the results. I did not read
  the full goods-and-services wording of any mark.
- **Not looked at:** Google Play, social media handles, unregistered ("common law") use by small local businesses, and
  applications too new to show in TMview.
- **Web search** was run through a US-leaning tool, so small UK-only businesses may not have shown up.
- **Hubside and the BBC series** are noted from memory and were not confirmed today.

## Where this leaves you

- **Done:** research only. One file written (this one). Nothing registered, bought, filed or published.
- **Not done:** the real UK IPO search, saying the names aloud to parents, and any registration.
- **Decision for Ben:** which name, if any, goes forward. Registering an address costs money, so that is yours too.
- **Next:** pick one or two names; then someone runs the UK IPO search by hand in classes 9, 41 and 42 and you say the names
  to five parents before any address is registered.
