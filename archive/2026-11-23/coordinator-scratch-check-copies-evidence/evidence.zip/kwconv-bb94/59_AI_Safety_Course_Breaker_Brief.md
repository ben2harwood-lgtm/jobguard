# AI Safety Course - G1 Breaker Brief

*Created 2026-06-27. Purpose: adversarial review of the Phase 1 evidence layer before any Phase 2 course design or Phase 3 tool build consumes it.*

## Reviewer Role

You are the Breaker. Your job is to look for failure modes in the Phase 1 evidence layer, not to improve the course idea or write downstream content.

Assume the current Claim Register is plausible but not safe to trust. Find weak sourcing, overclaims, missing review flags, outdated routes, hidden legal conclusions, unsupported age-band claims, and any place where a downstream builder could accidentally turn a cautious evidence note into a safety promise.

## Inputs

Review these files:

- `57_AI_Safety_Course_Claim_Register.md` - the proposed Phase 1 Claim Register.
- `58_AI_Safety_Course_Gap_Register.md` - claims and decisions excluded from downstream use.
- The governing execution brief: Phase 1 must pass G1 before Phase 2 or Phase 3 starts.

Treat existing course drafts in files `50`-`56` as non-canonical. They may reveal intent, but they do not override the Claim Register or Gap Register.

## Non-Negotiable Guardrails

Flag any breach of these immediately:

- Parent is the sole user and learner. No child accounts, child-facing flows, or child PII.
- Prevention and routing only. No live-incident advice.
- Synthetic-media and CSAM-adjacent territory stays at recognition, harm, consent, legal seriousness, prevention, and routing. No mechanism, tool how-to, prompt patterns, or tool names as instructions.
- No safety guarantees, efficacy claims, academic claims, or legal conclusions.
- Legal and safeguarding claims must be flagged for human review.
- Design and build must not begin until G1 passes.

## What To Test

### 1. Source Tier Failures

For every safety, legal, or routing claim, check whether the source tier is adequate:

- Legal and routing claims need Tier 1.
- Risk and developmental claims need Tier 1 or Tier 2.
- Tier 3 and Tier 4 cannot carry a safety claim.

Flag any row where the source does not actually support the claim as written.

### 2. Overclaiming

Look for language that goes beyond the evidence, especially:

- "prevents", "protects", "keeps safe", "effective", "proven", "detects", "identifies", "verifies", or "diagnoses";
- causal claims about AI companions, wellbeing, grooming, scams, or over-reliance;
- prevalence claims without a current official or Tier 2 source;
- age-band claims that sound measured rather than practical.

### 3. Missing Review Flags

Check whether these are always flagged:

- offences, legality, image-based abuse, intimate-image law, data protection, Online Safety Act duties;
- live-incident routing, CEOP, IWF/Report Remove, police, school DSL, NSPCC/Childline;
- disclosures, self-harm, eating disorders, extremism, sexual coercion, blackmail, grooming, sextortion.

If a row contains legal or safeguarding substance and has `none` in Review flag, flag it.

### 4. Routing Accuracy

Check every routing row and routing mention for:

- current service name;
- correct URL or route;
- correct audience or eligibility;
- whether the row gives advice beyond signposting;
- whether the row could lead a parent to collect, store, forward, or upload harmful material to Bearings.

Routes to check especially: CEOP, IWF, Report Remove, Childline, NSPCC, 999/101, Action Fraud/Report Fraud, school DSL.

### 5. Currency Risk

Challenge whether `Stable` should instead be `Fast-moving` or `Annual update`, especially for:

- deepfake/intimate-image law;
- Ofcom Online Safety Act duties and codes;
- AI product behaviour;
- platform settings;
- routing URLs and helpline details;
- DfE/JCQ guidance.

### 6. Gap Handling

Check whether any excluded claim in `58` has leaked into `57` as if resolved.

Also check the reverse: any weak row in `57` that should move into `58`.

### 7. Downstream Misuse Risk

For each row, ask: "Could a course designer or tool builder turn this into unsafe copy?"

Flag rows that need tighter wording to prevent:

- real-case assessment;
- AI verdicts on messages/images;
- platform-specific static walkthroughs;
- child-data collection;
- reassurance that a checklist can determine safety;
- advice through a live incident.

## Pass Criteria For G1

G1 passes only if all are true:

- 100% of safety/legal/routing claims meet the source-tier rules.
- 100% of legal/safeguarding claims are flagged and do not conclude application to a live case.
- Material claims are triangulated or explicitly marked as single-source authoritative.
- Contradictions, uncertainty, and gaps are visible rather than hidden.
- All claims are dated.
- Fast-moving areas are marked for re-check before launch.
- The Gap Register is complete enough to prevent downstream overclaiming.

## Output Format

Return findings in this structure:

| Severity | Claim ID / Gap ID | Problem | Why it matters | Recommended action |
|---|---|---|---|---|
| Blocker / Major / Minor | e.g. SMI-003 | What is wrong | Safety, legal, evidential, or build risk | Patch wording / add flag / move to Gap Register / re-source / delete |

Severity definitions:

- **Blocker:** G1 cannot pass until fixed.
- **Major:** Should be fixed before Phase 2/3 consume the row.
- **Minor:** Clarifies wording, traceability, or maintainability but does not block G1 alone.

After the findings table, give:

- **G1 verdict:** Pass / Pass with required patches / Fail.
- **Claims to move to Gap Register.**
- **Claims needing human legal review.**
- **Claims needing human safeguarding review.**
- **Fast-moving claims needing pre-launch re-check.**

## Breaker Constraints

Do not write course modules, assets, landing-page copy, or tools.

Do not introduce new claims unless they are needed to explain why an existing claim fails.

Do not soften the guardrails for commercial reasons.

Do not treat this Breaker pass as legal, safeguarding, or clinical advice. It is an adversarial evidence review to prepare for human gates.
