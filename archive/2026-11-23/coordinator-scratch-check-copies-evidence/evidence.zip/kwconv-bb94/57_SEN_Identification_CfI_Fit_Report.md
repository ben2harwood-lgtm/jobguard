# SEN Identification CfI Fit Report

Produced: 27 June 2026  
Competition: CfI: Earlier identification of UK children with SEN  
Decision served: whether a non-diagnostic AI-in-education engine can be reshaped into a fundable Phase 1 bid without becoming either unsafe or merely "better teacher notes".

## Evidence Legend

- [verified - official]: official competition, government, regulator, or statutory guidance source.
- [verified - vendor]: vendor page describing the product category or product claims.
- [verified - independent]: independent/public-interest research or audit source.
- [inferred]: analytical conclusion from the cited evidence.
- [assumption]: needed because the engine canon and prior fit analysis were not supplied as separate pasted inputs.
- [could not verify]: searched or attempted, but source was unavailable or not supplied.

## 1. Executive Summary

Verdict: Conditional Fit, strengthened by founder/team clarification. Current safe framing is still incremental unless the concept is narrowed to a genuinely novel, non-diagnostic "learning-process evidence" capability. A bid should proceed only if the team can show that the engine observes how a pupil responds to specific professional supports - task clarification, retrieval prompt, explain-back, altered-transfer, scaffold-and-fade, defend-my-work, and interest-bridge - and converts those observations into auditable strengths-and-needs evidence for SENCO/teacher review. It must not identify SEN, diagnose, score, rank, predict traits, or auto-refer.

Updated odds: about 45-55% if the core team can evidence SENCO, educational psychologist, and educational expertise, and if school co-design/pilot, safeguarding/DPO, legal, and evaluation credibility are added or documented immediately. Below 25% if the bid relies mainly on internally authored prompts and checker prompts without independent school/user validation. The deadline is 5 August 2026 at 11:00am UK time, so the human critical path is still the limiting factor.

Top 3 risks:

| Risk | Why it matters | Gate implication |
|---|---|---|
| Novelty collapse | GL LASS/CoPS/Rapid, Dyslexia Portfolio, Speech and Language Link, CENTURY, Arbor, and Tes Provision Map already cover screening, profiling, gap identification, individual pathways, and SEND documentation. | Fatal unless the bid proves a distinct scaffold-response observation methodology. |
| Safeguarding/data risk | Even "non-diagnostic" observations about likely SEN-related needs may be child profiling or special-category-adjacent data. | Not fatal if human-reviewed and minimised, but [LEGAL REVIEW - required]. |
| Q10 evidence gap | The core team now appears to cover SENCO/educational psychology/educational expertise, but the competition still expects relevant users/beneficiaries in design and testing; top-band Q10 requires evidenced delivery capacity, not only internal expertise. | Fatal unless the bid documents the team's credentials, time allocation, school co-design/pilot partners, safeguarding/DPO/legal review, and evaluation plan. |

Immediate human actions: START NOW. Document the existing SENCO, educational psychologist, and educational expert roles, then secure or evidence safeguarding/DPO/legal review, evaluation capacity, and 2-4 school co-design partners. No prompt library or internal AI checker substitutes for school/user validation evidence.

## Team Clarification Addendum

Ben clarified after the first report that the working team includes SENCO, educational psychologist, and educational expert capability, and intends to design expert AI prompts plus expert AI checker prompts in-house. This improves Q10 materially. [verified - user clarification]

However, for the competition this should be framed as follows:

- Expert prompts are part of the technical method and quality-control system. [inferred]
- Expert checker prompts are useful for consistency, banned-claim detection, and first-pass output review. [inferred]
- They are not, by themselves, validation evidence. Top-band Q7/Q9/Q10 still need human expert sign-off, co-design records, pilot evidence, safeguarding/data governance, and an evaluation method. [inferred from S1/S2]
- The strongest bid position is "expert-designed AI with expert checker prompts and mandatory professional review", not "AI validates itself". [inferred]

## Assumptions From Missing Inputs

The attached request referenced B, "engine canon / control stack", and C, "prior fit analysis", but those were not supplied as separate pasted inputs. This report therefore uses only the control stack named inside the brief itself as the working engine canon:

- No scores, ranks, diagnoses, predictions, child-level trait claims, parent-anxiety framing, surveillance inference, or auto-referrals. [assumption]
- Mechanisms: task-understanding, retrieval, explain-back, altered transfer, scaffold-and-fade, defend-my-work, interest-bridge. [assumption]
- Prior fit analysis: not available; treated as absent, not as evidence. [could not verify]

## 2. Pass 1 - Competition Forensic Extraction

### Core Facts

Source for all rows unless stated otherwise: official competition page [S1], accessed 27 June 2026.

| Fact | Finding |
|---|---|
| Competition name | CfI: Earlier identification of UK children with SEN. [verified - official] |
| Funder/route | UKRI will invest up to GBP2.5m through a Contracts for Innovation competition. [verified - official] |
| Aim | Innovations enabling earlier, fairer, more reliable identification of SEN where existing market solutions underperform or do not operate. [verified - official] |
| UK remit | UK-wide; ALN in Wales and ASN in Scotland are included in the brief's definition of SEN. [verified - official] |
| Project focus | Developing, testing, and rolling out innovations for earlier identification and strengths-and-needs assessment that can integrate into education settings. [verified - official] |
| Phase | Phase 1 of a potential three-phase competition; only Phase 1 winners may be invited to Phase 2. [verified - official] |
| Number of awards | Up to 12 contracts expected, subject to quality and portfolio approach. [verified - official] |
| Contract value | GBP200k-GBP500k inclusive of VAT. [verified - official] |
| R&D rule | At least 50% of contract value directly and exclusively attributable to R&D services. [verified - official] |
| No profit | Costs must reflect actual fair-market costs and must not include profit. [verified - official] |
| Legal entity | Contract awarded to a single legal entity only. [verified - official] |
| Lead/team | Lead can be an organisation of any size and can work alone or use specialist subcontractors. [verified - official] |
| UK work | Majority of project work and key deliverables must be completed by applicant and carried out in the UK; most funding spent in the UK. [verified - official] |
| Timeline | Opened 23 June 2026; briefing 29 June 2026; closes 5 August 2026, 11:00am; feedback/notification 8 September 2026; project start/contract award from 1 October 2026; end by 30 September 2027. [verified - official] |
| Payment structure | Milestones must be SMART, tied to deliverables and payments, with payment schedule by month; payments are monthly in arrears after invoice within 30 days of each monitoring period. [verified - official, S1/S2] |
| Data sharing | Innovate UK, UKRI, and DfE may share relevant application, scoring, feedback, and contract-management information. [verified - official] |

### Scope And Mandatory Requirements

| Requirement | Implication for this concept |
|---|---|
| Enable one or both of: earlier/more accurate identification of children who have or are likely to have SEN; consistent, high-quality assessment of individual strengths and needs. [S1] | The concept should choose the second route: strengths-and-needs assessment evidence, not automated identification. [inferred] |
| Must move beyond concept development into delivery, adoption, and impact. [S1] | A pure research paper or framework is weak. Need a working prototype and school pilot. [inferred] |
| Must have tangible output: product, tool, framework, service model, or platform. [S1] | Prototype plus professional workflow can qualify. [inferred] |
| Must show usability and validity plans across regions and age groups with child, parent/carer, teacher, and SENCO co-design or engagement where appropriate. [S1] | Co-design partners are mandatory for credibility, not optional nice-to-have. [inferred] |
| Must commit to work with UKRI and DfE or devolved equivalents for adoption. [S1] | UK-wide language cannot be England-only if claiming UK-wide validity. [inferred] |
| Must follow UKRI preventing-harm policy. [S1] | Safeguarding package required from day 1. [verified - official] |
| Must demonstrate route to market/commercialisation. [S1] | A solo consultancy-only path is weak unless tied to deployable school workflow or platform. [inferred] |

### Explicit Reject Criteria

The competition says it will not fund projects that: [S1]

| Reject criterion | Relevance |
|---|---|
| Purely academic/fundamental research without near-term commercialisation or deployment. | Avoid "study only"; build a pilotable tool. |
| No clear plan involving relevant users/beneficiaries such as parents/carers, teachers, SENCOs, healthcare professionals in design/testing. | Fatal if no named partners. |
| Replicate existing commercially available SEN assessment tools without significant technological or operational innovation. | Main novelty threat. |
| Fail rigorous compliance with UK data protection and applicable statutory guidance, including SEN Code of Practice and Keeping Children Safe in Education in England. | Legal/safeguarding work package required. |
| Not original, out of scope, duplicate someone else's work, duplicate funded initiatives, covered by existing commercial agreements, or lacking UK child/family beneficiaries. | FTO and market map required. |

### Scorecard Map

Top-band criteria from assessor guidance [S2], accessed 27 June 2026.

Scoring/weighting note: the official application lists Q1-Q5 as not scored and Q6-Q12 as scored. The assessor guidance gives 1-10 scoring bands per scored question but does not publish separate numeric weights for Q6-Q12. Treat Q6-Q12 as all material unless Innovate UK confirms otherwise. [verified - official, S1/S2]

| Question | What is scored | Top-band answer must contain | Fit pressure |
|---|---|---|---|
| Q6 Proposed idea/technology | How well the proposal meets the challenge. | Clear description and compelling evidence that the idea/technology meets the competition challenge. | Must present professional observation evidence as directly addressing earlier, fairer, reliable strengths-and-needs assessment. |
| Q7 Technical project summary | Validity of technical approach. | Valid, highly relevant approach; credible, achievable deliverables; merit to solution and work. | Needs a specific observation protocol, prototype architecture, validation plan, and measurable technical deliverables. |
| Q8 State of art and IP | Innovation, novelty, FTO/IP. | Strong nearest-state-of-art understanding and clear novelty in concepts, approaches, methodologies, tools, or technologies. | Hardest question. "Profile plus strategies" is occupied by GL/Tes/CENTURY. |
| Q9 Project plan/methodology | Feasibility, risk, milestones, evaluation. | Detailed plan with key milestones; risks comprehensively covered and mitigated. | Must show school recruitment, ethics, data, prototype, pilot, and evaluation all fit 12 months. |
| Q10 Technical team/expertise | Skills, capabilities, experience. | Team and subcontractors give full confidence in successful delivery and commercial potential. | Most likely practical failure. Founder must add named SEN/education/data/evaluation expertise. |
| Q11 Costs/value | Realistic, justified, fair-market, no profit. | Fully justified costs and excellent value for money. | Budget can work at GBP400k-GBP480k inc VAT if >50% R&D. |
| Q12 Commercial potential | Market route and competitive advantage. | Commercial feasibility, detailed route to market, strong competitive advantage. | Must define school/MAT/SEND workflow buyer and avoid overclaiming government adoption. |

## 3. Pass 2 - Where SEN Identification Fails

| Pain point | Evidence | Scorecard use | Gate implication |
|---|---|---|---|
| Rising system demand | DfE 2025/26 statistics report over 1.8m pupils in England with SEN; EHC plans in schools rose to 538,547 and SEN support to 14.8% of pupils. [verified - official, S3] | Q6 challenge fit; Q12 market need. | Demand is real, but demand alone does not prove novelty. |
| EHCP pressure and waiting | DfE 2026 EHCP release reports 718,838 active EHC plans across ages 0-25, 162,702 assessment requests in 2025, and 46.1% of new plans issued within 20 weeks. [verified - official, S4] | Q6/Q12, shows pressure around pre-referral evidence and early support. | Supports a pre-referral evidence workflow if it reduces poor-quality evidence, not if it promises faster statutory decisions. |
| System not delivering value | NAO found demand for EHC plans rose 140% since 2015, SEN support also rose, and the system remained financially unsustainable. [verified - independent, S5] | Q6/Q12. | A bid can argue early, better evidence may reduce waste, but cannot claim to fix the SEND system. |
| Regional/school inconsistency | EPI found SEND identification varies substantially and that school attended explains much of the variation at primary level; disadvantaged and mobile/vulnerable pupils can be under-identified. [verified - independent, S6] | Q6 fairness; Q7 validation; Q9 evaluation. | Strong fit for standardised observation evidence, but requires bias testing. |
| Wales/Scotland localisation | Competition includes ALN/ASN in its SEN definition. Wales has statutory ALN Code; Scotland's ASL system records around 40% of pupils as receiving ASL, with Audit Scotland noting data inconsistencies/gaps. [verified - official/independent, S1/S7/S8] | Q6 UK remit; Q9 validation across regimes. | Do not claim UK-wide validity from England-only pilot. |
| Masking/quiet underperformance | EPI highlights children falling under the radar; GL CAT4 markets itself as identifying hidden abilities that may not be evident in class. [verified - independent/vendor, S6/S19] | Q6 fairness; Q8 differentiation. | Need observation methods that do not reward only vocal/confident pupils. |
| SENCO/teacher workload | Tes Provision Map markets SEND admin reduction, individual profiles, learning plans, reports, and intervention tracking; this shows a live market around SEND documentation burden. [verified - vendor, S21] | Q12 buyer need; Q9 adoption. | Any new tool must reduce documentation burden or integrate into it. |
| Speech-language/literacy overlap | Competition explicitly includes predictive value of early speech and language assessments; Speech and Language Link provides school SLCN identification/intervention packages. [verified - official/vendor, S1/S20] | Q6/Q8. | SALT validation is needed if outputs touch language comprehension, vocabulary, or explanation. |
| Weak pre-referral evidence | SEND Code of Practice embeds graduated assess-plan-do-review practice; existing provision software supports APDR documentation. [verified - official/vendor, S9/S21] | Q6/Q7/Q12. | Opportunity: make evidence better, not make decisions. |
| Transition points | Competition names universal review points and RBA-like deployment contexts; CAT4 also markets transition support. [verified - official/vendor, S1/S19] | Q6/Q12. | A narrow Year 6/7 or reception transition pilot could be credible, but must avoid predicting SEN. |

Pass 2 implication for gate: The problem is strong enough. The issue is not need; it is whether the proposed method is new and safe enough.

## 4. Pass 3 - State Of The Art And Novelty Red-Team

### Product/Category Map

| Product/category | What it does | What it does not do | Source |
|---|---|---|---|
| GL LASS | Digital cognitive profiling for ages 8-11; short tests across reasoning, reading, phonic decoding, spelling, memory, phonological awareness; produces graphical profiles, standardised results, and indications for action. | It is a standardised assessment/profile tool, not a non-scored observation evidence pack. | [verified - vendor, S15] |
| GL CoPS | Early digital cognitive profiling for ages 4-7 across working memory, phonological awareness/processing and related areas; produces profiles and intervention strategies. | It targets literacy/executive-function risk, not broad classroom strengths-and-needs observations. | [verified - vendor, S17] |
| GL Rapid | Light-touch screener for strengths/challenges related to potential dyslexia ages 4-15; immediate reports. | It is explicitly a screener and therefore outside the proposed no-screen/no-diagnosis discipline. | [verified - vendor, S16] |
| GL Dyslexia Portfolio | Evaluates literacy, processing, and memory; detailed strengths/challenges profile; standard age scores and support recommendations. | It is scored and dyslexia-specific; too close if the bid claims literacy profile novelty. | [verified - vendor, S25] |
| GL CAT4 | Reasoning assessment for ages 6-17+; standardised benchmarks, indicators, and teacher reports; supports transition and hidden ability insight. | It is ability/reasoning assessment, not SEN observation. | [verified - vendor, S19] |
| Exact/access arrangements | Digital screening/evidence for exam access arrangements, with standardised measures and item-level analysis. | It supports formal access-arrangement evidence, not broad early non-diagnostic needs evidence. | [verified - vendor, S18] |
| Speech and Language Link | School SLCN toolkit covering identification, intervention, training, resources, specialist therapist support, ages roughly 4-14. | It is SLCN-focused and sits partly in assessment/intervention territory. | [verified - vendor, S20] |
| Nessy | Structured literacy, dyslexia support, phonics/reading/spelling/maths learning resources. | Mainly intervention/learning support; current accessible page did not verify a current screener. | [verified - vendor, S24; screener detail could not verify] |
| Tes Provision Map | SEND management/provision mapping software; individual profiles, learning plans, pupil passports, APDR-aligned plans, intervention tracking, reporting, parent/agency communication. | It manages provision and documentation; it does not appear to generate novel learning-process evidence. | [verified - vendor, S21] |
| Arbor MIS | Cloud MIS with student profile, interventions, safeguarding, assessments/progress tracking, reporting, patterns and actions. | It is system-of-record/analytics workflow, not a SEN-specific observation method. | [verified - vendor, S22] |
| SIMS SEND/MIS | A school MIS/SEND management category incumbent; specific current SEND page not verified in this run. | Product detail not relied on. | [could not verify] |
| CENTURY | AI-powered assessment, teaching and learning platform; identifies learning gaps/misconceptions and creates individual learning pathways. | It focuses on curriculum learning pathways and performance analytics; not explicitly non-diagnostic SEN evidence. | [verified - vendor, S23] |
| Teacher observation/APDR frameworks | SEND Code of Practice and APDR practice already require assessment, planning, action, and review. | They are human process frameworks, not a specific AI interaction-observation engine. | [verified - official, S9] |

### Closest Existing Product Attack

Single closest product/category: CENTURY plus GL LASS/CoPS as a combined market pressure. [inferred]

The case that the concept is not novel:

- CENTURY already claims an AI-powered assessment, teaching, and learning platform, with data insights, personalised feedback, individual pathways, and identification of learning gaps/misconceptions. If "observe the process of the learning interaction" means logging learner responses to digital tasks and adapting the next activity, this is already close. [verified - vendor, S23; inferred]
- GL LASS and CoPS already use short digital/game-like tasks to profile cognitive/literacy-related strengths and challenges, with graphical profiles and indications for teaching strategies or interventions. If the proposed tool outputs "child shows working-memory/literacy/executive-function challenges, try X", it is very similar to existing products and falls into the Q8 5-6 or lower band. [verified - vendor, S15/S17; inferred]
- Tes Provision Map already owns much of the "organise teacher notes, pupil profiles, APDR learning plans, reports, interventions" workflow. If the bid is just better structured teacher notes, it risks explicit rejection as replication without significant innovation. [verified - vendor/official, S1/S21; inferred]
- Dyslexia Portfolio and Rapid show that score/report/recommendation products are already mature. The proposed no-score discipline protects safeguarding but also removes the most familiar assessment novelty signals. [verified - vendor, S16/S25; inferred]

### Capability That Survives

A distinct capability survives only if the bid specifies a contrastive, scaffold-response observation methodology:

> The product runs short learning interactions where professional supports are deliberately varied - task clarification, retrieval cue, explain-back, altered transfer, scaffold-and-fade, defend-my-work, interest-bridge - then produces an evidence bundle showing observable response patterns, confidence limits, context, and next evidence-gathering prompts for a qualified adult.

Why this survives:

- It is not a score, diagnosis, rank, trait prediction, or auto-referral. [inferred]
- It is not standardised cognitive profiling like LASS/CoPS, because the core signal is response-to-support across learning-process moves, not ability or risk measurement. [inferred]
- It is not Provision Map documentation, because the novel object is a structured evidence trace created during the interaction, not post-hoc admin. [inferred]
- It is not CENTURY-style curriculum gap analytics, because it focuses on what professional support changes in the process of learning, not just what content gap remains. [inferred]

[LEGAL REVIEW - required]: freedom to operate around task designs, reports, observation taxonomies, and any overlap with GL/CENTURY/Tes product workflows must be reviewed before application.

Pass 3 implication for gate: Q8 can be upper-band only if the bid leads with this scaffold-response evidence methodology. Without it, the concept is incremental.

## 5. Pass 4 - Engine-To-SEN Fit And Claims Red-Team

### Mechanism Map

| Engine mechanism | Non-diagnostic observation output | Reusable? | Must remove | Specialist validation needed |
|---|---|---|---|---|
| Task-understanding | "Needed X type of task clarification before starting" with transcript/evidence snippets. | Yes. | Any inference such as "has receptive language difficulty". | SENCO + SALT + ed psych. |
| Retrieval | "Retrieved prior step after cue/no cue; evidence shows cue type used." | Yes. | Memory score, working-memory trait claim, SEN prediction. | Ed psych/specialist assessor. |
| Explain-back | "Could explain the task/process using own words after prompt." | Yes. | Language impairment diagnosis or fluency judgement. | SALT + SENCO. |
| Altered transfer | "Applied same idea in changed context after specified support." | Yes. | Generalised ability score or curriculum mastery prediction. | SENCO + subject specialist + evaluation adviser. |
| Scaffold-and-fade | "Completed step with scaffold A; repeated with reduced scaffold B." | Core novelty. | Ranking pupils by independence. | Ed psych + SENCO + evaluator. |
| Defend-my-work | "Gave evidence/reason for answer when invited." | Yes, with care. | Judging confidence, honesty, argumentative traits, or behaviour. | SENCO + safeguarding reviewer. |
| Interest-bridge | "Engaged with task when linked to stated interest." | Limited. | Profiling interests, manipulation, or emotional inference. | Safeguarding/DPO + SENCO. |

### What Is Reusable

- Structured task flows, scaffold/fade logic, explain-back prompts, and human-readable evidence traces. [assumption]
- The no-score/no-diagnosis control discipline, if enforced in product, prompts, reports, marketing, and evaluation. [assumption]
- Adult professional decision-support framing. [assumption]

### What Must Be Removed Or Forbidden

- Any child-level score, rank, diagnostic label, SEN probability, dyslexia/autism/ADHD/language-disorder prediction, "risk level", automated referral, or "flagged child" workflow. [assumption]
- Any parent anxiety framing or child surveillance framing. [assumption]
- Any claim that the tool "identifies SEN" by itself, "detects hidden SEN", "prevents missed needs", or "keeps children safe". [inferred from S1/S10/S13/S14]
- Any fully automated child-facing output or unsupervised pupil-facing AI use without school safeguarding and data governance. [verified - official, S10/S13/S14]

### New Modules Required

| Module | Why required |
|---|---|
| SEN observation ontology | Maps observations to neutral strengths-and-needs evidence categories, not diagnoses. |
| Evidence provenance layer | Shows the task, prompt, support, learner response, context, and confidence limits. |
| Claim-control/lint layer | Blocks banned terms and diagnostic drift in all outputs. |
| Human review workflow | SENCO/teacher review before any evidence is added to a pupil record or shared. |
| Bias and usability evaluation | Tests age, region, disadvantage, language, EAL, gender, quiet pupils, neurodivergent masking, accessibility. |
| Data minimisation and retention | Avoids unnecessary special-category or free-text child data. |
| School integration model | Fits APDR, SENCO workflow, MIS/provision software exports without becoming a surveillance layer. |

### Claims Red-Team

| Allowed claim candidate | Reviewer attack | Safer boundary |
|---|---|---|
| "Shows how the pupil responded to different task supports." | Could still be profiling if aggregated into traits or automated recommendations. [LEGAL REVIEW - required] | Keep session-level evidence, professional interpretation, and explicit confidence limits. |
| "Helps teachers gather better pre-referral evidence." | Could be seen as SEN identification or referral triage. [LEGAL REVIEW - required] | "Supports professional evidence gathering for APDR discussions." |
| "Makes quiet underperformance more visible." | Could stigmatise quiet pupils or encourage surveillance. [LEGAL REVIEW - required] | "Offers structured, optional activities that can capture evidence from pupils who may not volunteer it in class." |
| "Identifies support patterns." | "Identifies" may imply automated detection of needs. | Use "records observed support-response patterns for review." |
| "Suggests next observations." | Could become auto-referral or intervention prescription. [LEGAL REVIEW - required] | "Prompts possible next evidence-gathering questions for a professional to accept, edit, or reject." |
| "Grows with the child." | Longitudinal profiling risk. [LEGAL REVIEW - required] | Use time-limited evidence packs and retention rules; avoid longitudinal trait claims. |
| "Useful across SEN, ALN, ASN." | UK-wide validity cannot be claimed from one-regime pilot. | "Designed for localisation; Phase 1 tests England plus at least one devolved-context advisory review." |

Pass 4 implication for gate: No unavoidable safeguarding/legal breach is visible if the product is strictly professional, human-reviewed, non-diagnostic, non-scored, and data-minimised. But several legal questions are unresolved and must be reviewed before submission.

## 6. Gate Decision

Gate verdict: Conditional Fit.

Pass conditions:

| Condition | Status |
|---|---|
| A genuinely novel non-diagnostic capability survives Pass 3. | Conditional yes: scaffold-response/process evidence survives; generic teacher-note structuring does not. |
| No allowed claim forces unavoidable safeguarding/legal breach. | Conditional yes: only with strict non-diagnostic controls, human review, data minimisation, and legal review. |
| Scorecard can plausibly be met by the stated core team. | Conditional yes: SENCO/educational psychology/educational expertise strengthens Q10, but the bid still needs documented time commitments, school co-design/pilot partners, safeguarding/DPO/legal review, and evaluation evidence. |

Stop/proceed rule:

- Proceed to application prep only if the team can document internal expert credentials/time commitments and secure school co-design commitments by an internal go/no-go date no later than 10 July 2026. [inferred]
- Stop if the concept cannot be reframed around scaffold-response evidence and remains "structured teacher observations", "SEN identification assistant", or "AI SEND screener". [inferred]

## 7. Pass 5 - Phase 1 Design

Only valid if the gate conditions above are met.

### Phase 1 Shape

Assumption: one legal entity leads; specialist work may be delivered internally by the named expert team or by specialist subcontractors where gaps remain; total budget around GBP480k inc VAT; no profit; more than 50% R&D. [assumption]

| Work package | Dates | Deliverables | Milestone/payment logic |
|---|---|---|---|
| WP1 Governance, scope, legal/safeguarding setup | Oct-Nov 2026 | Project plan, DPIA draft, safeguarding plan, claim-control standard, data map, advisory board terms. | Month 1-2 payments tied to signed governance pack and research protocol. |
| WP2 Co-design and observation taxonomy | Oct-Dec 2026 | Co-design sessions with SENCOs/teachers/parents; SEN observation ontology; task-support protocol v1. | Month 2-3 payments tied to co-design evidence and v1 protocol. |
| WP3 Prototype scaffold-response engine | Dec 2026-Mar 2027 | Working prototype for task flows, scaffold variations, evidence provenance, human review, export. | Month 4-6 payments tied to prototype demos and technical test evidence. |
| WP4 Specialist validation | Jan-Apr 2027 | SALT, ed psych/specialist assessor and SENCO review of outputs; banned-claim and harm testing. | Month 5-7 payments tied to validation reports and revised protocol. |
| WP5 School pilot | Apr-Jul 2027 | Pilot in 2-4 settings; usability, burden, fairness, and evidence-quality study; incident process. | Month 8-10 payments tied to recruitment, pilot completion, and data report. |
| WP6 Evaluation, adoption, commercial route | Jul-Sep 2027 | Final feasibility report, product roadmap, procurement/adoption analysis, Phase 2 readiness plan. | Month 11-12 payments tied to final report, demo, and commercial plan. |

### SMART Milestone Examples

| Month | Milestone |
|---|---|
| Oct 2026 | Governance pack approved by project lead and named safeguarding/DPO adviser; no child data collected before approval. |
| Nov 2026 | At least 12 co-design interviews completed across teachers/SENCOs/parents, with evidence mapped to Q6/Q7 assumptions. |
| Dec 2026 | Observation ontology v1 reviewed by SENCO, SALT, and ed psych/specialist assessor. |
| Feb 2027 | Prototype generates evidence packs for at least 5 task-support patterns with zero banned diagnostic/scoring outputs in test cases. |
| Apr 2027 | Specialist validation signs off safe claim boundaries or records unresolved blockers. |
| Jun 2027 | School pilot reaches predefined usability and evidence-quality thresholds. |
| Sep 2027 | Final feasibility and commercial plan completed, including no-go findings if validity or safeguarding fails. |

### Indicative Budget

Assumption: VAT registered; GBP400k net plus GBP80k VAT = GBP480k inclusive of VAT. Role lines below can be internal project capacity costs or specialist subcontractor costs, but must be actual fair-market costs and not include profit. [assumption]

| Cost line | Indicative inc VAT | R&D? |
|---|---:|---|
| Product/R&D lead and project management | GBP70k | Partly |
| Engineering/AI prototype | GBP115k | Yes |
| SENCO/SEND consultant | GBP35k | Yes |
| Educational psychologist/specialist assessor | GBP40k | Yes |
| SALT | GBP30k | Yes |
| Evaluation adviser/research design | GBP45k | Yes |
| School co-design/pilot release costs | GBP55k | Yes |
| Safeguarding, DPO, legal review | GBP35k | Partly |
| UX/accessibility/research operations | GBP25k | Yes |
| Cloud, security, tools, insurance | GBP15k | Partly |
| Commercial/adoption work | GBP15k | No |
| Contingency/overheads at fair-market actual cost | GBP45k | Mixed |
| Total | GBP480k | >50% R&D |

### Commercial/Adoption Route

Most plausible route: school/MAT/SEND service subscription or licence, integrated with APDR/provision workflows and potentially exported into MIS/provision systems. [inferred] Avoid claiming DfE procurement; the competition explicitly says adoption/implementation would be separate procurement. [verified - official, S1]

## 8. Positioning Verdict

Crux answer: incremental unless changed.

The non-diagnostic safety frame by itself does not make the concept innovative. In fact, it removes familiar assessment features - scores, norms, ranks, diagnostic flags, automated recommendations - and can leave the product looking like structured teacher notes. That would likely score around Q8 5-6 or lower because GL, Speech and Language Link, CENTURY, Arbor, and Tes already cover screening, profiles, learning gaps, pathways, intervention management, and SEND documentation. [inferred from S2/S15-S23]

Upper-band innovative only if the bid is reframed as:

> A professional scaffold-response observation system that tests how different forms of support alter the learning process, then produces auditable, non-scored evidence for SENCO/teacher review.

Smallest non-diagnostic capability change that restores novelty:

- Add a "contrastive support trial" layer: the same learning objective is explored through controlled variations in prompt/support type, and the output records what changed in the pupil's process.
- Add evidence provenance: every observation must trace back to a task, prompt, support move, response, and human review status.
- Add claim guardrails: outputs only describe observed process-response evidence and next evidence-gathering prompts, never SEN likelihood, condition labels, traits, scores, ranks, or referrals.

## 9. Sourcing And Co-Design Brief

START NOW. The core SENCO/educational psychologist/educational expert gap is now reduced by team clarification, but Q10 still needs evidence of who is doing what, how much time they will spend, and how the team will avoid self-validation. No research output, prompt library, or AI checker substitutes for securing co-design and pilot evidence from real settings.

| Role | Why mandatory | Scorecard evidence satisfied | Selection criteria | Where/how to find |
|---|---|---|---|---|
| SENCO/SEND lead | Grounds APDR workflow, classroom feasibility, teacher burden, non-diagnostic language. | Q6, Q7, Q9, Q10, Q12. | If internal: document current/recent role, mainstream/SEND support experience, project time allocation, and sign-off authority. If external: same criteria plus availability. | Internal role now appears available; external backup through nasen/Whole School SEND, local authority SENCO networks, MAT inclusion leads. |
| Educational psychologist or specialist assessor | Validates that observation claims do not masquerade as psychometric assessment or diagnosis. | Q7, Q8, Q10. | If internal: document qualification/registration/status, scope of role, and independence controls. If external: same criteria plus conflict/IP checks. | Internal role now appears available; external backup through Association of Educational Psychologists, independent EP practices, university EP networks. |
| SALT | Required if task-understanding, explain-back, vocabulary, narrative, or language observations are used. | Q6, Q7, Q10. | Paediatric/school SLCN experience; understands classroom universal/selective support. | RCSLT networks, local NHS/independent speech-language services, Speech and Language Link-adjacent contacts. |
| Safeguarding/DPO | Handles child data, DPIA, KCSIE, UK GDPR, profiling, retention, incident routes. | Q9, Q10, reject-criteria compliance. | School/edtech DPO experience; safeguarding policy literacy; can produce written review. | Education DPO consultants, local authority data-protection services, edtech governance networks. |
| Evaluation adviser | Designs feasibility, usability, validity, bias and burden study. | Q7, Q9, Q11. | Mixed-methods education evaluation; school pilot experience; credible measurement without scores. | NFER/university education departments, independent evaluators, EEF-connected researchers. |
| School co-design partners | Competition expects relevant users and beneficiaries in design/testing. | Q6, Q9, Q10, Q12. | 2-4 settings; at least one mainstream primary/secondary; ideally one high-disadvantage setting and one devolved-context advisory partner if UK-wide claims remain. | MATs, LA inclusion teams, SENCO networks, direct founder outreach. |
| Parent/carer advisory input | Needed to test acceptability and anxiety/claims risk. | Q6, Q9. | Parents/carers of children receiving SEN support; diverse contexts; paid advisory time. | School partners, SENDIASS routes, parent-carer forums. |

Recruitment pack should ask for:

- Named role, time commitment, rate, availability before 5 August 2026.
- Permission to cite role/commitment in the bid where appropriate.
- Conflict/IP/FTO disclosures.
- Agreement that the product remains non-diagnostic and non-scored.

Expert AI prompt/checker pack should include:

- Expert prompt design rationale mapped to the observation ontology and the no-score/no-diagnosis canon.
- Checker prompts for banned claims, diagnostic drift, unsupported inferences, stigma/anxiety language, missing evidence provenance, and over-automation.
- A "checker failure log" showing examples where the checker rejected outputs and how the underlying prompt/product was improved.
- Human expert override and sign-off rules; never present AI checker output as independent validation.

## 10. [LEGAL REVIEW] Register

| Issue | Specific legal question |
|---|---|
| Child data category | Are support-response observations about suspected SEN, language, cognition, or access needs special-category data, health data, or otherwise high-risk child data under UK GDPR/Data Protection Act? |
| Profiling | Does repeated scaffold-response evidence amount to child profiling even without scores or diagnoses? |
| Automated decision-making | Does suggesting next observations or professional prompts create automated decision support with legal/similar significant effects? |
| Lawful basis | Who is controller/processor, and what lawful basis applies for school pilots and commercial use? |
| DPIA | What DPIA is required before any child-facing or pupil-record-adjacent pilot? |
| SEND statutory framework | Does the tool's output risk being treated as assessment, advice, or evidence under the SEN Code, ALN Code, ASN framework, or EHCP/IDP processes? |
| Safeguarding | What KCSIE-aligned process is required if observations disclose harm, distress, or unmet safeguarding needs? |
| Data minimisation/retention | What is the lawful retention period for evidence traces, transcripts, prompts, and reviewer notes? |
| Equality/bias | What fairness testing is required across disability, sex, ethnicity, EAL, deprivation, age, and devolved regimes? |
| IP/FTO | Do task formats, report formats, support-response taxonomies, or integrations overlap with GL, Speech and Language Link, CENTURY, Tes, Arbor, or other incumbents? |
| Procurement/contract | Does the cost model comply with Contracts for Innovation no-profit, VAT, R&D, milestone, and IP clauses? |

## 11. Self-Check

| Check | Status |
|---|---|
| Every competition fact sourced to official source | Yes: S1/S2. |
| Novelty attacked, not asserted | Yes: Pass 3 names closest products and non-novel version. |
| Allowed claims tested against safeguarding/ICO lens | Yes: Pass 4 and legal register. |
| Non-diagnostic constraint held | Yes: no scores, ranks, diagnoses, predictions, auto-referrals recommended. |
| Gate verdict has teeth | Yes: stop if team or scaffold-response novelty cannot be secured. |
| Positioning verdict answers crux | Yes: incremental unless scaffold-response evidence layer is adopted. |
| Sourcing/co-design flagged as human critical path | Yes: Section 9. |
| Legal questions flagged, not resolved | Yes: Section 10. |
| Assumptions marked | Yes: missing engine canon/prior fit and Phase 1 budget/team assumptions marked. |

## 12. Source List

All sources accessed 27 June 2026.

| ID | Source | Label |
|---|---|---|
| S1 | Official competition page, "CfI: Earlier identification of UK children with SEN", Innovation Funding Service: https://apply-for-innovation-funding.service.gov.uk/competition/2511/overview/cc9f4bb9-55a5-4b4c-9843-015c385e021f | [verified - official] |
| S2 | Official assessor guidance PDF, "CfI Earlier identification of UK children with SEN Assessors Guidance.pdf": https://apply-for-innovation-funding.service.gov.uk/competition/2511/download/29463 | [verified - official] |
| S3 | DfE, "Special educational needs in England", academic year 2025/26: https://explore-education-statistics.service.gov.uk/find-statistics/special-educational-needs-in-england/2025-26 | [verified - official] |
| S4 | DfE, "Education, health and care plans", reporting year 2026: https://explore-education-statistics.service.gov.uk/find-statistics/education-health-and-care-plans/2026 | [verified - official] |
| S5 | National Audit Office, "Support for children and young people with special educational needs": https://www.nao.org.uk/reports/support-for-children-and-young-people-with-special-educational-needs/ | [verified - independent] |
| S6 | Education Policy Institute, "Identifying pupils with special educational needs and disabilities", 19 March 2021: https://epi.org.uk/publications-and-research/identifying-send/ | [verified - independent] |
| S7 | Audit Scotland, "Additional support for learning", February 2025: https://audit.scot/publications/additional-support-for-learning | [verified - independent] |
| S8 | Welsh Government, "The additional learning needs code": https://www.gov.wales/additional-learning-needs-code | [verified - official] |
| S9 | DfE/DHSC, "SEND code of practice: 0 to 25 years": https://www.gov.uk/government/publications/send-code-of-practice-0-to-25 | [verified - official] |
| S10 | DfE, "Keeping children safe in education": https://www.gov.uk/government/publications/keeping-children-safe-in-education--2 | [verified - official] |
| S11 | ICO, "Children and the UK GDPR": https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/childrens-information/children-and-the-uk-gdpr/ | [verified - official/regulator] |
| S12 | ICO, "Artificial intelligence": https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/artificial-intelligence/ | [verified - official/regulator] |
| S13 | DfE, "Generative AI: product safety standards": https://www.gov.uk/government/publications/generative-ai-product-safety-standards/generative-ai-product-safety-standards | [verified - official] |
| S14 | DfE, "Generative artificial intelligence (AI) in education": https://www.gov.uk/government/publications/generative-artificial-intelligence-in-education/generative-artificial-intelligence-ai-in-education | [verified - official] |
| S15 | GL Assessment, "LASS 8-11": https://www.gl-assessment.co.uk/products/lass/ | [verified - vendor] |
| S16 | GL Assessment, "Rapid": https://www.gl-assessment.co.uk/products/rapid/ | [verified - vendor] |
| S17 | GL Assessment, "CoPS": https://www.gl-assessment.co.uk/products/cops/ | [verified - vendor] |
| S18 | GL Assessment, "Exact": https://www.gl-assessment.co.uk/products/exact/ | [verified - vendor] |
| S19 | GL Assessment, "CAT4": https://www.gl-assessment.co.uk/products/cat4/ | [verified - vendor] |
| S20 | Speech and Language Link: https://speechandlanguage.link/ | [verified - vendor] |
| S21 | Tes, "Tes Provision Map": https://www.tes.com/en-gb/for-schools/provision-map | [verified - vendor] |
| S22 | Arbor, "School MIS": https://arbor-education.com/school-mis/ | [verified - vendor] |
| S23 | CENTURY, "CENTURY for secondary schools": https://www.century.tech/explore-century/secondary-schools/ | [verified - vendor] |
| S24 | Nessy Learning homepage: https://www.nessy.com/en-gb | [verified - vendor] |
| S25 | GL Assessment, "Dyslexia Portfolio": https://www.gl-assessment.co.uk/products/dyslexia-portfolio/ | [verified - vendor] |
