# AI Safety Course - Pre-Revenue Paid Pilot Scope

*Created 2026-06-27. Status: conservative scope for validating demand before paid legal/safeguarding sign-off. This is not a launch approval. It defines the narrowest version that can be prepared while using AI-assisted review and manual founder oversight.*

## Position

The product can keep moving before paid professional sign-off, but it should do so as a **manual founding pilot**, not a scaled public course launch.

The safest commercial test is to sell a small, manually fulfilled parent education package with:

- no child accounts;
- no child-facing content;
- no child PII;
- no uploads or incident detail;
- no live-incident advice;
- no AI judgement of real content;
- no public Scenario Trainer, Self-Check, Stay Current update stream, or Routing Card unless narrowed and reviewed;
- no claim of legal/safeguarding sign-off.

## What Can Be Prepared Now

| Item | Status before paid human sign-off | Notes |
|---|---|---|
| Course outline | Can be shown in sales conversations | Use cautious, non-alarmist copy and no legal clearance claims. |
| Module scripts | Can be drafted | Keep Claim IDs attached and route live concerns out. |
| Family AI Safety Agreement builder | Can be used as a preview/draft tool | Keep no-storage/no-child-data; review wording before broad use. |
| Printable asset pack | Can be drafted | Do not mark route card print-ready. |
| Scenario Trainer | Internal only | Keep static draft data; no public route. |
| Readiness Self-Check | Internal only | Keep navigation-only draft data; no public route. |
| Stay Current stream | Internal only | Use as workflow/backlog, not a public promise of total currency. |
| Routing Card | Internal draft only | Needs source re-check plus legal/safeguarding review before print-ready use. |
| Landing/sales page | Can be drafted | Must avoid review/approval claims, compliance claims, and safety-outcome claims. |
| Payment link | Can be prepared but not scaled | Use only after final founder checks, privacy/terms/consumer-law basics, emergency signpost verification, and AI review findings are patched. |

## Minimum Sellable Pilot

Name:

**Bearings AI Safety Course - Founding Parent Pilot**

Format:

- Small manual cohort or individual founding buyers.
- Founder-reviewed delivery.
- Recorded or written modules only after AI legal/safeguarding review findings are patched.
- Family AI Safety Agreement and Private Stays Private / Verify Before Trust assets first.
- Routing handled by the existing emergency signpost, after that page is line-checked and linked, not a new print-ready card.

Suggested pilot inclusion:

1. Module 1: The AI Safety Map.
2. Module 2: Private Stays Private.
3. Module 3: Tool, Not Person.
4. Module 4: Verify Before Trust.
5. Family AI Safety Agreement builder.
6. Short "where to get help" signpost linking to the verified emergency page.

Hold back from the first paid pilot unless AI review and founder checks are strong:

- Module 6 synthetic-media/image-risk detail.
- Full Scenario Trainer.
- Full Readiness Self-Check.
- Printable Routing Card.
- Any claim about current law that has not been source re-checked immediately before sale.

## Sales Copy Boundary

Allowed:

- "A calm parent-led course for setting AI boundaries at home."
- "Helps parents set household rules, keep private information out of AI tools, and practise verification habits."
- "Draws on publicly available UK guidance and is being developed with a cautious review process."
- "If something is already happening, the course signposts to qualified services."
- "Founding pilot: content may change as we review and improve it."

Avoid:

- Claims that the course has been legally reviewed.
- Claims that the course has been safeguarding reviewed.
- Expert-approval claims.
- Safety-outcome claims.
- Harm-prevention claims.
- Compliance-completion claims.
- Child-safety-by-design claims.
- Anxiety-elimination claims.
- Claims that AI will assess a parent's situation.
- Offers to upload or paste a message/image for a verdict.

## Buyer Notice For Founding Pilot

Suggested wording:

> This is a founding pilot of a parent education course. It helps you set household AI rules, keep private information out of tools, and know when to use official routes. It is not legal advice, safeguarding advice, monitoring, crisis help, or a guarantee of outcomes. Please do not send us names, school details, screenshots, messages, images, or incident details. If something is happening now, use the emergency signpost.

## Manual Fulfilment Rules

- Review every email and output before sending.
- Do not answer live-incident questions; reply with the emergency/signpost boundary.
- Do not ask for screenshots, messages, images, school names, child names, or incident detail.
- Keep a short log of questions parents ask, but remove identifying details.
- Keep feedback to clarity, usefulness, and buyer language; do not claim efficacy.
- If a parent raises a live concern, stop the product conversation and signpost.
- Do not open, preview, download, save, copy, screenshot, forward, or upload unsolicited images, screenshots, messages, attachments, or incident material.
- If suspected under-18 nude or sexual material is received, stop the pilot channel, do not handle the material further, use the verified signpost/qualified route, and seek legal/safeguarding advice before any further action.

## AI Review Gate Before Pilot

Before any paid pilot:

1. Run the legal AI review brief.
2. Run the safeguarding AI review brief.
3. Create `73_AI_Safety_Course_PreRevenue_AI_Review_Findings.md`.
4. Patch all blockers and high findings.
5. Verify the emergency signpost line by line against current official sources.
6. Add first-sale basics: pre-contract information, cancellation/refund wording, plain terms, privacy notice, and ICO/data-protection fee decision.
7. Run content lint and guardrail scans.
8. Keep any unresolved legal/safeguarding issues out of pilot materials.

## Paid Human Review Trigger

Pay for professional review before any of these:

- public launch beyond a small founding pilot;
- school/PTA circulation;
- publishing the Scenario Trainer, Self-Check, or Routing Card;
- publishing synthetic-media/image-risk module as a major sales feature;
- using "reviewed", "expert", "approved", "legal", or "safeguarding" trust claims;
- more than 5 paying pilot households;
- any paid ads or broad email launch.

## Current Recommendation

Continue building:

- review briefs;
- pilot scope;
- low-risk module scripts;
- Family Agreement and privacy/verification assets;
- sales-page draft with cautious language.

Do not yet publish:

- Scenario Trainer;
- Readiness Self-Check;
- Routing Card;
- legal-current claims;
- route-current claims;
- platform-specific AI setting claims.
