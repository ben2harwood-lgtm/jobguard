# Privacy & Data Notice — V1 draft

**Two parts: (1) the minimal data model that engineers/forms must enforce, and (2) the parent-facing privacy notice.** This is a working draft built to UK GDPR / DPA 2018 data-minimisation duties — **send to a solicitor/DPO for sign-off before launch** `[solicitor]`. Confidence tags as elsewhere.

---

## Part 1 — The minimal data model (build to this)

**Principle:** collect the least data needed to produce the report; collect **no child-identifiable data**; collect **no special-category data**; no screenshots, no message uploads, no incident evidence. This is what keeps you clear of the ICO Children's Code and Article 9 risk `[confirmed]`.

| Data | Collected? | Why | Retention |
|---|---|---|---|
| Parent email | Yes | Deliver the report; account for the purchase | Duration of relationship + statutory record period |
| Parent name | Optional | Personalise correspondence | As above |
| Payment | Via Stripe | Take payment | Held by Stripe (processor); you keep order records, not card data |
| Questionnaire answers (structured) | Yes | Produce the report | Working data deleted after delivery; see below |
| Child's age **band** (not DOB) | Yes | Age-appropriate guidance | With the report record |
| Child's first name / initial | **Optional, default skip** | Light personalisation only | **Deleted immediately after report delivery** |
| Child's full name, DOB, school | **Never** | Not needed | n/a |
| Screenshots, messages, incident details | **Never** | Highest-risk data; not needed for prevention | n/a |
| Special-category data (health, etc.) | **Never** — design the free-text box to discourage it | Avoids Article 9 | n/a |

**Free-text handling:** the one optional free-text box (questionnaire Q25) carries a visible instruction not to include names, school, or live-incident details, and points to the emergency signpost. On review, redact anything identifying before storing `[inference]`.

**Lawful bases** `[confirmed]`: report delivery / subscription = **Art 6(1)(b) contract**; service improvement & security = **Art 6(1)(f) legitimate interests** (keep a one-page Legitimate Interests Assessment); marketing emails = **PECR** soft-opt-in or **consent**, kept separate from the purchase.

**Retention specifics** `ASSUMPTION` (confirm with solicitor): working questionnaire data and any optional child first name deleted within 30 days of report delivery; order/financial records kept for the statutory period (6 years) for tax; email kept until the person unsubscribes/asks for erasure.

**Accountability artefacts to have on file before launch** `[confirmed]`: this privacy notice, a retention schedule, the Legitimate Interests Assessment, a short "Children's Code does-not-apply" assessment, and a lightweight DPIA-style risk note. Register and pay the **ICO data-protection fee** (Tier 1, £52). Honour data-subject rights (access, erasure) — a simple email route is fine at this scale.

---

## Part 2 — Parent-facing privacy notice (plain English draft)

### Your privacy

We built this service to protect families — so we hold ourselves to collecting as little of your data as possible, and **none that identifies your child.**

**What we collect**

- Your **email address** (and your name, if you give it) — to send your report and handle your order.
- Your **answers to the questionnaire** — to write your report.
- Your child's **age band** (for example, 13–14) — so the guidance fits their age. We do **not** ask for their date of birth.
- Optionally, your child's **first name or an initial** — only if you choose to add it for a more personal report. You can skip this, and we'd rather you did if you're unsure. If you do add it, we delete it as soon as your report is sent.

**What we never collect**

- Your child's full name, date of birth, or school.
- Screenshots, messages, photos, or any details of a live incident.
- Any health, wellbeing, or other sensitive information about your child.

**Why we collect it, and what we do with it**

We use your answers to produce your personalised report, which a real person reviews before it's sent. We use your email to deliver it and, if you've agreed, to send you occasional updates (you can unsubscribe anytime). We take payment through Stripe; we don't see or store your card details.

**How long we keep it**

We delete the working data from your questionnaire (and any optional first name) within 30 days of sending your report. We keep order records for as long as the law requires us to for tax. We keep your email until you ask us to remove it or unsubscribe.

**Who can see it**

Only us. We don't sell your data, and we don't share it except with the services we need to run this (such as our email and payment providers), who process it on our behalf.

**Your rights**

You can ask us for a copy of your data, ask us to correct or delete it, or withdraw consent for emails — just email us at [EMAIL] and we'll sort it. You can also complain to the Information Commissioner's Office (ico.org.uk).

**One important thing**

This service is for parents. It doesn't monitor your child, and your child doesn't interact with us. If you're dealing with something urgent right now, please use our [emergency signpost](03_Emergency_Signpost_Screen.html) or call 999 — we point you to the right help, we don't handle emergencies ourselves.

*Data controller: [NAME / TRADING NAME], registered with the ICO (fee tier 1). Contact: [EMAIL]. Last updated: [DATE]. This notice will be finalised on legal review before launch.*
