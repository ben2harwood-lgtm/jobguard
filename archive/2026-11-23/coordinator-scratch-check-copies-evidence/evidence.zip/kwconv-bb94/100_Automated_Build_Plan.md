# 100 — Automated Build Plan: Keepwise, Fully Automated

**Status:** Execution plan. Supersedes the sprint sketch in `101_Tool_Build_Specs.md` where the two differ; the confirmed decision set (founder, 2026-07-04) overrides both.
**Version:** v1.1, revised 2026-07-05 after external critique — adjudicated. Accepted points are folded into the sections below and marked *(v1.1)*; the adjudication record is Appendix A.
**Sources:** blueprint `99_Automated_Offering_Design.md`; `101_Tool_Build_Specs.md` (the ten tool specs — normative acceptance criteria live there); §7.5 block taxonomy (reproduced in §3 below); spec `21` (revised §7.5, §2 guardrails, §10.3 lint); memo `96` §11; memo `97` condition 5; for Gate B0: `86_..._Terms_Privacy_Drafts.md`, `79_..._Email_Templates.md`, audit register items F24/F25/F71.
**Date:** 2026-07-05. British English throughout.

---

## 1. What we are building (the confirmed decision set, restated as constraints)

1. **Fully automated Keepwise.** No per-customer human labour anywhere in the delivery path. Plans are assembled from published content blocks (spec 21 §7.5 as rewritten, already committed); no LLM touches any customer-facing word. The authoring prompt now lives at `scripts/editorial/plan-prompt.ts` — relocated out of `lib/` with a CI import guard so nothing in the delivery path can import it *(v1.1; done by the lead session, 2026-07-05)*.
2. **Pricing.** System **£49 one-off** (env default in `lib/pricing.ts` changes 99 → 49). **Stay Current renewal £29/yr** (from 59). Founding pricing is **retired** — no £79 anchor, no fake discounts; founding tokens and copy are removed, not re-pointed (CPR-clean).
3. **The AI course folds in.** The AI Readiness Lab becomes a module of the £49 product once built and safeguarding-passed. No separate £49 course SKU.
4. **Honesty rule for the offer page.** The pricing page claims only what ships *today*: instant plan, 51-item library including the AI guides, conversation scripts, Family Agreement builder, printables, first year of updates. *(v1.1)* The updates line reads "**first year of updates included**" and carries **no calendar promise** for the digest (Option B — see §2 M4). The course module and later tools are scheduled here, not promised there.
5. **Concierge (£650) retired.** Per-customer labour by definition. Out of nav, pricing and the `/start` recommendation; `/concierge` becomes a brief honest notice linking to `/pricing` — no enquiry form.
6. **Claims sweep.** Every "checked/reviewed by a real person" claim is now false and must go. New true claims *(v1.1 wording)*:
   - *"Every published guidance block is editor-reviewed, dated, versioned and traceable to a source."* This **replaces** the earlier *"every word written, checked and dated by our editors"* — we use AI-assisted drafting, so any "written by" claim is fragile and it goes.
   - *"Matched to your children's ages and apps in minutes."*
   - *"Kept current all year"* — only ever with its **bounded definition**: review dates on blocks, an urgent withdrawal path, and update notices when relevant guidance changes; **never** implying real-time monitoring of platforms. The internal cadence standard behind the claim: monthly signpost check, six-month platform review, twelve-month concern review.
   Banned: "reviewed for you", "human-reviewed", "a real person checks/checked", "not a chatbot", "safe/pass/certified/protects", any founding/scarcity claim, promising unshipped tools or the course.
7. **Unchanged.** All guardrails; the emergency page (ungated, non-monetised); the library gate; the `ai-safety-*.ts` libs stay review-gated and unrouted (tests enforce this — do not route them).
8. **Naming.** Keepwise vs Bearings must be reconciled **before any offer page ships**. Founder decision; a blocking item in M0, not resolved by this plan.
9. **The data promise** *(v1.1)*. Public, enumerated form: *"No child names, no dates of birth, no school names, no message uploads, no photos, no contact lists, no monitoring, and no free-text disclosures about your child. Keepwise uses minimal parent-provided household setup information to assemble your plan."* The internal invariant **"no child-identifiable data"** stays as the design North Star — but note that age band + platforms tied to a parent account is still **personal data**, and Gate B0 treats it as such. Sibling count is **kept** as an interpolation input, with a data-minimisation justification recorded in the B0 data inventory.

---

## 2. Build-order roadmap and the pilot line

Six milestones and **four gates** *(v1.1: A0 and B0 added — see §5)*. The **pilot line** sits after M3: everything above it must exist before the first £49 sale; everything below it ships to live customers on a schedule the offer page does not promise.

### M0 — Decision sweep, taxonomy lock and launch scoping (pre-work)

- Pricing env change (99 → 49); renewal £29/yr wired; founding tokens/copy purged repo-wide; concierge retired per §1.5; claims sweep per §1.6 against the banned list, enforced as lint where the strings are templated.
- Keepwise/Bearings naming decision taken and applied to the offer-page draft.
- Block taxonomy finalised: 11 classes, ID grammar, frontmatter schema, the trigger table (§3.4) signed off as the authoring checklist.
- Decision recorded on the two open flags (§7): generic-platform fallback for the seven uncovered platforms, and Q1 made multi-band so multi-child households get per-band sections without overpromising per-child personalisation.
- *(v1.1)* **Gate B0 scoping + data inventory.** Enumerate every stored field, its lawful basis, retention and deletion path (including the sibling-count minimisation justification, §1.9); scope the B0 pack from existing assets (§5 Gate B0).
- *(v1.1)* **OSA scope memo.** Parent-facing service, no user-to-user functionality, no search ⇒ outside Part 3 duties; legal to confirm at B0. Standing rule: re-assess if any community, child-facing, search or AI-chat feature is ever proposed.
- *(v1.1)* **VAT/pricing note.** £49 is VAT-inclusive for the pilot; ~1,837 sales crosses the £90k registration threshold; net becomes ~£40.83 per sale if the price is held. Decision point logged, not decided here.
- *(v1.1)* **Unit-economics checkpoint.** Fees, refund rate, support minutes per customer, review amortisation, break-even volume, renewal conversion needed — written down before the first sale, revisited after the pilot cohort.
- *(v1.1)* **Standards adopted:** accessibility target (WCAG 2.2 AA on core flows); content-health thresholds (§3.6); admin security baseline (§4.1); and the **launch-critical platform coverage decision** — which platforms get full blocks vs thin honest blocks for launch.

### M1 — Editorial: MVP block pool (parallel track, starts alongside M0)

*(v1.1)* **Coverage-based, not count-based.** ~140 published blocks (MVP subset of the ~215–225 full pool) is now an **estimate, not the criterion**. MVP editorial is done when every one of the following is covered by a published block or an explicitly-named published fallback:

- **every questionnaire answer option** — including **thin honest blocks** for the seven previously-uncovered platforms (X, Telegram, Signal, smart TV, VR, smartwatch, mobile games with chat), each on the thin-block template: *what it is / common misunderstanding / what to check this week / what we cannot verify / library link / last-checked date / age-band notes / fallback*;
- **every high-risk concern**; **every age band**; **every urgent path**; **every first-week action**;
- the **top platform setup flows**; and
- **every claim the offer page makes**.

Composition as before: all `open`/`map`/`action` fragments, the Core Five platform tiers plus top tick-rate platforms, concern digests for fired triggers, all five band skeletons, all conversation blocks, top calm blocks, all nine `task` blocks, fixed furniture, the hash-pinned signpost, plus the published **generic-platform fallback** and the **evergreen fallback** per slot. Authoring runs slice-first (~48% of the corpus slices from existing MDX — see §3.5).

*(v1.1)* **Gate A0** (safeguarding architecture pre-read, §5) runs after the taxonomy draft and **before bulk authoring** — it exists to prevent authoring the pool against an architecture a reviewer would send back. *(v1.1)* A **content inventory map** is maintained from the first block: customer-visible library item ↔ source MDX ↔ derived block IDs ↔ plan slots ↔ review owner/date — so "51 items" vs "~140 blocks" vs offer-page claims never drift.

### M2 — Spec 1: Block-Assembly Plan Engine (now six sub-specs)

*(v1.1)* Spec 1 is split into six sub-specs: **1a** block schema/registry · **1b** assembly engine · **1c** publish admin + reviewer workflow · **1d** audit log/re-render · **1e** safety lint + CI · **1f** customer render/delivery. The original 60–80 h was optimistic for the full set; **re-estimate per sub-spec** at M2 kickoff.

Scope: engine, per-block publish admin (built to the **admin security baseline**, §4.1), immutable `block_publish_log`, `plan_assemblies` log (full field list in §4.2 — **captured from sale #1**), `verifySignpost()` at build and render, interpolation whitelist lint, the Don't-know rules (§3.4, incl. the *(v1.1)* high-stakes refinement), the *(v1.1)* **severity/interrupt layer** (§3.4), multi-band splice connectors.

*(v1.1)* **Render modes split:**
- **Audit render** — byte-identical reconstruction from the assembly log: original block versions + interpolation values + signpost version + code Git SHA + template version. The log must capture **all** of these from the first sale.
- **Customer current render** — latest published blocks + current signpost, logged as a **new** assembly.

The re-render **tooling** may land post-pilot; the complete **log** may not. Exit: 20 adversarial persona plans assembled deterministically and editor-signed.

### M3 — Pilot surface: Specs 2, 5, 9 + Gate A + Gate B0 + offer page + launch ops

Guided Setup Session (10 flows, DNS sub-feature flagged **off**), Family Agreement builder, Printables pack. Offer page at £49 written to the honesty rule (§1.6, §1.9) — promising "first year of updates included" with **no calendar promise** (Option B, M4 below). Plus *(v1.1)*:

- **First-week activation experience.** The customer lands on "**your household's 3 most useful actions this week**", each a 10-minute guided step with tick-off; the agreement pre-fills from the same choices; the emergency card is immediately printable; completion state is visible. Perceived value = *doing*, not library volume.
- **Ops completeness.** Checkout, delivery email, deletion request and account recovery tested end-to-end; the **offer-page claims evidence pack** complete; the **content health dashboard** (§3.6) live.
- **Gate B0 pack** (launch privacy, terms, checkout & data model — §5) submitted alongside the **Gate A** pack (block-library safeguarding review) — Gate A submission includes the persona plans, the claims set and lint, the signpost verification chain, and the setup-flow wording.

> **THE PILOT LINE** *(v1.1 — stricter; replaces the previous paragraph)*. The first £49 sale requires **all** of:
> 1. **Gate A passed**; 2. **Gate B0 passed**; 3. offer-page **claims evidence pack** complete; 4. **£49/£29 live**; 5. checkout/terms/refund/privacy live **and tested**; 6. **deletion request tested**; 7. **support process live**; 8. founding/concierge/false-claims purge complete *(done — commits `30048ef`/`a963fe1`)*; 9. **content health gate green** (§3.6); 10. **emergency signpost current**; 11. **all** questionnaire options covered by specific or explicitly-named fallback blocks; 12. four "doing" tools live in week one — Instant Plan, Guided Setup, Agreement Builder, Printables (satisfies 99 §2.6's three-tools-in-week-one rule); 13. **accessibility pass (WCAG 2.2 AA target) on core flows**. *(The £39 soft-launch price in the spec file's sprint table is superseded by the confirmed £49 decision. Naming reconciliation remains blocking via M0 — §1.8.)*

### M4 — Digest expansion + First-Phone sequence

*(v1.1 — reframed; the digest is decoupled from launch: Option B.)* The offer page promises "first year of updates included" and nothing calendar-bound. The **minimal digest machinery** — honest empty-month template; **service-only email lint** (no marketing content in service emails); unsubscribe/cancel logic; `digest_runs`/`digest_sends` logs — may be built earlier if the calendar promise is wanted; only once **Gate B1 + that machinery** are both done may the offer page **upgrade its claim** to a calendar promise.

Requires **Gate B1** (privacy wording) first: `household_profiles` retention added to `05_Privacy_and_Data_Notice`, PECR classification, `first_phone_date` characterised as a parent's plan date. Then Spec 3 (Changed-For-You Digest — honest empty month mandatory) and Spec 6 (Age-Up/First-Phone kits + 72-hour sequence). Book Gate B at Gate A/B0 submission time so B1 clears early in the trading window.

### M5 — Month 2–3: complete the seven-tool bundle

Spec 4 (New App? Ask Keepwise — ~30 app cards; *(v1.1)* unmatched-lookup rule per §7 M5 DoD), Spec 7 (AI-homework policy generator, shares Spec 5 machinery), Spec 8 (Quarterly re-check, due by month 3 for the first cohort). Full bundle live at £49.

### M6 — Post-pilot: DNS, Lab, long tail

DNS filter profile flag **on** only after **Gate B2** — the wording caution stands: the fixed reviewed claims string only, nothing stronger. AI Readiness Lab module (Spec 10) only after its safeguarding pass (Gate A extension or second pass) — folds into the £49 product per §1.3, entitlement-flagged. Long-tail blocks authored from live diagnostic tick-rate and unmatched-lookup data; full pool completed to ~215–225.

**Dependency spine:** M0 → (A0 → M1) ∥ M2 → M3 → (Gate A + Gate B0) → pilot → (B1 + minimal digest machinery → calendar-claim upgrade; M4) → M5 → (B2/safeguarding-2 → M6). Spec 1 is the foundation for everything; Specs 5→7 and 2+3→8 are the only cross-tool dependencies.

---

## 3. Block taxonomy and authoring plan

### 3.1 The report skeleton (fixed slots)

Every plan renders the same 11 slots, from `02_Sample_Readiness_Report.md`: **summary → top-3 actions → exposure map → platform notes → this-week conversation → settings checklist → family-agreement clauses → emergency signpost → don't-panic → next-month → how-this-was-made/upsell footer**. Blocks declare which slot they fill; the assembler never invents a section. *(v1.1)* The severity/interrupt layer (§3.4) may render the signpost **above** this flow for urgent-concern answers; it never adds sections.

### 3.2 Block classes (11 classes, ~215–225 blocks)

| # | Class | `blockType` | Fills slot | Count | Source route |
|---|---|---|---|---|---|
| 1 | Summary openers/closers | `open` | summary | ~22 | Fresh (1–3-sentence fragments) |
| 2 | Exposure-map notes | `map` | exposure map | ~21 | Fresh (pattern in sample report §3) |
| 3 | Top-3 action verdicts | `action` | top-3 / next-month | ~33 | Adapt from playbooks (Why/Do-this/Time) |
| 4 | Platform-setting blocks | `platform` | platform notes + checklist | ~52 | ~44 slice, ~8 fresh; two age tiers + under-age note (settings bullets are age-invariant — revises 99's "~3 tiers") |
| 5 | Concern digests | `concern` | next-month / cross-refs | ~30 | Slice (~150-word playbook digests) |
| 6 | Age-band skeletons | `band` | agreement + bundle + posture | 15 | Slice verbatim from `agebands/*.mdx` |
| 7 | Conversation blocks | `conversation` | this-week conversation | ~19 | Slice from `conversations.mdx` |
| 8 | Don't-panic blocks | `calm` | don't-panic | ~13 | Adapt (`is-this-normal.mdx`, file 44); *(v1.1)* calm-but-act wording carries the estate's under-18-image non-preservation carve-out |
| 9 | Find-this-out tasks | `task` | next-month | ~9 | Fresh; enforce Don't-know-never-raises-a-band |
| 10 | Fixed furniture | `fixed` | headers/footers | ~5 | Fresh |
| 11 | Locked signpost | `signpost` | emergency | 1 | Hash-pinned constant (authored via `scripts/editorial/plan-prompt.ts`, relocated *(v1.1)*; runtime constant in `lib/signpost.ts`), verified against 03/84. Never templated |

Total validates 99's ~220 estimate; the internal mix shifts (fewer platform tiers, more micro-fragments).

### 3.3 ID grammar and frontmatter

`class.topic.agetier` (e.g. `action.sextortion-talk.13-18`, `map.ai-exposure.moderate`). Frontmatter carries: `id`, `version`, `status` (draft/published/withdrawn), `blockType`, `slot`, `ageBands`, `platforms`, `concerns`, `domains`, **`triggers` (selection predicates as data, not code)**, `weight`, `pairsWith`, `sourceFile` (provenance — a library refresh flags derived blocks for re-review), `sources`, `publishedBy`/`checkedBy`/`publishedAt`, and `reviewBy` (platform +6mo, concern +12mo, signpost +1mo). Existing MDX frontmatter maps straight across.

### 3.4 Selection and sequencing (authoring checklist)

1. **Score:** answers → six exposure domains → Lower/Moderate/Higher + confidence (01 §2.3). A Don't-know **never creates a factual claim and never raises a verdict or exposure band** — it lowers confidence only and enqueues its `task` block. *(v1.1 refinement)* For the defined **high-stakes settings list** — private accounts unknown, who-can-message unknown, location sharing unknown, payment access unknown, content filters unknown — a Don't-know **raises the action priority of the discovery task** (never the band).
2. **Trigger:** the key-question table (in §7.5 source, e.g. `age_band` filters everything and picks the `band.*` trio; ticked apps → `platform.*` capped at 5, overflow → library links; `knows_core_rule`=No hard-pins `action.core-rule`; `priority_note` is never parsed — PII, rendered nowhere).
3. **Severity/interrupt layer** *(v1.1 — new)*: urgent-concern answers (sextortion, grooming, self-harm, coercion indicators) trigger an **interrupt**: signpost-first presentation **above** the standard 11-slot flow — **routing only, never advice**. `calm` blocks never render above urgent `action` blocks and never render alone for a high-risk concern. Any calm-but-act block carries the estate's **under-18-image non-preservation carve-out** wording (the critique's suggested "preserving evidence" line is rejected as written — Appendix A).
4. **Sequence:** Top-3 = fired actions sorted by (domain level desc, weight desc), max 2 per domain, ≥1 ten-minute technical action if device-settings ≥ Moderate. This-week conversation = `pairsWith` of action #1 + cornerstone. Don't-panic = top 3 fired `calm` (subject to the severity rules above). Next-month = actions 4+ plus all `task` blocks, deduped. Checklist = union of platform-block checklist lines.
5. **Gate:** only `status=published` with future `reviewBy`; stale → evergreen fallback + editor alert, subject to the product-level content health gate (§3.6). Interpolation whitelist: age-band label(s), ticked platform names, sibling count *(kept — data-minimisation justification recorded in the B0 inventory, §1.9)*. Assembly log per plan (field list §4.2).

### 3.5 Authoring plan and effort

- **Slice ~105 blocks (~48%)** directly from existing MDX at ~25 min each ≈ 44 h.
- **Adapt ~46 (~21%)** into plan voice at ~45 min ≈ 35 h.
- **Fresh ~68 (~31%)** — mostly 1–3-sentence fragments (~15 min ≈ 11 h) plus a few full blocks (~40 min ≈ 13 h); by word count fresh writing is only ~12–15%.
- **Authoring ≈ 100–115 h** full pool; **MVP pool ≈ 70–80 h** — *(v1.1)* both figures now estimates in service of the M1 **coverage criterion** (§2 M1), which is the actual exit test. Add taxonomy/trigger-table finalisation + assembly-rule spec + adversarial QA of 20 persona plans ≈ 40–45 h → **content-side total ≈ 145–160 h** (under 99's 180–220, because 99 priced every block at from-scratch cost).
- *(v1.1)* **Content inventory map** maintained throughout (§2 M1): library item ↔ source MDX ↔ block IDs ↔ plan slots ↔ review owner/date.
- **Order of authoring (M1):** *(v1.1)* Gate A0 pre-read first (post-taxonomy-draft, pre-bulk) → signpost + fixed furniture + fallbacks (unblocks engine testing) → band skeletons and conversation blocks (pure slices, fast wins) → platform blocks by diagnostic tick-rate, including the seven thin honest blocks (§2 M1 template) → action/calm adaptations → open/map/task fragments last (they need the finalised trigger table).

### 3.6 Content health gate (product-level) *(v1.1 — new)*

Runs in production, not just at authoring time; thresholds adopted in M0; **green status is a pilot-line condition**:

- **Emergency signpost stale → hard fail: no plan rendering** until refreshed.
- **Any high-risk block stale →** auto-withdraw + designated fallback + editor alert.
- **>10% of top-platform blocks stale →** the "kept current" claim comes **off the offer page** until fixed.
- **>20% stale → pause sales** / generic-plan mode.

The content health dashboard (M3) surfaces all four conditions in the publish admin.

---

## 4. The tool specs (normative detail in `101_Tool_Build_Specs.md`)

Rules binding every spec: zero child-identifiable data as the internal design North Star (age = band only; devices = enumerated slots, never free text) — *(v1.1)* publicly expressed only as the enumerated promise in §1.9, and band+platforms tied to a parent account is still personal data (Gate B0 treats it as such); no LLM in any delivery path (authoring prompt at `scripts/editorial/plan-prompt.ts`, CI import guard); block-level claims lint (banned: "safe", "protected", "pass", "prevents", "monitors", "we noticed", verdicts).

### 4.1 Admin security baseline *(v1.1 — new; the publish admin is a safety surface)*

Admin-only routes; 2FA; role separation (author ≠ checker where possible; **second reviewer mandatory** for emergency/sextortion/grooming/self-harm blocks); an explicit publish confirmation step for high-risk blocks; append-only audit log; withdrawal flow; an **emergency pause-plan-generation switch**; backups; staleness and unreviewed-change alerts.

### 4.2 Immutable log — field list *(v1.1 — expanded; captured from sale #1)*

Block id / version / content-hash; source file + hash; author; checker; publish timestamp; `reviewBy`; withdrawal timestamp; assembly id; pseudonymous household id; answer option ids; interpolation values; render engine version; code Git SHA; signpost version/hash; PDF/template version; **offer-page version at purchase**. The audit render (§2 M2) must be byte-identical from these fields alone.

### 4.3 Spec table

| Spec | Tool | Milestone | Hours [INF] | Hard dependencies |
|---|---|---|---|---|
| 1a–1f | Block-Assembly Plan Engine, split *(v1.1)*: schema/registry · assembly engine · publish admin + reviewer workflow · audit log/re-render · safety lint + CI · customer render/delivery | M2 | 60–80 was optimistic for the full set — **re-estimate per sub-spec** | None — foundation. Gates A **and B0** block first sale |
| 2 | Guided Setup Session (10 flows; DNS sub-feature flagged off) | M3 | 55–70 | Spec 1; DNS on ⇐ Gate B2 |
| 5 | Family Agreement builder (client-side, nothing stored) | M3 | ~10 | Spec 1 (or static-menu v1) |
| 9 | Printables bundling (emergency card from SIGNPOST constant only) | M3 | ~5 | Specs 1, 2, 5 |
| 3 | Changed-For-You Digest (honest empty month mandatory; decoupled from launch — Option B) | M4 | 30–40 | Spec 1; `household_profiles` + Gate B1 |
| 6 | Age-Up/First-Phone kits + 72-hour sequence | M4 | ~25 | Specs 1, 2, 3; Gate B1 (`first_phone_date` wording) |
| 4 | New App? Ask Keepwise (~30 cards; "not yet covered" is a feature; *(v1.1)* lookup never stores raw free text) | M5 | ~20 + 40 ed. | Spec 1 publish infra |
| 7 | AI-homework family-policy generator | M5 | 15–20 | Spec 5 machinery, Spec 1 |
| 8 | Quarterly re-check (score-free; re-render = living plan) | M5 | ~15 | Specs 2 + 3 |
| 10 | AI Readiness Lab module (74 + 53, self-serve only) | M6 | 30–40 | Spec 1; its own safeguarding pass; flagged off until passed |

Key acceptance criteria that gate milestones: Spec 1 — immutable publish + assembly logs to the §4.2 field list (ASA/CAP 3.7 authorship record), **audit render byte-identical from the log** (re-render tooling may land post-pilot; the complete log may not), severity/interrupt layer tested, Don't-know high-stakes priority rule tested, p95 submit→delivered < 2 min, honesty signature per section (*(v1.1)* "editor-reviewed, dated, versioned, traceable" wording — never "written by"), 20 signed persona plans. Spec 2 — completion records say "checked and completed", never "pass/safe/secured"; `flow_version` staleness surfaces in the re-check. Spec 3 — "nothing changed for your household" never suppressed; watches the landscape, never the child; service-only email lint. Spec 10 — adult-facing only, no submissions, no efficacy claims.

---

## 5. The professional-review gates *(v1.1: four gates — A0 and B0 added)*

**GATE A0 — Safeguarding architecture pre-read** *(v1.1 — new)*. Runs after the M1 taxonomy draft and **before bulk authoring**. Scope: the taxonomy; the severity model; emergency/urgent handling; Don't-know handling; the fallback strategy; the high-risk list; the blocked-claims list. Does **not** replace Gate A — it exists to prevent authoring ~140 blocks against an architecture the full review would send back.

**GATE A — Block-library safeguarding review.** *Blocks the first sale* (spec 21 §7.5 hard rule; satisfies memo 97's non-waivable condition 5 by design-verification). Scope: taxonomy and classes; assembly rules including Don't-know handling, the severity/interrupt layer and fallbacks; the crisis constant and its full verification chain (build test + `verifySignpost()` + 03/84/68 cross-check); the claims set and block-level lint; the 20 adversarial persona plans; setup-flow content and completion-record wording. **Extension:** the Lab lessons — may run as a second pass; the Lab stays flagged off and unsellable until it passes.

**GATE B0 — Launch privacy, terms, checkout & data model** *(v1.1 — new)*. ***Blocks the first sale.*** Scope:
- **Privacy notice** covering: diagnostic answers, plan assemblies, account/payment metadata, setup completion records, deletion requests, the retention schedule, lawful bases, the processor list, and the cookieless-analytics disclosure.
- **Terms of sale**; **refund/cancellation wording** including the digital-content cancellation acknowledgement (Consumer Contracts Regulations 2013: pre-contract information, durable-medium confirmation, delivery-start acknowledgement).
- **Support mailbox + a bounded support process**; **Stripe metadata minimisation**.
- The **enumerated data promise** (§1.9); the classification of **assembly logs as personal data** (pseudonymous household id + answer option ids); the **VAT position note** (M0).

**B0 lifts from existing repo assets — the `86_..._Terms_Privacy_Drafts.md` scaffolds, the `79_..._Email_Templates.md` support/boundary templates, and the audit-register F24/F25/F71 items. This is wiring plus solicitor sign-off, not fresh invention.**

**GATE B — Legal/privacy wording review** (two checkpoints, one engagement; book at Gate A/B0 submission):
- **B1 — privacy.** *Blocks the Digest and the First-Phone sequence* — and *(v1.1)* the digest **calendar-claim upgrade** (Option B, §2 M4). The `household_profiles` retention change (lawful basis: contract; deletion on request or lapse+90d; `free_text` never copied in) added to `05_Privacy_and_Data_Notice`; PECR classification of digest/sequence as service email; `first_phone_date` characterised as a parent's plan date, not child data.
- **B2 — DNS claims.** *Blocks the DNS flag-on.* The fixed claims string ("filters common adult content — not a guarantee, and never monitoring; we see nothing"), reversibility instructions, and the no-credentials/no-traffic architecture, reviewed against ASA/CAP substantiation and the education-not-control posture that keeps the product insurable (99 §9).

No gate is waivable. All are batched fixed-cost work — consistent with the zero-per-customer-labour rule. Timing rule of thumb: A0 is small and early (inside M1); submit Gate A **and Gate B0** at M3 code-complete and use the review turnaround (assume 1–2 weeks) to draft M4; engage Gate B in the same window.

---

## 6. Effort budget and weekly cadence

### 6.1 Budget (founder-hours, AI-assisted non-technical founder [INF])

| Milestone | Build | Editorial | Cumulative |
|---|---|---|---|
| M0 Decision sweep + taxonomy lock + launch scoping | 10–15 | (taxonomy in editorial ↓) | 10–15 |
| M1 MVP block pool (coverage-based; ~140 est.) + taxonomy/rules | — | 90–105 | 100–120 |
| M2 Spec 1a–1f engine (+ persona QA ~15–20 ed.) | 60–80 † | 15–20 | 175–220 |
| M3 Specs 2+5+9 + offer page + launch ops + Gate A/B0 packs | 60–75 ‡ | — | **235–295 ← pilot line** |
| M4 Specs 3+6 (post-B1) | 55–65 | — | 290–360 |
| M5 Specs 4+7+8 | 50–60 | ~40 (app cards) | 380–460 |
| M6 DNS + Lab + long-tail blocks | 45–55 | 30–45 (pool completion) | **455–560 total** |

† *(v1.1)* The 60–80 was optimistic for the six-sub-spec scope — re-estimate per sub-spec at M2 kickoff. ‡ *(v1.1)* M3 now also carries the launch-ops items and B0 wiring — treat 60–75 as a floor.

Build ≈ 310–360 h; editorial ≈ 145–165 h (Input A's refined figure; the spec file's flat ~150 stands). Sits inside — at the top of — 99's ~350–400 h envelope for the pilot-plus-bundle core (M0–M5 ≈ 380–460); M6 is post-revenue. External costs (Gate A/A0 safeguarding reviewer, Gate B0/B solicitor) are cash, not hours — budget separately.

### 6.2 Weekly cadence (suggestion)

Assume **18–20 focused hours/week**, split to protect both tracks:

- **Editorial block** — *(v1.1)* **10–12 h/week during M1** (build hours flex down to compensate; mornings suit fragment work): slice/adapt/tag/lint/publish blocks. Slices batch well; do adaptations when fresh. Outside M1, drop back to ~6 h/week.
- **Build block — 2–3 × 4 h** with AI pair-building: one spec strand at a time, always ending a session with tests green and the persona suite passing.
- **Friday hour:** review-queue triage (`reviewBy` horizon), assembly-log spot checks, content-health dashboard check, decision log.

**Timeline at that cadence** *(v1.1 — revised honestly for the coverage-based M1 and the added gates)*: M0 wks 1–2 · Gate A0 pre-read ~wk 3 (post-taxonomy-draft, pre-bulk-authoring) · M1 wks 2–10 (coverage-based — the duration is an estimate; the coverage list is the exit) · M2 wks 5–12 (starts once signpost/furniture/fallback blocks publish) · M3 wks 12–15 · Gate A + Gate B0 submission end wk 15, turnaround wks 15–17 spent drafting M4 and engaging Gate B · **pilot launch ≈ wk 16–18** (supersedes the wk 14–15 figure) · M4/digest machinery on merit, not calendar (Option B) · M5 by month 3 of trading · M6 as gates clear. *(v1.1)* Because the offer page makes **no calendar promise** until B1 + the minimal digest machinery are done, hour slips now move the **launch date**, never a promise already made to customers.

---

## 7. Definition of done per milestone

**M0 done when:** `lib/pricing.ts` default = 49 and £29/yr renewal wired; repo grep for founding/concierge/banned-claim strings returns only allow-listed historical docs; `/concierge` renders the honest notice with no form; naming decision recorded and applied to the offer-page draft; taxonomy + trigger table signed off; flag decisions (§2 M0) recorded. *(v1.1)* Plus: B0 scoping + data inventory drafted (incl. the sibling-count justification); OSA scope memo written (outside Part 3 duties — legal to confirm at B0; re-assess on any community/child-facing/search/AI-chat proposal); VAT/pricing note recorded (£49 VAT-inclusive; ~1,837-sale threshold; ~£40.83 net if held; decision point logged); unit-economics checkpoint written; accessibility target, content-health thresholds (§3.6), admin security baseline (§4.1) and the launch-critical platform coverage decision all adopted. Existing guardrail tests still green, `ai-safety-*.ts` still unrouted.

**M1 done when** *(v1.1 — coverage-based)*: every questionnaire answer option (including thin honest blocks for the seven listed platforms, on the §2 M1 template), every high-risk concern, every age band, every urgent path, every first-week action, the top platform setup flows, and every offer-page claim map to ≥1 published block or an explicitly-named published fallback (no silent empty renders — closes taxonomy flag 1); all published blocks carry named `publishedBy`/`checkedBy`, future `reviewBy`, lint green; the Gate A0 pre-read was completed before bulk authoring; the content inventory map is current; signpost block hash-matches 03/84. The ~140 count is the estimate; the coverage list is the test.

**M2 done when:** all Spec 1a–1f acceptance criteria pass in CI (stale-block fallback, immutable publish log, Don't-know rules incl. the high-stakes priority raise, severity/interrupt layer, interpolation whitelist lint, multi-band splice, `verifySignpost()` at build and render, p95 < 2 min); *(v1.1)* the assembly log captures the full §4.2 field list from the first assembly, and the **audit render** is byte-identical from the log (re-render tooling may follow post-pilot; the log may not); the publish admin meets the §4.1 security baseline; 20 adversarial persona plans (incl. all-Don't-know; single-platform+high-concern; 3-band household; urgent-concern interrupt) generated and editor-signed.

**M3 done when:** 10 setup flows live with per-OS variants and fallbacks, DNS flag off; Agreement builder produces the dated PDF client-side with signpost footer and persists nothing; Print pack renders emergency card from the SIGNPOST constant only; offer page passes the honesty rule (claims-lint against §1.6/§1.9) at £49 with no digest calendar promise; *(v1.1)* first-week activation experience live (3-actions landing, tick-off, agreement pre-fill, printable emergency card, visible completion state); checkout, delivery email, deletion request and account recovery tested end-to-end; claims evidence pack complete; content health dashboard live and green; accessibility pass (WCAG 2.2 AA target) on core flows; Gate A **and Gate B0** packs submitted. **Pilot launches only when the full pilot-line checklist (§2) is green — including Gate A and Gate B0 passes.**

**M4 done when** *(v1.1 — reframed as digest expansion)*: B1 wording live in `05_Privacy_and_Data_Notice` with self-serve profile deletion effective immediately; the minimal digest machinery verified (honest-empty-month template, service-only email lint, unsubscribe/cancel logic, `digest_runs`/`digest_sends` logs); the offer page upgrades to a calendar claim **only after** both of the above; digest #1 sent with full run/send substantiation; first-phone sequence fires from parent-declared dates only, one-click cancellable.

**M5 done when:** ≥30 app cards published with 6-monthly `reviewBy`; *(v1.1)* the app lookup normalises client-side against a known dictionary, unmatched queries render "not yet covered", the optional opt-in "suggest this app" field stores **the app name only** (no age band, no household id, no other answers), and raw free text from the lookup box is never stored; AI-homework generator ships with no authorship-verdict clauses; quarterly re-check live, score-free, with "re-render my plan" producing a fresh logged assembly; full bundle purchasable at £49 with the offer page still claiming only what is live.

**M6 done when:** DNS profile behind B2-approved fixed claims string, one-tap reversal proven; Lab lessons safeguarding-passed, flag on, folded into the £49 entitlement (no separate SKU); block pool at ~215–225 with long-tail authored from live tick-rate and unmatched-lookup data; review-date rota (platform +6mo / concern +12mo / signpost +1mo) running as routine, feeding the content health gate (§3.6).

---

## 8. Risks and open items

1. **Uncovered platforms (taxonomy flag 1) — resolved by design** *(v1.1)*. The seven options with no library guide (X, Telegram, Signal, smart TV, VR, smartwatch, mobile-games-with-chat) now get **thin honest blocks in M1** on the fixed template (§2 M1) as part of the coverage criterion; the generic-platform fallback remains for anything genuinely unmatched. DoD M1 makes silent empty renders impossible.
2. **Multi-child plans (taxonomy flag 2).** Q1 currently captures one band; Spec 1 AC5 requires per-band sections. M0 decision: make Q1 multi-band select; splice connectors handle assembly; block count is unchanged (selection logic doubles, not authoring). Marketing must not promise per-child personalisation beyond band sections until this ships — the "9-year-old and a 13-year-old" plan title from 99 §3 stays off the offer page.
3. **Naming (Keepwise/Bearings).** Blocking for the offer page; founder decision in M0. Brand mockups exist under Bearings; the decision set says Keepwise. Unresolved = no launch.
4. **Gate turnaround risk.** *(v1.1)* Now three external touchpoints (A0, A+B0, B). Mitigation: A0 is deliberately small and early; book reviewers at M2 exit; Gate A and B0 packs assembled continuously (persona plans, lint output, signpost chain, data inventory) rather than at the end.
5. **Digest claim drift** *(v1.1 — replaces the digest-deadline risk)*. Option B removes the calendar-bound promise entirely: the offer page says "first year of updates included" and upgrades only after B1 + the minimal machinery are done. The residual risk is the claim creeping back informally — the claims lint must cover digest wording, and any calendar language on the offer page without a green B1 + machinery check is a launch blocker.
6. **Superseded figures.** The spec file's £39 soft-launch, 99's ~3-tiers-per-platform and flat 150 h editorial, the count-based ~140 criterion, and the wk 14–15 pilot figure are superseded by the £49 decision, the taxonomy's evidence-based revisions and this v1.1 adjudication; this file is the reconciliation point.

---

## 9. Value-stack fold-in audit *(v1.2, 2026-07-06 — closing the file-98 gap)*

The founder asked whether the value-expansion research (file `98`, 63 judged ideas) is folded into this plan. Audit result: **the zero-human survivors are in** — Changed-For-You Digest (Spec 3), New App? lookup (Spec 4), Guided Setup (Spec 2, co-hero), Age-Up/First-Phone kits, dated completion records, first-week activation (M3), whole-household framing (multi-band Q1) — and the human-dependent headline items (posted plan with handwritten line, reviewer voice note, One-Question credit, £149 call tier) were **correctly killed by the 2026-07-04 go-automated decision**. Four automation-compatible ideas from 98 had fallen through the gap and are now assigned:

| # | Idea (98) | Why it survives automation | Milestone | Effort |
|---|---|---|---|---|
| 1 | **Secondary-School Switch Kit** — "get ready for Year 7" summer repackage of the System, sold hard May–Aug; 98's judges: "best effort-to-return ratio in the set" | 90% marketing repackage of existing blocks/kits; zero per-customer labour | **M4** (post-pilot; or M3 copy-only teaser if pilot lands in the summer window) | S (~12 h) |
| 2 | **News-scare briefs** — when a national story breaks, a calm "what this means for your house" note within ~48h, matched to household profiles via the digest engine | FIXED editorial cost per event, not per customer; the strongest renewal leg after the digest; wording rule: "aim for 48h", never a contractual SLA | **M4** (rides the digest machinery; add to the digest templates + B1 legal scope) | S per event |
| 3 | **Meet-the-Editor video** — 60–90 seconds of the named editor explaining how blocks are written, checked and dated | The person/proof lever survives the pivot: there IS a named accountable editor (§1.6 claims); this is the offer page's cheapest credibility asset | **M3** (offer-page proof pack) | S (~2 h) |
| 4 | **Gifting** — e-gift codes ("for the friend whose kid just got a phone") + grandparent-purchase framing on the first-phone kit | Zero marginal labour; unlocks the second buyer market (grandparents) at the highest-intent moment | **M5** (Stripe payment-link gift variant + redemption code path) | M |

Plus one seed already planted elsewhere and now made explicit: the Guided Setup **completion record carries a "next review due [date]" line** (Spec 2 AC update in `101`) — the 98 "Review Certificate" renewal-seed, minus the banned "pass/certified" framing. And the M3 offer page must SHOW the value stack (the "worth £49 arithmetic" of 99 §2.6: plan + setup of every device + a year of watching + the app-checker), not just list features.

**Explicitly NOT revived** (dead with the human layer, per 97/99): anything requiring per-customer founder minutes. If the pilot's break-glass triggers a strategy rethink, file 98's held items are the shelf to shop from.

---

## Appendix A — Adjudication note *(v1.1)*

External critique received 2026-07-05; every point adjudicated by the lead session before this revision — only accepted items are folded in above.

**Accepted** (numbering from the adjudication record): (1) Gate B0; (2) Gate A0; (3) digest decoupled from launch; (4) coverage-based M1 + wk 16–18 pilot; (5) stricter pilot line; (6) content health gate; (7) render-modes split; (8) expanded immutable-log field list; (9) Spec 1 six-way split; (10) admin security baseline; (11) claims rewrites + enumerated data promise; (12) severity/interrupt layer; (13) Don't-know high-stakes refinement; (14) unmatched-lookup rule; (15) `plan-prompt.ts` relocation cross-reference; (16) M0 additions; (17) M3 ops additions + M4 reframe; (18) first-week activation; (19) content inventory map.

**Rejected or amended:**
- The critique's suggested calm-block line ("preserving evidence") is **rejected as written** — for under-18 intimate images, any calm-but-act wording must carry the estate's **non-preservation carve-out**; wording that could read as advice to retain such images never ships.
- The digest month-1 promise is **not reinstated**: **Option B** chosen — no calendar promise on the offer page until Gate B1 + the minimal digest machinery are done, at which point the claim may upgrade.
- The critique's overall launch-readiness score is **contested**, but its B0 mis-sequencing point (legal/commercial launch plumbing missing from the pre-sale path) is **conceded** — hence Gate B0 on the pilot line.

**Satisfied by existing repo assets — wired, not rebuilt:** several items the critique scored as absent already exist: the `86_..._Terms_Privacy_Drafts.md` terms/privacy scaffolds, the `79_..._Email_Templates.md` support/boundary templates, and the audit-register F24/F25/F71 items. Gate B0 wires them together and takes them to solicitor sign-off. The `lib/plan-prompt.ts` relocation to `scripts/editorial/` with a CI import guard was completed by the lead session before this revision (§1.1).
