# Age-Band Packs

**The navigation spine. A parent buys "the pack for my 13-year-old," not a library to wade through.** Each pack pulls the relevant pieces from the platform library (`16`), conversation library (`17`) and playbooks (`18`) and tunes them to the developmental stage. The posture slides **co-use → co-set → coach → consult** across the five bands (5–10 → 17–18). `13–14 is the flagship` (legal social-media onboarding, sextortion peak, peak peer-influence) and is the most-resourced.

Each pack = **Posture · What's going on at this age · The risks that matter most now · Settings to prioritise · The 5 conversations · Family-agreement clauses · "If it goes wrong."**

---

## Band 5–10 — "The first tablet / Foundations" · Posture: **CO-USE**

*The foundation band — it sits below 11–12 and sets the patterns every later band builds on. Posture is co-use at its most hands-on: you are in the room, controls are front-loaded before the device is handed over, and "we do this together" is the default. The aim is to build calm habits early, not to lock a child down.* `[V/PV]`

**What's going on.** The on-ramp years: a shared family tablet or iPad, YouTube Kids, kids' and educational apps, simple games, and — increasingly — Roblox (with **Roblox Kids (5–8)** rolling out curated games and parental controls from June 2026). Smart speakers are often a child's first "ask anything" device. Most "big" social apps are 13+ and not yet relevant — keep them that way. Curiosity is high and judgement is just forming, so the device is best treated as something you use *with* them, in shared spaces, rather than something they take away alone. `[V/PV]`

**Risks that matter most now** (→ playbooks): accidental content exposure (a wrong tap, a sidebar thumbnail, search gone sideways) (C) · **YouTube autoplay rabbit holes** pulling them from gentle content toward odd or upsetting clips (C) · in-game and in-app spending / loot mechanics — easy taps that cost real money (D) · stranger contact inside games and game chat (core) · screen-time and **sleep** displacement, including where the device "sleeps" at night (G).

**Settings to prioritise** (→ `16`): **device layer first, front-loaded before handover.** Set up **Apple Screen Time** or **Google Family Link** with downtime, app limits, content/age ratings, and **Ask-to-Buy / purchase approval** so spending needs you (guide: `/library/platforms/apple-screen-time`, `/library/platforms/google-family-link`). Use **YouTube Kids** with autoplay turned off and a curated/approved-content mode, not the standard app (guide: `/library/platforms/youtube`). For **Roblox**, set the youngest-appropriate account type, parental controls, chat off or restricted, and a spend cap (guide: `/library/platforms/roblox`). Turn on SafeSearch and the broadband adult-content filter at the network level. Keep the tablet a **shared device used in shared rooms** — these are starting points; a setting may have moved, so check the platform's official help page for the current menu.

**The conversations** (→ `17`) — kept simple and age-right:
- **"Tell me if anything is weird or scary — you won't be in trouble."** The cornerstone, in words a young child gets: if something pops up that feels wrong, come and find me, and you're never in trouble for telling.
- **"We watch and play together."** Co-use as the normal way we use the tablet, not a punishment — sit alongside, ask what they're playing, narrate what you're doing.
- **"Things that ask for money."** If a game or app asks to buy something, that's a grown-up's job — stop and come and get me; we decide together.
- **"People you don't know in games."** Some games let strangers talk to you; we don't chat with people we don't know, and you tell me if someone you don't know tries to talk to you.
- **"Where the tablet sleeps."** The tablet has a bedtime and sleeps outside the bedroom — gentle framing that builds the no-device-in-the-bedroom habit for life.

**Family-agreement clauses (menu):** the tablet "sleeps" outside the bedroom (charges in a shared room overnight) · we watch and play together, in shared rooms · autoplay off and approved-content mode on · buying anything needs a grown-up (Ask-to-Buy / purchase approval on) · we don't chat with people we don't know in games · "I can tell you about anything that happens on the tablet and I won't be in trouble."

**If it goes wrong.** You're as hands-on as it gets at this age — sit with them, see what they saw, and respond calmly. Close or block it together, adjust the relevant setting, and use the matching playbook's steps. A child this age takes their cue from your face: a scare met without anger or panic teaches them that coming to you works — which is the single habit you most want carried into the harder teen bands. Most incidents here are accidental and first-time; treat them as practice runs for the cornerstone line.

---

## Band 11–12 — "First device" · Posture: **CO-USE**

**What's going on.** Starting secondary school drives a jump in varied use; YouTube, WhatsApp, gaming (Roblox, Minecraft) dominate; many get a first smartphone. Desire for independence outruns self-control. Honest birthdays still likely — keep them, because age-specific protections depend on it. `[V/PV]`

**Risks that matter most now** (→ playbooks): stranger contact / early grooming (core) · in-game spending & loot boxes (D) · first cyberbullying (A) · accidental pornography exposure (C) · age-inappropriate apps via fake birthdays.

**Settings to prioritise** (→ `16`): **device layer first** (Apple Screen Time / Google Family Link) — limits, downtime, Ask-to-Buy, content filters; SafeSearch + broadband adult-content filter; Roblox parental controls + spend cap; YouTube Kids or supervised account. Keep social apps on shared devices in shared rooms.

**The 5 conversations** (→ `17`): #1 cornerstone "come to me" · #2 show-me-your-world · #3 new-app check · #8 strangers/grooming · #11 phones-at-night.

**Family-agreement clauses (menu):** devices charge outside the bedroom overnight · social apps only on shared devices in shared rooms · SafeSearch/filters on · spending needs a PIN/permission · "I can come to you about anything online and won't be in trouble."

**If it goes wrong.** You're hands-on at this age — sit with them, screenshot, block/report together, and use the relevant playbook's steps. Most issues here are first-time scares; calm handling now sets the pattern for the harder teen years.

---

## Band 13–14 — "The threshold year" · Posture: **CO-SET** ⭐ flagship

**What's going on.** They hit the 13+ minimum, so Instagram/Snapchat/TikTok adoption surges. This is the **peak of the gap between reward-seeking and self-control, and the peak of peer-influence on risk** — developmentally the highest-stakes band. Identity and self-presentation intensify; likes become social currency. `[V]`

**Risks that matter most now** (→ playbooks): **financially-motivated sextortion — the headline risk, hitting boys 14–17 hardest** (core) · nudes/sexting, consensual and coerced (E) · grooming & coerced app migration (core) · cyberbullying (A) · AI companions (core) · body-image / appearance pressure (B-adjacent) · first independent pornography exposure (C).

**Settings to prioritise** (→ `16`): make sure the **real birthday** is set on every app (protections key off it); Snapchat Family Centre + **Ghost Mode** + Contact-Me = Friends; Instagram Teen Account supervision + confirm private/strict-messaging defaults; TikTok Family Pairing + under-16 no-DM/private defaults; keep the device-layer limits from 11–12 running.

**The 5 conversations** (→ `17`): #1 cornerstone (lead here) · **#4 sextortion (have this early)** · #5 nudes-what's-okay · #7 AI chatbots · #10 screen-time (collaborative). Plus #6 (nudes-pressure) and #15 (bullying) as needed.

**Family-agreement clauses (menu):** phone out of the bedroom at night · co-set screen-time limits, reviewed monthly · nobody (parent included) posts a photo of another family member without asking · **amnesty clause** — if something goes wrong online and you tell us, you won't be punished for telling · privacy/contact settings agreed together.

**If it goes wrong.** Move from "here are the rules" to "let's agree what we do." For sextortion specifically, the playbook is **stop, don't pay, don't delete, screenshot the threats (never the image), tell, report to CEOP/Report Remove** — and your calm, non-blaming reaction is the thing that protects them most. This band is where the cornerstone "you won't be in trouble" line earns its keep.

*Flagship note: this is the pack to make the richest and to market hardest — "starting secondary school and social media" is the clearest willingness-to-pay moment.* `[V]`

---

## Band 15–16 — "Autonomy / GCSE years" · Posture: **COACH**

**What's going on.** Markedly higher and more private use — Instagram, Snapchat, Discord, private messaging, interest communities; near-constant use is common. Self-control is catching up but reward-sensitivity is still high. Romantic/sexual relationships move substantially online. `[V/PV]`

**Risks that matter most now** (→ playbooks): sextortion and image-based abuse continue (core, E) · consensual-then-betrayed sharing & coercive control (E) · misogyny / extremist content & radicalisation (F) · AI companions / over-reliance (core) · sleep displacement (G) · scams & money-muling (core/D).

**Settings to prioritise** (→ `16`): hand day-to-day screen-time management to them with a **parental backstop**; review privacy/contact settings *with* them rather than imposing; Discord Family Centre if used; keep purchase controls and the device-layer backstop. The shift is supervision *with conversation*, not control.

**The 5 conversations** (→ `17`): #1 cornerstone · #6 nudes-pressure · #9 scams/money (add money-muling) · #12 how-online-makes-you-feel · #13 mistakes-&-repair. Plus #14 (pornography/unrealistic sex) via a hook.

**Family-agreement clauses (menu):** you manage your own screen-time tool, we review together weekly · privacy/contact settings agreed and revisited · a shared "what we'd do if…" plan for sextortion/leaked images · scams/money-muling red lines.

**If it goes wrong.** Coach, don't seize control: help them think it through, point to the right route, and keep the relationship intact so they keep coming back. Weekly low-key check-ins beat spot-checks.

---

## Band 17–18 — "Launch / near-adult" · Posture: **CONSULT**

**What's going on.** Full adult-pattern use; about to age out of child-specific protections (e.g. Report Remove is under-18 — at 18 they move to adult routes like StopNCII). Decisions increasingly self-governed; preparing for independent digital life. `[V]`

**Risks that matter most now** (→ playbooks): **digital footprint / reputation** for jobs and university (Module H) · scams & financial fraud (core) · sextortion via adult channels (core) · harmful online communities (F).

**Settings to prioritise** (→ `16`): mostly self-managed — focus on account security (2FA, unique passwords, NCSC guidance), reviewing their public footprint together, and knowing the **adult** reporting routes (StopNCII, Action Fraud, Revenge Porn Helpline).

**The 5 conversations** (→ `17`): #1 cornerstone (never expires) · #9 scams/money (adult-grade) · #4 sextortion (adult routes) · #13 mistakes-&-repair · a footprint/reputation talk ("what would a university or employer find?").

**Family-agreement clauses (menu):** mostly self-governed; the "agreement" becomes a standing offer of help · footprint/reputation review before applications · financial-scam red lines · "open door, no judgement, any time."

**If it goes wrong.** You're a consultant now — they lead, you advise, and you make sure they know the adult reporting routes. Resist taking over; reinforce that the door is always open.

---

## How the packs are sold and used

- The diagnostic (`21`, the premium plan) routes a buyer to **their** band as the starting point, with the others available in the System.
- **+Setup tier** unlocks all bands (useful for multi-teen households) and a facilitated family-agreement session.
- The **cornerstone conversation (#1) leads every band** — highest-impact line, never buried.
- Each band's "5 conversations + settings + agreement clauses" is the **"do it this weekend" bundle** — the concrete, finishable thing that justifies a premium price over a free library.

*Cross-references: platform paths in `16`, full scripts in `17`, full threat detail and signposts in `18`, posture/developmental evidence in the conversation research.*
