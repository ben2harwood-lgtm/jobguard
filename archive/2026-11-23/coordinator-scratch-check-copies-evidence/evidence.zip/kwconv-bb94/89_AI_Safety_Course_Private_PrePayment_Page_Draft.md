# AI Safety Course - Private Pre-Payment Page Draft

*Created 2026-06-27. Status: assembled private pre-payment page copy for warm founding-pilot buyers. Do not publish broadly. Do not send until placeholders are filled, the emergency signpost URL is live, and the first-sale decisions in `88_AI_Safety_Course_First_Sale_Decision_Log.md` are complete.*

## Page Title

Bearings AI Safety Course - Founding Parent Pilot

Parent education and household planning for AI use at home.

## Opening

Set clearer AI rules at home, without turning it into a panic lecture.

This is a small founding pilot for parents and carers who want practical household rules around AI: what stays private, why AI is a tool rather than a person, how to check before trusting output, and how to decide when a concern belongs outside the course.

This is not a broad public launch. It is a manually delivered pilot for a small number of households.

## Before You Join

You are buying a founding pilot place in the Bearings AI Safety Course, a parent education and household-planning pilot.

Price: GBP 49.

Provider: [TRADING NAME].

Contact: [EMAIL].

Address/contact address: [ADDRESS DECISION REQUIRED].

What you get:

- four short parent modules;
- printable starter assets;
- a Family AI Safety Agreement starter;
- a request for feedback on clarity and usefulness.

Delivery: manual digital delivery within [TIMEFRAME] after payment and required confirmations.

This pilot is not legal advice, safeguarding advice, monitoring, crisis help, child assessment, or incident review. It does not promise outcomes.

Please do not send child names, school details, account handles, screenshots, messages, images, attachments, schoolwork, prompts, or live-incident details.

If something is happening now, use the emergency signpost: [EMERGENCY LINK].

Terms: [TERMS LINK OR ATTACHED COPY].

Privacy notice: [PRIVACY LINK OR ATTACHED COPY].

Refund/cancellation: [INSERT CHOSEN WORDING].

## Who This Is For

- Parents and carers of children or teens who are starting to use AI tools.
- Families who want a simple household agreement before habits harden.
- Parents who feel unsure about chatbots, AI homework, privacy, and confident AI answers.
- Parents who want calm scripts and printable rules rather than another long guide to read.

## What You Get

### Four Short Parent Modules

1. The AI Safety Map
2. Private Stays Private
3. Tool, Not Person
4. Verify Before Trust

### Printable Assets

- Four Habits card.
- Private Stays Private card.
- Tool, Not Person script.
- Verify Before Trust sheet.
- Schoolwork Ask-First sheet.
- Family AI Safety Agreement starter.
- Pilot boundary card.

### Family AI Safety Agreement

You will leave with a short set of household clauses you can adapt and print. It is a conversation tool, not a contract or monitoring system.

## What This Pilot Does Not Include

- No child accounts.
- No child-facing content.
- No upload or review of messages, screenshots, images, schoolwork, prompts, or incidents.
- No AI judgement of real situations.
- No diagnosis, score, or child profile.
- No live-incident advice.
- No claim that the material has formal legal or safeguarding sign-off.

The full Scenario Trainer, Readiness Self-Check, Stay Current update stream, and printable Routing Card are being kept internal until review gates are complete.

## Why The Pilot Is Small

AI safety is a serious topic, especially where privacy, emotional reliance, schoolwork, contact pressure, and image risk are involved. The pilot starts with the lower-risk foundation: household rules, privacy, tool boundaries, and verification habits.

The heavier route-card and image-risk materials stay out of the pilot pack until the review process is stronger.

## Payment

Founding pilot price: GBP 49.

Payment link: [PRIVATE PAYMENT LINK - ONLY ADD AFTER GATE COMPLETE].

Use this payment button text:

> Join the founding pilot - pay GBP 49

Required confirmations before payment:

- I confirm I am 18+ and a parent/carer.
- I have read the pilot notice, terms, privacy notice, and refund/cancellation wording.
- I understand this is parent education and household planning only. I will not send child names, school details, account handles, screenshots, messages, images, attachments, schoolwork, prompts, or live-incident details.
- [IF EARLY DIGITAL DELIVERY] I want access to the digital pilot materials before the 14-day cancellation period ends, and I understand that once the digital materials are supplied I may lose my right to cancel for that digital content.

Optional:

- Email me occasional updates about Bearings. I can unsubscribe at any time.

## After Payment

You will receive a purchase-confirmation email with:

- what you bought;
- price paid;
- provider/contact details;
- terms and privacy copy;
- refund/cancellation wording;
- delivery timing;
- emergency signpost link.

Pilot materials will be sent manually within [TIMEFRAME].

## Questions

Non-urgent questions before joining: [EMAIL].

Please do not include child names, school details, screenshots, messages, images, account handles, attachments, or incident details.

If something is happening now, use the emergency signpost: [EMERGENCY LINK].

## Internal Gate Before Sending

Do not send this page until:

- [ ] all placeholders are filled;
- [ ] `88_AI_Safety_Course_First_Sale_Decision_Log.md` is complete;
- [ ] terms and privacy copy from `86` has been reviewed and attached/linked;
- [ ] emergency signpost link is live and checked;
- [ ] payment link collects or is preceded by the required acknowledgements;
- [ ] no school/PTA circulation is involved;
- [ ] content lint and focused phrase scans pass.
