# START HERE - Keepwise Household Digital-Safety System

**A premium, prevention-framed online-safety and AI-readiness system for UK parents of children and teens aged 5-18.** A short parent-only check leads into a reviewed household plan, a practical guidance library, printable tools, family-agreement support, and an optional Stay Current layer. **Not** monitoring, surveillance, child-facing content, or emergency response.

## Current Status

- **Current coded app:** `APP_README.md` describes the Next.js platform now present in this repo.
- **Working brand in code:** Keepwise. Older strategy/static files still mention Bearings; treat those as prior brand/prototype history unless Ben explicitly switches back.
- **Primary build/guardrail reference:** `21_MASTER_BUILD_SPEC.md`, with later offer-expansion context in `91_Full_Offering_Site_Assimilation_Plan.md`.
- **Latest audit context:** `audit/keepwise-full-adversarial/` captures the previous multi-angle review and the fix-first backlog.
- **Verification on 2026-07-02:** content lint, typecheck, Vitest suite, and production build all pass locally.

## Run The App

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

No secrets are required for local preview. Checkout routes show a clear Stripe setup page until payment links are configured.

## Verify

```bash
npm run content-lint
npm run typecheck
npm test
npm run build
```

These are the core checks to run before asking another model or reviewer to audit the build. The content lint is part of the safety system: it blocks non-negated safety guarantees, fear claims, and service-style "coaching" language.

## What To Hand Fable

Start with `92_Fable_Audit_Readiness_and_Brief.md`. It tells Fable what is current, what not to over-trust, what to inspect, and what output would be useful.

The short version: ask Fable to audit the actual app journey, code, copy, safety boundaries, value proposition, and conversion path. Do not ask it to strengthen claims or invent proof. It should preserve the no-monitoring, no-child-data, no-emergency-advice boundaries.

## Important Files

**Current app**
- `app/` - Next.js routes and pages.
- `components/` - shared UI and interactive tools.
- `lib/` - brand, pricing, access, content, events, checkout, PII and guardrail logic.
- `tests/` - guardrail and unit tests.
- `supabase/schema.sql` - database shape for later milestones.
- `.env.example` - deploy/local configuration template.

**Build and offer references**
- `21_MASTER_BUILD_SPEC.md` - main coded build specification and guardrails.
- `91_Full_Offering_Site_Assimilation_Plan.md` - latest expanded-offer site direction.
- `26_Pricing_Library_and_Content_v3.md` - pricing/content canon before the expanded AI Lab work.
- `90_Full_Offer_Value_and_Pricing_Research.md` - expanded full-offer pricing/value research.

**Safety, review, and launch controls**
- `00_Execution_Plan_and_Go-NoGo.md` - regulatory posture and decision gates.
- `73_AI_Safety_Course_PreRevenue_AI_Review_Findings.md` - issue log for AI-assisted review.
- `83_AI_Safety_Course_Claude_Pilot_Review_Findings.md` - external/cross-model review findings.
- `84_AI_Safety_Course_Emergency_Signpost_Verification.md` - emergency signpost verification record.
- `85_AI_Safety_Course_First_Sale_Legal_Admin_Pack.md` - first-sale legal/admin draft pack.
- `audit/keepwise-full-adversarial/` - full adversarial audit and implementation backlog.

**Content library**
- `content/` - MDX content currently ingested by the app.
- `16_Platform_Settings_Library.md`, `17_Conversation_Library.md`, `18_Threat_Playbook_Library.md`, `19_Age_Band_Packs.md`, `20_Currency_Layer.md` - original content source files.
- `27_Platform_QuickRef_Cards_print.html`, `33_Printable_AgeBand_Cards.html`, `34_Threat_Playbook_Cards_print.html`, `81_AI_Safety_Course_Founding_Pilot_Printable_Pack.html` - printable artefacts.

**Legacy/static prototypes**
- `brand-mockups/`, `brand-design/`, `brand-review/`, `brand-worlds/`, `brand-test-site/`, `keepwise-skins-site/` - useful design history and comparison material, but not the current app implementation.
- `23_Landing_Page_v2.html`, `10_Free_Readiness_Quiz.html`, `05_Privacy_and_Data_Notice.html`, `terms.html` - earlier standalone/static pages.

## Launch Blockers To Keep Visible

- Stripe Payment Links are not configured in this repo.
- Supabase/auth/email/plan delivery/admin review are still future milestones unless wired outside this code.
- Professional legal/safeguarding sign-off is still a launch blocker, not something an AI audit can replace.
- The final domain, support email, refund/cancellation wording, and first-sale operating decisions need Ben/legal approval.

*Updated 2026-07-02 for Fable audit readiness.*
