# Email Lifecycle Templates

**Copy-ready. Replace `Bearings`, `[FIRST NAME]`, `[QUESTIONNAIRE LINK]`, `[MAGIC LINK]`, `[LIBRARY LINK]`, `[FEEDBACK LINK]`, `[RENEWAL LINK]`, `[EMAIL]`.** Tone: calm, warm, plain, never salesy or alarmist. Marketing/efficacy wording stays inside the guardrails in `00`/`06`; have the set glanced at on the solicitor review.

Seven emails cover the whole journey: 1 purchase confirmation → 2 questionnaire nudge → 3 plan delivery → 4 feedback request → 5 library onboarding → 6 Stay Current renewal (month 11) → 7 refund. Plus a holding reply for anything that looks like a live incident. (Premium model: the System purchase already includes the full library + 12 months of updates, so there is no "buy the Plan" upsell — email 5 onboards the buyer into what's included; email 6 offers renewal when that included year is nearly up.)

---

## 1. Purchase confirmation (sent immediately after payment)

**Subject:** Your Bearings System — first step inside

Hi [FIRST NAME],

Thanks for this — you've taken a genuinely useful step for your family.

Here's what happens now: complete a short questionnaire (about 5 minutes) and I'll build your personalised plan — the prioritised actions for your household, linking straight into your library of guides, playbooks and scripts. A real person reviews every plan before it goes out, and I'll send it back within 48 hours.

**Start here: [QUESTIONNAIRE LINK]**

Your access is ready too — use this link to get into your account and library anytime, no password needed: **[MAGIC LINK]**

A note before you do: I don't need your child's name, school, or any screenshots — please don't include them. If something urgent is happening right now, don't wait for the plan; see the emergency signpost at the bottom of this email or call 999.

Any questions, just reply.

[NAME], Bearings

*Bearings provides prevention-focused online-safety education for parents. It doesn't monitor children or replace the police, a school's safeguarding lead, or professional advice. Emergency signpost: [LINK].*

---

## 2. Questionnaire nudge (sent ~48h later if not completed)

**Subject:** Your plan is ready to build — just need your answers

Hi [FIRST NAME],

Your System is paid for and your plan is ready to build — I just need your questionnaire answers to make it yours. It takes about 5 minutes: **[QUESTIONNAIRE LINK]**

No rush, and no need to gather anything — it's all multiple choice. If now's not the time, this email will keep.

[NAME]

---

## 3. Plan delivery (sent when the plan is published; PDF attached + library link)

**Subject:** Your personalised plan is ready

Hi [FIRST NAME],

Your plan's ready — it's attached as a PDF, and it's live in your library here: **[LIBRARY LINK]**. A few things worth knowing as you read it:

- **Start with the top three actions.** They're chosen to be the highest-value things to do first — you don't need to do everything at once, and each one links straight to the guide or playbook for it.
- **There's a "what not to panic about" section.** Read it. Part of the point of this is to put things in proportion.
- **The conversation for this week** is one short, specific thing — that's deliberate, with the full script a click away.

It's a calm read, not a scary one. Your library — guides, playbooks, scripts and the family-agreement builder — is open whenever you want it, and it's kept current for your first year. If anything's unclear, you've got a free follow-up question for the next 14 days — just reply.

[NAME], Bearings

*This plan reflects your answers and current UK guidance. It's educational, not a safeguarding assessment or a guarantee of safety. In an emergency, use the signpost in your plan or call 999.*

---

## 4. Feedback request (sent ~3 days after delivery)

**Subject:** Did your plan actually help?

Hi [FIRST NAME],

Quick one — did the plan help, and have you been able to act on any of it? Two minutes here: **[FEEDBACK LINK]**

I read every response, and it genuinely shapes what I build next. Honest answers are the most useful, including if something fell flat.

Thanks, [NAME]

---

## 5. Library onboarding (sent ~7 days after delivery)

**Subject:** Your plan's done — here's everything else that's included

Hi [FIRST NAME],

Your personalised plan is the starting point, not the whole thing. Your purchase also unlocks a full, kept-current library — and your first year of updates is already part of what you paid, with nothing more to do.

Worth a look this week:

- **Your age-band pack** — the settings, risks and conversations that matter most for your child's age, in one place.
- **The "do-it-this-weekend" bundle** — a platform setup guide, the matching threat playbook, and a ready-made conversation script, cross-linked so you can act in one sitting.
- **The family-agreement builder** — tick the clauses that fit, edit them, and print "Our Family Online Agreement."

Start here: **[LIBRARY LINK]**

Once a month I send a short briefing on what's actually changed — calm, sourced, and only the bits that apply to you. It's included for your first year.

[NAME], Bearings

*Bearings provides prevention-focused online-safety education for parents. It doesn't monitor children or replace the police, a school's safeguarding lead, or professional advice. Emergency signpost: [LINK].*

---

## 6. Stay Current renewal offer (sent ~month 11, 30 days before the included updates year ends; only if not already on Stay Current)

**Subject:** Your updates year is nearly up — keep it current for £59

Hi [FIRST NAME],

Almost a year ago you put a plan in place for your family's online safety — that's further than most people ever get.

Your library stays yours either way. What runs out at the end of this month is the **currency**: the monthly briefings, the setting-change alerts, and the refreshed guides that keep everything matching how the apps and the risks actually look now — a year on, that's the part that goes stale fastest.

**Stay Current keeps all of that coming for £59/year** (about £1.15 a week), cancel anytime: **[RENEWAL LINK]**

No pressure — if now's not the time, your existing guides don't disappear. But the whole point of this was that it wouldn't go out of date.

[NAME], Bearings

*Stay Current is education and planning — monthly briefings, updated guides, and planning tools. It isn't monitoring, crisis help, or bespoke advice. Emergency signpost: [LINK].*

---

## 7. Refund (reply within the 14-day window)

**Subject:** Re: your report

Hi [FIRST NAME],

Absolutely — refund done, no quibble, you'll see it back within a few working days. 

If you've a moment, I'd value one line on what was missing, so the next one's better. Either way, thanks for giving it a try.

[NAME]

---

## Holding reply — if a parent's message describes a live incident

**Use this immediately, before anything else. Do not give bespoke incident advice.**

Hi [FIRST NAME],

Thank you for telling me — I want to make sure you get the right help quickly, and that's not something I can handle for you directly.

- If your child is in immediate danger, call **999**.
- For sextortion/blackmail: stop contact, don't pay, don't delete anything, and report to **CEOP** (ceop.police.uk/Safety-Centre).
- To remove a nude image of an under-18: **childline.org.uk/remove**.
- To talk it through now: **NSPCC 0808 800 5000**, or **Childline 0800 1111** for your child.

The full list is here: [emergency signpost LINK]. These services are the right people for this — please reach out to them.

[NAME]

*Note to self: this is signposting only. Never coach a parent through a live incident — it's outside scope and outside the product's safe role (`00`, risk register).*
