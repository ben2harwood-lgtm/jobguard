# AI Safety Course - Stay Current Update Stream Spec

*Created 2026-06-27. Status: Phase 3 draft for the Stay Current update workflow described in `62_AI_Safety_Course_Phase3_Tools_Spec.md`. This is an internal review and publication workflow, not an automated news feed. It must not publish legal, route, platform, or safeguarding updates without human source re-check and review.*

## Purpose

Stay Current is the maintenance layer for the AI Safety Course. It records what changed, what source was checked, which course assets are affected, whether parent-facing wording is ready, and what human review is required before publication. [RTE-008, GAP-014, GAP-016]

It is not monitoring, crisis help, bespoke advice, a news feed, or a guarantee that every legal, platform, route, or AI-behaviour change is captured instantly. It is a human-reviewed update stream with named ownership, dates, sources, and correction handling. [GAP-014, GAP-016]

## Hard Boundary

- No update goes parent-facing without source IDs, date checked, owner, affected assets, and review status.
- Route, legal, image-risk, school safeguarding, and under-18 sexual-abuse updates require human review before publication.
- Platform-specific setting instructions require a current platform/source check before publication.
- Briefings summarise approved updates only.
- Candidate updates are internal until approved.
- No AI-generated update is sent without human review.

[RTE-008, GAP-006, GAP-008, GAP-014, GAP-016]

## Update Statuses

| Status | Meaning | Parent-facing? |
|---|---|---|
| candidate | A possible change has been noticed, but source re-check has not completed. | No |
| source_checked | A named reviewer checked source(s) on a date, but wording is not approved. | No |
| needs_legal_review | Legal wording, image-risk wording, or law/policy interpretation needs legal review. | No |
| needs_safeguarding_review | Route, harm, school, or child-safety wording needs safeguarding review. | No |
| approved | Human review gates are complete and parent-facing wording may publish. | Yes |
| published | Update has been added to the relevant page, briefing, asset, or module. | Yes |
| corrected | A published update was corrected; correction note is retained internally and parent-facing where material. | Yes, with correction note if material |
| retired | Update is no longer current or has been superseded. | No, except internal audit |

## Update Record

Each update record must include:

| Field | Required? | Notes |
|---|---|---|
| update_id | Yes | Stable ID, e.g. `SCU-2026-001`. |
| title | Yes | Internal title. |
| status | Yes | One of the update statuses above. |
| change_type | Yes | route, legal, safeguarding, platform, schoolwork, policy, course wording, asset wording, or briefing. |
| owner | Yes | Named human owner. |
| date_checked | Required before approval | Date sources were last checked. |
| source_ids | Required before approval | Source IDs from the Claim Register or newly approved source register. |
| claim_ids | Required before approval | Claim IDs affected by the update. |
| affected_assets | Required before approval | Modules, tools, route cards, worksheets, pages, or emails affected. |
| review_required | Yes | legal, safeguarding, both, source-only, or founder wording. |
| reviewer_decision | Required before approval | Short note from reviewer or "not required" with reason. |
| parent_summary | Required before publication | Short, calm, non-alarmist wording. |
| parent_action | Required before publication | One concrete action or "nothing to do". |
| correction_note | If corrected | What changed, when, and why. |

## Change Types And Review Rules

| Change type | Examples | Minimum review |
|---|---|---|
| route | CEOP, Report Remove, Childline, NSPCC, police, Report Fraud, school DSL wording | Safeguarding review; legal review if image or offence wording is involved |
| legal | under-18 image law, adult intimate-image law, Online Safety Act duties, exam malpractice wording | Legal review; safeguarding review if child-safety response wording changes |
| safeguarding | contact pressure, coercion, self-harm, eating-disorder, sexual content, threat routing | Safeguarding review |
| platform | settings path, age check, feature rollout, account type, parental-control change | Source check; safeguarding review if route/harm wording changes |
| schoolwork | JCQ, DfE, school-policy baseline, assessment wording | Source check; legal/founder wording review as needed |
| course wording | module script, asset, scenario, self-check result wording | Review based on affected claims |
| briefing | monthly member summary | Human editorial review; legal/safeguarding review if it changes sensitive wording |

## Publication Workflow

1. Create a candidate update with title, change type, owner, and affected area.
2. Re-check primary sources and add date checked, source IDs, and claim IDs.
3. Assign review gate based on change type.
4. Draft internal note and parent-facing summary.
5. Human reviewer approves, requests changes, or retires the update.
6. Approved update changes the relevant module, asset, route card, page, or email.
7. Monthly briefing may include approved updates only.
8. Corrections are recorded if parent-facing wording materially changes after publication.

## Briefing Rules

Every briefing should include:

- one thing worth knowing;
- who it affects;
- one action, or "nothing to do";
- one calm proportion line;
- affected assets or pages;
- date checked and source IDs internally.

Every briefing must avoid:

- fear digest framing;
- live-incident advice;
- unreviewed legal conclusions;
- tool-specific claims without current source check;
- any claim that the course, briefing, platform, or setting eliminates harm.

[GAP-001, GAP-014, GAP-016]

## Seed Backlog

These are candidate topics only. They are not parent-facing updates until re-checked and approved.

| Backlog ID | Topic | Likely change type | Review requirement |
|---|---|---|---|
| SCU-BACKLOG-001 | Under-18 image-risk routes and Report Remove eligibility | route; legal; safeguarding | Legal and safeguarding review |
| SCU-BACKLOG-002 | CEOP route scope and wording | route; safeguarding | Safeguarding review |
| SCU-BACKLOG-003 | Report Fraud and Police Scotland routing | route | Safeguarding/source review |
| SCU-BACKLOG-004 | DfE product-safety guidance title, URL, and status | policy | Source review |
| SCU-BACKLOG-005 | Current JCQ AI-in-assessments guidance | schoolwork | Source review |
| SCU-BACKLOG-006 | Ofcom child-protection duties and codes | legal; policy | Legal/source review |
| SCU-BACKLOG-007 | Platform AI companion or chatbot age restrictions | platform; safeguarding | Source and safeguarding review |
| SCU-BACKLOG-008 | Platform-specific AI privacy and retention setting changes | platform; privacy | Source and legal/privacy wording review |
| SCU-BACKLOG-009 | Synthetic-media tool or law changes | legal; safeguarding | Legal and safeguarding review |
| SCU-BACKLOG-010 | School/DSL wording and current KCSIE edition | safeguarding; schoolwork | Safeguarding/source review |

## Acceptance Criteria

- Candidate updates cannot be published.
- Briefings can include approved or published updates only.
- Route/legal/safeguarding updates cannot become approved without the relevant reviewer decision.
- Every approved update has source IDs, claim IDs, owner, and date checked.
- The update stream records corrections and retired items.
- No update is automatically sent to customers.
- Parent-facing output stays calm, practical, dated, and non-alarmist.

## Implementation Recommendation

Start with static internal data and an admin-only table later. Do not alter `content/currency/whats-changing.mdx` automatically. Public currency pages should be edited only after the update record is approved and the affected source/route has been re-checked.

The existing `content/currency/whats-changing.mdx` should be treated as a public content page that needs a pre-launch source and route re-check before sale, because it contains time-sensitive legal, platform, and route statements. [RTE-008, GAP-014, GAP-016]
