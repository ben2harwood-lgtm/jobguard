# 97 — The No-Review Scenario: What Happens If We Remove the Human?

**For:** Ben · **Date:** 4 July 2026 · **Status:** Decision memo — answers the founder's question directly
**Question asked:** *"What if we got rid of the human review aspect — what would that do to the offering and the price point?"*
**Inputs:** Files 95 (pricing & willingness-to-pay) and 96 (price vs scale), plus two fresh adversarial research legs — one arguing the strongest honest case FOR removing the review (software economics, comparables, CAC, exit value), one arguing what BREAKS (differentiation, claims, safety, ladder, reversibility). Every external figure is sourced; everything derived or assumed is flagged **[INF]** = inference.
**Stance:** Adversarial, no flattery. Both legs were written to win. Where the software business genuinely wins, this memo says so plainly.

---

## 1. The direct answer

**Remove the review and Keepwise stops being a £99 personal service and becomes a £19–£39 software product — a different business, not a cheaper version of this one.** It gains real things: zero marginal cost, instant delivery, no throughput ceiling, a simpler build, and a sellable software asset instead of a service job. It loses the only asset in the bundle with no free substitute, lands on the exact shelf where a charity already gives away a near-identical product, deletes the safety QA gate this repo has already watched fail without a human, and burns brand optionality that cannot be bought back.

**What the offering becomes:** an instant, auto-generated household plan (same ~25-question diagnostic) + the ~51-item kept-current library + Stay Current updates + Family Agreement builder + scripts + printables — delivered in seconds, no queue, no publish gate. It may honestly claim *"your personalised plan, generated from our editor-maintained library, instant and kept current."* It may **not** claim "reviewed", "human-checked", or anything implying individual attention (Section 4).

**The price it honestly supports:**

| Variant | Honest band | Centre | Anchor |
| --- | --- | --- | --- |
| One-off | **£19–£39** | **£29** | Huckleberry's algorithm-only Single Sleep Plan at **$29.99 (~£23)** ([huckleberrycare.com/pricing](https://huckleberrycare.com/pricing)); Parent Zone course £6.99; Wonder Weeks $4.99; the £7–£30 digital-parenting content shelf (file 95 §2) |
| Subscription | **£29–£49/yr** | **£39/yr** | Algorithmic parenting subs cluster at $60–$80/yr (~£47–£63) — Kinedu ~$60/yr, Moshi $59.99/yr, Huckleberry Plus $68.88/yr — and that shelf-top is held by heavily marketed brands. RevenueCat's 2025 data shows retention *falls* as subscription price rises (22.5% low-priced vs 12.2% high-priced), which argues for the low end ([revenuecat.com](https://www.revenuecat.com/state-of-subscription-apps-2025/)) |

Nothing on the self-serve algorithmic-parenting shelf is priced near £99, anywhere. The apparent exceptions — Big Little Feelings at $99, Positive Parenting Solutions at $249 — are carried by named, credentialed founders with audiences of millions, i.e. exactly the "person + proof" premium (file 96 §5) that an anonymous auto-generated plan cannot borrow. **[INF]** The honest comparator set for a no-name automated plan is the £7–£30 shelf, and file 96 §4 already priced this exact product: *"a £29–39 content product competing head-on with Internet Matters' free personalised toolkit… free wins that fight."*

### 1.1 The Huckleberry natural experiment — the most important comparable found

Huckleberry sells the *same* child-sleep help three ways: algorithm one-off ($29.99), algorithm subscription ($68.88/yr), and algorithm **plus certified human consultants** ($119.88/yr). Two extractions, and they cut in opposite directions:

1. **The human premium collapses when the human is productised.** Huckleberry's market-tested price for adding real certified humans to an algorithmic child plan is **+$51/yr (~£39) — a ~1.7× premium, not 3–4×**. Meanwhile the gap between a *bespoke* human (traditional sleep consultant, £250–£500) and the algorithm is 10–20×. Keepwise's £99-vs-£29 gap is therefore carried mostly by its **cost structure** (a bespoke 20-minute review at £13–£22/plan, file 96 §2.1) rather than by buyer-perceived value of "a human" in the abstract. This is the strongest single fact FOR the pivot: the review is a large, permanent, unscalable unit cost defending a premium the market credits at ~1.7× when productised.
2. **Yet Huckleberry did not delete the human.** Their revealed strategy is algorithm-as-cheap-on-ramp, human-as-premium-upsell. The company that ran this experiment at scale concluded the answer is a **ladder**, not an amputation. **[INF]** The honest form of this pivot, if it ever happens, keeps a human SKU above the automated one — which is precisely file 96 §4's existing "satellite SKU" design, run in the safe order.

---

## 2. The two businesses, side by side

WITH-review uses file 96's base case (150/500/1,200 customers in years 1–3, ~£73 net contribution per sale after fees, refunds and review). WITHOUT-review uses the *best honest case* from the FOR leg: £29 one-off / £39-yr sub, zero fulfilment cost, ~£25.60 net per £29 sale after Stripe + ~6% refunds.

| Dimension | WITH review (£99/£79) | WITHOUT review (£29 / £39-yr) | Who wins |
| --- | --- | --- | --- |
| **Price power** | £99 defensible after value-visibility fixes; £129–£149 credible ceiling (file 95 §1) | £19–£39 hard ceiling set by the shelf; £49+ collides with Calm-tier brands | With review |
| **Net contribution/sale** | ~£73 | ~£25.60 (£29) · ~£16.70 (£19) · ~£34.80 (£39) | With review |
| **Buyers needed to match Y3 contribution (~£87,600)** | 1,200 (base case) | **3,422 at £29 (2.9×) · 2,517 at £39 (2.1×) · 5,246 at £19 (4.4×)** | With review, unless funnel widens 2–4.4× |
| **Funnel width & channels** | Warm channels only (pilot, PTA, word of mouth); reviewer throughput caps at ~2,900 plans/yr/person (file 96 §5.3) | App-store distribution, freemium on-ramp, instant delivery, **no throughput ceiling** — channels the review model structurally cannot use | Without review |
| **Paid CAC viability** | Break-even CAC ~£78; UK Meta realistically £60–£114 — marginal at best (file 96 §2.2) | Break-even CAC ~£21.60 at £29. At sourced CPC/conversion figures, paid social is **break-even acquisition, not profit** — the tripwire playbook's own assumption. Only works if renewal LTV clears ~3× CAC; at £29–39/yr and ~40% year-1 retention **[INF from RevenueCat's 36–44% band]** it clears *barely* | Without review, narrowly — but it deepens, not escapes, the renewal dependency |
| **Moat vs free + ChatGPT** | The review is the one feature neither Internet Matters' free toolkit nor a frontier model can copy (file 95 §4) | **Collapses to a prompt wrapper.** The no-review product is a structural near-clone of Internet Matters' FREE 7-question personalised "My Family's Digital Toolkit" (age-specific bespoke advice + optional updates, [internetmatters.org/digital-family-toolkit](https://www.internetmatters.org/digital-family-toolkit/)), and its plan is drafted by the same class of model a parent can use free. The "not a chatbot" wedge doesn't weaken — it **inverts**: the product now *is* the chatbot | With review, decisively |
| **Safety / claims risk** | Bounded: human publish gate + publish-log = ASA substantiation record (file 96 §5.3) | **Unbounded tail risk** on auto-generated child-crisis guidance (Section 3); every "checked by a real person" claim on the pricing page becomes false; §5's premium levers — named reviewer, reviewer's note, SLA, slot scarcity, review-praising testimonials — all die (5 of 7 levers; only the guarantee and changelog survive) | With review |
| **Founder workload** | Review is a permanent 20–30 min/plan treadmill; hiring, QA and PI-insurance burden at scale (file 96 §1) | M3 pipeline collapses from draft→edit→publish to draft→publish. Ships sooner; solo founder stays solo far longer | Without review |
| **Reversibility** | Premium-first can add a cheap automated satellite SKU later — routine good-better-best (file 96 §4 designed it) | Cheap-first re-anchors the brand at £29-automated; climbing back to £99-human later reads as price-gouging and the spent wedge can't be re-minted (Section 5) | With review |
| **Sellable-asset value** | Service business: ~2–4× EBITDA, doesn't transfer without the humans ([ctacquisitions.com](https://ctacquisitions.com/guides/marketing-agency-business-valuation/)) | Software: ~3–5× ARR for slow-growth SaaS, up to 15–25× EBITDA when profitable ([aventis-advisors.com](https://aventis-advisors.com/saas-valuation-multiples/), [saas-capital.com](https://www.saas-capital.com/blog-posts/private-saas-company-valuations-multiples/)) | Without review |
| **Renewal engine** | £59/yr renewal reframed as "updates + annual human re-review as the child ages up" — the only credible churn fix in the education vertical, and ~430 renewals fund the currency layer (file 96 §2.3) | Renewal becomes "updates + changelog" — exactly what Internet Matters' free newsletter offers. **[INF]** The unvalidated 60% persistence assumption plausibly craters; the currency layer loses its funding mechanism below ~500 customers | With review |
| **Ladder coherence** | £99 → £149 (+call) → £650 Concierge, each rung buying more human access | £149 call tier orphaned (only human touchpoint on a product that disclaims humans); £650 above a £29 base reads absurd, not aspirational | With review |

**Playing it straight on the numbers:** the software business wins four columns outright — funnel width, CAC mechanics, founder workload, exit multiple — and those are not small things. But its Y3 contribution only matches the with-review base case if the funnel genuinely widens 2.1–4.4×, and file 95's core finding is that the objection suppressing conversion is *"why pay at all when it's free"* — an objection that is **strongest exactly where the pivot lands**, because at £29 the product is least differentiated from the free clone. Elasticity ≈ −0.8 means cutting £99→£29 adds roughly 40–60% more buyers **[INF]**, not the 190–340% needed. The remaining multiple must come from funnel mechanics (app-store presence, freemium conversion, break-even paid acquisition, renewal compounding) that require a polished app the non-technical founder has not built and cannot cheaply build. Best case, the software business *ties* the with-review base case on contribution while losing on moat, claims, safety and reversibility. Risk-adjusted, it undershoots.

---

## 3. The safety dimension — the review is the QA gate, not just marketing

This must be said plainly, because it is the part of the review that never appears on a pricing page.

**This repo is its own case study.** Commit `7df540c` restored a Papyrus HOPELINE247 crisis number after automated checks had confidently 'verified' the wrong state — an error caught only on the third pass, by a human. That is a logged instance, in this project, of automated verification being repeatedly and confidently wrong about a **life-safety number for children**. The plan generator's output surface (`lib/plan-prompt.ts`, SIGNPOST block) contains exactly this class of content: 999/101 routing, CEOP, Report Remove, NSPCC and Childline numbers, sextortion and image-takedown guidance. An LLM drafting per-household variants of that at volume, with no human publish gate, will eventually emit a plausible-but-wrong helpline number or a subtly wrong takedown instruction — and ship it, unread, to a frightened parent acting on it during a real incident. Prompt guardrails are drafting instructions; **the human publish action is the enforcement**.

**Dropping it is not a config change.** Spec 21 states: *"Human-in-the-loop is mandatory for the personalised plan (§7.5)… This is a guardrail, not a preference,"* and §7.5's hard rule: *"no path may set a plan to 'delivered' or email it without an admin publish action."* Removing a documented safeguarding control on automated child-safety guidance requires, by the project's own governance, a **full safeguarding re-review** — plus engineering mitigations (locked, hand-verified crisis-signpost blocks that the model cannot rewrite; deterministic templates for all crisis content; ongoing sample QA) and a re-costing of liability/PI exposure. **Price this into the pivot: it is not free to remove the reviewer; you must buy a replacement safety architecture, and even then the residual risk sits on children's crisis guidance.** [INF: sample QA catches error *rates*; it cannot catch the specific wrong number before the specific frightened parent reads it — that is what the publish gate does.]

**The claims consequence is immediate.** The current pricing page (`app/pricing/page.tsx`) says "a plan checked by a real person" and "No plan is sent until a person has checked it." Every such line becomes a false statement on removal day and must be deleted. Under ASA Rule 3.7 the ASA judges claims by what a consumer understands, not what the marketer meant ([asa.org.uk](https://www.asa.org.uk/advice-online/substantiation.html)); "personalised safety plan for your family" read against deterministic template-fill is the misleading-by-omission trap file 96 §5.3 flags. And the admin publish-log — the documentary substantiation held before any ad runs — ceases to exist. The review is simultaneously (a) the premium wedge, (b) the ASA substantiation record, and (c) the child-safety QA gate. It cannot be removed as a cost line without losing all three at once.

---

## 4. What the no-review product may and may not say

**May say (honest):** "Your personalised plan, built from our editor-maintained library" · "Instant — your plan in minutes, not days" · "Kept current — when the threat landscape changes, your library updates" (with the public changelog as proof) · "Built on guidance from Internet Matters, NSPCC, gov.uk and Ofcom, organised for your household."

**Must not say:** "reviewed" · "human-checked" · "a person checks every plan" · "safeguarding review" · anything a reasonable parent would read as individual professional attention. The "not a chatbot" headline — the single move that dragged the product onto the £50–£500 expert shelf (file 96 §5.3) — becomes unusable and self-incriminating.

**Genuine gains, stated without hedging:** (1) kills the one cost that never amortises — £13–£22/plan, forever, at every scale; (2) lifts the throughput ceiling and the hiring/PI burden — no 12–32-person review organisation at scale; (3) ships sooner and simpler — the M3 pipeline loses two of its three stages, a real benefit for a non-technical solo founder; (4) builds a sellable software asset instead of a hard-to-sell service job. These are true and they are why this question deserved a full memo rather than a reflex "no".

---

## 5. The sequencing asymmetry — this decides it

The evidence on demand is genuinely uncertain ("nobody can prove £99 from a desk" — file 95 §1). When evidence is uncertain, take the path you can walk back.

- **Premium-first → add automated tier later: easy and already designed.** File 96 §4 specifies the safe version — a clearly-labelled automated satellite SKU on its own page, never displayed beside the £99 plan, feeding the ladder without re-anchoring it. A brand established as "human-reviewed" can extend downward any time. This is a routine good-better-best move; it is also exactly Huckleberry's shape.
- **Cheap-first → add the review back later: hard, plausibly impossible.** [INF, strongly supported] Three mechanisms: (1) price anchors are sticky downward — customers who paid £29 for automation read a later £99 "now with a human" as gouging, not a new tier; (2) the "not a chatbot" wedge, once spent by launching *as* the chatbot, cannot be credibly re-minted; (3) the customers a cheap launch acquires are file 95 §5.4's own failure signal — people who bought "cheaper than the free stuff" — and their testimonials and word of mouth seed the *convenience* positioning, poisoning the premium climb-back.

One door swings both ways; the other locks behind you. That asymmetry, more than any single number above, is the decision.

---

## 6. Verdict

**Do not remove the human review. Keep spec §7.5 intact and run the pilot as designed at £79 founding / £99 full.**

The pivot's best arguments are real — the review is expensive, unscalable, and the market's productised-human premium is only ~1.7× — but the pivot fails on four grounds at once: it lands a £29 product on a shelf where a better-known charity gives away a near-clone for £0; it deletes the only feature with no free substitute and inverts the brand's founding claim; it removes a safeguarding control this repo's own incident history proves is load-bearing, on guidance that includes children's crisis numbers; and it spends irreversibly the one asset (the human-trust anchor) that the reverse move preserves. The £13–£22/plan it saves is bounded; what it spends is not. The zero-overhead version of this business is a different and worse business — file 96 §10's sentence survives this second, harder test.

**Named conditions under which the no-review pivot WOULD be right.** Write these down now, so a future decision is made on triggers rather than fatigue:

1. **The pilot falsifies the wedge.** Conversion at £79–£99 fails *and* the testimonial audit (file 95 §5.4's formal metric) shows buyers praising convenience/price, not the review — i.e. real customers demonstrate the review carries no willingness-to-pay. That is the market saying the human is a cost, not a moat.
2. **Review time measures ≥3× spec.** If real plans take 60+ minutes rather than ~20, unit cost rises to ~£40–£65/plan and the premium maths in file 96 §2 breaks; the trade in §1.1 then genuinely favours automation.
3. **A volume distribution partner appears** — a school trust, ISP, employer-benefits platform or insurer wanting thousands of instant plans under their own trust umbrella. A partner's brand replaces the review as the trust source, and instant delivery becomes the requirement rather than the compromise. (White-label automated + retained direct-to-parent reviewed is the likely shape. [INF])
4. **The founder chooses the software-company path deliberately** — funded app build, subscription engine, freemium funnel, competing on distribution against free — as a strategy, not as a cost-saving.
5. **In every case:** a completed safeguarding re-review and a replacement safety architecture (locked crisis blocks, deterministic crisis templates, sample QA, corrected marketing copy) *before* the first unreviewed plan ships. This condition is not waivable.

Even if triggers 1–2 fire, the first move is Huckleberry's, not amputation: keep the automated product as a cheap satellite on-ramp and *retain* a human tier above it.

---

## 7. What this means for the pilot — five actions, nothing structural

The pilot already tests the load-bearing question (will parents pay for a human-reviewed plan?), so nothing structural changes. Five adjustments make it also generate the evidence this memo's triggers need:

1. **Measure actual review minutes per plan** from plan one. This is trigger 2's data and today it is an assumption.
2. **Make the review visible** — named reviewer, credential, and a short reviewer's note on every delivered plan ("I changed X because your 14-year-old…"). File 96 §5.2: invisible review is priced at £0 by the buyer. The pilot must test the wedge at full strength, or a conversion failure is uninterpretable.
3. **Tag every testimonial and feedback item** by what it praises: review/human vs convenience/price. This is trigger 1's instrument.
4. **Lock the crisis-signpost block regardless** — hand-verified, model-untouchable crisis numbers in every plan. A no-regret hardening whichever business this becomes, and commit `7df540c` says do it now.
5. **Keep §7.5 and the publish-log untouched**, and design the diagnostic-to-plan pipeline so an automated satellite SKU *could* be bolted on later without rebuild — preserved optionality at near-zero cost. Do not build the auto-publish path now.

---

**Files referenced:** `/Users/benharwood/Claude/Projects/AI Safety Build/95_Pricing_WTP_Assessment.md` · `96_Price_Scale_Strategy.md` (§2, §4, §5, §10) · `21_MASTER_BUILD_SPEC.md` (§7.5 hard rule) · `app/pricing/page.tsx` (review claims) · `lib/plan-prompt.ts` (crisis-guidance surface).
**Key external sources:** Huckleberry pricing ([huckleberrycare.com/pricing](https://huckleberrycare.com/pricing), [/product/premium](https://huckleberrycare.com/product/premium)) · Internet Matters free toolkit ([internetmatters.org/digital-family-toolkit](https://www.internetmatters.org/digital-family-toolkit/)) · RevenueCat State of Subscription Apps 2025 ([revenuecat.com](https://www.revenuecat.com/state-of-subscription-apps-2025/)) · ASA substantiation guidance ([asa.org.uk](https://www.asa.org.uk/advice-online/substantiation.html)) · SaaS/service valuation multiples ([aventis-advisors.com](https://aventis-advisors.com/saas-valuation-multiples/), [saas-capital.com](https://www.saas-capital.com/blog-posts/private-saas-company-valuations-multiples/), [ctacquisitions.com](https://ctacquisitions.com/guides/marketing-agency-business-valuation/)) · repo commit `7df540c` (crisis-number incident, direct observation).
