# AI Safety Course - Founding Pilot No-Code Setup

*Created 2026-06-27. Status: setup guide for running the founding pilot manually with Stripe, email, and local/static materials. Do not use for broad launch. Run AI review, patch blocker/high findings, complete first-sale terms/privacy/refund decisions, and verify the emergency signpost first.*

## Setup Goal

Create the smallest paid pilot flow:

1. Parent reads the cautious pilot page.
2. Parent pays GBP 49.
3. Parent receives the materials manually.
4. Parent gives feedback.
5. Founder tracks whether demand and trust are strong enough to justify paid professional review.

## Required Materials

- Sales copy: `76_AI_Safety_Course_Founding_Pilot_Sales_Page_Copy.md`
- Outreach copy: `77_AI_Safety_Course_Founding_Pilot_Outreach_Copy.md`
- Email templates: `79_AI_Safety_Course_Founding_Pilot_Email_Templates.md`
- Tracker: `80_AI_Safety_Course_Founding_Pilot_Tracker.md`
- Printable pack: `81_AI_Safety_Course_Founding_Pilot_Printable_Pack.html`
- Module scripts: `74_AI_Safety_Course_Founding_Pilot_Module_Scripts.md`
- Asset copy: `75_AI_Safety_Course_Founding_Pilot_Asset_Copy.md`
- Emergency signpost verification: `84_AI_Safety_Course_Emergency_Signpost_Verification.md`
- First-sale admin pack: `85_AI_Safety_Course_First_Sale_Legal_Admin_Pack.md`
- Terms/privacy draft copy: `86_AI_Safety_Course_Founding_Pilot_Terms_Privacy_Drafts.md`
- Payment setup draft: `87_AI_Safety_Course_Founding_Pilot_Payment_Setup_Draft.md`
- First-sale decision log: `88_AI_Safety_Course_First_Sale_Decision_Log.md`
- Private pre-payment page draft: `89_AI_Safety_Course_Private_PrePayment_Page_Draft.md`

## Step 1 - Review Gate

Before setup:

- [ ] Run legal AI review brief.
- [ ] Run safeguarding AI review brief.
- [ ] Record findings in `73_AI_Safety_Course_PreRevenue_AI_Review_Findings.md`.
- [ ] Patch blocker/high findings or remove affected material from pilot.
- [ ] Confirm emergency signpost link works and matches `84_AI_Safety_Course_Emergency_Signpost_Verification.md`.
- [ ] Complete `85_AI_Safety_Course_First_Sale_Legal_Admin_Pack.md`.
- [ ] Fill all placeholders in `86_AI_Safety_Course_Founding_Pilot_Terms_Privacy_Drafts.md`.
- [ ] Complete `88_AI_Safety_Course_First_Sale_Decision_Log.md`.
- [ ] Fill all placeholders in `89_AI_Safety_Course_Private_PrePayment_Page_Draft.md`.

## Step 2 - Pilot Page

Use one of these options:

### Lowest friction

Send the private pre-payment page draft from `89_AI_Safety_Course_Private_PrePayment_Page_Draft.md` as an email or Google Doc to warm parents. Do not publish it broadly.

### Slightly more polished

Put the private pre-payment page copy into Carrd, Notion, Google Doc, or a private webpage.

Required elements:

- headline;
- pilot notice;
- what you get;
- what it does not include;
- price;
- buyer notice;
- terms link or attached terms copy;
- privacy link or attached privacy copy;
- refund/cancellation wording;
- emergency signpost link;
- non-urgent question email.

Do not add:

- public testimonials;
- claims of review or approval;
- outcome claims;
- upload/paste offers;
- route-card preview;
- scenario/self-check tool links.

## Step 3 - Stripe Payment Link

Create one payment link only after the requirements in `87_AI_Safety_Course_Founding_Pilot_Payment_Setup_Draft.md` are met.

Suggested payment setup:

- Product name: Bearings AI Safety Course - Founding Parent Pilot
- Price: GBP 49
- Quantity: one
- Collect email: yes
- Required checkbox: "I confirm I am 18+ and a parent/carer."
- Required checkbox: "I have read the pilot notice, terms, privacy notice, and refund/cancellation wording."
- Required checkbox: "I understand this is parent education and household planning only. I will not send child names, school details, account handles, screenshots, messages, images, attachments, schoolwork, prompts, or live-incident details."
- Required checkbox if early digital delivery is used: "I want access to the digital pilot materials before the 14-day cancellation period ends, and I understand that once the digital materials are supplied I may lose my right to cancel for that digital content."
- Optional checkbox: "Email me occasional updates about Bearings. I can unsubscribe anytime."
- Success message: "Thank you. Your pilot materials will be sent manually. Please do not send child details, screenshots, messages, images, school details, account handles, or incident details. If something is happening now, use the emergency signpost: [LINK]."

If the payment tool cannot collect every required acknowledgement, collect them before payment in a pre-payment form or confirmation email. Do not send the payment link until the acknowledgement record is complete.

Do not use a questionnaire for this pilot unless every field is selection-only and free of child PII.

## Step 4 - Delivery Folder

Create a private folder with:

- `81_AI_Safety_Course_Founding_Pilot_Printable_Pack.html` exported/printed to PDF if desired;
- module scripts as PDFs or private docs;
- emergency signpost link;
- a short README with the pilot boundary.

Folder rule:

- view-only for buyers;
- no comments;
- no upload request;
- no shared folder where buyers can see each other.

## Step 5 - Manual Delivery

When Stripe payment arrives:

1. Add buyer to `80_AI_Safety_Course_Founding_Pilot_Tracker.md`.
2. Check 18+ parent/carer consent.
3. Send Email 1.
4. Send Email 2 with material links.
5. Set reminder to send feedback email after 5-7 days.

## Step 6 - Boundary Handling

If a buyer sends incident details or asks what to do in a live situation:

1. Do not answer the facts.
2. Do not ask follow-up questions.
3. Send Email 4 boundary reply.
4. Log the boundary issue in the tracker with identifying details removed.
5. Review whether any pilot copy invited that message.

## Step 7 - Feedback And Decision

After 5 buyers or 10 serious leads, review:

- Did people understand the pilot boundary?
- Did anyone try to send live details?
- Which asset did parents want most?
- Did price feel acceptable?
- Did anyone object to lack of formal professional review?
- Did any wording feel too strong or too soft?

Decision:

- If demand is weak: revise positioning before building more.
- If demand is real but trust questions appear: pay for review before widening.
- If boundary issues appear: pause and patch copy/process.
- If 5 buyers complete cleanly: book paid legal/safeguarding review before broadening.

## Step 8 - What Not To Automate Yet

Do not automate:

- plan generation;
- scenario trainer;
- self-check;
- route-card printing;
- platform-specific updates;
- monthly briefing sends;
- feedback analysis that includes child detail.

Keep the pilot manual until trust and demand are clear.
