# 98 — Value Expansion: What Makes a Parent Say "I Have To Have This"

**For:** Ben · **Date:** 5 July 2026 · **Status:** Decision memo — ranked build list
**Question asked:** *"How can we add more value — what else can we build or give them — to make parents say I HAVE TO HAVE THIS?"*
**Inputs:** Files 95–97 (pricing, price-vs-scale, no-review scenario) as fixed strategy; a 60-idea generation-and-judging pass across seven lenses (human-touch, tangible, tools, moments, peace-of-mind, identity/channel, wild), each idea scored adversarially for willingness-to-pay lift, must-have-ness, solo-founder fit and moat vs free. Three ideas died on hard guardrails and are listed so they stay dead.
**Stance:** Honest, no flattery. The law running through every verdict: **the premium is licensed by a PERSON, a PROOF and a PROMISE — never by more content.** Anything that adds pages, adds nothing.

---

## 1. The headline — the three "I have to have this" plays

These three won because each passes all four tests at once: it is person/proof/promise (not content); it sits on a real trigger moment; one person can run it in ~10 spare hours a week; and neither Internet Matters nor ChatGPT can copy it.

**1. The Posted Plan — a handwritten line from the person who reviewed you.**
> Parent voice: *"Three days after I paid, an envelope landed with my family's plan printed properly — and a handwritten note from the woman who checked it: 'I looked at your household; the thing I'd do first is X.' A real person actually looked at us."*

Why: the whole £99 premium rests on a human review the buyer currently cannot see. Handwriting on posted card is the cheapest possible proof it happened — roughly £2 of postage and 5–8 minutes per plan — and the handwritten line literally *is* the killer testimonial ("it caught something I'd missed"). Highest-scored idea of all sixty.

**2. One Question, Answered by a Human — the promise in your back pocket.**
> Parent voice: *"When my 12-year-old suddenly wanted Discord, I didn't panic-Google at 11pm. I emailed the person who knows our plan — and she wrote back."*

Why: this is what moves the product off the "buy a guide" shelf (£0–25) onto the "expert help with a worry about my child" shelf (£50–500). The economics are the trick: felt value is near-100%, but only ~10–20% of buyers ever spend the credit, so the labour is tiny. **Ships only with the crisis gate built** (see §2).

**3. The Changed-For-You Digest — someone watching the landscape for YOUR kids.**
> Parent voice: *"Most months it says 'nothing changed that affects your household — enjoy the quiet.' Then Snapchat moved a setting on the app my 14-year-old actually uses, and Keepwise told me before I'd even heard about it."*

Why: this converts the £59 renewal from "a newsletter" into "a personal watch service" — the exact reframe the renewal economics need. ChatGPT will never proactively tell you an app your child uses changed; static free content can't either. The judge's verdict: *if only one renewal feature ships, it's this.*

Together: #1 makes the person visible, #2 makes the promise real, #3 gives the renewal its reason to exist. Person, promise, engine.

---

## 2. The ranked shortlist (12), grouped by when

Consolidations first, so we build once, not four times:

- **The renewal ritual is ONE product, not four.** "Anniversary Re-Look" + "Annual MOT" + "MOT Certificate" + "Age-Up Envelope" all scored well and are all the same thing: an annual, dated, human re-review with a physical artefact. Build it as **The Annual Re-Review** (below). The certificate ships at £99 from day one to seed the date.
- **The Digest and the "Living Plan" are one engine.** Both diff the household's declared profile against the tagged library. Build the tagging once; ship the Digest (push) first; render the Living Plan view later.
- **All physical-kit ideas collapse into one flagship box, later.** Handover Box absorbs the Ceremony Kit, Sleeps-Here pouch and fridge poster. One fulfilment pipeline or none.

### DO-NOW — before/during the pilot

| # | What it is | Rung | Cost | Judge's line |
|---|---|---|---|---|
| 1 | **Meet Your Reviewer (60 seconds)** — a video on the pricing page: the actual named person who checks plans, saying hello and what she looks for. | £0 funnel / conversion | S (~2 hrs, once) | "The strategy says the proof is invisible at checkout; this is the cheapest fix. Do this before any paid marketing." Script sells what she *does* ("I check every plan for age-fit and gaps"), never credentials she doesn't hold. |
| 2 | **The Posted Plan (+ the 2-minute voice note)** — plan printed on good stock, one handwritten line from the reviewer, posted; plus a 90-second recorded voice note ("two under-tens, one just got a phone — here's the first thing I'd do"). Promise both ON the pricing page so the proof works pre-purchase. | £99 base | M setup (~8 hrs), 5–10 min/plan | "Best idea in the set and the cheapest: manufactures PERSON and PROOF for ~£2 of postage — and it literally scripts the killer testimonial." Line stays plan-framed ("I'd do X first"), never safety-framed. Pre-commit the scale graduation: founding cohort at £99, then it moves to the £149 tier. |
| 3 | **One Question, Answered by a Human** — one "Ask [name]" email credit per household, first year. | £99 base | S | "The PROMISE that moves the product off the guide shelf, with breakage economics." Non-negotiable fixes: visible scope line at the ask box, pre-written signpost reply for anything incident-shaped, one credit hard cap, 2-working-day SLA (kills "urgent" framing). |
| 4 | **The Whole-Household Frame** — reposition everything as "one reviewed plan for EVERY kid, one price": the plan speaks in siblings ("your 8-year-old and your 14-year-old need almost opposite things — we've handled both"). | £99 base | S (6–10 hrs, copy + plan output) | "Strongest WTP move and it costs copy, not content — £99 feels cheap against per-child subscriptions." Two catches: the review must genuinely handle opposing age bands, and a 3-kid review breaks the 25-min budget — re-cost before promising. |
| 5 | **The Review Certificate** — a dated, designed one-pager for the fridge: "Household plan made & reviewed [date] by [name] — next review due [date]". | £99 base → renewal seed | S (6–10 hrs, one template) | "Best hours-to-value ratio. The 'next review due' date sits in the kitchen for twelve months as the visible reason the renewal exists." Never "pass", never "certified", never "safe" — file 39's line holds. |

### DO-NEXT — first 6–9 months post-pilot

| # | What it is | Rung | Cost | Judge's line |
|---|---|---|---|---|
| 6 | **The Changed-For-You Digest** — Stay Current filtered to the household: "one thing changed this month that affects YOU"; most months, honestly, "nothing — enjoy the quiet". | £59 renewal (this is what renewal IS) | M (20–35 hrs incl. library tagging) | "Structurally impossible for ChatGPT and static free content. If only one renewal feature ships, it's this." Copy discipline: "we watch the public landscape and match it to what you told us" — never "we noticed on Snapchat", which reads as surveillance. |
| 7 | **The Annual Re-Review** (consolidated ritual) — the named reviewer re-opens your household a year on, fresh reviewed plan + short personal note, posted in an age-up envelope, new certificate with a new due-date. | £59 renewal | M (~25–30 min/renewal — this is the labour the £59 honestly pays for) | "The renewal doesn't need a reason bolted on; this IS the reason." Prerequisite: the pipeline must retain the name-free age-band/platform profile for 12 months with consent — not yet built. Labour scales linearly: fine to ~300 renewers, forces a price rise or help near 1,000. Plan for that now. |
| 8 | **The Secondary-School Switch Kit** — a "get ready for Year 7" summer countdown wrapping the reviewed plan, sold hard May–August; £149 variant adds a transition call. | £99 / £149 seasonal on-ramp | S (~12 hrs, reuses existing packs) | "90% marketing repackage, 10% product — and that's a compliment. Best effort-to-return ratio here." A dated, universal, high-anxiety moment every Year 6 parent hits the same summer. |
| 9 | **The Age-Up Drill + First-Phone Satellite** — threshold rehearsal packs (first phone / turning 13 / turning 16): the two conversations, the settings that change, the calm handover — with a £49 "first phone" standalone as the front door to the System. | £99 base + £49 satellite + renewal heartbeat | S (12–18 hrs) | "First phone is the single highest-WTP moment in this market — the one time a parent is actively shopping." No DOBs ever: trigger from age band + parent-declared "first phone coming". |

### LATER — needs scale, proof or a calendar that can take it

| # | What it is | Rung | Cost | Judge's line |
|---|---|---|---|---|
| 10 | **New App? Ask Keepwise** — type an app name, get a calm one-screen parent brief from the human-maintained library, tuned to your age band; unreviewed apps get an unmistakable "not yet covered — general principles" fallback. | £99 base + renewal-gated currency | M (30–50 hrs) | "Sits exactly on the 'is this OK?' moment where the ChatGPT threat lives." Scope the marketing to "the ~50 apps UK kids actually use, human-checked" — "whatever launched last week" is a promise one founder cannot keep. Never safe/unsafe verdicts. |
| 11 | **The 48-Hour House Brief** — when a genuinely national scare breaks (new app panic, viral "game", sextortion headline), members get one calm email: what's real, what it means for houses like yours, and often "you can ignore this, here's why". | £59 renewal headline benefit | M (~2–4 hrs per brief, 6–8/yr) | "Proactive, calm, from a named person, arriving before you thought to Google — ChatGPT won't tap you on the shoulder." Promise wording: "a calm brief when a big story breaks" — aim for 48 hrs, never contract it. Population-level only; expect and deflect "but what about MY incident" replies. |
| 12 | **Phone-Ready Check** — a live 25–30 min call the week the first phone lands: we guide, you click, you hang up DONE. | £149 tier feature | M (~30 min real human time/sale) | "Genuinely hard for free to match." Fixes: talk-through only — we never see the child's device or screen; keep it inside the £149 tier (a £49 standalone guts the tier); hard weekly slot cap — this is the only idea bounded by your calendar. |

**Bench (worth hours only when the list above is done):** Summer Runway (renewal rhythm, add one human touch), the "If It Happens Tonight" fridge card (printable only; verify every official link — a dead 2am link is brand-ending), Ready-Together card for grandparents/sitters, Household Passport (retention garnish; no child names on anything hosted), Two Homes One Standard £49 co-parenting satellite (real white space; two separately-held documents, never a shared space), e-gift codes, the Readiness Guarantee (renamed from "Sleep-Well"; conditions only on the PARENT's completed steps; wording legally checked), Concierge bound folio, Time-Capsule renewal v1 (= attach last year's plan PDF to the renewal email — 2 hours, not a build).

---

## 3. The ladder map — one new reason-to-buy per rung

| Rung | New reason to buy | From |
|---|---|---|
| **£0 funnel** | *"See the actual person before you pay a penny."* | Meet Your Reviewer video; later a First-Phone Countdown free drip (must visibly withhold the human review, or it solves the felt need free — the strategy's own biggest risk, self-inflicted); 3-card conversation-script taster. |
| **£49 satellites** | *"Help for THE moment, from the same real people."* | First-Phone Drill satellite (#9); Two Homes One Standard (bench); later the 48-Hour Worry Brief one-off (£29–39, hard pre-payment triage that refuses anything live or child-specific, ~5 slots/week, fee credited against the £99 System). |
| **£99 System** | *"A named person actually reads YOUR household — and you can see, hear and hold the proof. And you get one real question answered this year."* | Posted Plan + handwritten line + voice note (#2), One Question (#3), Whole-Household Frame (#4), Certificate (#5), Switch Kit framing (#8); later the app lookup (#10). |
| **£149 Plan + Setup Call** | *"Don't just receive the plan — do it, live, with the person."* | Phone-Ready Check (#12), Switch Kit call variant (#8); at scale, the handwritten Posted Plan graduates up to here; later the Handover Box as the physical flagship edition. |
| **£59 renewal** ← the rung that needed the most | *"Every year, a person re-reads your household. Between times, we watch the changing landscape and only ever ping you when it touches YOUR kids."* | Annual Re-Review (#7) + Changed-For-You Digest (#6) + House Brief (#11). Three legs: a yearly human moment, a monthly personal filter, a rapid calm voice when the news is scary. That sentence is the renewal page. |
| **£650 Concierge** | *"Your whole household handled properly, once, beautifully — and re-reviewed on tape every year."* | Bound, name-stamped folio (bench); the bespoke annual narrated video ("Yearly Portrait", fixed version) lives here and at £149 — never at £59, where the labour maths dies. |

---

## 4. Moonshots — wild, kept alive in compliant form only

1. **The Fresh-Start Voucher (sold where the phone is sold).** A Keepwise card in the box when a family buys a child's first phone or kids' SIM — the offer physically inside the highest-intent 90 seconds in the market. Compliant pilot: ONE independent local phone shop, 50 printed insert cards with a code, zero data flowing from the retailer, copy reads "a calm plan for your household" — never "a safer phone". Year 2, once there's proof to show a shopkeeper.
2. **The Time Machine.** An interactive "road ahead" — the terrain most families travel from 11 to 17, tuned only by declared age band. Compliant form: population-level wording throughout ("most children at this stage…"), zero "your child will…" — anything else is the child-risk-forecast file 39 already rejected. A v2 marketing wow-surface, not a pilot build.
3. **The Bearings Almanac** (unjudged, promising). A printed family-digital-year wall planner — September reset, exam-season sleep, summer drift-check, birthday age-up — each with a QR to the current reset. Compliant form: generic per age band, no child data printed, dated, QRs resolve to kept-current pages so the paper can't enshrine stale advice. Test as a £149-tier/gift keepsake once the Posted Plan has proven the print-and-post pipeline.

---

## 5. The kill list — dead on guardrails, do not reinvent

- **The Panic Line** — a same-day "talk me down" call IS a hotline drifting into advice-in-crisis, and on-demand availability is unstaffable at 10 hrs/week; the panic moment is served compliantly by the Worry Brief.
- **The Standing Line** — a live members' line at 9pm *guarantees* crisis calls (grooming, sextortion, self-harm) taken by one non-clinical human; breaches signpost-only and unbounded labour twice over. Only salvage: an optional voice-note *reply* on the One Question credit.
- **The Panic Button That Does Nothing** — to a buyer, a journalist and a court of public opinion, a physical panic button is a crisis-response device regardless of the disclaimer; plus a hardware rabbit hole. The fridge card already covers it.

**Killed on judgement (not guardrails) — equally, don't reinvent:** Whisper as a headline "11pm co-pilot" (ship only as a quiet, static "If something's gone wrong: where to go" signpost page inside the plan — marketing it as crisis support is a promise the product is forbidden to keep); the Reviewer's Doorstep Visit (DBS/insurance/lone-worker reality; the fix dissolves it into the £149 call + Posted Plan); the Grandparents' Handbook as a SKU (it's more content — the thing files 95–97 forbid; keep one large-type "for the other grown-ups" printable inside the £99 deliverable instead); the Readiness Streak (a guilt mechanic on a fear-adjacent brand; keep a plain "plan last reviewed: [month]" stamp); the Ceremony Kit as a standalone (thin-to-negative margin; fold into the Handover Box); a £49 standalone setup call (guts the £149 tier); and any flavour of **free human review given away** — gifted places, second households, renew-and-gift — the giftee gets library + scripts, and the human review unlocks only when they pay. File 96 says protect renewal economics fiercely; unpaid reviews are how they die.

---

## 6. What not to do — the standing rules

1. **No more content volume.** Every idea that boiled down to "another guide, nicer" scored bottom of the list. The premium is licensed by a person, a proof and a promise; pages re-anchor us to the £0–25 shelf where Internet Matters wins for free.
2. **Nothing that re-anchors to the cheap shelf.** A beautiful printed guide is still a guide. Verdicts, scores and app ratings are free-substitutable. The artefacts we post must signal *expert attention*, not content.
3. **No unscalable founder hours inside the £99 base.** Every human touch ships with a pre-committed scale graduation (founding cohort → £149 tier) and a hard cap. The 10 hrs/week is a guardrail, not a hope.
4. **No promises one person can't keep.** "Aim for 48 hours", never "within 48 hours". No same-day anything. No "whatever launched last week". A publicly broken promise costs more than the feature earns.
5. **No safety-outcome language, ever.** "Reviewed", "ready", "set up well", "plan current" — never "safe", "protected", "pass", "certified". One sloppy sentence turns a value promise into an implied safety guarantee, and that idea is dead on arrival.

---

## 7. Pilot tie-in — what ships BEFORE the pilot

Three additions, under ~20 founder-hours combined, all aimed at one thing: making the invisible human review visible at the exact moment a stranger decides whether £99 is real.

1. **Meet Your Reviewer** (~2 hrs, once). The face on the pricing page. Cheapest conversion lift available; a prerequisite for everything person-shaped.
2. **The Posted Plan with the handwritten line** (~8 hrs setup; 5–8 min/plan at pilot volume), promised on the pricing page and delivered with the voice note riding inside review time already spent. This is the proof engine — and the pilot's testimonial machine.
3. **One Question, Answered by a Human** (~5–8 hrs incl. the crisis gate: scope line, canned signpost reply, one-credit cap, 2-day SLA). The promise that justifies the shelf move, at breakage-economics cost.

If hours remain: the Whole-Household copy reframe and the Review Certificate are pure copy-and-template work that make the same pilot cohort worth more — and the certificate quietly plants the renewal date twelve months before we need it. Nothing renewal-facing has to *ship* before the pilot (the first renewal is a year away), but the profile-retention consent line must go into the privacy notice now, or the Annual Re-Review has nothing to re-open.

**The bar for everything above:** the pilot exists to earn one sentence — *"a real person looked at us and caught something I'd missed."* Every pre-pilot hour goes to whatever makes that sentence more likely to be said, unprompted, by a stranger.
