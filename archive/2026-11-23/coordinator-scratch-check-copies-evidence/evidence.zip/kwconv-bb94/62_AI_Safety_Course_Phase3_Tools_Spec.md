# AI Safety Course - Phase 3 Interactive Tools Spec

*Created 2026-06-27. Status: Phase 3 draft built from `57_AI_Safety_Course_Claim_Register.md`, `58_AI_Safety_Course_Gap_Register.md`, `60_AI_Safety_Course_G1_Breaker_Findings.md`, and `61_AI_Safety_Course_Phase2_Design_Package.md`. This is not canonical or sellable until human legal/safeguarding review clears the flagged rows and fast-moving route checks.*

## Operating Boundary

The Phase 3 tools are parent-facing course supports. They help a parent choose household clauses, practise authored scenarios, print checklists, and keep track of route-only guidance. They do not assess a child, process a child's real content, diagnose risk, identify grooming or scams, judge whether a message or image is safe, or guide a live incident. [PRI-003, PRI-004, GRM-002, VBT-004, RTE-007, GAP-007, GAP-013]

All tools must be client-side by default. They must not create child accounts, collect child names, dates of birth, school names, screenshots, uploads, voice, images, private messages, schoolwork, incident details, or open-ended descriptions of live situations. [PRI-002, PRI-003, PRI-004, GAP-013]

If a parent indicates that something is already happening, the tool stops the educational flow and points to the ungated emergency/routing page or a printed routing card. The tool must not ask follow-up questions about the incident. [RTE-001, RTE-002, RTE-003, RTE-004, RTE-005, RTE-006, RTE-007]

## Build Priority

| Priority | Tool | Build decision | Reason |
|---:|---|---|---|
| 1 | Family AI Safety Agreement Builder | Build first | Lowest risk and highest practical value: tick/edit/print only, no child content, no judgement engine. [PRI-004, RTE-007] |
| 2 | Scenario Trainer | Spec now, build after safeguarding review | Useful for rehearsal, but must use authored scenarios only and deterministic feedback. [VBT-004, SMI-004, GRM-002] |
| 3 | Readiness Self-Check | Spec now, build after wording review | Can guide a parent to course assets, but must avoid diagnosis, score, or child profile. [AIC-003, ORW-004, GAP-007] |
| 4 | Stay Current Update Stream | Spec now, build only with owner/cadence | Route, legal, platform, and policy details can go stale without standing review. [RTE-008, GAP-014, GAP-016] |
| 5 | Routing Card Generator | Keep as printable/template first | Routing is important but high liability; start with a reviewed static card and route links. [RTE-001, RTE-007, RTE-008] |

## Shared Product Rails

### Allowed Interactions

- Select an age band.
- Tick pre-written clauses.
- Edit pre-written household wording.
- Add a household rule that is not framed as incident detail.
- Choose from pre-written scenario responses.
- Print or save a browser-generated PDF.
- Link to the course module, asset, or route page that matches an authored scenario.

### Disallowed Interactions

- Upload, paste, summarise, or describe a real message, image, voice note, screenshot, prompt, schoolwork item, private chat, or incident. [PRI-002, PRI-003, VBT-004, GAP-013]
- Use AI to judge whether a real case is grooming, fraud, deepfake, coercion, self-harm, or safe. [GRM-002, VBT-004, GAP-007]
- Ask for a child name, date of birth, school, account handle, location, contact detail, or identifying event detail. [PRI-003, PRI-004]
- Present a score, risk band, diagnosis, profile, or prediction about a child. [AIC-003, ORW-004, GAP-001]
- Tell a parent to save, screenshot, copy, download, forward, or ask a child to resend suspected nude or sexual images of under-18s. [SMI-002, SMI-006, GRM-004, GAP-015]
- Give platform-specific settings instructions unless they come from the living update process and have been re-checked. [GAP-006, GAP-008, GAP-014]

### Required Footer On Every Tool

Suggested wording:

> This tool is for education and planning. It does not assess a child, judge a live situation, monitor anyone, or guarantee outcomes. If something is happening now, stop using the tool and use the emergency/routing page.

Add the under-18 image carve-out wherever image pressure or sexual/nude-image risk appears:

> Do not save, screenshot, copy, download, forward, or ask a child to resend suspected nude or sexual images of under-18s. Use the routing card instead.

[GAP-001, SMI-002, SMI-006, GRM-004, RTE-007, GAP-015]

## Tool 1: Family AI Safety Agreement Builder

### Purpose

Turn the course into a short household agreement that a parent can adapt and print. It should feel practical rather than punitive: allowed uses, ask-first uses, never-enter private information, human-check moments, stop-and-route moments, and a review date. [PRI-002, VBT-001, AIC-005, RTE-007]

### User Flow

1. Parent selects age band: 9-11, 12-14, or 15-17 for the AI safety course. If the wider Bearings product keeps 5-10, 11-12, 13-14, 15-16, and 17-18 bands, map them into the closest course band internally.
2. Tool pre-ticks a small set of clauses for that band.
3. Parent can tick/untick clauses and edit wording.
4. Parent can add a household-only rule, with placeholder text that warns against entering names, school, account handles, or incident detail.
5. Tool renders a clean printable agreement.
6. Print/save-to-PDF uses the browser print function. No server call is made.

### Clause Menu

| Clause group | Default clause direction | Age adaptation | Claim IDs |
|---|---|---|---|
| Private stays private | No private information goes into AI tools without adult review. | 9-11: parent chooses and sits in. 12-14: co-set ask-first categories. 15-17: consent, accountability, and settings checks. | PRI-001, PRI-002, PRI-005 |
| Tool, not person | AI is not a private friend, therapist, judge, or secret-keeper. | 9-11: no open-ended companion chat. 12-14: secrecy and late-night boundaries. 15-17: wellbeing and trusted-person routes. | AIC-001, AIC-003, AIC-004, HAW-002 |
| Verify before trust | Check source, date, evidence, and consequence before believing, sharing, buying, submitting, or acting. | 9-11: ask an adult before sharing. 12-14: check links and claims. 15-17: inspect primary sources for schoolwork and decisions. | VBT-001, VBT-002, HCM-004 |
| Schoolwork ask-first | School policy and assessment rules come first; try first, ask before assessed work, and do not submit hidden AI-authored work as your own. | Strongest for 12-17; simple homework practice wording for younger children. | ORW-001, ORW-003, VBT-002 |
| Synthetic-media and image risk | Pause before forwarding convincing media; no mechanism/how-to; no save/screenshot/copy/download/forward for suspected under-18 sexual images. | 9-11: tell-a-grown-up. 12-14: peer pressure and group-chat wording. 15-17: consent, coercion, and route-now wording. | SMI-001, SMI-002, SMI-004, SMI-006 |
| Contact and pressure | Unknown person plus secrecy, pressure, gifts, platform switching, threats, or sexualised contact means stop and show a trusted adult. | 9-11: show an adult. 12-14: peer/group-chat scripts. 15-17: coercion, blackmail, consent, and routing scripts. | GRM-001, GRM-003, GRM-004 |
| Scams and money | Codes, logins, money, gifts, crypto, payment links, and urgent help requests are ask-first and check-separately. | Strongest for 12-17, but usable for all. | SCF-001, SCF-002, SCF-003 |
| Stop and route | If a tool encourages secrecy, sexualised interaction, self-harm, eating-disorder content, threats, coercion, or isolation, stop the interaction and involve a qualified adult/service. | All bands. | AIC-005, HCM-003, RTE-007 |

### Data And Storage

- State may live in React memory only.
- No localStorage, sessionStorage, IndexedDB, cookies, analytics payloads, server writes, or network calls for clause content.
- If event tracking is needed, record only `agreement_builder_opened` or `agreement_builder_print_clicked`, with no clause text, no age band if that could be combined with household identifiers, and no custom wording.
- Print output must not include a child name field.

[PRI-003, PRI-004]

### Acceptance Criteria

- A parent can select an age band, tick clauses, edit wording, add a rule, and print.
- The default clauses include the no-private-data, tool-not-person, verify-before-trust, schoolwork, image-risk, contact-pressure, scam, and stop-and-route categories.
- The builder makes no network calls and uses no browser storage.
- The builder includes the under-18 image carve-out.
- The page is gated with library access, but the emergency/routing link remains ungated.

## Tool 2: Scenario Trainer

### Purpose

Let a parent rehearse calm decisions using pre-written, non-explicit scenarios. The trainer helps the parent practise pausing, checking, choosing a household response, and routing where needed. It does not evaluate real cases. [SMI-004, VBT-004, GRM-002, RTE-007]

### Scenario Set

| Scenario family | Example direction | Response lesson | Claim IDs |
|---|---|---|---|
| Confident but false AI answer | AI gives a plausible homework fact with a made-up source. | Open the source, check date/evidence, school policy first. | HCM-001, VBT-001, VBT-002, ORW-003 |
| Private disclosure into chatbot | Child wants to paste a friendship problem or family detail. | Private stays private; move emotional worries to trusted people. | PRI-001, PRI-002, AIC-002 |
| Companion attachment | Child describes an AI character as the only one who understands them. | Tool-not-person script; watchpoint conversation, not diagnosis. | AIC-001, AIC-003, HAW-002 |
| Fake media shock | A convincing image, voice, or video appears in a group context. | Pause before forwarding; source/context checks; route if sexual, threatening, or coercive. | SMI-001, HAW-003, RTE-007 |
| Image pressure | Someone pressures a young person around an intimate image. | Reassure, do not blame, no save/screenshot/copy/download/forward, route. | SMI-002, SMI-006, GRM-004, GAP-015 |
| Unknown contact pressure | Unknown person asks to move apps, keep secrets, or accept gifts. | Unknown person plus secrecy/pressure means show an adult; route if sexual or threatening. | GRM-001, GRM-003, RTE-002 |
| Urgent money/code request | A familiar-looking account asks for money, code, gift card, or login. | Verify outside the thread; Report Fraud/Police Scotland route where relevant. | SCF-001, SCF-002, SCF-003, RTE-005 |

### Interaction Rules

- Each scenario has three to five authored choices.
- Feedback is deterministic and cites the course habit and route.
- No free-text input.
- No "you got it right/wrong" scoring. Use "stronger next step" language.
- If an authored choice selects "this is already happening", show route-only guidance and end the scenario.
- No explicit sexual content, tool names, prompt patterns, or how-to detail. [SMI-004]

### Acceptance Criteria

- Scenario content is stored as static structured data with Claim IDs.
- No route depends on AI inference or user-provided incident text.
- The trainer does not produce a child risk score, parent score, or safety verdict.
- Safeguarding review clears every scenario before release.

## Tool 3: Readiness Self-Check

### Purpose

Help a parent decide which course module or asset to use next. This is a navigation tool, not a risk assessment or outcome claim. [GAP-001, GAP-007]

### Flow

1. Parent answers short multiple-choice prompts about household habits, not child incidents.
2. Tool maps answers to recommended modules/assets.
3. Result language uses "start with" and "review next", not "high risk", "low risk", "safe", or "unsafe".
4. Any "already happening" answer ends the check and routes out.

### Inputs

Allowed prompts:

- "Which age band are you planning for?"
- "Which household rule is clearest today?"
- "Which topic do you most want to settle this week?"
- "Which asset would help you finish a conversation?"

Disallowed prompts:

- "Paste the message."
- "Describe what happened."
- "Upload the image."
- "What is your child's name/school?"
- "Has your child been groomed/scammed?"

[PRI-003, PRI-004, GRM-002, VBT-004, GAP-013]

### Output Pattern

| Output | Required wording |
|---|---|
| Recommended module | "Start with Module X because it matches the household rule you want to set." |
| Recommended asset | "Print or complete Asset Y next." |
| Route-out | "If this is already happening, stop the check and use the routing page." |
| No-result state | "Pick one rule to settle first; the agreement builder is the simplest next step." |

### Acceptance Criteria

- No scores, risk bands, child profiles, or diagnostic labels.
- Results link only to course assets, modules, or the routing page.
- Inputs are selections only.

## Tool 4: Stay Current Update Stream

### Purpose

Maintain a reviewed record of legal, platform, policy, route, and AI-behaviour changes that affect course assets. The stream is a human-reviewed update layer, not automated monitoring or bespoke advice. [RTE-008, GAP-014, GAP-016]

### Content Model

Each update should include:

- `title`
- `date_checked`
- `owner`
- `change_type`: route, legal, schoolwork, platform, policy, course wording, or asset wording
- `affected_assets`
- `claim_ids`
- `source_ids`
- `review_status`: draft, legal review, safeguarding review, approved, retired
- `parent_summary`
- `internal_note`

### Workflow

1. Founder or reviewer records a candidate update.
2. Route/legal/safeguarding-sensitive updates remain draft until human review.
3. Approved update changes the relevant module, asset, and route card.
4. Monthly briefing summarises only approved updates.
5. Retired or superseded updates remain visible internally for audit.

### Acceptance Criteria

- No update goes public without an owner, date checked, source IDs, and Claim IDs.
- Route and legal updates require human review before parent-facing publication.
- The briefing sender does not imply monitoring, bespoke advice, or guaranteed currency.

## Tool 5: Routing Card Generator

### Purpose

Give parents a reviewed route-only reference that is printable and easy to find. This starts as a static asset. A configurable generator is deferred until route ownership and review cadence are confirmed. [RTE-001, RTE-007, RTE-008, GAP-011, GAP-016]

### Static Card Sections

| Concern type | Route wording |
|---|---|
| Immediate danger or crime in progress | 999. Non-emergency police contact is 101. [RTE-001] |
| Online sexual abuse, grooming, or online sexual communication with a child | CEOP, scoped to that concern type. [RTE-002] |
| Nude images of under-18s shared online | Under-18 Report Remove route where eligible; check current eligibility before launch. [RTE-003] |
| Child support | Childline. [RTE-004] |
| Adult worried about a child | NSPCC helpline. [RTE-004] |
| Fraud or cyber-crime | Report Fraud in England, Wales, and Northern Ireland; Police Scotland 101 in Scotland; 999 if immediate danger. [RTE-005] |
| School-linked safeguarding concern | School DSL or equivalent safeguarding route. [RTE-006] |

### Tool Boundary

The card may help parents choose a service category. It must not ask for facts, decide the correct legal category, or tell the parent what to preserve in a live case. [SMI-003, GRM-002, RTE-007, GAP-015]

## Rejected Tool Ideas

| Rejected idea | Reason |
|---|---|
| Paste-a-message grooming checker | False reassurance and child-content processing risk. [GRM-002, VBT-004, GAP-013] |
| Deepfake detector or image checker | Would invite uploads and safety verdicts; under-18 image context is legally serious. [SMI-002, SMI-003, GAP-013, GAP-015] |
| Schoolwork custody, authorship, or AI-use verdict | Would require processing a child's work and making assessment-like claims about authorship, retention, cheating, or learning. Keep schoolwork support to rules, explain-back habits, source checking, and school-policy-first language. [GAP-010, GAP-013, GAP-017] |
| AI companion audit bot | Would process private child/emotional content and could become diagnosis-like. [AIC-003, PRI-001, GAP-004, GAP-013] |
| Child-facing quiz/game | Violates adult-only and no child-facing product boundary. [PRI-003] |
| Risk score or red/amber/green child profile | Unsupported by evidence and conflicts with no diagnosis/profile boundary. [AIC-003, ORW-004, GAP-001, GAP-007] |
| Platform settings auto-walkthrough without upkeep | Platform details change quickly and require standing review. [GAP-006, GAP-008, GAP-014] |

## Build Tests

| Test | Required check |
|---|---|
| No child data | Tool schemas and components contain no child name, DOB, school, screenshot, photo, upload, or incident-detail fields. |
| No storage | Client tools that edit clauses or scenarios make no network calls and use no localStorage/sessionStorage/IndexedDB. |
| No AI judgement | Scenario Trainer and Self-Check use static authored options only. |
| No verdict wording | Results do not say "safe", "unsafe", "grooming", "scam", or "deepfake" as a verdict on user-provided material. |
| Image carve-out | Image-risk clauses and scenarios include the no-save/no-screenshot/no-copy/no-download/no-forward rule. |
| Route-out | Any "already happening" state links to `/emergency` or the route card and ends the tool flow. |
| Gating | Course tools inside `/library/**` require library access; `/emergency` remains public. |
| Content lint | Banned efficacy/fear phrases remain blocked with negation-aware exemptions. |

## Human Review Gate

Before release, human legal/safeguarding review must clear:

- All image-risk clauses and scenario feedback. [SMI-002, SMI-003, SMI-006, GAP-015]
- All contact, coercion, grooming, and blackmail scenario feedback. [GRM-001, GRM-002, GRM-004]
- All route names, phone numbers, URLs, eligibility, and jurisdiction notes. [RTE-001, RTE-002, RTE-003, RTE-004, RTE-005, RTE-006, RTE-008, GAP-016]
- The Stay Current update workflow and owner/cadence. [GAP-014, GAP-016]
- Any data/privacy statements to ensure design constraints are not represented as legal compliance conclusions. [PRI-003, PRI-004]

## Immediate Implementation Recommendation

Patch the existing `FamilyAgreementBuilder` first:

- Replace generic online-safety clauses with AI safety clauses from this file.
- Remove "do not delete anything" from image/blackmail contexts and use the no-save/no-screenshot/no-copy/no-download/no-forward carve-out.
- Keep it client-side with no network calls or browser storage.
- Add or update static tests for the no-storage rule and image carve-out.

After that, prepare the Scenario Trainer as static data only, but do not ship it until the authored scenarios clear safeguarding review.
