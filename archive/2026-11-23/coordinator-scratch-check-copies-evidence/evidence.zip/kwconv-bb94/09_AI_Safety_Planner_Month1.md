# AI Safety Planner — description + month-1 content

**The retention layer. Automated, content-and-template-driven — never "coaching", never a person on call.** This file holds: the public description page, then a complete first month of content (welcome, monthly briefing, two action plans, two conversation scripts, the editable family agreement). Enough to ship the subscription and keep a new member's first 4 weeks genuinely useful.

Framing rules carried through: education + planning + signposting only; not monitoring, crisis help, safeguarding determinations, legal/clinical advice, AI-companion features, or anything child-facing.

---

## A. Description page (public)

### The Family Safety Plan

Your report told you where to start. The Plan helps you keep going — without it becoming another thing you're behind on.

Every fortnight, one short, specific action: a ready-made conversation to have, a settings check to do, or a family agreement to update. Once a month, a calm briefing on what's actually changed in the online risks facing teenagers — so you hear it from us, in proportion, instead of from a frightening headline.

**What you get**

- A fortnightly action — small, concrete, done in 10–15 minutes.
- Ready-to-use conversation scripts (no need to find the words yourself).
- An editable family-agreement template you can revisit as your teen gets older.
- A monthly threat briefing: what changed, whether it matters for your household, and what (if anything) to do.
- An annual refresh of your readiness report.

**What it is — and isn't.** It's prevention education and planning. It is **not** monitoring or spyware, **not** crisis help, and **not** a substitute for the police, your child's school safeguarding lead, or professional advice. In an emergency we point you to the right people — we don't intervene.

**£7/month or £70/year. Cancel anytime.**

> Internal note: this is an automated content subscription. The value is the cadence, the scripts, and the briefing — not a human advising anyone. Keep all copy in the "Plan/Planner" register; never "coach".

---

## B. Welcome (sent on sign-up)

**Subject:** Welcome to your Family Safety Plan — here's how it works

Hi [FIRST NAME],

Glad you're here. The Plan is built to be easy: nothing to install, nothing to monitor, and never more than one small thing to do at a time.

Here's the rhythm:

- **Every fortnight:** one short action lands in your inbox. This week's is below — it's the most valuable conversation most families haven't had yet.
- **Once a month:** a calm briefing on what's changed.
- **Anytime:** reply to any email with a question.

Your first action is below. It takes five minutes and it's the one that matters most.

[NAME]

---

## C. Action 1 (week 1) — the conversation that protects against sextortion

**Why this one first:** of everything in online safety, this is the single conversation most linked to keeping a teenager safe — because the thing that protects them is knowing they can come to you, fast, without being in trouble. It's short. You don't need to be an expert.

**Do this — a 5-minute conversation. Pick a low-pressure moment (in the car is ideal — no eye contact needed):**

> "I want to tell you about a scam that targets people your age, so you're ready if it ever happens. Someone online — often pretending to be a teenager — gets a person to send a nude photo, then threatens to share it with everyone unless they're paid. If anything like that ever happens to you: **stop talking to them, don't pay anything, don't delete the messages, and come to me.** You will not be in trouble. We'll sort it out together — there are people whose whole job is fixing exactly this."

**The four things they need to remember:** stop · don't pay · don't delete · tell someone.

**If they ask "what would we actually do?"** — you'd report it to CEOP (ceop.police.uk/Safety-Centre), and use childline.org.uk/remove to get any image taken down. That's it. Knowing the route removes most of the fear.

*Based on National Crime Agency guidance. This reduces exposure by preparing your child — it isn't a guarantee, and it's never the young person's fault if it happens.*

---

## D. Action 2 (week 3) — lock the settings on the apps that matter

**Why:** a ten-minute settings session removes a chunk of exposure for free. Do it *together* — it's a conversation, not a raid. The goal is "let's set this up well", not "I'm checking up on you".

**The short list (do the ones that apply):**

- **Snapchat** — turn off **Quick Add**, set **Snap Map to Ghost Mode**, confirm the friend list is people they actually know. (Snapchat → Settings → privacy / Family Centre.)
- **WhatsApp** — set **Last Seen, Profile Photo and Groups** to *My Contacts*, turn on **two-step verification**.
- **Instagram/TikTok** — account set to **private**; review who can message and comment; location off on posts.
- **The phone itself** — agree it **charges outside the bedroom overnight**. This one change does a lot.
- **Gaming** — agree the rule: people met in games stay in games. No moving to other apps, no sharing socials.

**The framing line that keeps it collaborative:**

> "Let's set these up together so the app works for you and the randoms can't. Five minutes and it's done."

*These reduce exposure; they don't monitor your child or guarantee anything. Settings change — the monthly briefing flags it when they do.*

---

## E. Monthly briefing #1 (end of month 1)

**Subject:** This month in teen online safety — what changed, and what (if anything) to do

Hi [FIRST NAME],

The whole point of this briefing is to save you from doomscrolling safety news. Here's what's worth knowing this month, in proportion.

**1. AI fake images are the fastest-rising issue — and the law just caught up.**
Apps that turn an ordinary photo into a fake nude have driven a sharp rise in AI-generated abuse imagery, and new UK law now criminalises the tools themselves. *What it means for you:* your teen can be targeted without ever sending anything, so the message is "any photo can be misused, it's never your fault, and there's a route to remove it" (childline.org.uk/remove). One conversation covers it. *Source: Internet Watch Foundation; Crime and Policing Act 2026.*

**2. AI "companion" chatbots are now a recognised risk — and gaining age limits.**
Some companion apps formed unhealthy dependencies in teens and gave unsafe responses; major ones have moved to 18+ and new UK rules require it for romantic/companion bots. *What it means for you:* worth asking, lightly, whether your teen uses any "AI friend" apps — and reinforcing that an AI is not a friend or a therapist. A fortnightly action will give you the script. *Source: Online Safety Act / 2026 update.*

**3. Nothing you need to panic about.**
No new emergency, no reason to change anything dramatically. The under-16 social-media rules being discussed in the news are **not yet in force** — you'll hear it here first when they are.

**Your next action** (in two weeks): the "AI is not your friend" conversation. Nothing to do until then.

[NAME]

*General guidance from UK authorities, not a prediction or a safeguarding assessment. Emergency signpost: [LINK].*

---

## F. Conversation scripts pack (members' library — starter set)

Short, copy-able openers. Members get one per fortnight; here are the first set.

**Scams & money mules**
> "Quick thing — if anyone ever offers you easy money for letting them use your bank account, that's a real crime called money muling, and it can wreck your own finances and record. And any 'job' that asks you to pay money upfront is a scam. If you're ever unsure about one, show me — no judgement."

**AI is not a friend or therapist**
> "Some apps are AI chatbots designed to feel like a friend or even a therapist. They're clever, but they're not a person and they don't actually care about you, and sometimes they give bad advice. Use them for fun or homework if you like — but for anything that's actually upsetting, come to me, or there are real people at Childline. Deal?"

**Moving to another app (grooming red flag)**
> "One rule that keeps you safe: if someone you've met in a game or online ever wants to move the chat to a private or disappearing-message app, that's a red flag — even if they seem nice. You don't have to be rude, just tell me. People who are who they say they are don't need to hide the conversation."

**The 'no judgement' baseline (use early and often)**
> "Whatever happens online, you can tell me and you won't lose your phone for being honest. I'd always rather know."

---

## G. Editable family agreement template

A starting point to adapt **together** — agreements work better than rules imposed top-down. Cross out, change, and re-sign as your teen gets older.

> **Our Family Online Agreement**
> *Agreed [DATE]. We'll review it again in 6 months.*
>
> 1. Phones charge **[downstairs / outside bedrooms]** overnight from **[time]**.
> 2. People we meet in games or online **stay** in games or online — no moving to private apps, no meeting up, no sharing personal details.
> 3. New apps get a **quick chat before** they're downloaded — not to say no, just to set them up well.
> 4. **No judgement rule:** if something scary, weird, or embarrassing happens online, you can tell [parent] and you won't be in trouble or lose your phone for being honest.
> 5. We keep accounts **private** and check settings together every few months.
> 6. If anyone ever pressures you for a photo or threatens you: **stop, don't pay, don't delete, tell [parent].**
> 7. [Your own rule — add one your family cares about.]
>
> Signed: ____________ (young person)   ____________ (parent/carer)

*This agreement is a conversation tool, not a contract or a safeguarding measure.*

---

## Cadence summary (for the automation later)

| When | Send |
|---|---|
| Sign-up | Welcome (B) + Action 1 (C) |
| Week 3 | Action 2 (D) |
| End month 1 | Monthly briefing #1 (E) |
| Fortnightly after | One script from the library (F), rotating |
| Month 12 | Annual report-refresh offer |

Months 2–3 reuse the same shape — keep building the library two scripts ahead of the cadence. Do not automate sending until manual sends have proven members actually open and act (see the tracker, `12`).
