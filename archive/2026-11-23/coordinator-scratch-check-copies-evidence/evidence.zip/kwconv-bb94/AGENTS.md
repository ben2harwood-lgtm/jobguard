# AI Safety Build

This project is a strategy, content, and lightweight web prototype workspace for an AI safety/readiness offer aimed at families and schools.

## Working Principles

- Treat `21_MASTER_BUILD_SPEC.md` as the primary build/spec reference unless Ben says another file supersedes it.
- Preserve cautious safety language. Do not introduce guarantees such as "keeps children safe", "fully compliant", or "prevents harm" unless the surrounding document already makes and justifies that exact claim.
- Keep parent/school-facing copy practical, specific, and non-alarmist.
- Prefer small, reviewable edits to existing Markdown/HTML files.
- Do not publish, send, upload, or share project materials without explicit instruction.

## Important Files

- `00_Execution_Plan_and_Go-NoGo.md` - operating plan and decision gates.
- `21_MASTER_BUILD_SPEC.md` - main build specification.
- `22_Build_Plan_Audit.md` - audit notes and risks.
- `23_Landing_Page_v2.html` - current landing page prototype.
- `24_NoCode_Launch_Runbook.md` - launch/runbook plan.
- `12_Funnel_and_Decision_Gate_Tracker.xlsx` - spreadsheet tracker.

## Local Notes

The folder was originally worked on through Claude Code at:

`/Users/benharwood/Claude/Projects/AI Safety Build`
