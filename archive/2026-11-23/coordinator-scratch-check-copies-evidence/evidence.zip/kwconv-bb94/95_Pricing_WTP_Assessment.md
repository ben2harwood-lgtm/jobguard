# 95 — Pricing & Willingness-to-Pay Assessment: Is £99 the Right Full Price?

**Date:** 3 July 2026 · **For:** Ben · **Status:** Decision memo, desk research + repo evidence
**Question asked:** "Is £99 the right full price — will people pay that for what we offer?"
**Method:** Four research legs — UK price-comparables map, willingness-to-pay evidence review, adversarial three-way argument (for / too high / too low) grounded in the actual repo, and a pilot test design. Every claim is sourced or explicitly flagged as inference. Where the evidence simply does not exist, this memo says so rather than guessing.

---

## 1. Direct answer

**Honest headline: nobody can prove £99 from a desk.** There is no published UK study of what parents will pay for personalised online-safety *guidance* (as opposed to monitoring software). That category barely exists as a paid category yet — which is both the opportunity and the risk. The only thing that settles this question is the founding pilot (Section 5). Everything below is the best available read, not certainty.

With that said, the evidence supports a clear two-stage answer:

**£99 is defensible in principle but over-reaches on evidence for what ships today.**

- **What ships today** — a genuinely excellent ~51-item curated library, conversation scripts, Family Agreement builder, and a *described but not yet evidenced* human-review-and-plan service (no named reviewer, no testimonials, no turnaround commitment, no delivered-plans count; and in the current codebase the post-purchase diagnostic pipeline is not yet built — `app/api/quiz/route.ts` stores `answers_jsonb: {}`, i.e. the pre-sale quiz answers are discarded and there is no review queue or plan generator). Price follows what a buyer can *verify at checkout*, and today that is the library plus a promise. **Realistic band today: £49–£79.** The current £79 founding price is the honest top of that band, and it needs the review genuinely delivered by hand to earn it.
- **After the value-visibility fixes** — reviewer named with credentials, a stated turnaround SLA ("reviewed plan within N working days"), the update changelog published publicly, the library counted correctly on the pricing page (it currently *under*-claims: the page says 10 platform guides and 12 playbooks; the repo ships 19 and 24), 3–5 real testimonials, and the diagnostic→review pipeline actually wired. **At that point £99 is comfortably defensible, and £129–£149 becomes the credible growth target**, because the right comparator shifts from "safety app" to "parenting consultant" (see Section 2).

**The core finding of all four research legs converges on one sentence: the price is not the problem; the proof is.** The £99-justifying half of the offer (human review + personalisation) is currently invisible at the point of sale, while the half the buyer *can* see (the library) has strong free substitutes. Fix the visibility and £99 flips from over-reach to arguably underpriced.

---

## 2. The market map — where £99 one-off actually sits

All prices verified July 2026 unless flagged. Full sourcing in the research legs; key anchors below.

### The four shelves a parent might place Keepwise on

| Shelf | What it is | Price band | Read on £99 |
|---|---|---|---|
| **Free advice** (Internet Matters, NSPCC, Common Sense Media, gov.uk, Ofcom, Childnet) | Age-band guides, per-app setting walkthroughs, free parent courses, printables — **and Internet Matters' free "My Family's Digital Toolkit", which is personalised and includes ongoing updates** ([internetmatters.org/digital-family-toolkit](https://www.internetmatters.org/digital-family-toolkit/)) | **£0** | The real competitor. The information itself is a commodity priced at zero. |
| **Monitoring apps** (a different job — surveillance/filtering) | Qustodio Basic £43.95/yr, Complete £75.95/yr ([qustodio.com](https://www.qustodio.com/en/premium/)); Norton Family ~£29.99/yr; Kaspersky Safe Kids ~£20.99/yr; Bark $99–$148/yr (US); Google Family Link **free** | **~£30–£76/yr** UK mainstream | £99 one-off is priced *above a full year* of the best-known app that visibly "does something ongoing". This is the comparison a stressed parent instinctively makes, even though it is the wrong category. |
| **Digital-parenting courses & info-products** | Parent Zone "Parenting in the Digital Age" course **£6.99+VAT** ([parentzone.org.uk](https://parentzone.org.uk/purchase-parenting-digital-age-here)); NSPCC online-safety training ~£30; ebooks/toolkits £8–£25 | **£7–£30** | The most damaging comparison on the map. A parent who has seen the £6.99 Parent Zone course experiences £99 as 14× "the course from the people who do this". One-off digital content tops out around £25. |
| **Human expert help with a specific parenting worry** | Parent coaching £45–£180/hr (Anita Cleare £180/hr — [anitacleare.co.uk](https://anitacleare.co.uk/get-parenting-support/parenting-coaching/); directory average ~£82/hr); sleep-consultant packages £250–£500; some consultants email a bespoke plan after the call ([bespokefamily.co.uk](https://www.bespokefamily.co.uk/parent-consultations)) | **£50–£500** | The only shelf where £99 looks *cheap*. A human-reviewed written plan + 51-item library + a year of updates undercuts a single £180 coaching hour. |

### The positioning read

**The anchor parents will reach for by default is the free tier plus the ~£30–£76/yr apps. The anchor the product needs them to use is the £82/hr coach or £250+ consultant.** £99 only reads as fair when the parent reframes the purchase from *"buy a guide"* (market price: £0–£25) to *"pay a human expert to help me with a specific worry about my child"* (market price: £50–£500). The entire premium therefore rests on making human review + personalisation + kept-current feel like **expert time bought**, not **content licensed** — because on a pure content basis the market has already priced this near zero.

Note also: £99 (~$125) sits in the completely normal $97–$197 band for self-serve info-products globally, and productised-service norms say a single price point forgoes the close-rate lift of tiering. The price is not odd internationally; it is odd *for this UK category*, because the UK category barely exists.

---

## 3. The single biggest demand risk — and how comparable products beat it

**The risk: the concern-to-payment gap.** Parental worry is near-universal and well-evidenced (Ofcom 2025: 68–79% of UK parents worried on specific vectors — [Ofcom Children and Parents 2025](https://www.ofcom.org.uk/media-use-and-attitudes/media-habits-children/children-and-parents-media-use-and-attitudes-report-2025); 180,000+ families signed the Smartphone Free Childhood pact). But **no UK study links that worry to spending on advice** — this is a genuine evidence hole, not an oversight. And the strongest adjacent data point cuts against us: a 2025 US survey found 80% of Gen Z parents fear AI-enhanced threats to their kids, yet 37% still give full autonomy or only light monitoring ([Bitwarden/BusinessWire](https://www.businesswire.com/news/home/20251014411599/en/)). Stated concern demonstrably does not convert into protective effort, let alone payment. Worry is universal *and free to hold*; credible help is free to get; there is no evidence UK parents yet treat online-safety **advice** as a paid category at all.

So the make-or-break question is not the number on the button. It is whether the product converts abstract anxiety into a purchase **before the parent clicks over to Internet Matters and solves the felt need for £0**.

**How comparable products beat "why pay when it's free":** the membership/curation literature is consistent — when information is free, people pay for *curation, personalisation, convenience, time saved, and a trusted human/expert layer*. That maps exactly onto Keepwise's four pillars (human review, personalised plan, curated library, staying current) — the theory genuinely supports the premium thesis. Two important caveats: (a) that literature describes retaining warm members who already value the niche, not converting cold parents on a landing page; and (b) the tactical evidence says a **visible money-back guarantee** is the single strongest conversion lever for anxiety-priced one-off purchases (one cited test: +21% sales, +6.5% net after refunds). Keepwise currently offers no guarantee — for a £99 trust-me purchase from an unknown brand, that is a gap worth closing before any price rise. (Education-sector chargeback/refund norms: budget for ~1% chargebacks and materially higher refund rates; a guarantee formalises what card networks will grant anyway.)

---

## 4. The three-way case, and the verdict

### The case FOR £99
The thing being sold is a **decision, not a document** — sequence and triage under the family's own constraints ("what do I do *first* for *my* 13-year-old"), which no free source provides. The **human review is the one feature neither the free tier nor any app can copy** — Internet Matters' free toolkit is algorithmic; Keepwise's differentiator is a person checking the plan for age-fit, gaps and proportionality. Benchmarked against the human shelf (£45–£180/hr coaching, £250–£500 consultant packages), £99 for a reviewed plan *plus* the library *plus* a year of updates undercuts the nearest human comparator by half. The playbook set is genuinely differentiated on the 2024–26 threat surface (AI nudify, sextortion, AI companions, money-muling) that charity libraries cover thinly. **This case is strong — if and only if the review is delivered and visible.**

### The case AGAINST £99 (too high)
The premium engine is **not evidenced at the point of sale — and today, not built in code**. The buyer sees a sample plan for a fictional child and a prose description of a review; no reviewer, no testimonials, no SLA, no guarantee, no delivered count — and the diagnostic answers are currently discarded (`answers_jsonb: {}`). Meanwhile the part the buyer *can* see overlaps heavily with free content, and the free tier is now *also personalised with updates* (Internet Matters toolkit). The honest framing is brutal: **the buyer is being asked to pay £99 for one feature — human review — because everything else in the bundle has a credible free substitute, and that one feature is invisible and unproven.** The (correct) ethical boundaries also strip out the visible ongoing activity parents intuitively pay apps £30–£76/yr for. On verifiable-at-checkout value, this is a £39–£59 product today.

### The case it's TOO LOW
If the human review is real, £99 **one-off, never renewing** is structurally underpriced. 30–45 minutes of skilled review is worth £30–£90 of labour alone at coaching rates; bundling it with the library and a year of maintenance for a single £99 makes the human tier thin-to-negative margin. Parents already pay £180 for one coaching hour that ends with an emailed plan; the Concierge tier "from £650" proves the founder already knows human attention commands multiples of £99. With the reviewer named, an SLA stated, the changelog public, the library correctly counted (19 guides / 24 playbooks, not 10 / 12) and a handful of testimonials, **£129–£149 is comfortably defensible** — still a fraction of one coaching hour.

### Verdict
**Keep £79 founding now. Do not raise the standing price to £99 in practice until the value-visibility fixes land. Once they land, £99 is correct and £129 is the tested next step.** The three cases are not actually in conflict: they describe the same product at different levels of *proof*. The single highest-leverage move available is not a price change in either direction — it is building and evidencing the review pipeline, so the buyer is shown the £99-justifying half of the product instead of the commoditised half.

---

## 5. The founding pilot — price, questions, decision rule

**Frame honestly: 5 warm buyers cannot prove a price; they can only disqualify one.** Design the pilot to fail loudly. (Van Westendorp needs ~30+ respondents to produce intersecting price lines; at n=5 we borrow its four *questions* as a conversation script, nothing more.)

### Recommended pilot pricing
Run a small split under founding-tier cover, with each tier genuinely different so no two friends pay different prices for the identical thing:

| Buyers | Price | Framing |
|---|---|---|
| 2 | **£79** | Founding rate, self-serve |
| 2 | **£99** | Founding rate (the real target) |
| 1 | **£129** | Founding rate + 20-min live setup call |

Fallback if the split feels dishonest: anchor all five at **£99 founding (was £149)** and rely entirely on the before-questions and decline script below. Defensible for a solo founder selling into his own network; you lose the conversion-cliff read but keep total integrity.

### The questions (verbatim)

**BEFORE any price is mentioned** (once you say £99, their honest number is gone) — describe the full product, then:
1. "At what price would this feel so cheap you'd worry it's not any good?"
2. "What price would feel like a genuine bargain — an easy yes?"
3. "What price would start to feel expensive — you'd still consider it but think about it?"
4. "At what price would it be so expensive you definitely wouldn't buy?"
5. **The one that does the most work:** "What would have to be true about it for £150 to feel worth it to you?" (Their answer names which pillar — review / personalisation / curation / currency — actually carries the premium in their head.)

Read the answers as five individual price corridors (bargain → getting-expensive), not an average. Check whether £99 falls inside most corridors.

**AFTER purchase:** "What did you expect to pay before I told you? What would have felt too expensive?"
**AT 2 WEEKS' use:** "Was it worth what you paid? Would you have paid more? What would you tell another parent it's worth?"

**ON EVERY DECLINE** (a silent no is wasted signal): "Totally fine — this helps either way. Is it the *price*, or does the *thing itself* not feel like something you need? If it were half the price, would you have said yes?" Classify every no as **price / value / timing**. Only *price* declines count toward a cut; "I'd just use the free stuff" is a positioning problem a discount won't fix; "no specific worry yet" is a trigger-timing problem, not a price signal.

### Decision rule (signal, not proof)
- **KEEP £99** if ≥3 of 5 convert, at least one converts at £99+ without a price objection, and post-purchase expected-price answers mostly land ≥£99.
- **RAISE (test £129–£149 on the *next* cohort)** if 4–5 of 5 convert with visible ease, nobody flinches, and before/after numbers cluster above £99.
- **DROP** if ≥3 of 5 declines are price declines (half-price-would-flip), or ≤2 convert *and* the post-use verdict is "not £99-good / mostly free elsewhere". Set the new price at the modal "bargain" answer from the before-questions — likely £49 or £69 (£69 lands tellingly on Qustodio Complete's annual price, a number the market already accepts).
- **AMBIGUOUS (the likely real outcome):** hold £99 as list, keep £79 founding live, expand to n=10–15 before any permanent change.

**The tell to watch for:** if buyers convert but the value they name back is "cheaper/easier than the free stuff" rather than "the human review and my plan", the product sold on convenience — and convenience is a race to the bottom against £0. That is the difference between a £99 product and a £39 one.

---

## 6. How this feeds the F21 ladder decision (register 94)

F21 flags two mutually exclusive ladders live at once: **(A)** the 90/91/93 ladder — System £99 *founding* (£129 later) + AI Lab £49 + £129 founding bundle — versus **(B)** the shipped V3 canon — System £99 standard / £79 founding, no AI Lab, no bundle. This memo bears directly on that choice:

1. **The evidence supports Option B for the pilot.** Today's verifiable value sits at £49–£79 (Section 1); £79 founding / £99 standard is exactly the honest shape of that finding. Option A's "£99 founding, £129 later" asserts a price the desk research calls *unproven-to-optimistic for what ships today* and stakes it as the *discounted* tier — the wrong side of the evidence. Adopt B, stamp 90 line 205 / 91 line 93 as superseded on price, and sweep the surfaces listed in F21 so £79/£99/£129 each mean one thing everywhere.
2. **But Option A's ladder is the right *destination*.** Section 4's "too low" case shows £99-standard-plus-£129-growth is where a *proven* human-reviewed service belongs. The pilot decision rule (Section 5) is precisely the mechanism that authorises moving from B's numbers to A's: a RAISE outcome plus the value-visibility fixes landing (reviewer named, SLA, public changelog, corrected library counts, testimonials, wired diagnostic pipeline) is the trigger to re-run the F21 decision with A on the table.
3. **Whatever is chosen, fix the founding-label integrity first.** F23's finding (mockups labelling the standard £99 as "founding") is the same defect this memo warns about commercially: for a trust-is-the-product brand, a scarcity claim that isn't real is worse than a £20 pricing wobble. The founding discount must be genuinely founding — it is also the experimental cover the pilot split relies on.
4. **Record the outcome in decision log 88**, per F21's own instruction — this memo is an input to open decision 3 in file 93, not a parallel decision channel.

**Bottom line for F21: pick ladder B now, run the pilot at £79/£99/£129 as designed in Section 5, and treat ladder A as the post-proof ladder you graduate to — on pilot evidence, not on hope.**

---

## Confidence and sourcing notes

Bolded prices with vendor URLs were verified July 2026. Flagged as **inference, not fact**: the £39–£69 "safest tested band" from the WTP leg; Etsy/Kindle price bands; USD→GBP mental conversions; tutoring rates; Google Family Link being free (established fact, not re-verified this session); Kidscape and Safer Online course prices (genuinely unpublished). The repo evidence (discarded diagnostic answers, undersold library counts, no review pipeline) is direct observation of `app/api/quiz/route.ts`, `app/pricing/page.tsx`, and `content/` as of commit c80a3d8; it describes what *ships in code*, not necessarily Ben's manual fulfilment intent. No published UK willingness-to-pay study exists for this exact category — every recommendation above should be treated as a hypothesis the pilot tests, not a conclusion it decorates.
