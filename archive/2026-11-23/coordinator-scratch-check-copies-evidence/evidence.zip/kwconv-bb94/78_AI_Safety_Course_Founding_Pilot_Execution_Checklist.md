# AI Safety Course - Founding Pilot Execution Checklist

*Created 2026-06-27. Status: operational checklist for getting from draft course package to a small founding pilot. This assumes AI-assisted pre-review first and paid professional sign-off after real demand signal or before broader release.*

## Rule Of The Pilot

Small, manual, cautious. Do not scale, advertise widely, or publish high-risk tools before review gates are clear.

## Step 1 - Run AI Review

- [x] Send `70_AI_Safety_Course_Legal_AI_Review_Brief.md` and `71_AI_Safety_Course_Safeguarding_AI_Review_Brief.md`, with pilot files 72-80, to a combined external/cross-model AI reviewer.
- [x] Save the raw external AI review in `83_AI_Safety_Course_Claude_Pilot_Review_Findings.md`.
- [x] Record final patch status in `73_AI_Safety_Course_PreRevenue_AI_Review_Findings.md`.
- [x] Patch all blocker findings.
- [ ] Patch all high findings or remove affected material from pilot scope.
- [ ] Re-run content lint and guardrail scans.

Stop if:

- any under-18 image wording issue remains unresolved;
- any route-out issue remains unresolved;
- any material asks for child PII or incident detail;
- any copy implies formal legal/safeguarding review or expert approval.
- first-sale terms, privacy, cancellation, refund, or data-protection basics are missing.

## Step 2 - Lock Pilot Scope

Pilot includes:

- [ ] Module 1: The AI Safety Map.
- [ ] Module 2: Private Stays Private.
- [ ] Module 3: Tool, Not Person.
- [ ] Module 4: Verify Before Trust.
- [ ] Four Habits card.
- [ ] Private Stays Private card.
- [ ] Tool, Not Person script.
- [ ] Verify Before Trust sheet.
- [ ] Schoolwork Ask-First sheet.
- [ ] Family AI Safety Agreement starter.
- [ ] Pilot Boundary Card.

Pilot excludes:

- [ ] Scenario Trainer.
- [ ] Readiness Self-Check.
- [ ] Printable Routing Card.
- [ ] Full synthetic-media/image-risk module.
- [ ] Platform-specific current settings walkthroughs.
- [ ] Any review of real messages, screenshots, images, schoolwork, prompts, or incidents.

## Step 3 - Prepare Sales Surface

- [ ] Convert `76_AI_Safety_Course_Founding_Pilot_Sales_Page_Copy.md` into a draft page or email.
- [ ] Add emergency signpost link after line-by-line route verification.
- [ ] Add buyer notice exactly or more conservatively.
- [ ] Add first-sale notice: terms, privacy, refund/cancellation wording, and any required digital-content acknowledgement.
- [ ] Fill all placeholders in `86_AI_Safety_Course_Founding_Pilot_Terms_Privacy_Drafts.md`.
- [ ] Complete `88_AI_Safety_Course_First_Sale_Decision_Log.md`.
- [ ] Fill all placeholders in `89_AI_Safety_Course_Private_PrePayment_Page_Draft.md`.
- [ ] Add price: GBP 49 unless changed deliberately.
- [ ] Add "founding pilot" wording.
- [ ] Run content lint if copy is placed in the app.

Do not add:

- legal review claims;
- safeguarding review claims;
- expert approval claims;
- outcome claims;
- compliance claims;
- upload/paste/review offers.

## Step 4 - Payment And Admin

- [ ] Create a Stripe Payment Link for GBP 49 pilot.
- [ ] Require checkbox: "I confirm I am 18+ and a parent/carer."
- [ ] Add required pre-contract information before payment.
- [ ] Add plain terms, refund/cancellation wording, and privacy notice before payment.
- [ ] Decide and record ICO/data-protection fee position before payment.
- [ ] Follow `87_AI_Safety_Course_Founding_Pilot_Payment_Setup_Draft.md` before creating or sharing a payment link.
- [ ] Add separate optional marketing consent checkbox.
- [ ] Set success page or confirmation email with pilot boundary.
- [ ] Keep a spreadsheet with buyer email, date, payment status, delivery status, feedback status, refund status.
- [ ] Prepare refund process.

## Step 5 - Delivery

Manual delivery only:

- [ ] Send welcome email.
- [ ] Deliver module links or PDFs.
- [ ] Deliver asset copy / printable pack.
- [ ] Point to emergency signpost.
- [ ] Ask for feedback after delivery.
- [ ] Keep the boundary reply ready before opening email/DM channels.

Do not:

- ask for child details;
- answer live-incident questions;
- take screenshots or message content;
- open, preview, download, save, copy, screenshot, forward, or upload unsolicited images, screenshots, messages, attachments, or incident material;
- discuss a specific child case;
- improvise legal or safeguarding wording.

Boundary reply for live concerns:

> I cannot advise on a live situation or review incident details. Please use the emergency signpost or the appropriate qualified route.

Inbound material protocol:

- If an email, DM, or public comment appears to include a live incident, child details, screenshots, message content, images, account handles, school details, or attachments, do not open attachments or preview images.
- Send the boundary reply without quoting the details.
- Log only the boundary issue type in `80_AI_Safety_Course_Founding_Pilot_Tracker.md`; remove identifying details.
- If suspected under-18 nude or sexual material is received, stop the pilot channel, do not handle the material further, use the verified signpost/qualified route, and seek legal/safeguarding advice before any further action.

## Step 6 - Outreach

- [ ] Use one-to-one warm parent message first.
- [ ] Send to 5-10 warm parents.
- [ ] Prefer DM-only outreach. Use a parent-group post only after the AI review blockers are patched and only if comments can be redirected without retaining child detail.
- [ ] Track who asks for the link.
- [ ] Track what nearly stopped them.

Use `77_AI_Safety_Course_Founding_Pilot_Outreach_Copy.md`.

## Step 7 - Feedback

Ask:

- [ ] Which rule felt easiest to explain at home?
- [ ] Which rule still felt unclear?
- [ ] Which asset would you actually use?
- [ ] What wording felt too strong, too soft, or confusing?
- [ ] What nearly stopped you joining?

Do not ask for outcome claims. Do not ask for child examples or incidents.

## Step 8 - Demand Gate

Continue only if:

- [ ] At least 5 pilot buyers or strong committed interest.
- [ ] No serious trust objection.
- [ ] No parent tries to use the product for live incident advice without being route-boundaried.
- [ ] Feedback says the assets are clear enough to use.
- [ ] Refunds or objections do not point to a trust/scope problem.

Pay for professional review before:

- [ ] more than 5 paying pilot households;
- [ ] school/PTA circulation;
- [ ] public paid ads;
- [ ] broad email launch;
- [ ] publishing Scenario Trainer, Self-Check, or Routing Card;
- [ ] claiming any review or expert approval.

## Current Build Status

| Area | Status |
|---|---|
| Evidence layer | Drafted and Breaker-patched; needs human review later. |
| Course design | Drafted. |
| Phase 3 tools | Drafted; only Family Agreement builder implemented as gated tool. |
| Scenario Trainer | Draft data only; not public. |
| Readiness Self-Check | Draft data only; not public. |
| Stay Current update stream | Internal workflow only. |
| Routing Card | Draft data only; not print-ready. |
| Pilot scripts | Drafted. |
| Pilot assets | Drafted. |
| Sales copy | Drafted. |
| Outreach copy | Drafted. |
| AI review findings | External/cross-model Claude review run; blocker/high patch pass in progress. |
| Emergency signpost | Source checked and patched in `84`; re-check before first sale. |
| First-sale legal/admin pack | Drafted in `85`; needs Ben decisions before payment link. |
| Terms/privacy/payment drafts | Drafted in `86` and `87`; not publishable until placeholders and decisions are completed. |
