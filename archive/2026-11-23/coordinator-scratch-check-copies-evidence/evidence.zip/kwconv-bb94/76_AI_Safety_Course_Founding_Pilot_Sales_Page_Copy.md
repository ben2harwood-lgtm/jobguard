# AI Safety Course - Founding Pilot Sales Page Copy

*Created 2026-06-27. Status: draft sales copy for a small founding pilot. Do not publish until AI legal/safeguarding review findings are run and blocker/high issues are patched. This copy deliberately avoids claims of legal review, safeguarding review, expert approval, compliance, or safety outcomes.*

## Page Title

Bearings AI Safety Course - Founding Parent Pilot

Parent education and household planning for AI use at home.

## Hero

### Headline

Set clearer AI rules at home, without turning it into a panic lecture.

### Supporting Copy

A calm parent-led pilot course for families who want practical household rules around AI: what stays private, why AI is a tool rather than a person, how to check before trusting output, and how to decide when a concern belongs outside the course.

### CTA

Join the founding pilot - GBP 49

Secondary link: Ask a non-urgent question first

## Pilot Notice

This is a founding pilot, which means the material is still being reviewed and improved. It is parent education and household planning, not protection, monitoring, legal advice, safeguarding advice, crisis help, or an assessment of your child.

Please do not send names, school details, screenshots, messages, images, account handles, or incident details. If something is happening now, use the emergency signpost.

## Who This Is For

- Parents and carers of children or teens who are starting to use AI tools.
- Families who want a simple household agreement before habits harden.
- Parents who feel unsure about chatbots, AI homework, privacy, and confident AI answers.
- Parents who want calm scripts and printable rules rather than another long guide to read.

## What You Get

### Four short parent modules

1. **The AI Safety Map**  
   Four household habits: think before use; tool, not person; private stays private; human check before trust or action.

2. **Private Stays Private**  
   A practical rule for names, school, location, routines, messages, images, voice, schoolwork, account details, and live concerns.

3. **Tool, Not Person**  
   How to talk about companion-style AI without panic or diagnosis.

4. **Verify Before Trust**  
   Four checks before believing, sharing, buying, submitting, or acting.

### Printable assets

- Four Habits card.
- Private Stays Private card.
- Tool, Not Person script.
- Verify Before Trust sheet.
- Schoolwork Ask-First sheet.
- Family AI Safety Agreement starter.
- Pilot boundary card.

### Family AI Safety Agreement

You will leave with a short set of household clauses you can adapt and print. It is a conversation tool, not a contract or monitoring system.

## What This Pilot Does Not Include

- No child accounts.
- No child-facing content.
- No upload or review of messages, screenshots, images, schoolwork, or incidents.
- No AI judgement of real situations.
- No diagnosis, score, or child profile.
- No live-incident advice.
- No claim that the material has formal legal or safeguarding sign-off.

The full Scenario Trainer, Readiness Self-Check, Stay Current update stream, and printable Routing Card are being kept internal until review gates are complete.

## Why The Pilot Is Small

AI safety is a serious topic, especially where privacy, emotional reliance, schoolwork, contact pressure, and image risk are involved. The pilot starts with the lower-risk foundation: household rules, privacy, tool boundaries, and verification habits.

The heavier route-card and image-risk materials stay out of the pilot pack until the review process is stronger.

## What Parents Will Be Asked

You will be asked for feedback on:

- whether the rules are clear;
- whether the assets are usable;
- what felt confusing;
- what wording felt too strong or too soft;
- what nearly stopped you joining.

You will not be asked to share child details or live incident information.

## Price

Founding pilot: **GBP 49**

This is a pilot price for early families who are comfortable helping improve the material. Later versions may include more modules, tools, and reviewed assets at a higher price.

## FAQ

### Is this for children?

No. It is for parents and carers. There are no child accounts and no child-facing activities.

### Will you look at my child's messages or screenshots?

No. Please do not send messages, screenshots, images, account handles, school details, or incident details. The course uses invented examples and household rules only.

### Is this legal or safeguarding advice?

No. It is parent education and household planning. Live concerns should use the emergency signpost or qualified routes.

### Is the course fully reviewed?

This is a founding pilot. The material draws on publicly available UK guidance and a cautious AI-assisted review process, but it has not yet had paid professional legal or safeguarding sign-off.

### What if something is happening now?

Do not use the course for that. Use the emergency signpost.

## Footer Line

Bearings is parent education and planning. It is not monitoring software, crisis help, legal advice, safeguarding advice, or a child assessment.

## CTA Block

Join the founding pilot - GBP 49

Non-urgent questions before joining? Email [EMAIL].

Emergency signpost: [EMERGENCY LINK]
