# AI Safety Course - Founding Pilot Terms And Privacy Drafts

*Created 2026-06-27. Status: draft public-facing copy for the founding pilot only. Do not publish or send until Ben fills the placeholders, checks the digital-content cancellation choice, and gets legal review where needed. This is not legal advice.*

## Use Case

These drafts are for the tiny manual founding pilot described in `72_AI_Safety_Course_PreRevenue_Paid_Pilot_Scope.md`.

They are not the live terms or privacy pages for the broader Keepwise product.

## Pre-Payment Summary Block

Place this before any payment link, in the sales page, private Google Doc, or payment pre-read email.

> **Before you join**
>
> You are buying a founding pilot place in the Keepwise AI Safety Course, a parent education and household-planning pilot.
>
> Price: GBP 49.
>
> Provider: [TRADING NAME].
>
> Contact: [EMAIL].
>
> Address/contact address: [ADDRESS DECISION REQUIRED].
>
> What you get: four short parent modules, printable starter assets, and a Family AI Safety Agreement starter.
>
> Delivery: manual digital delivery within [TIMEFRAME] after payment and required confirmations.
>
> This pilot is not legal advice, safeguarding advice, monitoring, crisis help, child assessment, or incident review. It does not promise outcomes.
>
> Please do not send child names, school details, account handles, screenshots, messages, images, attachments, schoolwork, prompts, or live-incident details. If something is happening now, use the emergency signpost: [EMERGENCY LINK].
>
> Terms: [TERMS LINK OR ATTACHED COPY].
>
> Privacy notice: [PRIVACY LINK OR ATTACHED COPY].
>
> Refund/cancellation wording: [INSERT CHOSEN OPTION].

## Payment Checkbox Copy

Use separate confirmations where the payment tool allows it. If the payment tool cannot collect these reliably, collect them in a pre-payment form or confirmation email before sending the payment link.

Required:

> I confirm I am 18+ and a parent/carer.

Required:

> I have read the pilot notice, terms, privacy notice, and refund/cancellation wording.

Required:

> I understand this is parent education and household planning only. I will not send child names, school details, account handles, screenshots, messages, images, attachments, schoolwork, prompts, or live-incident details.

Required only if Ben chooses immediate manual delivery of digital materials:

> I want access to the digital pilot materials before the 14-day cancellation period ends, and I understand that once the digital materials are supplied I may lose my right to cancel for that digital content.

Optional:

> Email me occasional updates about Keepwise. I can unsubscribe at any time.

## Draft Terms

### 1. Who Provides The Pilot

The Keepwise AI Safety Course founding pilot is provided by [TRADING NAME].

Contact: [EMAIL].

Address/contact address: [ADDRESS DECISION REQUIRED].

### 2. What You Are Buying

You are buying access to a small founding pilot of parent education and household-planning materials about AI use at home.

The pilot includes:

- four short parent modules;
- printable starter assets;
- a Family AI Safety Agreement starter;
- manual delivery and a request for feedback.

The pilot does not include:

- child accounts;
- child-facing activities;
- review of real messages, screenshots, images, schoolwork, prompts, or incidents;
- live-incident advice;
- AI judgement of real situations;
- professional legal or safeguarding sign-off.

### 3. Eligibility

The pilot is for adults aged 18+ who are parents or carers.

### 4. Price

The founding pilot price is GBP 49.

Payment is handled by Stripe. Keepwise does not see or store card details.

### 5. Delivery

Delivery is manual. Pilot materials will be sent to the buyer's email address within [TIMEFRAME] after payment and required confirmations.

Do not automate instant access until the cancellation wording and checkout flow have been reviewed.

### 6. Cancellation And Refunds

Ben must choose and review one of these options before sale.

#### Option A - Delivery After Cancellation Period

> You can cancel within 14 days of purchase by emailing [EMAIL]. Digital pilot materials will not be supplied until after that period unless you ask for earlier access.

#### Option B - Early Digital Delivery

> If you ask for the digital pilot materials before the 14-day cancellation period ends, you understand that once the materials are supplied you may lose your right to cancel for that digital content.

Pilot refund policy to confirm:

> If the pilot clearly is not what you expected, email [EMAIL] within [NUMBER] days. Refund requests will be reviewed manually and fairly.

### 7. Boundaries

The pilot cannot review live situations, child messages, images, screenshots, schoolwork, prompts, account handles, school details, or incident facts.

Do not send:

- child names;
- school details;
- account handles;
- screenshots;
- messages;
- images;
- attachments;
- schoolwork;
- prompts;
- live-incident details.

If a live concern is raised, the response is the boundary reply and the emergency signpost.

If suspected under-18 nude or sexual material is received, the pilot channel stops. The material will not be opened, reviewed, copied, forwarded, uploaded, or commented on through the pilot.

### 8. Emergency Signpost

If something is happening now, use the emergency signpost: [EMERGENCY LINK].

If there is immediate danger or a crime in progress, use 999.

### 9. Changes During The Pilot

This is a founding pilot. Content may change as it is reviewed and improved.

### 10. Feedback

Feedback should be about clarity, usefulness, tone, and whether the assets are practical. Do not include child names, school details, screenshots, messages, images, or incident details in feedback.

### 11. Professional Review Status

The material has been built with source checks and AI-assisted issue-finding. It has not yet had paid professional legal or safeguarding sign-off.

## Draft Privacy Notice

### 1. Who Is Responsible

[TRADING NAME] is responsible for the personal data collected for the Keepwise AI Safety Course founding pilot.

Contact: [EMAIL].

Address/contact address: [ADDRESS DECISION REQUIRED].

### 2. What Data We Collect

For the founding pilot, we may collect:

- parent/carer name;
- email address;
- payment status and Stripe transaction reference;
- confirmation that you are 18+ and a parent/carer;
- terms/privacy/refund acknowledgement;
- optional marketing consent;
- delivery status;
- feedback about clarity, usefulness, and tone;
- boundary issue type if a live concern is raised, with identifying details removed.

The pilot is designed not to collect child names, school details, account handles, screenshots, messages, images, attachments, schoolwork, prompts, or live-incident detail.

### 3. Why We Use It

We use the data to:

- provide the paid pilot;
- manage payment and refund records;
- send the materials;
- respond to non-urgent questions;
- ask for feedback;
- improve the pilot materials;
- keep a minimal boundary log if needed;
- send marketing updates only where you opt in.

### 4. Lawful Basis To Confirm

Draft basis for review:

- contract for buyer, payment, acknowledgement, and delivery data;
- legal obligation for accounting/payment records;
- legitimate interests for minimal no-child-detail feedback and boundary notes;
- consent for optional marketing.

### 5. Who We Share It With

Draft processors/services to confirm before sale:

- Stripe for payment processing;
- [EMAIL PROVIDER] for email delivery and support;
- [SPREADSHEET/NO-CODE TOOL] if used for the pilot tracker.

Do not add another tool to the workflow unless this notice is updated.

### 6. How Long We Keep It

Draft retention plan for review:

- lead records: delete or anonymise after [PERIOD];
- buyer/payment records: keep as required for accounting/tax, then delete or archive securely;
- delivery status: delete or anonymise after [PERIOD];
- feedback: keep only no-child-detail notes needed for product improvement;
- boundary log: keep only issue type and response used, with identifying details removed.

### 7. Your Rights

You can ask to see, correct, delete, or restrict use of personal data where those rights apply. You can object to some uses of data. You can withdraw marketing consent at any time.

Contact [EMAIL].

You can complain to the ICO if you are unhappy with how personal data is handled.

## Confirmation Email Add-On

Add this block to Email 1 after payment once the choices above are final:

> Your purchase summary:
>
> Product: Keepwise AI Safety Course - Founding Parent Pilot.
>
> Price paid: GBP 49.
>
> Provider: [TRADING NAME].
>
> Contact: [EMAIL].
>
> Terms: [TERMS LINK OR ATTACHED COPY].
>
> Privacy notice: [PRIVACY LINK OR ATTACHED COPY].
>
> Refund/cancellation: [INSERT CHOSEN WORDING].
>
> Digital delivery: [INSERT DELIVERY TIMING AND DIGITAL-CONTENT ACKNOWLEDGEMENT IF USED].

## Publication Gate

Before using this copy:

- fill every placeholder;
- choose Option A or Option B for digital delivery;
- decide refund period and wording;
- confirm ICO fee/exemption outcome;
- update the payment flow to collect the required confirmations;
- run content lint and a manual phrase scan;
- keep the raw review note that this is not paid professional sign-off.
