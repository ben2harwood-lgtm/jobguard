# No-Code Launch Runbook — take real money this week, no developers

**Why this exists.** The coded app (`21`) is the right *eventual* build, but your own plan (`00` §1, `21` §0/§4, `15`) says: prove demand with lean, manual fulfilment **before** any engineering spend. This machine has no developer toolchain, you have zero sales, and almost all the content already exists. So this is the fastest honest route to your first paying customers — using off-the-shelf tools a non-technical founder can run alone. When sales and retention clear the gates in `00` §7, you graduate to the coded app in `21`.

> **Premium model throughout:** The System £99 (founding £79) · The Concierge from £650 (scoped) · Stay Current £59/yr (year 1 bundled). Never quote the old £39 / £7-mo or £179 numbers. Canon: `26`.

---

## The no-code stack (all free or near-free tiers)

| Job | Tool | Why |
|---|---|---|
| Host the static pages | **Netlify Drop** (drag-and-drop) or **Carrd** | `23` landing, `03` emergency, `10` quiz, `05` privacy are already HTML/can be — just host them |
| Diagnostic + free quiz capture | **Tally** (free) | No-code forms; PII-safe; emails you each submission |
| Payments | **Stripe Payment Links** | One link per tier; no checkout code; collects email + consent |
| The "library" | **Gated Notion** (private share link) or **PDF pack** | Paste `16`–`20` in as pages; share the link only with buyers |
| Email | **MailerLite/Buttondown free**, or just **Gmail** at first | Wire the `08` templates; at <20 sales/week manual Gmail is fine |
| Funnel tracking | **`12` tracker (xlsx)** + Stripe dashboard | Already built; one tab, the gate metrics from `00` §7 |
| Analytics (optional) | **Plausible** or none yet | Cookieless; skip until you have traffic worth measuring |

---

## Part A — the leanest launch (do this week → first 5 sales)

You do **not** need the full self-serve library for the first handful of buyers. Deliver the personalised plan + the relevant guides by email/Notion, by hand.

1. **Pages live.** The full set of pages is already built as HTML — just fill the placeholders and host: `23_Landing_Page_v2.html` (landing), `03_Emergency_Signpost_Screen.html` (signpost), `10_Free_Readiness_Quiz.html` (quiz), `05_Privacy_and_Data_Notice.html` (privacy), `terms.html` (Terms — a **placeholder skeleton**; send to your solicitor before relying on it). Footers already cross-link privacy, terms and the emergency signpost.
   - In `23`, replace `Bearings`, `[QUIZ LINK]`, `[BUY SYSTEM]`, `[CONCIERGE ENQUIRY]`, `[BUY STAY CURRENT]`, `[EMAIL FORM ACTION]`, `[EMAIL]`. In `05`/`terms.html`, replace `Bearings`, `[NAME / TRADING NAME]`, `[EMAIL]`, `[DATE]`. Pick the brand from the `06` shortlist (Bearings / Household Ready / Outset).
   - Drag the HTML files onto **Netlify Drop** → live URL in ~60 seconds (rename your chosen landing page to `index.html`). Point a domain at it later.
2. **Diagnostic in Tally.** Build the 25 questions from `01` §2.2. **Guardrail config (non-negotiable):**
   - No field for child full name, DOB, school, photos, screenshots, or incident detail.
   - The one optional first-name field: **default empty, clearly skippable** ("you can skip this — we don't need it").
   - The final free-text field shows: *"Please don't include names, schools, or incident detail. If something is happening right now, use the emergency signpost or call 999."*
   - Set Tally's confirmation/redirect to a calm "Thanks — your plan lands within 48 hours" message.
3. **Stripe Payment Links** (test mode first, then live):
   - System **£99** one-off · a second link or coupon for the **£79** founding price · Stay Current **£59/yr** recurring. **The Concierge (from £650)** is *not* a Payment Link — it's an enquiry → a manual scoped **Stripe invoice** (scoping rubric in `26` §6); add an "Enquire about Concierge" form/mailto on the landing page (`[CONCIERGE ENQUIRY]`).
   - On each link, collect email and add a **required custom checkbox**: *"I confirm I am 18+ and a parent/carer."* Add a **separate, optional** marketing opt-in checkbox (PECR).
   - Set the success URL → your **Tally diagnostic link** (so buying flows straight into the questionnaire).
4. **Fulfilment (your <20-min loop).** New Stripe payment → send email 1 (`08`) → buyer completes Tally → paste their answers into the `07` prompt → **edit every line** (the `07` checklist) → export the plan to PDF → deliver with email 3, with links into the relevant `16`–`20` guides (as Notion links or attached PDFs). Map the `07` slug table to your Notion page URLs.
5. **Emails wired.** Load the 7 `08` templates into your sender (or Gmail drafts): 1 confirmation+magic-link, 2 nudge (+48h), 3 plan delivery, 4 feedback (+3d), 5 library onboarding (+7d), 6 Stay Current renewal (month 11), 7 refund. *(In no-code there's no magic link — replace that line in email 1 with the Notion library share link.)*
6. **Tracking on.** Open `12`; log every visitor source, quiz completion, sale, refund, and feedback score against the `00` §7 gates.
7. **Soft launch.** Send to 5–10 warm parents + one parent group. Goal: **first 5 paid Systems.** Ask each buyer "what nearly stopped you?" Deliver every plan <48h.

---

## Part B — the fuller no-code product (weeks 2–4, once sales start)

- **Stand up the gated Notion library:** `16` (10 platform guides) · `17` (conversation library + "what not to say" card) · `18` (12 playbooks + 3 modules) · `19` (4 age-band packs — the navigation spine) · `20` (what's-changing). Cross-link them. Share the top-level link only with paying buyers.
- **Family-agreement builder:** start as a Notion/Google Doc template from `09` §G; buyers copy and edit it.
- **Monthly briefing:** draft from the `20` backlog; send to "current" buyers manually. Don't automate until manual sends prove opens/actions (`00`).
- **The Concierge:** fulfil the done-*with*-you walkthrough over a video call; it's a manual, scoped service (quote from £650 per `26` §6), not a self-serve feature. Cap it at ~4/month.

---

## Compliance — must be true before you take live payment (`00` §10/§12)

- [ ] **ICO data-protection fee** self-assessed and paid (~£52).
- [ ] **Privacy notice** (`05`) live and linked; **30-day deletion** of the optional first name + free-text working data is something you actually do (calendar reminder until automated).
- [ ] **Marketing consent** kept separate from purchase (PECR).
- [ ] **Solicitor sign-off** on marketing copy + disclaimer + Terms of Service + a written "OSA out-of-scope / Children's-Code-does-not-apply" note. *(Launch blocker, not a build blocker.)*
- [ ] **No user-to-user anything** — Tally/Notion/email only; no comments, forum, or child-facing flow (keeps you out of OSA scope).
- [ ] **Emergency signpost** reachable without paying; every number/URL re-verified on launch day.
- [ ] **HMRC** Self Assessment registered; consider PI/PL insurance.

---

## When to graduate to the coded app (`21`)

Build the Next.js product **only after** the manual model clears the `00` §7 gates — broadly: **≥20 paid Systems in 90 days at ≥1% visitor→paid, refunds <15%, and ≥10% System→Stay Current**, or when manual fulfilment volume genuinely hurts (~50+ sales). At that point the audit (`22`) confirms `21` is ready to hand to a coding agent, and the patched `07`/`08` + the slug table carry straight over. Until then, every pound spent on engineering is premature.
