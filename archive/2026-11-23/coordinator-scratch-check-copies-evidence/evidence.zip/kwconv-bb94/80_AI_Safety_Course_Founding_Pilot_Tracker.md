# AI Safety Course - Founding Pilot Tracker

*Created 2026-06-27. Status: lightweight tracker for the first founding pilot conversations and buyers. Copy this table into a spreadsheet if useful.*

## Lead Tracker

Use only warm personal or non-employer channels before paid professional review. Do not record child names, school names, account handles, incident details, or precise child age.

| Lead ID | Name | Source | Contacted date | Reply | Link sent | Bought | Notes with no child detail |
|---|---|---|---|---|---|---|---|
| PILOT-001 |  | warm parent / parent group DM / LinkedIn / founder network |  | yes / no | yes / no | yes / no |  |
| PILOT-002 |  | warm parent / parent group DM / LinkedIn / founder network |  | yes / no | yes / no | yes / no |  |
| PILOT-003 |  | warm parent / parent group DM / LinkedIn / founder network |  | yes / no | yes / no | yes / no |  |
| PILOT-004 |  | warm parent / parent group DM / LinkedIn / founder network |  | yes / no | yes / no | yes / no |  |
| PILOT-005 |  | warm parent / parent group DM / LinkedIn / founder network |  | yes / no | yes / no | yes / no |  |
| PILOT-006 |  | warm parent / parent group DM / LinkedIn / founder network |  | yes / no | yes / no | yes / no |  |
| PILOT-007 |  | warm parent / parent group DM / LinkedIn / founder network |  | yes / no | yes / no | yes / no |  |
| PILOT-008 |  | warm parent / parent group DM / LinkedIn / founder network |  | yes / no | yes / no | yes / no |  |
| PILOT-009 |  | warm parent / parent group DM / LinkedIn / founder network |  | yes / no | yes / no | yes / no |  |
| PILOT-010 |  | warm parent / parent group DM / LinkedIn / founder network |  | yes / no | yes / no | yes / no |  |

## Buyer Tracker

| Buyer ID | Lead ID | Paid date | Amount | Consent 18+ parent/carer | Materials sent | Feedback requested | Feedback received | Refund | Boundary issue? |
|---|---|---|---:|---|---|---|---|---|---|
| BUYER-001 |  |  | 49 | yes / no | yes / no | yes / no | yes / no | yes / no | yes / no |
| BUYER-002 |  |  | 49 | yes / no | yes / no | yes / no | yes / no | yes / no | yes / no |
| BUYER-003 |  |  | 49 | yes / no | yes / no | yes / no | yes / no | yes / no | yes / no |
| BUYER-004 |  |  | 49 | yes / no | yes / no | yes / no | yes / no | yes / no | yes / no |
| BUYER-005 |  |  | 49 | yes / no | yes / no | yes / no | yes / no | yes / no | yes / no |

## Feedback Log

| Buyer ID | Easiest rule | Still unclear | Asset they would use | Wording issue | What nearly stopped them? | Product change |
|---|---|---|---|---|---|---|
| BUYER-001 |  |  |  |  |  |  |
| BUYER-002 |  |  |  |  |  |  |
| BUYER-003 |  |  |  |  |  |  |
| BUYER-004 |  |  |  |  |  |  |
| BUYER-005 |  |  |  |  |  |  |

## Boundary Log

Use this if a parent tries to send live incident information, screenshots, child details, or asks for incident advice. Do not quote or retain identifying detail in this log.

| Date | Buyer/lead ID | Boundary issue | Response used | Material opened? | Follow-up needed? | Notes with identifying details removed |
|---|---|---|---|---|---|---|
|  |  | live concern / child PII / screenshot / message content / image / school detail / incident advice request / unsolicited attachment | boundary email / emergency signpost / no reply sent / pilot paused | yes / no | yes / no |  |

## Pilot Gate Summary

| Metric | Target | Actual | Status |
|---|---:|---:|---|
| Warm parents contacted | 5-10 |  |  |
| Link requests | 3+ |  |  |
| Paid pilot buyers | 5 before broadening |  |  |
| Refunds | 0-1 acceptable in tiny pilot |  |  |
| Boundary issues | 0 ideal; any issue triggers review |  |  |
| Feedback received | 3+ |  |  |
| Parent says an asset is usable | 3+ |  |  |

## Stop Conditions

Pause the pilot if:

- any parent sends live incident material;
- any unsolicited image, screenshot, message, or attachment is received;
- any parent expects the pilot to review messages/images;
- any copy appears to invite incident detail;
- a route or source issue is found;
- more than one pilot buyer asks whether the course is professionally reviewed;
- refunds or objections suggest trust/scope problems;
- the first 5 buyers are reached, which triggers paid professional review before widening.
