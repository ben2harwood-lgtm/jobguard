# Threat & Naming Reference

**The evidence base behind the report content and marketing claims, plus the naming shortlist.** Current to June 2026. Verification: `[V]` verified against named official source · `[PV]` partly verified · `[NV]` needs verification. Don't publish a `[PV]`/`[NV]` figure as a marketing claim until sourced to a primary report.

---

## What changed in 2025–2026 (the context the monthly briefing exists to track)

- **Crime and Policing Act 2026** (Royal Assent 29 Apr 2026) created offences to possess/make/supply AI models built to generate CSAM, criminalised "nudification" tools and AI "paedophile manuals", and **brought AI chatbots into Online Safety Act scope** `[V]`. *Some provisions commence on later dates set by regulation — verify commencement before any "it is now illegal to…" claim* `[NV]`.
- **AI-generated CSAM surged:** IWF found **3,440 AI child-sexual-abuse videos in 2025 vs 13 in 2024**; 65% were the most severe category `[V — IWF, 16 Jan 2026]`.
- **Sextortion of UK children hit record highs** — Report Remove averaging ~nine child reports a week `[V — IWF, 7 Apr 2026]`.
- **AI companion harms became a named regulatory target** — Character.AI ended under-18 open-ended chat (by 25 Nov 2025); the 2026 Act requires romantic/companion chatbots to enforce an 18+ minimum `[V]`.
- **OSA child-protection duties came fully online through 2025** (illegal-harms duties 17 Mar 2025; children's-access age checks from 25 Jul 2025) `[V]`.
- **Under-16 social-media restriction is law-in-principle but NOT in force** — expected ~Spring 2027. **Do not tell parents it's live** `[V]`.

---

## The five priority threats

The nominated five are the right five for UK teens in 2026. Note threats 2 and 3 are intertwined (grooming increasingly uses AI imagery and ends in sextortion).

### 1. Financially-motivated sextortion — highest-velocity threat to teen boys

**For parents:** A criminal (usually an overseas organised gang, not a local predator) poses as an attractive peer, moves the chat to a private app, persuades the teen to send a nude, then immediately threatens to share it with family/friends unless paid. It escalates within the hour `[V — NCA]`.

**UK picture 2026:** Report Remove handled 1,894 self-reports in 2025 (+66%); 34% involved sextortion, ~nine UK child reports a week; **98% of sextortion reports were boys, mostly 14–17** `[V — IWF, 7 Apr 2026]`. Offenders increasingly use AI-"nudified" images to make threats credible `[V — NCA, 2026]`.

**Prevention (parent):** have the "stop, don't pay, don't delete, tell me, you won't be in trouble" conversation *before* it happens; tighten privacy so strangers can't see follower lists; pre-load Report Remove and CEOP; know the red flag (an account that turns sexual fast and pushes to another app).

**Report asks:** Q17, Q24 (sextortion conversation had? child knows the core rule?).

**Must not claim:** that the product prevents sextortion, or that it can detect or intervene. Frame: helps you prepare your teen and know the reporting routes.

**Sources:** NCA Sextortion (nationalcrimeagency.gov.uk) `[V]` · CEOP/Thinkuknow "Online blackmail" `[V]` · Report Remove (childline.org.uk/remove) `[V]`.

### 2. AI deepfake image/voice abuse — fastest-growing, biggest legal change

**For parents:** Apps can turn an ordinary clothed photo of a real child into a fake nude ("nudify"), or generate synthetic abuse imagery; voice-cloning fakes a familiar voice. The fakes look real and are used for bullying and sextortion. A teen can be victimised without ever sending anything `[V — IWF]`.

**UK picture 2026:** IWF assessed 8,029 AI images/videos as realistic CSAM in 2025, girls 97% of victims; AI CSAM **videos up ~26,000%** year-on-year `[V — IWF, Jan–Mar 2026]`. Using nudify tools on a child is an indecent-images offence; the 2026 Act added offences for the tools/models themselves `[V]`. Non-consensual sexual deepfakes of adults became an offence via the Data (Use and Access) Act 2025, in force 6 Feb 2026 `[PV]`.

**Prevention (parent):** reduce public photos; make clear any photo can be altered and it's never the victim's fault; know the removal routes (Report Remove, Take It Down); name that making a "nudified" image of a classmate is a crime, not a prank.

**Report asks:** Q16, Q18.

**Must not claim:** that the product stops images being made or removes them itself. Frame: explains the risk and the official removal routes.

**Sources:** IWF AI-CSAM hub (iwf.org.uk) `[V]` · gov.uk Crime and Policing Act 2026 factsheets `[V]`.

### 3. Grooming and coerced migration to private apps — largest by recorded offence volume

**For parents:** An adult builds trust (often via games or DMs), then steers the child onto private/disappearing-message apps where there's less oversight, before manipulating them. "Let's move to another app" is the warning behaviour `[V — NSPCC]`.

**UK picture 2026:** 7,263 Sexual Communication with a Child offences in 2024/25, up 89% since 2017/18; where the platform was known, ~40% Snapchat; 81% of victims are girls `[V — NSPCC, 2025]`. NSPCC's focus is the migration to encrypted/disappearing channels that defeats detection `[V]`.

**Prevention (parent):** teach that anyone asking to move to a private/secret/disappearing chat is a warning sign; use platform family tools; keep the relationship non-judgemental so the child discloses early; report suspected grooming to CEOP; NSPCC Helpline 0808 800 5000 for worries.

**Report asks:** Q9, Q12, Q19, Q23.

**Must not claim:** detection or monitoring of grooming. Frame: prevention through conversation + knowing the routes.

**Sources:** NSPCC grooming data (nspcc.org.uk) `[V]` · CEOP Safety Centre (ceop.police.uk) `[V]`.

### 4. Scams, phishing & social engineering aimed at young people

**For parents:** Fraud aimed at teens — fake concert/sports tickets, "get-rich-quick"/crypto schemes, fake jobs asking for upfront fees, account-takeover phishing, and "money-mule" recruitment (being paid to move criminal cash through your account, which can give a teen a criminal record) `[V — NCA]`. Increasingly AI-assisted.

**UK picture 2026:** Ofcom reports 90%+ of young people have met online scams `[PV — source before publishing]`; UK social-engineering scams rose 62% YoY in 2025 with a shift to AI-assisted fraud `[PV — industry data]`. Report via Action Fraud `[V]`.

**Prevention (parent):** legitimate jobs never ask for upfront money; "easy money for using your bank account" is mule recruitment; buy tickets only via official resale; slow down on urgency/too-good-to-be-true; unique passwords + 2FA; report to Action Fraud 0300 123 2040.

**Report asks:** Q20.

**Must not claim:** that the product blocks scams. Frame: teaches the tells and the reporting route.

**Sources:** reportfraud.police.uk `[V]` · NCSC phishing guidance (ncsc.gov.uk) `[V]`.

### 5. AI-companion / chatbot dependency & unsafe advice — fastest-emerging, now regulated

**For parents:** AI "companion" apps act as friends, partners, or pseudo-therapists. Teens can form intense dependency, and some bots fail to challenge suicidal thoughts, give unsafe advice, or engage in sexualised roleplay with minors `[V — Internet Matters / regulatory]`.

**UK picture 2026:** ~1 in 4 13–17s reported using AI chatbots for mental-health support `[PV — source before publishing]`; Character.AI ended under-18 open chat by 25 Nov 2025; the 2026 Act brings chatbots into OSA scope and requires companion bots to enforce 18+ `[V]`.

**Prevention (parent):** ask which AI apps they use and try them yourself; set the principle that AI is not a therapist or friend — for distress, go to a person or a helpline; watch for dependency signs; keep under-18s off romantic/companion AI; report unsafe responses to the platform and Report Harmful Content.

**Report asks:** Q13, Q14, Q21.

**Must not claim:** that the product assesses or fixes a child's AI use or mental health. Frame: awareness + boundaries + signposting to real help.

**Sources:** Internet Matters (internetmatters.org) `[V]` · gov.uk Online Safety Act collection `[V]` · UK Safer Internet Centre (saferinternet.org.uk) `[V]`.

**All five belong in the first set of report playbooks.**

---

## Naming & positioning shortlist

**Whitespace:** nobody clearly owns the *calm, premium, paid "assessment + plan" for the household* (not the child's device). Internet Matters and Aura are the nearest tone references; Qoria/Smoothwall owns the school/MAT space you'd meet on the B2B stretch.

**Existing players to avoid colliding with:** Internet Matters (neutral parent guidance), Parent Zone (editorial + schools), NSPCC Net Aware (app reviews), Childnet (conversation guides), Thinkuknow/CEOP (official education), Bark/Qustodio/Aura (monitoring/controls), SafeToNet/Ineqe (B2B tech/safeguarding), Life360/Family Link (location/device).

**Category labels (pick one, use consistently):** consumer-facing — **"household online-safety report"** + **"family safety plan"**; for the school stretch, switch the umbrella term to **"digital readiness."**

**Top 3 name recommendations** (all conflict/domain/trademark notes are sanity-check only — `[NV]`; run a proper UK IPO search in classes 9/42/45 and live domain/Companies House checks before committing):

1. **Bearings** — *"Get your bearings on family life online."* Calm, modern, implies orientation not surveillance; cleanest whitespace; no family-app collision found. Watch-outs: common-word domain needs a modifier (getbearings / bearings.family), thinner trademark protectability. **Best all-rounder.**
2. **Household Ready** — *"A readiness report and ongoing safety plan for your home."* Most literal fit, zero alarm, household-not-device framing (your differentiator), best domain odds, safest to clear, stretches to schools. Watch-out: descriptive, so weaker standalone mark — protect the logo/lockup. **Safest, most on-brief.**
3. **Outset** — *"Start your family on the front foot online."* Short, premium, proactive-not-reactive; avoids spyware and therapy registers; scales to schools. Watch-out: bare domains likely taken (outset.family / tryoutset), clear classes 9/42. **Most brandable single word.**

*Honourable mention:* Threshold (premium, but common-word crowding). **Avoid:** anything with Spy/Track/Monitor/Watch/Guard/Shield (surveillance); cutesy/childish (Nanny/Cub/Sprout); alarmist (Sentinel/Defender/Fortress); therapy-sounding (Calm/Mindful/Thrive); AI-companion-sounding (anything "-AI", Buddy/Pal); and Beacon, Roost, Hearth, Tangle, Lattice, Tend, Keystone (collision/availability risk). Kindred and Steady carry existing-brand baggage — treat as amber.

---

## Full source list (regulatory + threat)

**Regulatory:** OSA explainer (gov.uk/government/publications/online-safety-act-explainer) · OSA scope checker (ofcom.org.uk/online-safety/illegal-and-harmful-content/check) · OSA Schedule 1 exemptions (legislation.gov.uk/ukpga/2023/50/schedule/1) · Ofcom age assurance (ofcom.org.uk/online-safety/protecting-children) · ICO Children's Code scope (ico.org.uk — childrens-code-guidance) · ICO data-protection fee (ico.org.uk/for-organisations/data-protection-fee) · ICO DPIA threshold (ico.org.uk — when-do-we-need-to-do-a-dpia) · ASA substantiation (asa.org.uk/advice-online/substantiation.html) · DMCC unfair practices CMA207 (gov.uk) · DMCC Schedule 20 (legislation.gov.uk/ukpga/2024/13/schedule/20).

**Threat:** NCA Sextortion · CEOP Safety Centre / Thinkuknow · IWF (Report Remove, AI-CSAM research) · NSPCC (grooming data, helpline) · Childline · Samaritans / Shout / Papyrus · Action Fraud (reportfraud.police.uk) · NCSC phishing · Report Harmful Content (SWGfL) · Internet Matters · UK Safer Internet Centre · gov.uk Crime and Policing Act 2026 factsheets.
