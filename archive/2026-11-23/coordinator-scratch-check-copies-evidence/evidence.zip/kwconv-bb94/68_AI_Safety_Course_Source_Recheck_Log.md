# AI Safety Course - Official Source Recheck Log

*Created 2026-06-27. Status: partial official-source recheck to support human review. This is not legal advice, safeguarding clearance, or launch approval. It records what was checked against official/primary source pages on 2026-06-27 and what remains to be checked before sale.*

## Scope

This pass rechecked route, education, and policy sources that affect the AI Safety Course, Scenario Trainer, Readiness Self-Check, Stay Current workflow, and Routing Card.

It did not complete:

- legal interpretation;
- safeguarding judgement;
- platform-by-platform AI settings checks;
- final URLs/phone numbers in rendered public pages;
- review of any paid sales copy;
- review of terms, privacy, or email copy.

## Rechecked Sources

| Source ID | Source | Recheck result | Course implication |
|---|---|---|---|
| S08 | CEOP report page, `https://www.ceop.police.uk/ceop-reporting/` | CEOP page still frames the route around child sexual exploitation/abuse, sexual harm, and grooming online. It also says CEOP does not respond to online bullying, fake accounts, or account hacking. | Keep CEOP wording scoped; do not use CEOP as the route for every online harm. |
| S09 | IWF Report Remove page, `https://www.iwf.org.uk/our-technology/report-remove/` | IWF page still points to Report Remove as a Childline/IWF service for young people under 18 in the UK to report and remove sexual images/videos of themselves. | Keep Report Remove route scoped to eligible under-18 image/video removal; re-check eligibility before publication. |
| S10 | Childline Report Remove page, `https://www.childline.org.uk/info-advice/bullying-abuse-safety/online-mobile-safety/report-remove/` | Childline page states Report Remove helps young people under 18 in the UK report sexual images/videos of themselves and includes current age-range flow including an 18-and-over option. It also states AI-generated images that look like the young person can be reported. | Routing card should mention eligibility and now-18+ flow needs re-check; do not blur Childline, IWF, and CEOP routes. |
| S11 | NSPCC Helpline page, `https://www.nspcc.org.uk/about-us/our-services/nspcc-helpline/` | NSPCC page gives 0808 800 5000, email contact, and current voice helpline availability of 10am-4pm Monday-Friday, with email available at any time. | Route card can name NSPCC for adults worried about a child, but hours must be re-checked before publication. |
| S12 | GOV.UK contact police page, `https://www.gov.uk/contact-police` | GOV.UK confirms 999 for emergencies or crime in progress/immediate danger, and 101 for non-emergencies. It also points Scotland users to local policing team contact search. | Keep 999/101 wording; route-card Scotland wording still needs final route check. |
| S14 | Report Fraud page, `https://www.reportfraud.police.uk/` | Page identifies Report Fraud as the cyber crime and fraud reporting centre, gives 0300 123 2040, says it supports England, Wales and Northern Ireland, and says Scotland should report via 101. | Existing Action Fraud replacement wording remains correct directionally; keep Scotland caveat. |
| S18 | KCSIE GOV.UK page, `https://www.gov.uk/government/publications/keeping-children-safe-in-education--2` | GOV.UK page currently points to Keeping Children Safe in Education 2025, statutory guidance, last updated 1 September 2025, applies to England. | Keep school DSL/safeguarding wording tied to current KCSIE 2025; re-check before launch. |
| S03 | JCQ AI Use in Assessments page, `https://www.jcq.org.uk/knowledge-hub/ai-use-in-assessments-your-role-in-protecting-the-integrity-of-qualifications/` | JCQ page shows "AI Use in Assessments: Your role in protecting the integrity of qualifications", dated 30 April 2025. It emphasises own work, acknowledgement, malpractice, and centre procedures. | Schoolwork module remains grounded; re-check annually or before launch. |
| S01 | DfE generative AI in education, `https://www.gov.uk/government/publications/generative-artificial-intelligence-in-education/generative-artificial-intelligence-ai-in-education` | GOV.UK page title and URL remain current. Page is a policy paper, updated 12 August 2025, and includes risks around inaccurate, inappropriate, biased, out-of-date, unreliable, and personal-data exposure. | Claim Register S01 remains usable; keep school/education scope clear. |
| S02 | DfE generative AI product safety standards, `https://www.gov.uk/government/publications/generative-ai-product-safety-standards/generative-ai-product-safety-standards` | GOV.UK page title and URL are current. Page is labelled Guidance, updated 19 January 2026, and mainly intended for edtech developers/suppliers to schools and colleges. | Breaker concern about exact title/URL is addressed for now; still re-check before sale. |
| S07 | Ofcom age-check explainer, `https://www.ofcom.org.uk/online-safety/protecting-children/age-checks-for-online-safety--what-you-need-to-know-as-a-user` | Ofcom page says from 25 July 2025 services allowing pornography need strong age checks, and riskiest services are expected to use strong age checks for suicide, self-harm, eating-disorder content, and other harmful content. | Keep Online Safety Act wording as platform responsibility and avoid any claim that platform duties remove family risk. |
| S21 | Shout 85258 get-help page, `https://giveusashout.org/get-help/` | Shout page says to text "Shout" to 85258, describes the service as free, confidential, and 24/7, and says to call 999 if life is at imminent risk. | Emergency page Shout wording remains usable. |
| S22 | Samaritans contact page, `https://www.samaritans.org/how-we-can-help/contact-samaritan/` | Samaritans page says 116 123 is free and available any time, day or night. | Emergency page Samaritans wording remains usable. |
| S23 | Papyrus HOPELINE247 page, `https://www.papyrus-uk.org/help-me/hopeline-24-7` | Papyrus page gives 0300 102 2470 and text HOPE to 88247, and says HopeLine 24/7 is available every hour of every day. | Emergency page patched on 2026-06-27 to replace old 0800 068 4141 wording. **Live-page verification 2026-07-03 (supersedes the 07-03 "correction" below):** raw-HTML fetches of papyrus-uk.org (homepage and `/help-me/hopeline-24-7/`) on 2026-07-03 show ONLY 0300 102 2470 and text HOPE to 88247, branded HopeLine 24/7, with `tel:` links confirming (`tel:+443001022470`, `tel:88247`). 0800 068 4141 appears on none of them. The three URLs the earlier 07-03 "correction" cited (`/papyrus-hopeline247/`, `/hopeline247-faqs/`, `/hopeline247-text-and-email-services/`) now 301-redirect to `/help-me/hopeline-24-7` and no longer exist as distinct pages; that "correction" was based on stale search-index snippets, not the live page — the 06-27 patch direction (drop the freephone, keep 0300 102 2470 + 88247) was right. **Rule: crisis numbers must be verified against the rendered live page (or a raw-HTML fetch of the resolved URL), never search snippets.** Because the false correction was already applied downstream, this log fix is paired with reverting it: 0800 068 4141 removed from `app/emergency/page.tsx`; `tests/guardrails-structure.test.ts` un-inverted to pin absence of 0800 068 4141 and presence of 0300 102 2470; remaining occurrences swept in `03_Emergency_Signpost_Screen.md`/`.html` (already clean), `29_Masterclass_Scripts.md`, `31_Content_Review.md`, `34_Threat_Playbook_Cards.md`/`_print.html`; rebuild so `.next` artifacts no longer serve the dead number. |
| S24 | Report Harmful Content, `https://reportharmfulcontent.com/` | Page says it provides reporting guidance and direct links across platforms, but cannot take reports of sexual images of under-18s and points those to IWF. | Emergency page patched on 2026-06-27 to avoid using RHC for under-18 sexual-image reports. |

## Recheck Outcomes

| Item | Status | Notes |
|---|---|---|
| CEOP route scope | Source checked | Keep scoped to online sexual abuse/grooming/sexual harm. |
| Report Remove/IWF/Childline | Source checked, still needs review | Eligibility, now-18+ flow, and image-risk wording need legal/safeguarding review. |
| Police 999/101 | Source checked | Current GOV.UK wording supports 999/101 route. |
| Report Fraud / Scotland 101 | Source checked | Report Fraud page supports England/Wales/NI and Scotland 101 caveat. |
| NSPCC/Childline contact | Source checked, still needs final hours check | NSPCC hours can change; re-check immediately before publication. |
| KCSIE | Source checked | Current page points to 2025 statutory guidance; applies to England. |
| JCQ AI assessments | Source checked | Current page dated 30 April 2025. |
| DfE product safety exact title/URL | Source checked | Breaker title/URL defect addressed for now. |
| Ofcom child duties / age assurance | Source checked | Use platform-responsibility framing only. |
| Shout 85258 | Source checked | Text SHOUT to 85258 remains current; 999 if life is at imminent risk. |
| Samaritans | Source checked | 116 123 remains current and 24/7. |
| Papyrus HOPELINE247 | Verified against live page 2026-07-03; 06-27 patch confirmed correct | Raw-HTML fetches of the resolved live pages (homepage and `/help-me/hopeline-24-7/`) on 2026-07-03 show ONLY 0300 102 2470 and text HOPE to 88247 (`tel:+443001022470`, `tel:88247`); 0800 068 4141 is on none of them, and the three URLs the earlier 07-03 "correction" cited now 301-redirect to `/help-me/hopeline-24-7`. That "correction" relied on stale search snippets and has been reverted downstream. Emergency page and tests now use 0300 102 2470 + text HOPE to 88247 only. Rule: verify crisis numbers against the rendered live page (or raw-HTML fetch of the resolved URL), never search snippets. |
| Report Harmful Content | Source checked and patch applied | Emergency page now distinguishes platform-reporting support from under-18 sexual-image reporting. |

## Follow-Up Patches Recommended

- Update final parent-facing route card only after human review.
- Add `date_checked` and reviewer fields to any future print-ready route-card data.
- Keep `content/currency/whats-changing.mdx` behind pre-launch source review because it contains time-sensitive legal and platform claims.
- Re-check platform-specific AI companion, privacy, retention, age-restriction, and setting details separately before any platform-specific lesson or briefing ships.

## Remaining Launch Blockers

- Human legal review.
- Human safeguarding review.
- Final source/route re-check immediately before sale.
- Sales/landing/email copy review against the Claim Register and Gap Register.
- Full app test suite after dependencies are installed.
