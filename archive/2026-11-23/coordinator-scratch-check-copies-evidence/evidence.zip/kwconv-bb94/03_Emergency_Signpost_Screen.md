# Emergency Signpost — who to contact right now

**Canonical content for the signpost screen. Calm, non-monetised, no bespoke intervention advice — routing only.** Verified June 2026; re-check every number/URL on launch day and quarterly. A deployable version is `03_Emergency_Signpost_Screen.html`.

---

> **If a child is in immediate danger, call 999 now.**
>
> This page tells you who to contact. It does not replace the police, social services, your child's school safeguarding lead, or any helpline — it points you to them. We don't monitor, investigate, or intervene.

---

## Find your situation

**Immediate danger, or risk to life**
→ **Call 999.** If it's urgent but not life-threatening, call the police on **101**.

**Sextortion or blackmail in progress** (someone threatening to share a nude/intimate image unless paid)
→ **Stop all contact. Don't pay. Don't delete anything** (it's evidence — deactivate rather than delete accounts).
→ Tell a trusted adult.
→ Report to **CEOP**: ceop.police.uk/Safety-Centre · call **101**, or **999** if your child is at immediate risk.
→ To get an image removed, see "a nude image of an under-18" below.
*Paying tends to invite more demands. It is not the child's fault.*

**A nude or sexual image of an under-18 has been shared, or is being threatened** (including fake/AI-generated "nudify" images)
→ **Report Remove** (Childline + Internet Watch Foundation) helps under-18s get a nude image removed or pre-emptively blocked: **childline.org.uk/remove**
→ You can also use **Take It Down** (NCMEC): takeitdown.ncmec.org
*For an adult (18+), use **StopNCII.org** or the **Revenge Porn Helpline** 0345 6000 459.*

**Suspected grooming** (an adult contacting a child sexually, or pressuring them to move to a private/secret app)
→ Report to **CEOP**: ceop.police.uk/Safety-Centre
→ **999/101** if the child is in immediate or urgent danger.
*CEOP is specifically for online child sexual abuse and grooming. It does not handle bullying, fake accounts, or hacking — for those, report to the platform and to Report Harmful Content (below).*

**A scam, fraud, or money lost**
→ **Action Fraud**: reportfraud.police.uk · **0300 123 2040** (England, Wales, NI).
→ In **Scotland**, report to **Police Scotland on 101**.
→ If money moved through a bank account, **contact the bank immediately**.

**Harmful content or abuse on a platform** (bullying, fake accounts, hacking, harmful material)
→ Report it to the platform first. If that doesn't resolve it, **Report Harmful Content** (for users 13+): reportharmfulcontent.com

**Your child is distressed, or at risk of self-harm or suicide**
→ **Childline** (under-19s): **0800 1111** · childline.org.uk
→ **Shout** (24/7 text support): **text SHOUT to 85258**
→ **Samaritans** (anyone, 24/7): **116 123**
→ **Papyrus HopeLine 24/7** (under-35s, 24/7): **0300 102 2470** · **text 88247**
→ **Call 999 if their life is at risk.**

**A concern connected to school** (peer-on-peer abuse, image-sharing among classmates, bullying)
→ Contact the school's **Designated Safeguarding Lead (DSL)** first.
→ Escalate to your **local authority children's services** if needed.
→ Use **CEOP** if it involves online sexual abuse/grooming, and **999/101** if it's criminal or urgent.

**Worried about a child in general, and not sure where to start**
→ **NSPCC Helpline**: **0808 800 5000** · help@nspcc.org.uk

---

## Notes for whoever builds this screen

- Keep it to **one screen**, calm, no marketing, no upsell, no logo-heavy design. It appears in every report and as its own page linked in the site footer.
- **Do not** add "what to do" steps beyond the brief stop/don't-pay/don't-delete/tell-someone safety messages above — those are standard NCA messaging, not bespoke advice. No further instructions.
- **Routing accuracy matters:** Report Remove / Take It Down = **under-18**; StopNCII / Revenge Porn Helpline = **18+**. Action Fraud = England/Wales/NI; Scotland = Police Scotland 101. CEOP ≠ bullying/hacking. Getting these splits wrong is the common error.
- Re-verify every number and URL on launch day and quarterly. All `[verified]` as of 20 June 2026 against NCA/CEOP, IWF, NSPCC, Childline, Samaritans, Action Fraud, SWGfL/UK Safer Internet Centre.
