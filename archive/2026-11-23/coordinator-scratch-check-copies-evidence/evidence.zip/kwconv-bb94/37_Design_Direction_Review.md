# Design / Aesthetic Review (adversarial)

**20 Jun 2026.** The visual aesthetic (warm paper · cedar/copper · Source Serif 4 + IBM Plex) was accepted as canon without testing — same problem as the Bearings name. This review researched real luxury/premium/trust sites, then generated and design-director-polished **four rendered design directions** of the *same copy*, each scored. Rendered files live in `brand-design/` (served on :8767 with a chooser).

---

## TL;DR
- **The current instinct is right but under-executed.** Warm neutrals genuinely out-luxury stark white (Aesop, Toteme prove it). The gap is *restraint and refinement*, not the concept.
- **All four directions render genuinely premium** (every one scored 9/10 on premium, AA-accessible, zero-JS).
- **Biggest single win, regardless of direction:** swap **Source Serif 4 → Fraunces** (warm, optical, distinctive masthead), **retire the IBM Plex Mono labels** for tracked-out uppercase small-caps, **cool the paper** to ~`#F4F1EA`, and **demote copper to a hairline-only accent** (cedar as marks/rules, never filled buttons). That alone moves the brand from "nice indie" to "expensive editorial."

---

## The four directions (all in `brand-design/`)

| Dir | Name | premium / trust / distinct | One-line | Verdict |
|---|---|---|---|---|
| **A** | **Quiet Luxury** | 9 / 8 / 8 | Fraunces, vast whitespace, fashion-house calm | Most "expensive"; risks reading slightly cold/fashion. |
| **B** | **Premium Clinical-Trust** | 9 / **9** / 7 | Stripe/Oura clarity, one confident accent | Highest trust; least *ownable* (reads fintech/dev-tool). |
| **C** | **Elevated Warm-Editorial** | 9 / 8 / 8 | The current direction, *properly executed* | **Lowest-disruption premium win — keeps brand DNA.** |
| **D** | **Dark Concierge Luxe** | 9 / 8 / 8 | Deep canvas, champagne accent, members-club | Striking, but may feel *exclusive* to a mass-market anxious parent. |

---

## Recommendation
- **Adopt C (Elevated Warm-Editorial) as the main site** — it *is* the current direction fixed (Fraunces + cooler paper + copper-as-hairline + real whitespace), so it keeps hard-won brand equity while hitting genuine premium. Lowest risk, top scores.
- **If you want bolder/more distinctive, go A (Quiet Luxury)** — also warm enough for the audience, more fashion-forward.
- **Borrow B's "quantified-trust" pattern into whichever you pick** — present credibility as plain precise facts (sources reviewed, 30-day deletion, "reviewed [date]") on a calm canvas. It's the single clearest premium+trust move and it actively counters fear-selling.
- **Reserve D (dark) for the Concierge tier's own page**, not the main funnel — it suits the £650 white-glove offer, but dark + child-safety + exclusivity risks chilling the core £79–£99 parent.

## Universal moves (apply to any direction)
Fraunces display · retire mono labels → tracked uppercase small-caps · paper `#F4F1EA` · copper hairline-only · cedar as marks/rules not fills · ~2× the whitespace of a normal SaaS page (120–200px section padding) · quantified-trust block · real warm photography of people (Oura/Bobbie register), not textured-cream decoration · cap 4 colours per page · one idea per screen.

## Two copy flags the reviewers caught (apply to all)
1. **Soften the H1 "crisis."** Every reviewer flagged "before it becomes a crisis" as the one fear-leaning note in otherwise calm copy. Test against "before it becomes a problem."
2. **Substantiate the trust chips.** "Checked by a real person / No child data / Kept current" are assertions — link them (to the privacy notice + a "how review works" page) so they're literally evidenced, not just reassuring (ASA/DMCC-aware).

## Reference sites worth a look
Quiet luxury: The Row, Aesop, Toteme, Celine, Aman. Premium-trust: Stripe (+ Stripe Press), Oura, Mercury, Maven Clinic, Wealthsimple, Bobbie, Linear. Recommended Google Fonts: **Fraunces** (display, recommended) · Spectral / EB Garamond / Libre Caslon Display (alternates) · **Inter** or the existing IBM Plex Sans (body).
