# Keepwise full platform: build plan

**Status:** written 10 Nov 2026 after Ben approved the outline in chat ("Yes, write it"). It replaces
`KEEPWISE_FOUNDING_OFFER_BUILD_PLAN_2026-11-09.md`.
**HOLD: nothing is built from this plan until Ben has read it and said go.**

**Authority:** Ben, 9 Nov 2026: "it can't have human in the loop. It's got to be fully autonomous." Ben, 10 Nov 2026: "I
want a full platform with so much value and info and courses that it's easy to sell." Evidence: the GPT stress test and
platform design in `Next Gen Learning Platform/drafts/chatgpt-jobs/keepwise-stress-test-2026-11-10/GPT-REPLIES.md`.
Where the July automatic plan (`100_Automated_Build_Plan.md`) or the 31 Oct founding offer disagree with this plan, this
plan wins. The July engine, content, guardrails and review gates are reused, not thrown away.

## Checked against what is already built (11 Nov 2026)

The first draft of this plan missed an existing build list. This section corrects it, and the stages below have been
edited to match.

**What exists.** `docs/chat-build/KEEPWISE_QUEUE.json` is a 50-job build list (KW-001 to KW-050, revision 64, 8 Nov
2026): 13 jobs accepted, 4 blocked, 33 queued, and "none ready under current gates". On 11 Nov all 809 tests pass and the
type check is clean. None of that work is committed: it sits as 73 changed or new files in the main checkout.

**One build list.** The existing queue stays the build list. This plan re-orders it and adds the jobs it lacks. Where a
piece below is covered by an existing job, that job and its accepted work are used. Nothing is rebuilt under a new name.

| Plan piece | Already there | Existing job | Still to do |
|---|---|---|---|
| KW-A0 save the work | Nothing saved; the 13 accepted jobs are all uncommitted | none | All of it, and first |
| KW-A1 offer page | Home and pricing pages (£49 tiers); a single buy box on `codex/kw-f1` (£99 wording) | none (new) | Membership wording; re-apply the buy box on the saved work |
| KW-A2 questions to plan | Engine and strict question form proven on test content; free 8-question quiz works | KW-007, KW-013 done; KW-009, KW-015, KW-017 open | Customer screens; real content (see correction 1); on-device save |
| KW-A3 set-up steps | First-phone walkthrough for iPhone and Android, three stages, ticks kept on the device, links to Apple's and Google's own instructions | KW-033 blocked (needs real phones tested) | A check per step, "My screen looks different", dated ticks |
| KW-A4 agreement and pack | Agreement maker builds and prints; saves nothing | KW-010, KW-012 open | Pre-fill from the plan, one pack, re-check date |
| KW-A5 First Phone course | Draft scripts only; no course player | KW-036 open | All of it |
| KW-A6 free front door | Free quiz; email sign-up deliberately switched off | KW-013 done | Checklist page; sign-up storage |
| KW-A7 sample | A hand-written sample page | none | Produce it from the engine once content is published |
| KW-A8 membership unlock | Sign-in built, not yet proven with a real email service; purchase handling built with passing tests | KW-004 done; KW-005 blocked (needs a real database run); KW-006 open | KW-005 run on a local database, then KW-006 |
| KW-B1 one source | Source proof, content health controls and correction tracking | KW-016, KW-018 done | Public change record |
| KW-B2 course player | Not built | KW-036 open | All of it |
| KW-B3 My Household | Database design for a household saved on our servers; screens not connected | KW-008, KW-009, KW-011 open | Home screen (see correction 3) |
| KW-B4 What's Changed | Page and list exist; the list was last dated 20 June 2026 | KW-019, KW-020 open | Matching; refresh the list |
| KW-B5 search and app page | Catalogue, search, filters and new-app lookup over the 19 guides | KW-029, KW-030 done | The fuller page layout; facts re-checked |
| KW-B6 practice conversations | Trainer wired in; its scenarios are marked "needs safeguarding review" | KW-034 done; KW-035 open | Reviewed content |
| Stage 3 catalogue | 19 app guides, 25 topic guides and 5 age packs in the library; a before-you-buy chooser part-built; no courses | KW-022, KW-031, KW-036, KW-037, KW-041 open | The 16 courses; most tools |
| KW-D2, KW-D3 | Terms and privacy pages; account deletion queued | KW-024 open | Rewrite for a membership |

**Corrections.**

1. **The blocker is review, not building.** The engine only uses published blocks, and 10 of the 74 are published. They
   are a mixed proof set, not a first-phone set, so no real first-phone plan can be produced today. The July rule stands:
   nothing is sold before the safeguarding review (gates A0 and A) and the launch privacy and terms review (gate B0). The
   A0 pack (`105_Gate_A0_Submission_Pack.md`) is ready to send and has never been sent. So KW-G1 needs both reviews for
   the first-phone slice. To keep that small, a first-phone-only review pack is drafted as part of KW-D4.
2. **Bulk writing waits for the first review.** Gate A0 comes before bulk writing, so the 16 courses are not written in
   bulk until it is back. One course (First Phone) is drafted for the review pack.
3. **Where a family's choices live.** The built design saves a household's answers and plan on our servers under the
   adult's account (age bands and tick-box answers only; the database refuses names and free text). For the sell-test the
   choices stay on the parent's device, which is what the walkthrough already does. The server-side saving stays built
   but switched off until the privacy review has covered it. Ben decides at KW-G2.
4. **Price.** The money code is built for £49 once plus £29 a year. It already handles one payment covering a year with
   an optional renewal, so £79 is a change of numbers, not a rebuild.
5. **The old offer-page branch.** `codex/kw-f1` was cut from the last commit, which lacks the uncommitted work, and
   three of its files overlap with it. KW-A1 runs after KW-A0 and re-applies the buy box on top.
6. **Parked from the existing queue until after KW-G2:** schools (KW-038 to KW-042), translations (KW-045), recordings
   (KW-046), shared caregiver accounts (KW-025 to KW-028), the comparator (KW-032) and outcome feedback (KW-014). They
   stay queued and are not dropped.

**What can run now without any review or spending:** KW-A0, the offer page, KW-005 and KW-006 on a local database, the
on-device plan screens, the agreement pack, the course player on made-up content, and the first-phone review pack.

## What we are building

One membership for a whole household, with everything included, and no person involved for any individual family. A
parent arrives with a job to do ("the phone arrives next week"), gets it done, and then finds the rest of the platform
behind it.

| Part | Finished size | What the parent gets |
|---|---|---|
| Parent Academy | 16 short courses | Each course ends in something finished, such as a set-up phone or a signed agreement |
| Family Toolkit | 10 tools | The tools do the organising; no course ends in "now write this up yourself" |
| Apps and AI | About 50 guides | One page per app: what it is, its stated age rules, what parents can and can't control |
| Practice conversations | About 30 | Written, branching rehearsals for adults ("They say everyone else has the app") |
| My Household | One plan | Saved choices, ticked tasks and review dates in one place |
| What's Changed | Dated change list | Shows only the changes that touch this household, and says so when there are none |
| Running it | Self-service | Buying, signing in, cancelling, refunds and downloads all work as buttons |

Nothing in it is used by a child.

**Finished means:** a parent can read the offer, try a free piece, buy (once Ben switches on), and use every part above
without anyone at Keepwise touching their family's plan, and the site claims nothing beyond what works that day.

## Rules for every piece

1. **Fully automatic.** No person checks, reviews, calls or answers any individual family. One-off work on the shared
   library is fine. No AI writes advice at the moment of delivery: plans, lessons and guides are put together from
   pre-written, dated, sourced pieces.
2. **Not a monitoring product.** No monitoring, no child accounts, nothing a child uses, no features where users talk to
   each other, no open chatbot.
3. **Data.** Ask for age band, devices and apps only. No child names, birthdays, schools, screenshots or free text about a
   child. A household's choices and its plan stay on the parent's own device; our servers hold only the adult's account
   and purchase.
4. **Words.** Never "safe", "protected", "verified", "certified", "reviewed for you", "checked by a person", a guarantee,
   or help with an incident. Finished steps are labelled "Marked complete by you". No thumbs-up or thumbs-down on an app,
   and no tool declares a child "ready". No streaks, scores, badges or certificates. No fake discounts, invented
   testimonials or fake scarcity.
5. **Something happening now.** Point to official help only (999, CEOP, NSPCC, Childline). That page stays free and
   outside the paywall.
6. **Honest sales page.** Only what works today may appear on it.
7. **Dated and sourced.** Every instruction carries a source and a "last checked" date. Overdue ones are labelled or
   withdrawn, never left looking current. Public wording says "dated and sourced" only; "reviewed by" appears only where
   a named reviewer did it and a record exists.
8. **Nothing goes live.** Nothing charges, sends, publishes or deploys. No spending before revenue. Builders work on side
   branches. The build speed rules in `~/.claude/CLAUDE.md` apply: one build and at most two repair rounds per piece, one
   independent Claude check, two checks for money, sign-in or child-safety wording. Keepwise queues behind JobGuard for
   builder time, through the sole coordinator.
9. **Who does what.** Writing goes to Astra (ChatGPT) from one self-contained brief per job, then a separate check of
   every claim against its source. Code goes to the builders.

## Stage 1. The first-phone route, working start to finish (built first)

This is the first course, three of the ten tools, and the test of whether parents will pay.

| Piece | Goal | Done when | Starts from |
|---|---|---|---|
| **KW-A0** | Save the July work in progress | The uncommitted July changes in the main checkout (sign-in, billing hand-off, first-phone walkthrough, downloads) are copied onto a side branch as they are; the main checkout is left untouched; a short note says what passes and what fails | Main checkout |
| **KW-A1** | Membership offer page | Home and pricing offer one membership with the first phone as the lead promise; they list only what works today; no founder check, no three-day wait, no "first 30"; "Prevention planning, not emergency help" sits beside the buy button with NSPCC and CEOP links; price comes from one setting; buy goes to the "not open yet" hand-off; content lint, typecheck and tests pass | The work saved by KW-A0, with the single buy box from `codex/kw-f1` re-applied on top |
| **KW-A2** | Questions to instant plan | Parent picks age band, the child's device, their own device and apps; an ordered "Before you hand it over" plan appears at once, built from published blocks; a device check says upfront when a pairing can't do something; stated age and account rules are shown (for example WhatsApp's minimum age); choices and plan are saved on the device with download and re-load; tests prove no answers are stored on the server | Plan engine (`lib/blocks`, 74 blocks), `/quiz`, `lib/household` |
| **KW-A3** | Set-up steps with a test | For each supported phone pairing, every step says what the setting is for, how to do it, what it cannot do, and a check the parent runs to see it worked; "My screen looks different" offers documented alternatives or the maker's own help page, never invented steps; ticks are dated and labelled "Marked complete by you" | Apple and Google guides in `content/platforms`, guided set-up spec in `101_Tool_Build_Specs.md` |
| **KW-A4** | Agreement and handover pack | The agreement maker pre-fills from the plan's choices and includes promises from the adults too; one printable pack holds the dated set-up checklist, the agreement, conversation openers and a 30-day re-check date | `/library/family-agreement`, `17_Conversation_Library.md` |
| **KW-A5** | First Phone course | Short readable lessons with two routes ("Help me do it", "Help me understand it"); each lesson opens the matching tool with choices carried over; the course ends in the finished handover pack; no quiz score and no badge | First-phone script in `29_Masterclass_Scripts.md`, the July walkthrough |
| **KW-A6** | Free front door | First-phone checklist on screen and printable; email sign-up with a separate, unticked marketing box, stored with nothing sent; one set-up step, one lesson and the sample plan are free to view | Old KW-F3 |
| **KW-A7** | Sample from the real engine | The public sample is the plan and handover pack for a made-up family, produced by KW-A2 to KW-A4 and not written by hand | Old KW-F6 |
| **KW-A8** | Membership unlock, test only | Email-link sign-in works; a made-up "paid" event unlocks the membership and a made-up "refunded" event locks it; no real payment provider is touched | July sign-in and billing work saved by KW-A0 |

Order: KW-A0 first. Then KW-A1 (after KW-A0, see correction 5) and KW-A2 side by side. Then KW-A3 and KW-A4, then KW-A5, KW-A6 and KW-A7. KW-A8 can run
any time after KW-A0. Supported phone pairings are confirmed against Apple's and Google's current help pages in KW-A3;
where one parent phone can't manage the other kind, the plan says so at the start.

## Stage 2. The shared workings

Built once so that each new course, tool or guide is content, not a new software project.

| Piece | Goal | Done when |
|---|---|---|
| **KW-B1** | One source per instruction | Each instruction is stored once with its source, the devices and apps it applies to, its last-checked date and where it is used; changing it once changes every course, tool and guide; overdue items are labelled automatically; a public change record exists |
| **KW-B2** | Course player | Any course is content files plus one template: lessons, the two routes, tool hand-off, text first with slots for audio and video; no forced order; the First Phone course moves onto it unchanged |
| **KW-B3** | My Household | The home screen asks "What would you like to sort out?" (set something up, make a decision, learn about something, check what's changed) with the current task and plan beneath; everything is held on the device, with download and re-load |
| **KW-B4** | What's Changed | A dated change list, matched on the device against the household's choices; an honest "nothing changed for you" state; any later email is only a neutral "there are updates" nudge |
| **KW-B5** | Search and app page | Search covers the written library only; one page per app answers what it is, why a child wants it, what users can do, its stated age rules, what parents can choose, what the controls can't do and what to talk about, with source links and a last-checked date |
| **KW-B6** | Practice conversations | Written branching rehearsals: pick a situation and an opening line, see a made-up reply and what the wording gets across, save an opener; nothing is recorded or typed about the family; a live problem leaves the rehearsal for official help |

## Stage 3. Fill the catalogue in waves, most sellable first

One piece per course (`KW-C01` to `KW-C16`, numbered as below), per new tool (`KW-T03` to `KW-T10`), per batch of about
ten app guides (`KW-L1` to `KW-L3`) and per batch of about ten practice conversations (`KW-R1` to `KW-R3`). A piece is
done when it ends in its finished output, every instruction is dated and sourced, the content lint passes, and the sales
page lists it only once it works.

| Wave | Courses | New tools | Also |
|---|---|---|---|
| 1. AI and homework | 9, 10, 11 | AI Homework Agreement Maker | AI guides; a card for checking an AI answer |
| 2. Gaming and group chats | 4, 5 | New-App Decision Builder, Gaming Spending Planner | Game and messaging guides |
| 3. Starting secondary (ready before May 2027) | 3, 1, 6 | First-Device Decision Planner, Screen-Routine Builder, Caregiver and Two-Home Sheet | |
| 4. The rest | 7, 8, 12, 13, 15, 16 | Independence Review Planner, with a "what changes at 13 and 16" view | App guides up to about 50; practice conversations up to about 30 |
| 5. Last, and only after a safeguarding review | 14 | | Adult reference card and official help routes |

| No. | Course | The parent leaves with | Starting material already in this folder |
|---|---|---|---|
| 1 | Their First Tablet | A set-up and handover plan | Ages 5 to 10 script in `29_Masterclass_Scripts.md` |
| 2 | Their First Phone (Stage 1, KW-A5) | A finished handover pack | Ages 11 to 12 script; first-phone walkthrough |
| 3 | Starting Secondary School | A transition plan | `43_AgeUp_Cards_DRAFT.md`, `35_Seasonal_Template_Packs.md` |
| 4 | Understanding Gaming | A gaming agreement and spending plan | Roblox, Fortnite, Minecraft, Steam, consoles and Twitch guides; loot-box guide |
| 5 | Group Chats and Messaging | House messaging rules and openers | WhatsApp and Discord guides; cyberbullying guide |
| 6 | Screen Routines That Fit Your Family | A weekly routine | Screen-time and sleep guide; room-by-room draft |
| 7 | Social Media and Online Pressure | A decision and discussion plan | Instagram, TikTok and Snapchat guides; online challenges and dark-patterns guides |
| 8 | Privacy, Photos and Digital Footprints | House sharing rules | Privacy-footprint guide |
| 9 | AI Explained for Parents | A plain understanding and a discussion guide | AI Readiness Lab module 1 (`55_…Complete_Course_Pack.md`); AI chatbots guide |
| 10 | AI and Homework: Keeping the Thinking | An AI homework agreement | Lab module 3; AI schoolwork guide; policy generator spec |
| 11 | AI Companions and Emotional Boundaries | A boundaries discussion plan | AI companions guide |
| 12 | Scams, Deepfakes and Persuasive Content | A checking routine | Scams and critical-thinking guides |
| 13 | Conversations Without the Lecture | Practised wording | `17_Conversation_Library.md`; scenario trainer content (file 63) |
| 14 | Recognising Pressure and Manipulation | An adult reference card | Sensitive guides already drafted; held for review |
| 15 | More Independence, Less Guesswork | An independence and review plan | Age-up cards; older-band masterclass scripts |
| 16 | Getting More from Technology | A positive-use plan | Lab modules 2 and 4 |

Starting material is listed by file name. Each course brief confirms what is still accurate before anything is reused;
much of the July social-app material is aimed at under-16s and needs re-aiming.

Tools 1, 2 and 5 (Household Plan Builder, Setup Navigator, Family Agreement Maker) come from Stage 1.

## Stage 4. The switch-on pack

These are mostly documents, so they are drafted alongside Stage 1 and the sell-test does not wait for Stages 2 and 3.

| Piece | Goal | Done when |
|---|---|---|
| **KW-D1** | New facts sheet and headlines | A draft replaces the Keepwise section of the approved facts sheet, which still says £99, three working days and "checked by the founder"; Ben approves it before any wording goes public; until then the growth engine posts nothing about Keepwise |
| **KW-D2** | Terms, privacy and refund wording | Drafts for a yearly membership: 14-day refund, optional renewal, what is kept on the device and what on the server, separate marketing consent; marked draft until Ben approves (starts from file 86) |
| **KW-D3** | Self-service account | Cancel, refund under the published terms, receipts, download-my-plan and delete-my-account all work as buttons against test data |
| **KW-D4** | Claims and review pack | Every claim on the sales page is listed against the thing that makes it true; the sensitive-topic content is listed for a safeguarding review; the legal reading list is ready (starts from the July gate packs) |
| **KW-G1** (gate, Ben) | First switch-on: the sell-test | Ben adds the pay link, picks hosting, settles the name, approves the price, terms and facts sheet, decides who reviews sensitive content, and switches the first-phone route on for real parents |
| **KW-G2** (gate, Ben) | Full-platform switch-on | After the sell-test, Ben confirms the price and the order of Waves 3 to 5; the sales page widens as each wave works |

## Order and timing

Stage 1 goes first, with Stage 4's documents drafted beside it. Bulk writing for the waves waits for the first
safeguarding review (correction 2 above); only the First Phone course is drafted before then. Stage 2 follows Stage 1 in
the builder queue. Waves 3 to 5 are confirmed at KW-G2.

To catch this Christmas, Stage 1 and the pack need to be ready for Ben by about 5 December. Builder time goes to JobGuard
first, so that date may be missed. The next good moments are January (phones given at Christmas that still need setting
up) and the Year 7 season from May.

## The sell-test (KW-G1)

Real parents are shown the working first-phone route and asked to pay. Proposed pass mark, which Ben can change: of the
first 500 parents who reach the offer page from a first-phone front door, at least 10 buy, and fewer than 1 in 10 buyers
ask for a refund. If it is missed, Ben decides at KW-G2 whether to change the price, the front door or the catalogue
order before more is built.

For scale: at £79, about 320 sales a year cover a £25,000 yearly upkeep, or about 390 if VAT applies. That leaves out the
one-off cost of making the catalogue.

## Choices written into this plan

- **Price.** Working price £79 per household per year, everything included, 14-day refund, optional renewal at the stated
  price. It replaces July's £49 plus £29 a year and the £99 founding offer. It is a starting guess, not a tested price. It
  is one setting, shown nowhere public until Ben approves it at KW-G1.
- **Name.** "Keepwise" stays as the working name; it is one setting. keepwise.co.uk is a live UK site of money and
  life-admin tools under the same name. Nothing is spent on the name. Ben settles it at KW-G1 (July's alternative was
  "Bearings").
- **Choices kept on the parent's device, for the sell-test.** The cautious option for children's data. The cost: clearing
  the browser loses the plan unless it was downloaded, so download and re-load are part of KW-A2. The server-side saving
  that is already built stays switched off until the privacy review covers it (correction 3 above).
- **The social media ban is not the lead pitch.** It is a topic inside courses 7 and 15 and the "what changes at 13 and
  16" view. Never state it as already in force; re-check gov.uk before quoting a date.
- **App pages.** One page per app, never one per app and age. Start from the 19 already written and grow towards 50 only
  with a re-check schedule for each.
- **Sensitive content.** The July plan made a safeguarding review of the shared library and a legal read conditions of
  the first sale. Both stay, as one-off checks of the shared library and not of any family, and nothing is sold before
  them. Who does them, and paying for them, is Ben's call before KW-G1. The first review covers the first-phone slice
  only, to keep it small; the guides on grooming, sextortion, self-harm, nudes, pornography and radicalisation, and
  course 14, stay locked and out of that first review.
- **Dropped from the old plan.** KW-F5 (Ben's review desk), the three-working-day wait, £99, "first 30 families", "ends
  30 November", "checked by the founder", and KW-F2's form saved on the server. Ben changed the offer; these are not
  being rebuilt under new names. KW-F1's branch is kept and KW-A1 starts from it. KW-F2's branch has no work on it and
  is left as it is.
