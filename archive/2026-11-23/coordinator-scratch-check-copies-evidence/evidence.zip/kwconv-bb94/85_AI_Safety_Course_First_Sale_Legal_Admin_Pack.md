# AI Safety Course - First Sale Legal/Admin Pack

*Created 2026-06-27. Status: internal first-sale preparation pack for the founding pilot. This is not legal advice, a contract, a privacy notice, or publication-ready copy. It turns the Claude review's first-sale high finding into a decision checklist and conservative draft wording for review before any payment link is sent.*

## Why This Exists

The external AI review in `83_AI_Safety_Course_Claude_Pilot_Review_Findings.md` flagged that consumer-law and data-protection basics apply at the first paid sale, not only after the product has paying customers.

This pack supports a tiny manual pilot. It does not replace paid legal review.

## Official Source Snapshot

Checked 2026-06-27:

| Topic | Source | Relevant implication for the pilot |
|---|---|---|
| Distance selling before order | GOV.UK online and distance selling, `https://www.gov.uk/online-and-distance-selling-for-businesses` | Before order, provide business name/contact/address, description, price, payment, cancellation/loss-of-cancellation information, and information in a format the customer can save. |
| Online selling | GOV.UK online selling, `https://www.gov.uk/online-and-distance-selling-for-businesses/online-selling` | Online sales need clear pay-now wording, steps to place order, downloadable/storable terms, email address, description, total price, and confirmation email. |
| Digital content / downloads | GOV.UK online selling, same page | If supplying downloads/streaming instantly, get the customer to agree before supply and confirm they know they may lose the 14-day cancellation right; include this in confirmation. |
| Privacy information | ICO right to be informed, `https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/individual-rights/the-right-to-be-informed/` | Individuals need clear privacy information at the time personal data is collected: purposes, retention, sharing, and plain-language access. |
| Data protection fee | ICO data protection fee, `https://ico.org.uk/for-organisations/data-protection-fee/` | Organisations, including sole traders, that use personal information need to pay the ICO data protection fee unless exempt. |

## First-Sale Go/No-Go

Do not send a payment link until each item is either complete or deliberately held back from sale:

- [ ] Business name/trading name decided.
- [ ] Contact email decided.
- [ ] Business/contact address decision made. Do not improvise this into public copy without Ben's approval.
- [ ] Product description finalised in cautious parent-education terms.
- [ ] Total price shown as GBP 49.
- [ ] Payment button or payment-link text makes clear that payment is being taken.
- [ ] Terms are available in a saveable format before payment.
- [ ] Privacy notice is available before payment.
- [ ] Refund/cancellation route is stated before payment.
- [ ] Digital-content cancellation approach chosen.
- [ ] Confirmation email includes the contract/purchase summary and saveable links/copy.
- [ ] ICO fee/exemption position completed through the ICO route and recorded.
- [ ] Emergency signpost link is live and verified in `84_AI_Safety_Course_Emergency_Signpost_Verification.md`.
- [ ] Inbound-material protocol from `78`/`79` is ready before email or DM channels open.

## Digital Content Decision

Choose one operating option before sale.

### Option A - Delay Delivery

Delay digital-material delivery until after the cancellation period. This is operationally awkward for a founding pilot, but it avoids relying on instant-access cancellation wording.

Draft buyer wording:

> You can cancel within 14 days of purchase unless you ask us to start supplying the digital pilot materials sooner. If you want immediate access, use Option B wording instead.

### Option B - Immediate Manual Delivery

Use only after legal review of the checkbox wording. GOV.UK says downloads/streaming services need agreement before supply and acknowledgement that the 14-day cancellation right may be lost.

Draft checkbox wording for review:

> I want access to the digital pilot materials before the 14-day cancellation period ends, and I understand that once the digital materials are supplied I may lose my right to cancel for that digital content.

Conservative pilot recommendation:

- Do not automate instant access.
- Take payment only after the buyer sees the buyer notice, terms, privacy notice, refund/cancellation wording, and digital-content checkbox.
- Deliver manually after checking the payment and consent record.

## Draft Terms Skeleton

Use this as structure only. It is not publication-ready.

### 1. What You Are Buying

The Keepwise AI Safety Course founding pilot is parent education and household planning material. It includes short parent modules and printable starter assets.

It is not:

- legal advice;
- safeguarding advice;
- monitoring;
- crisis help;
- child assessment;
- incident review;
- a guarantee of outcomes.

### 2. Who It Is For

The pilot is for adults aged 18+ who are parents or carers. It is not child-facing and does not create child accounts.

### 3. What Not To Send

Do not send child names, school details, account handles, screenshots, messages, images, attachments, schoolwork, prompts, or live-incident details.

If something is happening now, use the emergency signpost. If suspected under-18 nude or sexual material is received, the pilot channel stops and the material is not reviewed through the pilot.

### 4. Price And Delivery

Founding pilot price: GBP 49.

Delivery is manual. Buyer receives the pilot materials within [TIMEFRAME] after payment and required confirmations.

### 5. Refunds And Cancellation

Draft position to confirm before sale:

> If you change your mind before the digital materials are supplied, email [EMAIL]. If the materials have already been supplied after your explicit request for early access, cancellation rights may be limited. This wording needs legal review before use.

Operational refund policy for the small pilot:

> If the pilot clearly is not what you expected, email [EMAIL] within [NUMBER] days. We will review refund requests manually and fairly.

### 6. Boundaries During The Pilot

The pilot cannot review live situations, child messages, images, screenshots, schoolwork, prompts, or incident facts. The only response to live concerns is the boundary reply and emergency signpost.

### 7. Changes To The Pilot

This is a founding pilot. Content may change as it is reviewed and improved.

### 8. Professional Review

The material has been built with source checks and AI-assisted issue-finding. It has not yet had paid professional legal or safeguarding sign-off.

## Draft Privacy Notice Skeleton

Use this as structure only. It is not publication-ready.

### Controller

[BEN/TRADING NAME] is responsible for the personal data collected for the founding pilot.

### Contact

[EMAIL]

### Data Collected

- parent/carer name;
- email address;
- payment status and transaction reference handled through Stripe;
- 18+ parent/carer confirmation;
- optional marketing consent;
- delivery and feedback status;
- feedback about clarity and usefulness, with no child details.

The pilot is designed not to collect child names, school details, account handles, screenshots, messages, images, attachments, schoolwork, prompts, or live-incident detail.

### Why The Data Is Used

Candidate purposes to confirm:

- deliver the paid pilot;
- manage payment/refund records;
- respond to non-urgent questions;
- ask for feedback;
- improve the pilot materials;
- send marketing only where consent is given.

### Lawful Basis

Candidate basis to confirm before sale:

- contract for buyer/admin/delivery data;
- legal obligation for accounting/payment records;
- legitimate interests for minimal product-improvement notes that contain no child detail;
- consent for optional marketing.

### Sharing

Candidate processors/services to confirm:

- Stripe for payment processing;
- email provider for delivery and support;
- any no-code form or spreadsheet tool actually used.

Do not add tools to the workflow unless the privacy notice is updated.

### Retention

Draft retention plan to confirm:

- lead records: delete or anonymise after [PERIOD];
- buyer/payment records: retain as required for accounting/tax, then delete or archive securely;
- feedback: keep only no-child-detail notes needed for product improvement;
- boundary log: record only issue type, no identifying child details.

### Rights

Plain-language notice should explain how a buyer can ask for access, correction, deletion where applicable, restriction, objection, and how to complain to the ICO.

## ICO Fee Decision

Before first sale:

1. Complete the ICO data-protection-fee route or self-assessment using the actual trading setup.
2. Record either:
   - fee paid, date, and registration/reference; or
   - exemption basis and date checked.
3. Do not write "GDPR compliant" or similar in any sales copy.

## Ben Decisions Needed

This pack cannot be completed without Ben deciding:

- trading name and contact email;
- what business/contact address can lawfully and comfortably appear;
- whether to delay delivery or use reviewed immediate-access digital-content wording;
- refund window and policy;
- exact payment provider flow and checkbox wording;
- privacy notice controller name and processors;
- ICO fee/exemption outcome.

Until these are decided, `73_AI_Safety_Course_PreRevenue_AI_Review_Findings.md` should keep first-sale legal/admin basics as open.
