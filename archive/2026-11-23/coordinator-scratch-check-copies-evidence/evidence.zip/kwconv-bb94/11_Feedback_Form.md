# Feedback Form — post-report

**Build in Tally/Google Forms, send 3 days after delivery (email #4 in `08`). Keep it to 6 questions — every extra one costs you responses.** The point is to measure the things that feed your decision gates (`00`, §7): satisfaction, whether they *acted*, and Plan intent. "Took an action" matters more than "liked it".

---

## The questions

**1. Overall, how useful was your report?**
`○ Very useful ○ Useful ○ OK ○ Not very ○ Not at all`
*(Top-2-box feeds the "report satisfaction" gate.)*

**2. Have you done — or planned — any of the actions in it?**
`○ Already done at least one ○ Planned, not done yet ○ Not yet ○ Probably won't`
*(This is the real value signal. "Already done at least one" = the behaviour that counts.)*

**3. Did it help you feel calmer or more in control — or more worried?**
`○ Calmer / more in control ○ No change ○ More worried`
*(Guards the "prevention not panic" promise. Any cluster of "more worried" = tone problem to fix.)*

**4. What was the single most useful part?**
`[short text]`
*(Tells you what to lead with in marketing.)*

**5. What was missing, or what would have made it more useful?**
`[short text]`
*(Your roadmap. Read every one.)*

**6. How likely are you to recommend it to another parent?**
`○ Very likely ○ Likely ○ Maybe ○ Unlikely`
*(Proxy for the referral gate; follow strong answers with "know a parent who'd find it useful?")*

**Optional 7. Anything else?** `[short text]`

---

## Build notes

- **No child data, no incident detail.** Add a line under Q5/Q7: *"Please don't include your child's name, school, or details of anything happening right now."*
- **One screen, no login.** Pre-fill a hidden field with the report reference if your tool allows, so you can match feedback to the funnel sheet (`12`) without asking for it.
- **Pipe results into the tracker.** Each response updates the satisfaction / action-taken / referral columns.
- **Watch for the kill-signal early:** a run of "Not very useful" + "More worried" + low recommend is your sign to fix the report before spending on acquisition — exactly the iterate/kill logic in `00`.

---

## Quick reference — which gate each question feeds

| Q | Metric | Gate it informs |
|---|---|---|
| 1 | Report satisfaction (top-2 box) | Keep ≥75% / Iterate 60–75% / Kill <60% |
| 2 | Action-taken rate | Core "real value" behaviour |
| 3 | Calm vs worried | Trust / "prevention not panic" guardrail |
| 6 | Recommend likelihood | Referral gate (≥10% of buyers refer) |
