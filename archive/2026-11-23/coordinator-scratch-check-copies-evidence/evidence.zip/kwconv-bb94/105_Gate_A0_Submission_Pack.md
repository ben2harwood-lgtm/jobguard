# Gate A0 Submission Pack — Safeguarding Architecture Pre-Read

*Created 2026-07-05. Status: ready-to-send pre-read pack for an external safeguarding professional. Gate A0 is defined in `100_Automated_Build_Plan.md` §5 (line 189): a small, early architecture review that runs after the block-taxonomy draft and **before bulk authoring**, so that the reviewer shapes the content architecture rather than vetoing ~200 finished blocks later. Approximately 15 pages. British English.*

---

## Part 1 — What Keepwise is (one page, in reviewer terms)

**The product.** Keepwise is a UK parent-facing online-safety product: a one-off purchase (£49, VAT-inclusive pilot price) that gives a parent a personalised household online-safety plan plus a guidance library, with an optional £29/yr "Stay Current" renewal for updates. Buyers are adults (18+ parent/carer, soft-gated). Children aged roughly 5–18 are the *subject* of the guidance but never users of the product.

**What it is.** Fully automated. The parent answers a ~25-question structured diagnostic — age band(s), devices, platforms, concern-awareness answers, sibling count, and one optional free-text "worry box" for the parent's own concern (PII-flagged, never parsed into the plan, never rendered). Deterministic software then assembles a plan and delivers it in under two minutes.

**The block-assembly model in three sentences.** Every sentence a customer can ever receive is written, source-checked, dated and individually **published by a human editor once**, as a tagged content block; unpublished blocks cannot be selected (`21_MASTER_BUILD_SPEC.md` §7.5, lines 191–199). At runtime a rules engine — **no LLM anywhere in the delivery path** — selects, orders and splices published blocks against the parent's answers; personalisation is by selection and sequencing, never generation, and the only interpolated variables are age band(s), ticked platform/device names and sibling count (`101_Tool_Build_Specs.md` Spec 1, AC4). Every delivered plan writes an immutable assembly log sufficient to reconstruct exactly what any customer received (`101` Spec 1, AC7).

**What it is not.** The product does **no monitoring** of any child, device, account or message. It collects **no child-identifiable data** — the public promise is enumerated: *"No child names, no dates of birth, no school names, no message uploads, no photos, no contact lists, no monitoring, and no free-text disclosures about your child"* (`100_Automated_Build_Plan.md` §1.9, line 24; the former optional child-first-name field was deleted from the questionnaire entirely — `101` Spec 1 "Data touched"). It has **no user-to-user features**, no child accounts, nothing child-facing (`21` §2 guardrails). It gives **no incident handling and no live-incident advice**: every emergency or live concern is **signposted to qualified services only** — the product routes, it never advises on an unfolding incident. It makes **no safety guarantees** and issues no verdicts; a claims lint enforces this at build time (Part 3, artefact F).

**The locked signpost constant — and why.** The crisis-signpost block that appears in every plan is a single hash-pinned constant in `lib/signpost.ts` (quoted in full in Part 3, artefact E). It is hand-verified against live sources, SHA-256-pinned, and re-checked at build **and** at render; any byte of drift hard-fails delivery — no plan can ship with an unverified crisis block (`101` Spec 1, AC6). The design motivation is a logged incident in this very project: in July 2026, commit `7df540c` had to restore the Papyrus HOPELINE247 crisis number after automated checks had **confidently "verified" the wrong state twice** — the error was caught only on the third pass, by a human (`97_No_Review_Scenario.md` line 61). The lesson drawn: for life-safety content, "an automated check said it was fine" is not assurance. Constants plus hashes plus mandatory human re-verification replace it. No template, no interpolation, no model output anywhere near that string.

**Where this review sits.** Four professional gates govern the product (`100` §5, lines 187–205): **A0** (this pre-read, ~week 3) → **A** (full block-library safeguarding review at M3 — blocks the first sale) → **B0** (launch privacy/terms/checkout/data-model — also blocks the first sale) → **B1/B2** (later features). Nothing is sold before Gates A and B0 pass; no gate is waivable.

---

## Part 2 — The review questions

These are scoped to **architecture**, not copy. The blocks mostly do not exist yet; that is the point. Please answer each in the response format in Part 5. "Blocker" answers stop authoring until resolved.

**Q1 — Taxonomy and trigger table.** Are the 11 block classes (Part 3, artefact A) and the answer→block trigger table (artefact B) sound as a safeguarding architecture? Specifically: (a) is any *class* of safeguarding-relevant content missing (i.e. something a household plan should be able to say that no class can carry)? (b) is the design rule "each block varies on at most one axis (usually age); combining is the assembler's job" safe, or are there concern×age or concern×platform combinations that genuinely need jointly-authored blocks? (c) is the fixed 11-slot report skeleton (artefact A) right — does any slot ordering worry you?

**Q2 — Severity model and the urgent-concern interrupt.** Where a questionnaire answer indicates a possibly live urgent concern (current trigger set: **sextortion, grooming, self-harm, coercion indicators**), the plan renders **signpost-first** — the verified emergency signpost above the standard flow — and the interrupt is **routing-only, never advice** (`100` §3.4 point 3, line 130; `101` Spec 1, AC12). (a) Is signpost-first-then-plan the right presentation, or should an urgent-concern answer suppress or defer parts of the standard plan? (b) Is the urgent trigger set complete — should, for example, suspected under-18 intimate-image circulation, contact-from-an-adult indicators, or eating-disorder content indicators also trigger the interrupt? (c) Is "routing-only, never advice" the right boundary for an automated product, or are there micro-instructions (e.g. "don't delete the messages") that a routing screen *must* carry to avoid harm — and if so, which exact ones?

**Q3 — The Don't-know rule.** A "Don't know" answer **never creates a factual claim and never raises a verdict or exposure band** — it lowers the stated confidence level and enqueues a "find this out" task block (`101` Spec 1, AC3; `01_Readiness_Report_System.md` §2.3). One refinement: for a defined **high-stakes settings list**, a Don't-know **raises the action priority of the discovery task** (never the band). The proposed high-stakes list (`100` §3.4 point 1, line 128): **private accounts unknown · who-can-message unknown · location sharing unknown · payment access unknown · content filters unknown.** (a) Is "uncertainty never inflates the verdict" defensible from a safeguarding standpoint, or are there answers where not-knowing *is* the risk signal and should do more? (b) Is the high-stakes list right and complete — e.g. should "talks to online-only contacts: Don't know" or "disappearing-message use: Don't know" join it?

**Q4 — Fallback strategy.** Seven questionnaire platform options have no full guide (X, Telegram, Signal, smart TV, VR, smartwatch, mobile games with chat). They get **thin honest blocks** on a fixed template — *what it is / common misunderstanding / what to check this week / what we cannot verify / library link / last-checked date / age-band notes / fallback* (`100` §2 M1, line 48). Anything genuinely unmatched gets a published **generic-platform fallback**; a stale block is auto-withdrawn and replaced by a designated **evergreen fallback** with an editor alert (`101` Spec 1, AC1). Is this honest and safe — in particular, is "what we cannot verify" the right register for platforms we cover thinly, and is silently substituting an evergreen fallback for a stale block acceptable, or should the plan disclose the substitution to the parent?

**Q5 — The high-risk concern list.** Is the concern coverage complete for UK parents of children 5–18? Three tiers to check (Part 3, artefact G): (i) the full 25-concern corpus the plan can draw on; (ii) the **second-reviewer-mandatory** set (emergency, sextortion, grooming, self-harm — `100` §4.1, line 162); (iii) the **urgent-interrupt** set (Q2 above). Please name anything missing at any tier — and anything present that you would *demote* (concerns where prominence itself could cause disproportionate parental alarm).

**Q6 — The blocked-claims list.** All customer-facing copy passes a negation-aware claims lint that fails the build on 14 banned patterns (Part 3, artefact F — `lib/content-lint.mjs` lines 26–52), plus block-level bans on "safe", "protected", "pass", "prevents", "monitors", "we noticed" and verdicts of any kind (`101` header rules). Marketing additionally bans "human-reviewed", "a real person checks", "not a chatbot", and all scarcity claims (`100` §1.6). Is this list adequate? What dangerous claim-shapes are we missing — particularly implied-outcome phrasings a worried parent would over-read?

**Q7 — Calm-block rules.** The plan includes a deliberate "don't panic about" de-escalation section. Rules (`100` §3.4 point 3, line 130; `101` Spec 1, AC12): `calm` blocks **never render above urgent action blocks** and **never render alone for a high-risk concern**; any calm-but-act block carries the estate's under-18-image **non-preservation carve-out** verbatim (Part 3, artefact H). Note: an external critique's suggested "preserving evidence" line was **rejected** — wording that could read as advice to retain under-18 intimate images never ships (`100` Appendix A). (a) Are these rules right? (b) Is deliberate de-escalation itself safe in an automated product, given we cannot see the household — or should calm blocks be conditioned more tightly on what the parent actually answered?

**Q8 — What must be ungated?** The emergency signpost page is **ungated** (reachable without login or purchase), non-monetised, and linked from the global footer and every plan/library page (`21` §7.7). Everything else sits behind purchase. Should anything else be free-to-access on safeguarding grounds — e.g. the sextortion "stop, don't pay, don't delete, tell" first-response card, or the Report Remove route explanation — even at commercial cost?

**Q9 — Open.** Anything else in this architecture that you would send back at the full Gate A review. It is far cheaper to hear it now.

---

## Part 3 — The artefacts under review

### A. The report skeleton and block taxonomy

Every plan renders the same 11 slots (`100` §3.1, line 102, from `02_Sample_Readiness_Report.md`):

> **summary → top-3 actions → exposure map → platform notes → this-week conversation → settings checklist → family-agreement clauses → emergency signpost → don't-panic → next-month → how-this-was-made footer**

The severity/interrupt layer may render the signpost **above** this flow for urgent-concern answers; the assembler never invents a section.

Block classes (`100` §3.2, lines 106–120):

| # | Class | `blockType` | Fills slot | Count | Source route |
|---|---|---|---|---|---|
| 1 | Summary openers/closers | `open` | summary | ~22 | Fresh (1–3-sentence fragments) |
| 2 | Exposure-map notes | `map` | exposure map | ~21 | Fresh |
| 3 | Top-3 action verdicts | `action` | top-3 / next-month | ~33 | Adapted from playbooks (Why / Do this / Time) |
| 4 | Platform-setting blocks | `platform` | platform notes + checklist | ~52 | Sliced from 19 platform guides; two age tiers + under-age note |
| 5 | Concern digests | `concern` | next-month / cross-refs | ~30 | Sliced (~150-word playbook digests) |
| 6 | Age-band skeletons | `band` | agreement + bundle + posture | 15 | Sliced verbatim from age-band packs |
| 7 | Conversation blocks | `conversation` | this-week conversation | ~19 | Sliced from conversation library |
| 8 | Don't-panic blocks | `calm` | don't-panic | ~13 | Adapted; calm-but-act wording carries the under-18-image carve-out (artefact H) |
| 9 | Find-this-out tasks | `task` | next-month | ~9 | Fresh; enforce the Don't-know rule (artefact D) |
| 10 | Fixed furniture | `fixed` | headers/footers | ~5 | Fresh |
| 11 | Locked signpost | `signpost` | emergency | 1 | Hash-pinned constant (artefact E). Never templated |

Total ~215–225 blocks. Age bands: **5–10 · 11–12 · 13–14 · 15–16 · 17–18** (five band packs exist in `content/agebands/`); parenting posture slides co-use → co-set → coach → consult across them. Every block carries frontmatter including `status` (draft/published/withdrawn), `triggers` (selection predicates as data, not code), provenance (`sourceFile`, `sources`), named `publishedBy`/`checkedBy`, and a `reviewBy` date — platform blocks +6 months, concern blocks +12 months, signpost +1 month (`100` §3.3, line 124).

### B. The trigger table (draft — this is what A0 shapes)

Answers come from the ~25-question diagnostic in `01_Readiness_Report_System.md` §2.2 (being revised for launch: Q1 becomes a **multi-band** select so multi-child households get per-band sections, and the optional child-first-name question is **deleted**). Answers score into six exposure domains — device & settings · contact & platform · image & location · threat-awareness gaps · AI exposure · family readiness — each rated Lower/Moderate/Higher **exposure** (never "risk score") with a confidence level (`01` §2.3). Selection then runs (`100` §3.4, lines 126–132):

| Answer signal (questionnaire key) | Trigger behaviour |
|---|---|
| `age_band` (Q1, multi-band) | Filters **every** block by `ageBands`; selects the `band.*` skeleton trio per declared band; multiple bands → one plan, sectioned per band via splice connectors |
| Sibling count (Q2) | **Interpolation only** — never selects or scores |
| Devices ticked (Q4) | Device-layer `platform.*` blocks; smart TV / VR / smartwatch → thin honest blocks |
| Bedroom/overnight use (Q5), settings setup (Q6), accounts private (Q10) | Device-settings domain inputs; Q10 "Don't know" is on the high-stakes list (artefact D) |
| Platforms/messaging/gaming ticked (Q7, Q8, Q11) | One `platform.*` block per ticked platform, **capped at 5** by tick-rate weight; overflow → library links, never dropped silently |
| Disappearing-message use (Q9), online-only contacts (Q12) | Contact & platform domain; "regularly" on Q12 raises grooming-related concern digests |
| AI tools (Q13) — companion/character apps | `concern.ai-companions` digest + conversation pairing |
| Location sharing (Q15), image understanding (Q16) | Image & location domain; Q15 "Don't know" is on the high-stakes list |
| Concern-awareness answers (Q17–Q21: sextortion, AI "nudify" images, grooming, scams, AI companions) | "Not yet" → the matching `action.*` + `conversation` pairing; answers indicating a **live** concern → severity interrupt (artefact C) |
| `knows_core_rule` (Q24) = No | **Hard-pins** `action.core-rule` — the stop / don't pay / don't delete / tell-a-trusted-adult rule — into the top-3 |
| `priority_note` (Q25, parent free-text worry box) | **Never parsed, never rendered** — PII-flagged, purged ≤30 days (`101` Spec 1 "Data touched") |

Sequencing: top-3 = fired actions sorted by (domain level desc, weight desc), max 2 per domain, at least one ten-minute technical action if device-settings ≥ Moderate; this-week conversation = `pairsWith` of action #1 plus the cornerstone "you won't be in trouble" conversation; don't-panic = top 3 fired `calm` blocks subject to the severity rules; assembly gate = only `status=published` blocks with a future `reviewBy` (`100` §3.4, points 4–5).

### C. The severity/interrupt layer

`100` §3.4 point 3 (line 130) and `101` Spec 1 AC12, verbatim in substance:

- Urgent-concern answers (**sextortion, grooming, self-harm, coercion indicators**) trigger an **interrupt**: signpost-first presentation **above** the standard 11-slot flow — **routing only, never advice**.
- `calm` blocks never render above urgent `action` blocks and never render alone for a high-risk concern.
- Any calm-but-act block carries the under-18-image non-preservation carve-out (artefact H).
- The interrupt adds no sections and generates no words — it re-orders verified published content and puts the locked signpost first.
- Persona and lint tests enforce all of the above in CI; one of the 20 pre-Gate-A adversarial persona plans is specifically the urgent-concern-interrupt case (`101` Spec 1, AC10, AC12).

### D. The Don't-know rule

`101` Spec 1 AC3, verbatim in substance:

- A "Don't know" **never creates a factual claim and never raises a verdict or exposure band** — it lowers the domain's stated confidence and emits a "find this out" `task` block (unit-tested).
- **High-stakes refinement:** for the defined list — **private accounts unknown · who-can-message unknown · location sharing unknown · payment access unknown · content filters unknown** — a Don't-know **raises the action priority of the discovery task** (never the band; unit-tested).
- Low-confidence domains are labelled honestly ("we couldn't assess this well because…"), turning gaps into actions rather than guesses (`01` §2.3).

### E. The locked signpost constant

From `lib/signpost.ts` lines 20–26 — this exact text, byte-for-byte, is the only emergency block any plan can ever contain:

```
**If something is happening right now:**
- **Immediate danger or risk to life — call 999.** Urgent but not life-threatening — **101**.
- **Online sexual abuse, grooming, or pressure to move to a private/secret app → CEOP**: ceop.police.uk/ceop-reporting/
- **A nude or sexual image of an under-18 (including fake/AI "nudify" images) → Report Remove** (Childline + IWF): childline.org.uk
- **Worried about a child and not sure where to start → NSPCC Helpline 0808 800 5000** (phone Mon–Fri 10am–4pm; email any time).
- **Your child wants to talk to someone → Childline 0800 1111** (free, confidential, under-19s).
These services help, advise and act. This plan does not — it points you to them.
```

**Verification discipline** (`lib/signpost.ts` lines 28–50; `21` §7.5 point 3; `101` Spec 1 AC6):

- The constant's SHA-256 is pinned in the same file (`SIGNPOST_SHA256`, last hand-verification 2026-07-04, cross-checked against `03_Emergency_Signpost_Screen.md` and the external source-recheck logs `68`/`84`).
- `verifySignpost()` hash-checks at **build** (test suite) and at **render** (delivery path). A mismatch throws and hard-fails delivery to a safe error page — no code path delivers a plan without a verified signpost.
- Any edit therefore *requires* re-verifying every number and URL against the live services and updating the pinned hash in the same commit. That friction is deliberate.
- Cadence: the signpost is re-verified monthly (`reviewBy` +1mo); a stale signpost is a **hard fail — no plan rendering at all** (artefact I).
- The printable emergency card renders from this constant only (`101` Spec 9).

### F. The claims lint — 14 banned patterns

Negation-aware (a required disclaimer such as "it does **not** monitor children or guarantee safety" is exempt; a naive grep is explicitly insufficient — `21` §10.3, lines 292–299). Runs on all content and rendered copy; fails the build. From `lib/content-lint.mjs` lines 26–52:

| # | Pattern (label) | Catches e.g. |
|---|---|---|
| 1 | keeps your/them/children (…) safe | "keeps your child safe" |
| 2 | guarantee …safety | "a guarantee of safety" |
| 3 | child-safe by design | — |
| 4 | fully compliant | — |
| 5 | prevents grooming/harm/sextortion/bullying/abuse | "prevents grooming" |
| 6 | never worry again | — |
| 7 | coach / coaching | service framing; the age-band posture term is allow-listed |
| 8 | protects your child/family | "protects your children" |
| 9 | blocks harmful content | — |
| 10 | predator-proof | — |
| 11 | expert-approved | — |
| 12 | guaranteed peace of mind | either word order |
| 13 | the safest way | — |
| 14 | we noticed (surveillance framing) | anything implying we watched the child |

Additional block-level bans: "safe", "protected", "pass", "prevents", "monitors", "we noticed", verdicts of any kind (`101` header rules). Marketing-side bans: "reviewed for you", "human-reviewed", "a real person checks/checked", "not a chatbot", "safe/pass/certified/protects", any founding/scarcity claim, promising unshipped tools (`100` §1.6, line 21). The product never issues schoolwork/authorship verdicts and never claims to detect or monitor anything (`21` §2 guardrails).

### G. The concern corpus (for Q5)

**Tier (i) — full 25-concern corpus** (`content/playbooks/`): sextortion · grooming · sexting & peer image-sharing · AI "nudify"/fake intimate images · self-harm, suicide & eating-disorder content · cyberbullying & peer-on-peer abuse · pornography exposure · radicalisation & extremist content · gambling, loot boxes & in-game spending · scams & money-muling · crypto/financial pressure · AI companions/character chat · AI in schoolwork · parasocial attachment · online challenges · doxxing & swatting · dark patterns & subscription traps · livestreaming · privacy & digital footprint · screen-time & sleep · critical thinking & misinformation · disclosure ("what not to say") scripts · is-this-normal de-escalation · age-up transitions · room-by-room device setup.

**Tier (ii) — second-reviewer-mandatory blocks** (author ≠ checker, explicit publish confirmation — `100` §4.1, line 162): emergency · sextortion · grooming · self-harm.

**Tier (iii) — urgent-interrupt trigger set** (`100` §3.4 point 3): sextortion · grooming · self-harm · coercion indicators.

### H. The under-18-image carve-out (estate-wide wording)

As used across the estate (canonical instance: `components/FamilyAgreementBuilder.tsx` line 79):

> "For suspected nude or sexual images of under-18s: do not save, screenshot, copy, download, forward or ask anyone to resend; use the routing card instead."

In plan voice this pairs with the age-band playbook rule — *stop, don't pay, don't delete, screenshot the threats (**never the image**), tell, report to CEOP/Report Remove*. Every calm-but-act block carries the carve-out; wording that could read as advice to *retain* such images is banned outright (an external critique's "preserve evidence" phrasing was rejected on exactly this ground — `100` Appendix A).

### I. Content-health thresholds (product-level, running in production)

`100` §3.6 (lines 143–152); green status is a condition of the first sale:

| Condition | Consequence |
|---|---|
| Emergency signpost stale | **Hard fail — no plan rendering** until refreshed |
| Any high-risk block stale | Auto-withdraw + designated fallback + editor alert |
| >10% of top-platform blocks stale | The "kept current" claim comes **off the offer page** until fixed |
| >20% of blocks stale | **Pause sales** / generic-plan mode |

A content-health dashboard surfaces all four conditions in the publish admin, which itself meets a security baseline: 2FA, role separation, second reviewer for high-risk blocks, append-only audit log, withdrawal flow, and an emergency pause-plan-generation switch (`100` §4.1).

---

## Part 4 — What Gate A0 is NOT

- **Not the full Gate A review.** Gate A runs at M3 on the *authored* corpus: every published block, the 20 adversarial persona plans, the full signpost verification chain, the claims lint output, and the setup-flow wording. Gate A — not A0 — blocks the first sale (`100` §5, line 191). A0 is the architecture pass that makes Gate A likely to succeed.
- **Not legal advice.** Privacy, terms, consumer-law and data-model review is a separate gate (B0) with a solicitor. Nothing here asks you for legal opinions, and nothing you approve here will be presented as legal clearance.
- **Not sign-off for sale.** No customer sees anything as a result of A0 passing. A0's only output is: proceed with authoring against this architecture, with your required changes applied.
- **Not an endorsement.** Your name and comments will not be used in marketing. (Marketing claims of professional approval are on the banned list.)

---

## Part 5 — Response format requested

One row per issue, in any document format you prefer:

| Item | Concern | Severity | Required change | Blocks authoring? |
|---|---|---|---|---|
| Part/artefact + the specific element (e.g. "Artefact C — interrupt trigger set") | What is wrong or missing, in a sentence or two | blocker / high / medium / low | Exact change or instruction | yes / no |

Severity definitions:

- **blocker** — the architecture is unsafe as designed; authoring must not start until changed.
- **high** — must change before the full Gate A review; authoring may proceed on unaffected classes.
- **medium** — should change before Gate A; does not hold up authoring.
- **low** — advisory; judgement call recorded for Gate A.

Please also answer Q1–Q9 directly (a sentence each is fine where you have no concern), and state plainly whether, subject to your required changes, **authoring of the ~200-block pool may begin**.

---

## Part 6 — Logistics (for Ben — delete this section before sending)

- **Who:** the independent safeguarding consultant per the audit plan's stage-3 professional-review engagement (`93_Whole_Project_Audit_and_Improvement_Plan.md` §6 stage 3 and §7 item 5 — a safeguarding professional covering routes, scenarios and disclosure wording; UK online-safety/child-protection background, e.g. former DSL or NSPCC/CEOP-experienced). Ideally the **same person** who will do Gate A at M3 — A0 is how they get context cheaply, and continuity makes Gate A faster.
- **What to send:** this file, Parts 1–5 only (remove Part 6). Optionally attach `03_Emergency_Signpost_Screen.md` and one age-band pack as background; nothing else is needed for an architecture pass.
- **Expected effort:** a pre-read of ~15 pages plus written responses — suggest quoting 2–4 hours of their time. This is paid work; it is a cash cost, budgeted separately from build hours (`100` §6.1).
- **Turnaround ask:** ~1 week. Gate A0 sits at ~week 3 of the build, after the taxonomy draft and before bulk authoring (`100` §6.2 timeline); slice-work (verbatim band skeletons, signpost, furniture) can continue during the review, but adaptation and fresh authoring wait for the verdict, so a fast turnaround directly protects the schedule.
- **When they reply:** blocker/high items get applied to the taxonomy and trigger table *before* authoring resumes; the response document is retained and referenced in the Gate A submission at M3, alongside evidence that every required change was made.
- **Booking note:** at the same time, pencil the Gate A + Gate B0 engagements for ~week 15 (`100` §5 timing rule), so the reviewers are not a bottleneck at the pilot line.
