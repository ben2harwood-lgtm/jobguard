# Is This Normal? — Proportion Guide (DRAFT)

> These are unreviewed first drafts produced 2026-06-21. Every setting path, figure and link is marked for fact-check before publishing.


---

## Is this normal? A calm proportion guide

**DRAFT — fact-check every setting path, figure and link against the live source before publishing.**

Last drafted: 2026-06

Most worries about a child's online life start with a single question: *is this normal?* Your nine-year-old wants a phone because "everyone has one." Your thirteen-year-old is on social media at 11pm. Your seven-year-old has discovered a chatbot. It is hard to know whether you are looking at an ordinary stage of growing up or a problem that needs acting on.

This guide gives you general, UK-wide proportion — what the research says is common across all children of a given age. It is here to take the heat out of the "everyone else is letting them" feeling, and to help you decide from a calm place rather than a worried one.

Two things this guide is **not**. It is not an assessment of *your* child — population averages describe a whole country, not the child in front of you, and what is right for your home is yours to decide. And it is never a reason to wave away a real concern. If something specific is worrying you, the number being "normal" does not make it fine. There is a signpost at the end for exactly that.

---

## How to read these numbers

- **"Common" is not "right for your child."** A figure like "most 11-year-olds own a phone" tells you that you are not an outlier either way — whether you have given a phone or held off. It does not tell you what your child is ready for. That judgement is yours.
- **These are population figures, surveyed and dated.** They come from large UK studies, mostly Ofcom and Internet Matters. They change year on year; the dates matter, so they are shown.
- **Averages hide a lot.** Within any age, some children do far more of something and some far less. Your child sitting away from the average is, by definition, normal too.
- **A trend is not a target.** "Use is rising" is a description, not advice to keep pace with it.

---

## When children get phones

The clearest pattern in the UK data is that **the move to secondary school is the tipping point** for a first smartphone, not any particular birthday before it.

- Smartphone ownership rises sharply from **56% of 10-year-olds to 83% of 11-year-olds** — the year most children start Year 7 (Ofcom, *Children and Parents: Media Use and Attitudes*, May 2026).
- Below that age, owning a *smartphone* is much less common, though many younger children use a **family tablet** to go online — around three-quarters of 8–9s use a tablet [verify exact figure against the 2026 report].

What this means in practice: if you are weighing up a phone around the end of primary school, you are in the middle of the crowd whichever way you decide. Plenty of parents give a first phone at the secondary-school move; plenty give a simpler "call-and-text" phone first, or wait. None of those is unusual.

If it helps to separate the two questions — *a phone* and *a smartphone with full internet and apps* — that is a reasonable way to think about it. A device that makes calls is a different decision from a device that opens every app.

---

## Social media use by age

Social media use is widespread well below the platforms' own minimum ages (usually 13). That is the reality the figures describe — it is not a recommendation.

- **Younger children:** a growing minority of 5–7s use social media apps, often on a parent's account or alongside an adult, though a growing share use it independently [verify split against the 2026 report].
- **Primary-to-secondary:** most children have their own account well before the minimum age — around **79% of 3–17s** have their own profile on at least one social media, messaging or video-sharing site, and around **40% of under-13s** have a social-media profile despite being under the minimum age (Ofcom, 2025).
- **Teenagers:** social media use is close to universal among teenagers; almost all are signed up to at least one platform — around **97% of 13–17s** have their own profile on a social media, messaging or video-sharing site (Ofcom, 2025) [verify framing].
- **What they mostly do:** about **two-thirds (65%)** of 8–17 social-media users say they mainly read, watch, follow or "like" content, against around a third (34%) who post, share or comment (Ofcom, 2026). For most children, most of the time, it is watching rather than broadcasting.

A note worth keeping in view: a sizeable minority of children are signed up with an **age of 18 or over**, which lets them past some protections. Ofcom's *Children's Online User Ages* research found around a third (32%) of 8–17s had a user age of 18+. If your child is on a platform, it is worth checking the birth date on their account.

**The under-16 question.** A widely discussed restriction on under-16s using social media is **announced UK government policy but not yet in force** — regulations are expected to be laid late 2026, with implementation around Spring 2027 [verify commencement before relying on it]. As of this drafting, there is no live legal ban — so "everyone says it's banned now" is not yet accurate.

---

## Time online and screen time

There is no official "right amount" of screen time in the UK, and the research is about how much children *do* use screens, not how much they *should*.

- Time online **rises with age**: the most recent Ofcom figures describe 8–14s spending the equivalent of around one day a week online and 15–17s around two days a week [verify exact framing against the May 2026 report].
- The NHS does not set a single national screen-time limit; its guidance focuses on **sleep, activity, mealtimes and content** rather than a fixed number of minutes [verify current NHS wording].

The useful takeaway is that comparing your child's total hours to a neighbour's is rarely the point. What the child is doing, whether it displaces sleep and activity, and whether they can step away are more telling than the count itself.

---

## AI and chatbots

This is the fastest-moving area, so the figures are newest and will date quickest.

- AI tools are now mainstream among children: around **56% of 8–17s** use them, rising to **66% of 16–17s** (Ofcom, May 2026).
- Using AI for *company* is much less common but no longer rare — around **11% of 8–17s who use AI** said they had used it as someone to talk to or "as a friend" (Ofcom, May 2026).

So a child using a chatbot for homework, ideas or curiosity is firmly in the mainstream. A child leaning on one as a confidant is in a smaller group, and is the pattern worth gently noticing — not because using it is wrong, but because an AI is not a friend or a counsellor. If a child is in distress, the right place to turn is a trusted person or a helpline, not a bot.

---

## Seeing something upsetting

Some exposure to unpleasant or unsettling content online is, sadly, common rather than rare — and saying so is not the same as accepting it.

- Internet Matters reported that **67% of 9–17s** had experienced some form of harm online over the year (*Children's Wellbeing in a Digital World Index*, 2025).
- The most common were **false information (around 41%)**, being **contacted by strangers (around 27%)**, seeing **violent content (around 22%)**, and getting **bullying or abusive messages from people they don't know (around 19%)** (Internet Matters, 2025).

Reading those numbers, two things can be true at once. Encountering something upsetting is common enough that it is not a sign you have done anything wrong as a parent. And a specific incident affecting your child still deserves to be taken seriously on its own terms. "Lots of children see this" is context, not comfort, and never a reason to brush off what your child tells you.

The single most protective ordinary habit the research and the helplines point to is an **open, non-judgemental relationship** — a child who believes they can tell you something bad without being punished or losing their device is a child who tells you early. That is a conversation, not a setting.

---

## So — is this normal?

For most of the everyday questions, the honest answer is: **probably, yes.** A first phone at the start of secondary school, social media use that is mostly watching, a chatbot used for homework, the occasional upsetting thing seen and shrugged off — these sit squarely inside what UK children of that age commonly do.

Knowing that is meant to lower the temperature, not to settle every decision. "Common" still leaves you to choose what your home does. And it never overrides your own read of your own child.

---

## If you are worried about *your* child — here is where to go

Proportion is for calming general worry. It is **not** for a live concern. If something specific is happening, skip the averages and go straight to the right help.

- **A child is in immediate danger** — call **999**.
- **Online sexual abuse, grooming, or someone pressuring a child to move to a private/secret app** — report to **CEOP**: ceop.police.uk/ceop-reporting.
- **A nude or sexual image of an under-18 has been shared or is being threatened (including fake/AI "nudify" images)** — **Report Remove**, run by Childline and the Internet Watch Foundation, helps under-18s get an image removed or blocked: childline.org.uk/remove.
- **Worried about a child in general and not sure where to start** — **NSPCC Helpline**: **0808 800 5000**.
- **Your child wants to talk to someone themselves** — **Childline**: **0800 1111** (free, confidential, under-19s).

These services help, advise and act. This guide does not — it points you to them. We don't monitor, investigate or intervene, and nothing here replaces the police, your child's school safeguarding lead, or a helpline.

---

## Sources

- Ofcom, *Children and Parents: Media Use and Attitudes Report 2026* (published 21 May 2026) — smartphone ownership by age, social media use among 5–7s, watching vs posting (65%/34%), AI use, time online. ofcom.org.uk/media-use-and-attitudes/media-habits-children
- Ofcom, "Younger phone owners, the rise of AI, and consumption over creation" (May 2026). ofcom.org.uk/online-safety/protecting-children
- Ofcom, *Children and Parents: Media Use and Attitudes Report 2025* (published 7 May 2025) — own-profile figures (79% of 3–17s; ~40% of under-13s; 97% of 13–17s). ofcom.org.uk/media-use-and-attitudes/media-habits-children
- Ofcom, *Children's Online User Ages* research ("A third of children have false social media age of 18+") — user-age findings (32% of 8–17s have a user age of 18+). ofcom.org.uk/online-safety/protecting-children
- Internet Matters, *Children's Wellbeing in a Digital World Index 2025* — proportion experiencing harm and types of harm. internetmatters.org/hub/research
- NHS, advice on children and screen time [verify current page and wording]. nhs.uk
- CEOP Safety Centre. ceop.police.uk/ceop-reporting
- Report Remove (Childline + Internet Watch Foundation). childline.org.uk/remove
- NSPCC Helpline 0808 800 5000. nspcc.org.uk
- Childline 0800 1111. childline.org.uk

*All figures and links are dated and marked for fact-check. Re-verify every percentage, date and URL against the live source before publishing, and refresh the AI and harm figures at least annually — they move fast.*
