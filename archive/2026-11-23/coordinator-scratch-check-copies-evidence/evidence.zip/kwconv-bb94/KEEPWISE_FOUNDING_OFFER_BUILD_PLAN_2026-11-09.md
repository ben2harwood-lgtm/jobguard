# Keepwise founding offer: build plan

> **STATUS: REPLACED, 10 Nov 2026. Do not build from this.** Ben ruled on 9 Nov that Keepwise has no person in the loop,
> and on 10 Nov approved a full-platform plan in chat ("Yes, write it"). The plan to use is
> `KEEPWISE_FULL_PLATFORM_BUILD_PLAN_2026-11-10.md`. This file is kept as history.

**Status (historical):** plan of record for the 2026 founding offer. Written 9 Nov 2026 at Ben's request ("plan it out, do the
build plan, start building").
**Authority:** Ben's 31 Oct 2026 approval of the founding offer (`Next Gen Learning Platform/drafts/30-day-sales-plans-2026-10-31.md`
§1) and the approved facts sheet (`Next Gen Learning Platform/drafts/engine-approval-pack-2026-10-31.md`, Keepwise section).
Where `100_Automated_Build_Plan.md` (July: £49, fully automatic, no human check) disagrees, the 31 Oct offer wins:
**£99 one-off, a year of updates, first 30 families or until 30 November, every plan checked by the founder, Ben Harwood,
delivered within 3 working days.** The July plan's block engine and content are reused, not thrown away.

**Finished means:** a parent can read the offer, get the free checklist, buy (once Ben switches the pay link on), fill a
three-question form, and receive a plan Ben has checked, with nothing on the site claiming more than this.

**Rules for every piece:** words come only from the approved facts sheet and headlines. Never "keeps children safe",
"verified", a guarantee, or incident help. The form asks for age band, devices and apps only: no child names, no school,
no screenshots. Nothing charges, sends, publishes or deploys. Builders work on a side branch from the last commit; the
uncommitted July changes in the main checkout are left alone.

## Stages and pieces

| Stage | Piece | Goal | Done when |
|---|---|---|---|
| 1. Offer on the site | **KW-F1** | One £99 founding offer on the home and pricing pages | Only the £99 plan is offered; approved headline, facts and buttons; "checked by the founder, Ben Harwood"; "Prevention planning, not emergency help" beside the buy button linking NSPCC and CEOP; concierge and other tiers out of the nav; buy goes to the existing checkout hand-off, which says "not open yet" until Ben adds a pay link; content lint, typecheck and tests pass |
| 1. Offer on the site | **KW-F2** | The three-question form after buying | Form asks age band, devices and apps only; refuses anything that looks like a name or school (existing `lib/pii.ts`); confirmation says the plan arrives within 3 working days; answers saved with made-up test data; tests prove no other field is stored |
| 2. Free checklist | **KW-F3** | Free first-phone checklist with email sign-up | One-page checklist (is the child ready, settings before handing it over, what to agree) on screen and printable; email sign-up stored, nothing sent; links to the £99 plan and the Cue founding list |
| 3. Plans Ben checks | **KW-F4** | Draft a family's plan from their form | Each saved form produces a draft plan from published blocks via the existing engine, waiting for Ben; tests with made-up families |
| 3. Plans Ben checks | **KW-F5** | Ben's review desk | Ben can open a draft, edit it, mark it checked and export a printable plan plus ready-to-paste email text; nothing is sent automatically |
| 3. Plans Ben checks | **KW-F6** | Sample plan matches the £99 plan | The public sample is a checked plan for a made-up family, produced by KW-F4/F5 |
| 4. Switch-on pack | **KW-F7** | Terms and privacy match the offer | Draft terms and privacy text updated for £99, Ben-checked delivery and the three-question form; marked draft until Ben approves |
| 4. Switch-on pack | **KW-G1** (gate, Ben) | Switch on | Ben adds the pay link, chooses hosting, gets the name checked by a lawyer, approves terms and switches it on |

Order: KW-F1 and KW-F2 first (in parallel), then F3, then F4 → F5 → F6, then F7. KW-G1 is Ben's.
