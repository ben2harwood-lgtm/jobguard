# AI Safety Course - Pre-Revenue AI Review Findings

*Created 2026-06-27. Status: findings log for AI-assisted legal and safeguarding review. Internal and external/cross-model AI review findings are recorded here before deciding what can enter a founding pilot.*

## Review Status

| Review | Status | Reviewer / model | Date | Notes |
|---|---|---|---|---|
| Internal legal-risk AI pass | run | Codex internal pass | 2026-06-27 | Not independent or professional; used to find obvious pilot-copy issues. |
| Internal safeguarding-risk AI pass | run | Codex internal pass | 2026-06-27 | Not independent or professional; used to find obvious pilot-copy issues. |
| External/cross-model legal AI review | run | Claude Opus 4.8 Max, combined pilot review | 2026-06-27 | Raw response captured in `83_AI_Safety_Course_Claude_Pilot_Review_Findings.md`; this did not include the full evidence layer. |
| External/cross-model safeguarding AI review | run | Claude Opus 4.8 Max, combined pilot review | 2026-06-27 | Same combined pass as above; issue-finding only, not professional sign-off. |
| Post-review patch pass | run | Codex | 2026-06-27 | Blocker and high patches applied and independently re-verified in current copy 2026-07-03; first-sale legal/data basics (85/88) remain open; paid professional review still required. |

## Findings Log

| Reviewer | File / section | Finding | Severity | Required change | Status |
|---|---|---|---|---|---|
| legal AI / safeguarding AI | file + section | issue | blocker/high/medium/low | exact change | open/patched/accepted risk/defer to human |
| Internal safeguarding-risk AI pass | `76_AI_Safety_Course_Founding_Pilot_Sales_Page_Copy.md` CTA/footer | "Ask a question first" and generic email CTA could invite live-situation detail by email. | medium | Reframe as non-urgent questions and keep emergency signpost adjacent. | patched |
| Internal safeguarding-risk AI pass | `77_AI_Safety_Course_Founding_Pilot_Outreach_Copy.md` warm and group outreach | Outreach invited replies/messages without repeating the no child-detail/live-situation boundary in every likely reply path. | medium | Add wording not to send child details, screenshots, messages, images, or live-situation information; route live/urgent concerns to emergency signpost. | patched |
| Internal legal-risk AI pass | `76_AI_Safety_Course_Founding_Pilot_Sales_Page_Copy.md` whole page | Pilot copy correctly states no paid professional sign-off, but must not be edited later into "reviewed" or "expert approved" language before paid review. | high | Keep copy under pre-publish scan and repeat the no-formal-review wording before publication. | patched - operating guardrail |
| Internal safeguarding-risk AI pass | `74` and `75` pilot materials | Core modules are lower-risk, but any parent question about a live situation during delivery could pull founder into incident advice. | high | Use the boundary reply in `78`; do not answer incident facts; record no identifying details. | patched - operating guardrail |
| Claude external combined review | `79`, `78`, `80` inbound channels | No founder protocol for unsolicited child data or suspected under-18 sexual/nude images arriving by email, DM, or public comments. | blocker | Add inbound protocol: do not open/preview/download/save/copy/screenshot/forward/upload unsolicited material; boundary reply only; no identifying detail in log; stop pilot and seek qualified advice if suspected under-18 nude/sexual material arrives. | patched for pilot; legal/safeguarding review still required |
| Claude external combined review | Emergency signpost / `[EMERGENCY LINK]` | Every live-concern route depends on the emergency signpost, but the signpost was not included in the review slice and had to be checked line by line. | blocker | Verify `app/emergency/page.tsx`; patch route wording; record verification. | patched in `84`; re-check before first sale |
| Claude external combined review | `78`, `app/emergency/page.tsx`, `components/FamilyAgreementBuilder.tsx` | The Family Agreement builder was not included in the Claude slice, and the live emergency page needed direct verification. | high | Confirm builder guardrails through code/test scan; verify emergency page separately. | patched for current code; rerun before publication |
| Claude external combined review | `78` payment/admin, `72` pilot scope | First paid sale still needs pre-contract information, cancellation/refund wording, plain terms, privacy notice, and ICO/data-protection fee decision. | high | Add these first-sale basics before sending a payment link. | open - draft pack in `85`; Ben/legal decisions needed |
| Claude external combined review | `80` lead tracker | Tracker allowed "school" as a pilot source, conflicting with school/PTA gate. | high | Remove school as a lead source before professional review. | patched |
| Claude external combined review | `70`/`71` review scope | Claude pass did not include the full evidence layer, lib data, or all app code, so it cannot vouch for claim sourcing or all tool behaviour. | high | Record limitation; run source/tool checks separately before sale. | accepted limitation; source/tool checks ongoing |
| Claude external combined review | `74`/`75` companion AI watchpoints | Watchpoints could read like a child-risk checklist despite no-diagnosis wording. | medium | Reframe as conversation openers and keep no-assessment wording adjacent. | patched |
| Claude external combined review | `76` CTA | Deprecated "Ask a question first" remained in sales copy. | medium | Use only "Ask a non-urgent question first." | patched |
| Claude external combined review | `72`/`76` source and naming copy | "AI Safety Course" and "Uses UK official sources" could imply stronger current-source or safety-outcome claims than intended. | medium | Keep parent-education descriptor and soften source claim to publicly available UK guidance. | patched |
| Claude external combined review | `80` lead tracker | Adult name plus child age band fit created avoidable personal-data linkage. | medium | Remove child age-band tracking and add no-child-detail data note. | patched |
| Claude external combined review | `78` build status vs `73` review status | AI review status was inconsistent across files. | medium | Reconcile statuses. | patched |

2026-07-03 follow-up audit re-verified patched items (76 CTA, 76 no review-claims, 80 school source removed, boundary replies in 77/78/79) in current copy.

## Blocker Rules

Treat any of the following as blocker unless explicitly negated or contained by route-only wording:

- save, screenshot, copy, download, forward, or request suspected under-18 nude/sexual images;
- ask for child names, school, handles, screenshots, messages, images, voice, schoolwork, prompts, or live-incident detail;
- use AI to judge real messages, images, schoolwork, or incidents;
- classify a real message as grooming or safe;
- classify a real request as fraud or safe;
- give a safety, legal, safeguarding, or compliance guarantee;
- tell parents to investigate, negotiate, confront, or collect more material in a live incident;
- imply paid professional legal/safeguarding review has happened.

## Patch Rules

For every blocker or high finding:

1. Patch the source file.
2. Add or adjust a guardrail test if the issue could recur mechanically.
3. Run content lint.
4. Re-run focused guardrail scans.
5. Mark the finding as patched only after the check passes.

## Pilot Clearance Note

This file may support a founding pilot decision only after:

- both AI reviews are run;
- all blocker/high findings are patched or removed from pilot scope;
- the pilot scope in `72_AI_Safety_Course_PreRevenue_Paid_Pilot_Scope.md` is followed;
- the pilot copy does not claim legal/safeguarding review or expert approval.

It does not replace paid legal or safeguarding review.
