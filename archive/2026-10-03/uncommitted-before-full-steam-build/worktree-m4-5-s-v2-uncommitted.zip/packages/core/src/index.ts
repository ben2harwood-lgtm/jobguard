/** Domain-only package. Network, database, vendor and platform imports are forbidden. */
export const CORE_PACKAGE = "@jobguard/core" as const;
export * from "./allocation.js";
export * from "./fee.js";
export * from "./fee-statement.js";
export * from "./job.js";
export * from "./capture.js";
export * from "./money.js";
export * from "./quantity.js";
export * from "./review.js";
export * from "./rational.js";
export * from "./tax.js";
export * from "./quote.js";
export * from "./quote-document.js";
export * from "./acceptance.js";
export * from "./activation.js";
export * from "./decision-checks.js";
export * from "./variation.js";
export * from "./proof.js";
export * from "./final-account.js";
export * from "./customer-billing.js";
export * from "./recovery.js";
export * from "./recovery-case.js";
export * from "./recovery-eligibility.js";
export * from "./commercial-integrity.js";
export * from "./job-import.js";

export * from "./materials.js";
export * from "./purchase-order.js";
export * from "./supplier-documents.js";
export * from "./supplier-facts.js";
export * from "./supplier-fact-corpus.js";
export * from "./supplier-matching.js";
export * from "./discrepancy.js";
export * from "./readiness.js";
export * from "./inbox-relevance.js";
export * from "./evidence-pack.js";

export * from "./recovery-message.js";
