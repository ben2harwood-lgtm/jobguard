import { describe, expect, it } from "vitest";
import { deriveSyncTokenClaimsV1, evaluateSyncDownloadV1, pageSyncDownloadV1, planSyncReconcileV1, SyncDownloadContractError } from "../../packages/core/src/sync-download.js";
const uid = (n: number) => `${String(n).padStart(8, "0")}-0000-4000-8000-000000000001`;
const T1 = uid(1), T2 = uid(2), USER = uid(10), MEMBER = uid(11);
const job = (n: number, tenantId = T1, extra: Record<string, unknown> = {}) => ({ tenantId, jobId: uid(1000 + n), workOrderId: uid(5000 + n), reference: `WO-${n}`, priority: "routine", issuedOn: "2026-10-01", dueOn: null, openVisitId: null, ...extra });
const authority = (over: Record<string, unknown> = {}) => ({ userId: USER, tenantId: T1, membershipId: MEMBER, role: "operative", status: "active", assignedJobIds: [uid(1001), uid(1002)], ...over });
const request = (over: Record<string, unknown> = {}) => ({ version: "sync-subscription-request.v1", requestedTenantId: T1, profile: "contractor_assigned_jobs.v1", ...over });
const facts = (over: Record<string, unknown> = {}) => ({ version: "sync-download-facts.v1", environment: "synthetic_demo", request: request(), authority: authority(), source: [job(1), job(2), job(3)], ...over });
const base = evaluateSyncDownloadV1(facts({ authority: null }));

describe("adversarial", () => {
  it("proto keys", () => {
    const polluted = JSON.parse(`{"version":"sync-download-facts.v1","environment":"synthetic_demo","request":${JSON.stringify(request())},"authority":${JSON.stringify(authority())},"source":[{"tenantId":"${T1}","jobId":"${uid(1001)}","__proto__":{"workOrderId":"${uid(5001)}","reference":"PROTO","priority":"routine","issuedOn":"2026-10-01","dueOn":null,"openVisitId":null}}]}`);
    const d = evaluateSyncDownloadV1(polluted);
    console.log("proto source row ->", JSON.stringify(d));
    const pa = JSON.parse(`{"version":"sync-download-facts.v1","environment":"synthetic_demo","request":${JSON.stringify(request())},"authority":{"__proto__":{"status":"active"},"userId":"${USER}","tenantId":"${T1}","membershipId":"${MEMBER}","role":"operative","assignedJobIds":["${uid(1001)}"]},"source":[]}`);
    console.log("proto authority ->", JSON.stringify(evaluateSyncDownloadV1(pa)));
    const req = JSON.parse(`{"version":"sync-subscription-request.v1","requestedTenantId":"${T1}","profile":"contractor_assigned_jobs.v1","__proto__":{"tenantId":"${T2}"}}`);
    console.log("proto request ->", JSON.stringify(evaluateSyncDownloadV1(facts({ request: req }))).slice(0, 120));
    for (const role of ["constructor", "__proto__", "toString", "hasOwnProperty"]) expect(evaluateSyncDownloadV1(facts({ authority: authority({ role }) }))).toEqual(base);
    const inherited = Object.create({ status: "active" }); Object.assign(inherited, { ...authority() }); delete inherited.status;
    console.log("inherited status ->", evaluateSyncDownloadV1(facts({ authority: inherited })).reason);
    const nullproto = Object.assign(Object.create(null), authority());
    console.log("null-proto authority ->", evaluateSyncDownloadV1(facts({ authority: nullproto })).outcome);
  });
  it("case / unicode", () => {
    const up = T1.toUpperCase().replace(/0/g, "0");
    const U1 = "0000000A-0000-4000-8000-000000000001", L1 = U1.toLowerCase();
    console.log("auth upper/request lower", evaluateSyncDownloadV1(facts({ authority: authority({ tenantId: U1 }), request: request({ requestedTenantId: L1 }), source: [job(1, L1)] })).reason);
    console.log("assigned upper/source lower rows", evaluateSyncDownloadV1(facts({ authority: authority({ assignedJobIds: [uid(1001).toUpperCase()] }) })).rows.length);
    console.log("fullwidth", evaluateSyncDownloadV1(facts({ request: request({ requestedTenantId: T1.replace("1", "１") }) })).reason, up.length);
    console.log("Operative", evaluateSyncDownloadV1(facts({ authority: authority({ role: "Operative" }) })).reason, evaluateSyncDownloadV1(facts({ authority: authority({ status: "Active" }) })).reason, evaluateSyncDownloadV1(facts({ authority: authority({ role: "operative​" }) })).reason);
  });
  it("duplicates", () => {
    const src = [job(1), job(1, T1, { reference: "DUP" }), job(2)];
    const d = evaluateSyncDownloadV1(facts({ source: src }));
    console.log("dup rows", d.rows.map(r => r.reference));
    const p1 = pageSyncDownloadV1({ facts: facts({ source: src }), afterJobId: null, pageSize: 1 });
    const p2 = pageSyncDownloadV1({ facts: facts({ source: src }), afterJobId: p1.nextAfterJobId, pageSize: 1 });
    console.log("dup paging", p1.rows.map(r => r.reference), p2.rows.map(r => r.reference));
    const dupDeliv = planSyncReconcileV1({ version: "sync-reconcile.v1", delivered: [uid(1003), uid(1003)], decision: base });
    console.log("dup delivered tombstones", dupDeliv.tombstones.length);
  });
  it("paging cursor edges", () => {
    for (const pageSize of [NaN, -1, 1.5, Infinity, "10" as unknown as number]) expect(() => pageSyncDownloadV1({ facts: facts(), afterJobId: null, pageSize })).toThrow(SyncDownloadContractError);
    for (const afterJobId of ["", "-1", "x", "../"]) expect(() => pageSyncDownloadV1({ facts: facts(), afterJobId, pageSize: 1 })).toThrow(SyncDownloadContractError);
    const last = pageSyncDownloadV1({ facts: facts(), afterJobId: "ffffffff-ffff-4fff-bfff-ffffffffffff", pageSize: 1 });
    expect(last.rows).toEqual([]); expect(last.nextAfterJobId).toBeNull();
    const exact = pageSyncDownloadV1({ facts: facts(), afterJobId: null, pageSize: 2 });
    console.log("exact-fit next", exact.nextAfterJobId);
    console.log("refused page invalid facts", pageSyncDownloadV1({ facts: {}, afterJobId: null, pageSize: 1 }).reason);
  });
  it("time edges", () => {
    const input = { version: "sync-token-input.v1", environment: "synthetic_demo", facts: facts(), generation: 0, issuedAtSeconds: 100, expiresAtSeconds: 200, audience: "a" };
    for (const bad of [{ expiresAtSeconds: 100 }, { expiresAtSeconds: 99 }, { issuedAtSeconds: 1.5 }, { expiresAtSeconds: NaN }, { expiresAtSeconds: Infinity }, { issuedAtSeconds: -1 }, { generation: 0.5 }]) expect(() => deriveSyncTokenClaimsV1({ ...input, ...bad })).toThrow(SyncDownloadContractError);
    const past = deriveSyncTokenClaimsV1({ ...input, issuedAtSeconds: 0, expiresAtSeconds: 1 });
    const forever = deriveSyncTokenClaimsV1({ ...input, issuedAtSeconds: 0, expiresAtSeconds: Number.MAX_SAFE_INTEGER });
    console.log("past exp accepted", past.exp, "forever accepted", forever.exp);
    const realistic = deriveSyncTokenClaimsV1({ ...input, issuedAtSeconds: Date.now(), expiresAtSeconds: Date.now() + 3600_000 });
    console.log("iat/exp ms used as JWT seconds would expire in year", new Date(realistic.exp * 1000).getUTCFullYear());
  });
  it("missing authority / cleanup", () => {
    const { authority: _drop, ...noAuth } = facts();
    const missing = evaluateSyncDownloadV1(noAuth);
    console.log("authority key absent ->", JSON.stringify(missing));
    const malformed = evaluateSyncDownloadV1(facts({ authority: authority({ status: "revoked", role: "" }) }));
    console.log("revoked but malformed role ->", malformed.reason, malformed.cleanup);
    const plan = planSyncReconcileV1({ version: "sync-reconcile.v1", delivered: [uid(1001)], decision: missing });
    console.log("reconcile after missing authority ->", plan.outcome, plan.keep);
    const reassigned = planSyncReconcileV1({ version: "sync-reconcile.v1", delivered: [uid(1001), uid(1002)], decision: evaluateSyncDownloadV1(facts({ source: [job(1, T2), job(2)] })) });
    console.log("reassigned to other tenant ->", JSON.stringify(reassigned.tombstones));
    const srcInvalid = evaluateSyncDownloadV1(facts({ source: [job(1, T1, { priority: "x" })] }));
    console.log("source_invalid reconcile ->", planSyncReconcileV1({ version: "sync-reconcile.v1", delivered: [uid(1001)], decision: srcInvalid }).outcome);
    // forged decision: refused but cleanup none
    console.log("forged allowed decision w/ extra row", planSyncReconcileV1({ version: "sync-reconcile.v1", delivered: [uid(1001)], decision: { ...base, outcome: "allowed", reason: "authority_required", cleanup: "required", rows: [] } }).outcome);
  });
  it("identical refusal shape and key order", () => {
    const variants = [facts({ authority: null }), facts({ authority: authority({ status: "x" }) }), facts({ authority: authority({ tenantId: T2 }) }), facts({ request: request({ requestedTenantId: T2 }) }), facts({ authority: authority({ role: "owner" }) }), facts({ authority: authority({ status: "revoked" }), source: Array.from({ length: 5000 }, (_, i) => job(i)) })];
    const s = variants.map(v => JSON.stringify(evaluateSyncDownloadV1(v)));
    expect(new Set(s).size).toBe(1);
    const t = (f: unknown) => { const st = process.hrtime.bigint(); for (let i = 0; i < 200; i++) evaluateSyncDownloadV1(f); return Number(process.hrtime.bigint() - st) / 200 / 1000; };
    const big = Array.from({ length: 2000 }, (_, i) => job(i));
    console.log("timing us: other-tenant", t(facts({ request: request({ requestedTenantId: T2 }), source: big })).toFixed(0), "revoked", t(facts({ authority: authority({ status: "revoked" }), source: big })).toFixed(0), "null", t(facts({ authority: null, source: big })).toFixed(0), "allowed", t(facts({ source: big, authority: authority({ assignedJobIds: big.map(j => j.jobId) }) })).toFixed(0));
  });
});
