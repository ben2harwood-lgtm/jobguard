import { expect, it } from "vitest";
import { evaluateSyncDownloadV1 } from "../../packages/core/src/sync-download.js";
const uid = (n: number) => `${String(n).padStart(8, "0")}-0000-4000-8000-000000000001`;
const T1 = uid(1), T2 = uid(2);
it("cross-tenant row whose jobId IS assigned is not delivered", () => {
  const d = evaluateSyncDownloadV1({ version: "sync-download-facts.v1", environment: "synthetic_demo",
    request: { version: "sync-subscription-request.v1", requestedTenantId: T1, profile: "contractor_assigned_jobs.v1" },
    authority: { userId: uid(10), tenantId: T1, membershipId: uid(11), role: "operative", status: "active", assignedJobIds: [uid(1001)] },
    source: [{ tenantId: T2, jobId: uid(1001), workOrderId: uid(5001), reference: "T2-LEAK", priority: "routine", issuedOn: "2026-10-01", dueOn: null, openVisitId: null }] });
  expect(d.rows).toEqual([]);
});
