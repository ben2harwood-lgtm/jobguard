import { expect, it } from "vitest";
import { evaluateSyncDownloadV1, pageSyncDownloadV1, planSyncReconcileV1, deriveSyncTokenClaimsV1 } from "../../packages/core/src/sync-download.js";
const uid = (n: number) => `${String(n).padStart(8, "0")}-0000-4000-8000-000000000001`;
const T1 = uid(1), T2 = uid(2);
const job = (n: number, tenantId = T1, extra: Record<string, unknown> = {}) => ({ tenantId, jobId: uid(1000 + n), workOrderId: uid(5000 + n), reference: `WO-${n}`, priority: "routine", issuedOn: "2026-10-01", dueOn: null, openVisitId: null, ...extra });
const authority = (o: Record<string, unknown> = {}) => ({ userId: uid(10), tenantId: T1, membershipId: uid(11), role: "operative", status: "active", assignedJobIds: [uid(1001), uid(1002)], ...o });
const request = (o: Record<string, unknown> = {}) => ({ version: "sync-subscription-request.v1", requestedTenantId: T1, profile: "contractor_assigned_jobs.v1", ...o });
const facts = (o: Record<string, unknown> = {}) => ({ version: "sync-download-facts.v1", environment: "synthetic_demo", request: request(), authority: authority(), source: [job(1), job(2), job(3)], ...o });
const bad = { priority: "banana" };
it("admittedJobIds never exceeds authority ∩ tenant ∩ narrow", () => {
  const cases = [
    facts({ source: [job(1, T1, bad), job(2, T2, bad), job(3, T1, bad), job(1, T2), job(2)] }), // T2 row with assigned id, unassigned T1 id
    facts({ request: request({ jobIds: [uid(1002)] }), source: [job(1, T1, bad), job(2, T1, bad)] }),
    facts({ source: [job(1), job(1), job(2, T2, bad), job(9, T1, bad)] }),
    facts({ authority: authority({ assignedJobIds: [] }), source: [job(1, T1, bad)] }),
  ];
  for (const f of cases) {
    const d = evaluateSyncDownloadV1(f);
    const a = (f.authority as any).assignedJobIds as string[]; const n = (f.request as any).jobIds as string[] | undefined;
    for (const id of d.admittedJobIds) { expect(a).toContain(id); if (n) expect(n).toContain(id); }
    console.log("case", d.outcome, d.reason, d.cleanup, JSON.stringify(d.admittedJobIds), JSON.stringify(d).includes("WO-") ? "CONTENT" : "no-content");
  }
  // authority refusals carry no admitted ids even if source is malformed
  for (const a of [authority({ status: "revoked" }), authority({ tenantId: T2 }), null, undefined, "x", authority({ role: "viewer" })]) {
    const d = evaluateSyncDownloadV1(facts({ authority: a, source: [job(1, T1, bad), job(1)] }));
    expect(d.admittedJobIds).toEqual([]); expect(d.reason).toBe("authority_required");
  }
});
it("malformed authority really tombstones", () => {
  for (const a of [undefined, null, "revoked", 7, [], {}, { status: "active" }, authority({ assignedJobIds: ["legacy"] }), authority({ extra: 1 }), authority({ userId: "x" })]) {
    const f: any = facts({ authority: a }); if (a === undefined) delete f.authority;
    const p = planSyncReconcileV1({ version: "sync-reconcile.v1", delivered: [uid(1001), uid(1002)], decision: evaluateSyncDownloadV1(f) });
    expect(p.outcome).toBe("cleanup_required"); expect(p.keep).toEqual([]); expect(p.tombstones).toHaveLength(2);
  }
  // pages too
  const pg = pageSyncDownloadV1({ facts: facts({ authority: {} }), afterJobId: null, pageSize: 1 });
  console.log("page malformed authority", pg.reason, pg.cleanup, JSON.stringify(pg.admittedJobIds));
});
it("ordering: authority loss hidden behind request/source/envelope errors", () => {
  const revoked = authority({ status: "revoked" });
  const probes: Record<string, unknown> = {
    "revoked + bad profile": facts({ authority: revoked, request: request({ profile: "old.v0" }) }),
    "revoked + garbage source row (non-uuid jobId)": facts({ authority: revoked, source: [{ tenantId: T1, jobId: "x" }] }),
    "revoked + extra envelope key": { ...facts({ authority: revoked }), extra: 1 },
  };
  for (const [k, f] of Object.entries(probes)) {
    const d = evaluateSyncDownloadV1(f);
    const p = planSyncReconcileV1({ version: "sync-reconcile.v1", delivered: [uid(1001)], decision: d });
    console.log(k, "->", d.reason, d.cleanup, "reconcile", p.outcome);
  }
});
it("forged decisions at reconcile", () => {
  const ok = evaluateSyncDownloadV1(facts());
  const forged = [
    { ...ok, admittedJobIds: [...ok.admittedJobIds, uid(1003)] },
    { ...ok, admittedJobIds: [uid(1001), uid(1001)] , rows: [ok.rows[0], ok.rows[0]] },
    { version: "sync-download-decision.v1", environment: "synthetic_demo", outcome: "refused", reason: "source_invalid", rows: [], admittedJobIds: [uid(1003)], cleanup: "required" },
  ];
  for (const d of forged) { try { const p = planSyncReconcileV1({ version: "sync-reconcile.v1", delivered: [uid(1003)], decision: d }); console.log("forged accepted", p.outcome, JSON.stringify(p.keep)); } catch { console.log("forged refused"); } }
});
it("seconds sanity", () => {
  const input = { version: "sync-token-input.v1", environment: "synthetic_demo", facts: facts(), generation: 0, issuedAtSeconds: Date.now(), expiresAtSeconds: Date.now() + 3600_000, audience: "a" };
  console.log("ms values in seconds fields accepted:", deriveSyncTokenClaimsV1(input).exp);
});
it("dup across pages and source_invalid timing/shape", () => {
  const p = pageSyncDownloadV1({ facts: facts({ source: [job(1), job(2), job(2)] }), afterJobId: uid(1001), pageSize: 1 });
  console.log("dup page", p.outcome, p.reason, JSON.stringify(p.admittedJobIds), p.nextAfterJobId);
});
