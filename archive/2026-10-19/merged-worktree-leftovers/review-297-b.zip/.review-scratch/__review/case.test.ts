import { it } from "vitest";
import { evaluateSyncDownloadV1, planSyncReconcileV1 } from "../../packages/core/src/sync-download.js";
const T1 = "0000000a-0000-4000-8000-000000000001", J = "0000abcd-0000-4000-8000-000000000001";
const row = (tenantId: string, jobId: string) => ({ tenantId, jobId, workOrderId: J, reference: "R", priority: "routine", issuedOn: "2026-10-01", dueOn: null, openVisitId: null });
const f = (a: Record<string, unknown>, src: unknown[], req = T1) => ({ version: "sync-download-facts.v1", environment: "synthetic_demo", request: { version: "sync-subscription-request.v1", requestedTenantId: req, profile: "contractor_assigned_jobs.v1" }, authority: { userId: J, tenantId: T1, membershipId: J, role: "operative", status: "active", assignedJobIds: [J], ...a }, source: src });
it("case", () => {
  console.log("assigned UPPER, source lower:", evaluateSyncDownloadV1(f({ assignedJobIds: [J.toUpperCase()] }, [row(T1, J)])).rows.length);
  console.log("source tenant UPPER:", evaluateSyncDownloadV1(f({}, [row(T1.toUpperCase(), J)])).rows.length);
  console.log("all UPPER tenant:", evaluateSyncDownloadV1(f({ tenantId: T1.toUpperCase() }, [row(T1, J)], T1.toUpperCase())).rows.length);
  const d = evaluateSyncDownloadV1(f({}, [row(T1, J)]));
  console.log("delivered UPPER vs decision lower ->", JSON.stringify(planSyncReconcileV1({ version: "sync-reconcile.v1", delivered: [J.toUpperCase()], decision: d })));
});
