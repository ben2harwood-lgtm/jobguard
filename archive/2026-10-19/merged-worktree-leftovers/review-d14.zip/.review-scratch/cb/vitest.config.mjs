export default { test: { include: ["**/*.test.ts"], exclude:["**/node_modules/**"] } };
