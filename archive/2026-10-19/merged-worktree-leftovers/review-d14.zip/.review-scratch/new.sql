CREATE OR REPLACE FUNCTION app.ent4b_origin_provenance() RETURNS trigger LANGUAGE plpgsql SET search_path=pg_catalog AS $$
DECLARE command app.command_receipt; grant_row app.role_grant; team_row app.team; branch_row app.org_unit;
 v app.variation; values_to_hash text[]; value_text text; encoded text:='extra-origin-hash.v1'||chr(10);
BEGIN
 IF NEW.job_track<>'contractor' THEN RETURN NEW; END IF;
 IF NOT EXISTS(SELECT 1 FROM app.job WHERE (tenant_id,id)=(NEW.tenant_id,NEW.job_id) AND provenance='work_order') THEN
  IF num_nonnulls(NEW.command_type,NEW.raising_grant_id,NEW.raiser_assigned,NEW.work_order_id,NEW.work_order_revision_id,NEW.site_visit_id,NEW.evidence_id,NEW.resident_confirmation_evidence_id,NEW.client_capture_id,NEW.origin_hash)<>0 THEN
   RAISE EXCEPTION 'INVALID_ORIGIN' USING ERRCODE='23514';
  END IF;
  RETURN NEW;
 END IF;
 IF NEW.kind='jobguard_surfaced_confirmed' THEN
  IF current_user<>'jobguard_migration' THEN RAISE EXCEPTION 'PROMPT_ORIGIN_HELD' USING ERRCODE='23514'; END IF;
  IF NOT EXISTS(SELECT 1 FROM app.prompt_resolution r JOIN app.extra_prompt p ON(p.tenant_id,p.job_id,p.id)=(r.tenant_id,r.job_id,r.prompt_id)
   JOIN app.command_receipt c ON(c.tenant_id,c.command_id)=(r.tenant_id,r.command_id)
   WHERE (r.tenant_id,r.job_id,r.variation_id,r.command_id,r.actor_membership_id)=(NEW.tenant_id,NEW.job_id,NEW.variation_id,NEW.command_id,NEW.raising_membership_id)
   AND r.kind='created' AND r.prompt_hash=p.prompt_hash AND p.surfaced_at<NEW.server_recorded_at AND c.command_type='ConfirmPrompt' AND c.status='processing'
   AND NEW.raising_role IN('supervisor','surveyor','commercial_manager') AND app.lp_citations_valid(NEW.job_id,p.id))
  THEN RAISE EXCEPTION 'PROMPT_ORIGIN_HELD' USING ERRCODE='23514'; END IF;
 END IF;
 SELECT * INTO command FROM app.command_receipt WHERE (tenant_id,command_id)=(NEW.tenant_id,NEW.command_id);
 NEW.command_type:=command.command_type;
 SELECT w.id,c.revision_id INTO NEW.work_order_id,NEW.work_order_revision_id FROM app.work_order w
 JOIN app.work_order_current c ON(c.tenant_id,c.work_order_id)=(w.tenant_id,w.id) WHERE (w.tenant_id,w.job_id)=(NEW.tenant_id,NEW.job_id);
 IF NEW.work_order_id IS NULL OR NEW.work_order_revision_id IS NULL OR NOT app.contractor_member_active(NEW.raising_membership_id) THEN
  RAISE EXCEPTION 'INVALID_ORIGIN' USING ERRCODE='23514';
 END IF;
 SELECT * INTO grant_row FROM app.role_grant WHERE (tenant_id,id)=(NEW.tenant_id,NEW.raising_grant_id);
 SELECT * INTO team_row FROM app.team WHERE (tenant_id,id)=(NEW.tenant_id,app.contractor_job_team(NEW.job_id));
 SELECT * INTO branch_row FROM app.org_unit WHERE (tenant_id,id)=(NEW.tenant_id,team_row.branch_id);
 IF grant_row.id IS NULL OR grant_row.membership_id IS DISTINCT FROM NEW.raising_membership_id OR grant_row.role IS DISTINCT FROM NEW.raising_role
  OR EXISTS(SELECT 1 FROM app.role_grant_revocation WHERE (tenant_id,grant_id)=(NEW.tenant_id,grant_row.id))
  OR team_row.id IS NULL OR branch_row.id IS NULL
  OR NOT coalesce((grant_row.scope_kind='tenant' AND grant_row.scope_id=NEW.tenant_id)
    OR (grant_row.scope_kind='team' AND grant_row.scope_id=team_row.id)
    OR (grant_row.scope_kind='branch' AND grant_row.scope_id=branch_row.id)
    OR (grant_row.scope_kind='region' AND grant_row.scope_id=branch_row.parent_id),false) THEN
  RAISE EXCEPTION 'INVALID_ORIGIN' USING ERRCODE='23514';
 END IF;
 NEW.raiser_assigned:=app.contractor_job_assigned(NEW.raising_membership_id,NEW.job_id);
 IF NEW.site_visit_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM app.site_visit WHERE (tenant_id,id,job_id,membership_id)=(NEW.tenant_id,NEW.site_visit_id,NEW.job_id,NEW.raising_membership_id)) THEN
  RAISE EXCEPTION 'INVALID_ORIGIN' USING ERRCODE='23503';
 END IF;
 SELECT sha256 INTO NEW.evidence_hash FROM app.evidence_object WHERE (tenant_id,job_id,id)=(NEW.tenant_id,NEW.job_id,NEW.evidence_id);
 IF NEW.resident_confirmation_evidence_id IS NOT NULL AND EXISTS(SELECT 1 FROM app.evidence_object WHERE (tenant_id,job_id,id)=(NEW.tenant_id,NEW.job_id,NEW.resident_confirmation_evidence_id) AND evidence_type<>'resident_confirmation') THEN RAISE EXCEPTION 'INVALID_ORIGIN' USING ERRCODE='23514'; END IF;
 SELECT * INTO v FROM app.variation WHERE (tenant_id,job_id,id)=(NEW.tenant_id,NEW.job_id,NEW.variation_id);
 IF v.excess_of_revision_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM app.work_order_line WHERE (tenant_id,job_id,revision_id,scope_item_id)=(NEW.tenant_id,NEW.job_id,v.excess_of_revision_id,v.excess_of_scope_item_id)) THEN
  RAISE EXCEPTION 'INVALID_ORIGIN' USING ERRCODE='23503';
 END IF;
 -- Boolean spelling and microsecond timestamps are independent of session timezone/DateStyle.
 values_to_hash:=ARRAY[NEW.tenant_id::text,NEW.job_id::text,NEW.variation_id::text,NEW.job_track,NEW.kind,NEW.provenance,NEW.command_id::text,NEW.command_type,
  NEW.raising_membership_id::text,NEW.raising_role,NEW.raising_grant_id::text,CASE WHEN NEW.raiser_assigned THEN 'true' ELSE 'false' END,
  to_char(NEW.server_recorded_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),NEW.device_id,
  to_char(NEW.device_captured_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),NEW.client_capture_id::text,NEW.work_order_id::text,NEW.work_order_revision_id::text,
  NEW.site_visit_id::text,NEW.evidence_id::text,NEW.evidence_hash,NEW.resident_confirmation_evidence_id::text,NEW.source_capture_kind,NEW.source_capture_hash];
 FOREACH value_text IN ARRAY values_to_hash LOOP
  encoded:=encoded||CASE WHEN value_text IS NULL THEN 'N;' ELSE 'S'||octet_length(convert_to(value_text,'UTF8'))::text||':'||value_text||';' END;
 END LOOP;
 NEW.origin_hash:=encode(sha256(convert_to(encoded,'UTF8')),'hex');
 RETURN NEW;
END $$;
