CREATE FUNCTION app.issue_practice_session(digest text) RETURNS void LANGUAGE plpgsql SECURITY DEFINER
 SET search_path=pg_catalog AS $$ BEGIN
 IF digest !~ '^[0-9a-f]{64}$' OR NOT EXISTS(
  SELECT 1 FROM app.membership m WHERE m.tenant_id='11111111-1111-4111-8111-111111111111'::uuid
   AND m.id='d1500000-0000-4000-8000-000000000003'::uuid AND m.identity_user_id='d1500000-0000-4000-8000-000000000001'::uuid
   AND m.role='owner' AND m.revoked_at IS NULL AND(m.expires_at IS NULL OR m.expires_at>clock_timestamp())
 ) THEN RAISE EXCEPTION 'UNAUTHENTICATED' USING ERRCODE='42501'; END IF;
 INSERT INTO control_plane.practice_session(token_digest) VALUES(digest);
 PERFORM set_config('app.tenant_id','11111111-1111-4111-8111-111111111111',true);
 -- New generated home scenarios, never a claim on the shared/legacy fixtures.
 INSERT INTO app.job(id,tenant_id,title,status,practice_session_digest,practice_scenario) VALUES
 (gen_random_uuid(),'11111111-1111-4111-8111-111111111111','Practice kitchen','quoting',digest,'home'),
 (gen_random_uuid(),'11111111-1111-4111-8111-111111111111','Kitchen extension','live',digest,'home'),
 (gen_random_uuid(),'11111111-1111-4111-8111-111111111111','Loft conversion','quoting',digest,'home');
END $$;
