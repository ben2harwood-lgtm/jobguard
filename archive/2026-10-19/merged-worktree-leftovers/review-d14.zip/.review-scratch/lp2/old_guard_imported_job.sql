CREATE FUNCTION app.guard_imported_job() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NEW.provenance='imported' AND current_setting('app.import_command',true)<>'enabled' THEN
   RAISE EXCEPTION 'imported jobs require authorized import command' USING ERRCODE='42501';
 END IF;
 RETURN NEW;
END $$;
