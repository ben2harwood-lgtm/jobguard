import sys,re
f,name,occ=sys.argv[1],sys.argv[2],sys.argv[3] if len(sys.argv)>3 else 'last'
t=open(f).read()
starts=[m.start() for m in re.finditer(r'CREATE (OR REPLACE )?FUNCTION app\.'+name+r'\(',t)]
s=starts[-1] if occ=='last' else starts[int(occ)]
# find end: closing $$ ; after body
m=re.search(r'\$\$',t[s:]); b=s+m.end()
e=t.find('$$',b)
end=t.find(';',e)
print(t[s:end+1])
