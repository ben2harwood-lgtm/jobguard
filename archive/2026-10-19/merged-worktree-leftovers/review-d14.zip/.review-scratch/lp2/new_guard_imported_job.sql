CREATE OR REPLACE FUNCTION app.guard_imported_job() RETURNS trigger
 LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE expected_operation text;
BEGIN
 expected_operation:=CASE NEW.provenance WHEN 'imported' THEN 'adoption' WHEN 'work_order' THEN 'work_order'
  ELSE CASE NEW.practice_scenario WHEN 'home' THEN 'practice_home' WHEN 'core-1000' THEN 'practice_sandbox' END END;
 IF expected_operation IS NULL THEN RETURN NEW; END IF;
 IF NEW.tenant_id IS DISTINCT FROM nullif(current_setting('app.tenant_id',true),'')::uuid
 THEN RAISE EXCEPTION 'JOB_INSERT_PERMIT_REQUIRED' USING ERRCODE='42501'; END IF;
 DELETE FROM app.lp_job_insert_permit p WHERE
  (p.backend_pid,p.transaction_id,p.tenant_id,p.job_id)=(pg_backend_pid(),pg_current_xact_id(),NEW.tenant_id,NEW.id)
  AND p.operation=expected_operation AND p.insert_shape=app.lp_job_insert_shape(NEW);
 IF NOT FOUND THEN RAISE EXCEPTION 'JOB_INSERT_PERMIT_REQUIRED' USING ERRCODE='42501'; END IF;
 RETURN NEW;
END $$;
