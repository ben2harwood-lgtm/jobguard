CREATE OR REPLACE FUNCTION app.issue_practice_session(digest text) RETURNS void LANGUAGE plpgsql SECURITY DEFINER
 SET search_path=pg_catalog AS $$
DECLARE j uuid; item record; t uuid:='11111111-1111-4111-8111-111111111111';
BEGIN
 IF current_database() IS DISTINCT FROM 'jobguard_synthetic_demo' THEN RAISE EXCEPTION 'MODE_FORBIDDEN' USING ERRCODE='42501'; END IF;
 IF digest IS NULL OR digest !~ '^[0-9a-f]{64}$' OR NOT EXISTS(
  SELECT 1 FROM app.membership m WHERE m.tenant_id='11111111-1111-4111-8111-111111111111'::uuid
   AND m.id='d1500000-0000-4000-8000-000000000003'::uuid AND m.identity_user_id='d1500000-0000-4000-8000-000000000001'::uuid
   AND m.role='owner' AND m.revoked_at IS NULL AND(m.expires_at IS NULL OR m.expires_at>clock_timestamp())
 ) THEN RAISE EXCEPTION 'UNAUTHENTICATED' USING ERRCODE='42501'; END IF;
 INSERT INTO control_plane.practice_session(token_digest) VALUES(digest);
 PERFORM set_config('app.tenant_id','11111111-1111-4111-8111-111111111111',true);
 FOR item IN SELECT * FROM (VALUES('Practice kitchen','quoting'),('Kitchen extension','live'),('Loft conversion','quoting')) AS recipe(title,status) LOOP
  j:=gen_random_uuid();
  INSERT INTO app.lp_job_insert_permit(tenant_id,job_id,backend_pid,transaction_id,operation,insert_shape,actor_membership_id)
  VALUES(t,j,pg_backend_pid(),pg_current_xact_id(),'practice_home',
   app.lp_job_insert_shape(jsonb_populate_record(NULL::app.job,jsonb_build_object('tenant_id',t,'id',j,'title',item.title,
    'status',item.status,'revision',0,'provenance','system_generated_quote','practice_session_digest',digest,'practice_scenario','home'))),
   'd1500000-0000-4000-8000-000000000003');
  INSERT INTO app.job(id,tenant_id,title,status,practice_session_digest,practice_scenario) VALUES(j,t,item.title,item.status,digest,'home');
 END LOOP;
END $$;
