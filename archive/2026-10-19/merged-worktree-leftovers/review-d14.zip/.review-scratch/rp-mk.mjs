import fs from "node:fs";
const o=fs.readFileSync("rp-orig/readiness.contracts.ts","utf8");
const R=(a,b)=>{ if(!o.includes(a)) throw new Error("missing "+a); return o.replace(a,b); };
const B="resolved:z.boolean().optional()";
const m={
 coerce:R(B,"resolved:z.coerce.boolean().optional()"),
 default:R(B,"resolved:z.boolean().default(false)"),
 prepbool:R(B,'resolved:z.preprocess(v=>v==="true"?true:v==="false"?false:v,z.boolean().optional())'),
 nullable:R(B,"resolved:z.boolean().nullable().optional()"),
 lowercase:R("commandId:z.string().uuid(),scenarioNow:z.string().datetime(),resolved","commandId:z.string().uuid().toLowerCase(),scenarioNow:z.string().datetime(),resolved"),
 tsnorm:R("scenarioNow:z.string().datetime(),resolved","scenarioNow:z.string().datetime().transform(s=>new Date(s).toISOString()),resolved"),
 advnorm:R("scenarioNow:z.string().datetime()})","scenarioNow:z.string().datetime().transform(s=>new Date(s).toISOString())})"),
 undef:R(B+"}).strict()",B+"}).strict().transform(o=>({...o,resolved:o.resolved}))"),
 mutate:R(B+"}).strict()",B+"}).strict().transform((o,ctx)=>o)").replace("export const readinessPlanV1=","const _p=")+"\nexport const readinessPlanV1={parse:(i:any)=>{const r=_p.parse(i);delete i.resolved;return r},safeParse:(i:any)=>{const r=_p.safeParse(i);if(r.success)delete i.resolved;return r}} as any;",
 advlower:R('commandId:z.string().uuid(),scenarioNow:z.string().datetime()})','commandId:z.string().uuid().toLowerCase(),scenarioNow:z.string().datetime()})'),
};
for(const [k,v] of Object.entries(m)){fs.writeFileSync(`rp-${k}/readiness.contracts.ts`.replace(/^/,""),v);}
