const m = await import(process.argv[2]);
const old = /(?:from\s+["'](?:pg|postgres|@aws-sdk\/|stripe|@anthropic-ai\/)|\bfetch\s*\()/;
const cases = [
 'import * as undici from "undici"; undici.fetch("https://example.invalid");',
 'const f = globalThis; f.fetch("x");',
 'client.fetch ("x");',
 'globalThis["fetch"]("x");',
 'fetch?.("x");',
 'export { Pool } from "pg";',
 'import type { Pool } from "pg";',
 'const fs = await import(`node:${"fs"}`);',
 '(0, fetch)("x");',
 'const { fetch: f } = globalThis; f("x");',
];
for (const c of cases) console.log(JSON.stringify(c), "old:", old.test(c), "new:", m.checkCorePuritySource("x.ts", c, {computed:"report"}).length>0);
