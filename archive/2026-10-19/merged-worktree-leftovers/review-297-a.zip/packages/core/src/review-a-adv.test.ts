import { describe, expect, it } from "vitest";
import { deriveSyncTokenClaimsV1, evaluateSyncDownloadV1, pageSyncDownloadV1, planSyncReconcileV1 } from "./sync-download.js";
const uid = (n: number) => `${String(n).padStart(8, "0")}-0000-4000-8000-000000000001`;
const T1 = uid(1), T2 = uid(2), USER = uid(10), MEMBER = uid(11);
const J = (n: number) => uid(1000 + n);
const job = (n: number, tenantId = T1, extra: Record<string, unknown> = {}) => ({ tenantId, jobId: J(n), workOrderId: uid(5000 + n), reference: `WO-${n}`, priority: "routine", issuedOn: "2026-10-01", dueOn: null, openVisitId: null, ...extra });
const authority = (o: Record<string, unknown> = {}) => ({ userId: USER, tenantId: T1, membershipId: MEMBER, role: "operative", status: "active", assignedJobIds: [J(1), J(2)], ...o });
const request = (o: Record<string, unknown> = {}) => ({ version: "sync-subscription-request.v1", requestedTenantId: T1, profile: "contractor_assigned_jobs.v1", ...o });
const facts = (o: Record<string, unknown> = {}) => ({ version: "sync-download-facts.v1", environment: "synthetic_demo", request: request(), authority: authority(), source: [job(1), job(2), job(3)], ...o });
const base = evaluateSyncDownloadV1(facts({ authority: null }));

describe("review-a adversarial", () => {
 it("A1 cross-tenant row whose jobId IS assigned is never delivered (the real S03 case)", () => {
  const d = evaluateSyncDownloadV1(facts({ authority: authority({ assignedJobIds: [J(1)] }), source: [job(1, T2, { residentName: "CANARY" })] }));
  expect(d.rows).toEqual([]);
  const mixed = evaluateSyncDownloadV1(facts({ authority: authority({ assignedJobIds: [J(1)] }), source: [job(1, T2, { reference: "T2-REF" }), job(1)] }));
  expect(mixed.rows.map(r => r.reference)).toEqual(["WO-1"]);
 });
 it("A2 job-id selector cannot widen: unassigned, other-tenant, case variants, empty list", () => {
  expect(evaluateSyncDownloadV1(facts({ request: request({ jobIds: [J(3)] }) })).rows).toEqual([]);
  expect(evaluateSyncDownloadV1(facts({ request: request({ jobIds: [] }) })).rows).toEqual([]);
  const HX = "aaaaaaaa-0000-4000-8000-00000000000b";
  const fx = facts({ authority: authority({ assignedJobIds: [HX] }), source: [job(1, T1, { jobId: HX })] });
  expect(evaluateSyncDownloadV1(fx).rows).toHaveLength(1);
  expect(evaluateSyncDownloadV1({ ...fx, request: request({ jobIds: [HX.toUpperCase()] }) }).rows).toEqual([]);
  expect(evaluateSyncDownloadV1({ ...fx, source: [job(1, T1, { jobId: HX.toUpperCase() })] }).rows).toEqual([]);
  expect(evaluateSyncDownloadV1(facts({ request: request({ jobIds: "*" }) })).outcome).toBe("refused");
  expect(evaluateSyncDownloadV1(facts({ request: request({ jobIds: [J(1)], tenantIds: [T2] }) })).outcome).toBe("refused");
 });
 it("A3 nested / aliased / prototype fields never leak", () => {
  const evil = [
   job(1, T1, { reference: { residentName: "CANARY" } }),
  ];
  const d1 = evaluateSyncDownloadV1(facts({ source: evil }));
  expect(d1).toMatchObject({ outcome: "refused", reason: "source_invalid", rows: [] });
  expect(JSON.stringify(d1)).not.toContain("CANARY");
  const raw = JSON.parse(`{"tenantId":"${T1}","jobId":"${J(1)}","workOrderId":"${uid(5001)}","reference":"WO-1","priority":"routine","issuedOn":"2026-10-01","dueOn":null,"openVisitId":null,"__proto__":{"address":"CANARY"},"JobId":"x","job_id":"y","resident":{"name":"CANARY"},"bank":{"sort":"CANARY"},"token":"CANARY","price":"CANARY"}`);
  const d2 = evaluateSyncDownloadV1(facts({ source: [raw] }));
  expect(d2.outcome).toBe("allowed");
  expect(JSON.stringify(d2)).not.toContain("CANARY");
  for (const r of d2.rows) expect(Object.keys(r).sort()).toEqual(["dueOn", "issuedOn", "jobId", "openVisitId", "priority", "reference", "workOrderId"]);
  const d3 = evaluateSyncDownloadV1(facts({ source: [job(1, T1, { dueOn: { address: "CANARY" } })] }));
  expect(d3.reason).toBe("source_invalid");
 });
 it("A4 every authority failure is byte-identical, including roles by case and odd statuses", () => {
  const variants = [
   authority({ status: "Active" }), authority({ status: "active " }), authority({ role: "Operative" }), authority({ role: "owner" }),
   authority({ role: "admin" }), authority({ role: "contractor_admin" }), authority({ tenantId: T2 }), null,
  ];
  for (const a of variants) expect(JSON.stringify(evaluateSyncDownloadV1(facts({ authority: a })))).toBe(JSON.stringify(base));
  expect(JSON.stringify(evaluateSyncDownloadV1(facts({ request: request({ requestedTenantId: T2 }) })))).toBe(JSON.stringify(base));
  // Unknown tenant vs other existing tenant: identical
  expect(evaluateSyncDownloadV1(facts({ request: request({ requestedTenantId: uid(777) }) }))).toEqual(base);
  // refusal does not depend on whether the request selector names real jobs
  expect(evaluateSyncDownloadV1(facts({ authority: null, request: request({ jobIds: [J(1)] }) }))).toEqual(base);
  expect(evaluateSyncDownloadV1(facts({ authority: null, request: request({ jobIds: [uid(424242)] }) }))).toEqual(base);
  // unauthorized caller with malformed source rows elsewhere: does authority refusal depend on other tenants' data?
  expect(evaluateSyncDownloadV1(facts({ authority: authority({ tenantId: T2 }), source: [job(1, T1, { priority: "banana" })] }))).toEqual(base);
 });
 it("A5 paging: authority lost mid-way refuses; tenant switch mid-way refuses; cursor from elsewhere yields nothing extra", () => {
  const ids = Array.from({ length: 250 }, (_, i) => i + 1);
  const f = facts({ authority: authority({ assignedJobIds: ids.map(J) }), source: ids.map(n => job(n)) });
  const p1 = pageSyncDownloadV1({ facts: f, afterJobId: null, pageSize: 100 });
  for (const a of [authority({ status: "revoked", assignedJobIds: ids.map(J) }), authority({ tenantId: T2, assignedJobIds: ids.map(J) }), null, authority({ role: "viewer", assignedJobIds: ids.map(J) })]) {
   const p = pageSyncDownloadV1({ facts: { ...f, authority: a }, afterJobId: p1.nextAfterJobId, pageSize: 100 });
   expect(JSON.stringify(p)).toBe(JSON.stringify({ ...base, nextAfterJobId: null }));
  }
  // assignment shrinks mid-way: later pages only contain still-assigned
  const shrunk = pageSyncDownloadV1({ facts: { ...f, authority: authority({ assignedJobIds: [J(250)] }) }, afterJobId: p1.nextAfterJobId, pageSize: 100 });
  expect(shrunk.rows.map(r => r.jobId)).toEqual([J(250)]);
  // a cursor that is not in the set (e.g. other tenant id) still pages correctly, never widens
  const odd = pageSyncDownloadV1({ facts: f, afterJobId: uid(0), pageSize: 1000 });
  expect(odd.rows).toHaveLength(250);
  // last page exact boundary gives null cursor
  const exact = pageSyncDownloadV1({ facts: f, afterJobId: null, pageSize: 250 });
  expect(exact.nextAfterJobId).toBeNull();
 });
 it("A6 paging with duplicate source rows for one job: observe", () => {
  const f = facts({ source: [job(1), job(1, T1, { reference: "DUP" }), job(2)] });
  const all = evaluateSyncDownloadV1(f).rows.map(r => r.jobId);
  const p1 = pageSyncDownloadV1({ facts: f, afterJobId: null, pageSize: 1 });
  const p2 = pageSyncDownloadV1({ facts: f, afterJobId: p1.nextAfterJobId, pageSize: 1 });
  console.log("A6 full", all.length, "paged", [...p1.rows, ...p2.rows].map(r => r.reference));
  expect(evaluateSyncDownloadV1(f)).toMatchObject({ outcome: "refused", reason: "source_invalid", rows: [], cleanup: "required" });
  expect(p1.rows).toEqual([]); expect(p2.rows).toEqual([]);
 });
 it("A7 reconcile: tombstones ids only; inconsistent decisions; hold on source_invalid", () => {
  const delivered = [J(1), J(2), J(3)];
  const allowed = evaluateSyncDownloadV1(facts({ authority: authority({ assignedJobIds: [J(2)] }) }));
  const p = planSyncReconcileV1({ version: "sync-reconcile.v1", delivered, decision: allowed });
  for (const t of p.tombstones) expect(Object.keys(t)).toEqual(["jobId"]);
  // assignment removed for J1 AND another permitted row malformed: what happens?
  const invalid = evaluateSyncDownloadV1(facts({ authority: authority({ assignedJobIds: [J(2)] }), source: [job(1), job(2, T1, { priority: "banana" })] }));
  const h = planSyncReconcileV1({ version: "sync-reconcile.v1", delivered: [J(1), J(2)], decision: invalid });
  console.log("A7 source_invalid plan", JSON.stringify(h));
  expect(h).toMatchObject({ outcome: "cleanup_required", tombstones: [{ jobId: J(1) }], keep: [J(2)] });
  // source_invalid never admits a cross-tenant or unassigned id
  const x = evaluateSyncDownloadV1(facts({ authority: authority({ assignedJobIds: [J(2)] }), source: [job(1, T2), job(3), job(2, T1, { priority: "banana" })] }));
  expect(x.admittedJobIds).toEqual([J(2)]);
  // narrowed selector + bad row: admitted ids are the narrowed set (observe over-cleanup)
  const n = evaluateSyncDownloadV1(facts({ request: request({ jobIds: [J(2)] }), source: [job(1), job(2, T1, { priority: "banana" })] }));
  console.log("A7 narrow+invalid admitted", JSON.stringify(n.admittedJobIds), JSON.stringify(planSyncReconcileV1({ version: "sync-reconcile.v1", delivered: [J(1), J(2)], decision: n }).tombstones));
  // forged source_invalid admitting extra ids is accepted (provenance not checkable in a pure plan)
  let fr: unknown; try { fr = planSyncReconcileV1({ version: "sync-reconcile.v1", delivered, decision: { ...x, admittedJobIds: delivered } }).keep; } catch (e) { fr = String(e); }
  console.log("A7 forged source_invalid admits all", JSON.stringify(fr));
  // forged allowed with duplicated admitted id
  try { fr = planSyncReconcileV1({ version: "sync-reconcile.v1", delivered, decision: { ...allowed, admittedJobIds: [J(2), J(2)], rows: [allowed.rows[0], allowed.rows[0]] } }).keep; } catch (e) { fr = String(e); }
  console.log("A7 forged allowed dup", JSON.stringify(fr));
  // hand-crafted inconsistent decision accepted?
  const forged = { ...base, cleanup: "none" };
  let r: unknown; try { r = planSyncReconcileV1({ version: "sync-reconcile.v1", delivered, decision: forged }); } catch (e) { r = String(e); }
  console.log("A7 forged refused/authority_required/cleanup none", JSON.stringify(r));
  expect(String(r)).toContain("SyncDownloadContractError");
  const forged2 = { ...allowed, outcome: "refused", reason: null, cleanup: "none" };
  try { r = planSyncReconcileV1({ version: "sync-reconcile.v1", delivered, decision: forged2 }); } catch (e) { r = String(e); }
  console.log("A7 forged refused with rows", JSON.stringify(r));
  expect(String(r)).toContain("SyncDownloadContractError");
  // rebuild after purge: a stale/wider source cannot restore an unassigned id
  const rebuilt = evaluateSyncDownloadV1(facts({ authority: authority({ assignedJobIds: [J(2)] }), source: [job(1), job(1), job(2), job(3)] }));
  expect(rebuilt.rows.map(r => r.jobId)).toEqual([J(2)]);
 });
 it("A8 token claims: no default lifetime, no secrets; unbounded max lifetime observed", () => {
  const input = { version: "sync-token-input.v1", environment: "synthetic_demo", facts: facts(), generation: 0, issuedAtSeconds: 0, expiresAtSeconds: 1, audience: "a" };
  const c = deriveSyncTokenClaimsV1(input);
  expect(Object.keys(c).sort()).toEqual(["aud", "environment", "exp", "generation", "iat", "membershipId", "profile", "sub", "tenantId", "version"]);
  expect(() => deriveSyncTokenClaimsV1({ ...input, expiresAtSeconds: undefined })).toThrow();
  expect(() => deriveSyncTokenClaimsV1({ ...input, issuedAtSeconds: undefined })).toThrow();
  expect(() => deriveSyncTokenClaimsV1({ ...input, secret: "x" })).toThrow();
  expect(() => deriveSyncTokenClaimsV1({ ...input, role: "owner" })).toThrow();
  expect(() => deriveSyncTokenClaimsV1({ ...input, facts: facts({ authority: authority({ role: "owner" }) }) })).toThrow();
  const huge = deriveSyncTokenClaimsV1({ ...input, expiresAtSeconds: Number.MAX_SAFE_INTEGER });
  console.log("A8 max lifetime accepted exp=", huge.exp);
  let ms: unknown; try { ms = deriveSyncTokenClaimsV1({ ...input, issuedAtSeconds: 1_760_000_000_000, expiresAtSeconds: 1_760_000_003_600 }).exp; } catch (e) { ms = String(e); }
  console.log("A8 millisecond-magnitude values under seconds names", JSON.stringify(ms));
  expect(() => deriveSyncTokenClaimsV1({ ...input, facts: facts({ authority: undefined }) })).toThrow();
  expect(() => deriveSyncTokenClaimsV1({ ...input, facts: facts({ source: [job(1), job(1)] }) })).toThrow();
  // allowed with zero assigned rows still mints claims
  console.log("A8 zero-assigned claims", JSON.stringify(deriveSyncTokenClaimsV1({ ...input, facts: facts({ authority: authority({ assignedJobIds: [] }) }) }).sub));
 });
});
