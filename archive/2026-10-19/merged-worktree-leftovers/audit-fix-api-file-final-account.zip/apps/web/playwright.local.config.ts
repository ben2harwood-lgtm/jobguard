// UNCOMMITTED local helper: only points Playwright at an installed headless shell because the pinned browser (chromium_headless_shell-1193) is not installed on this Mac.
import { defineConfig } from "@playwright/test";
import base from "./playwright.config";
export default defineConfig({
  ...base,
  use: { ...base.use, launchOptions: { executablePath: "/Users/benharwood/Library/Caches/ms-playwright/chromium_headless_shell-1234/chrome-headless-shell-mac-arm64/chrome-headless-shell" } },
});
